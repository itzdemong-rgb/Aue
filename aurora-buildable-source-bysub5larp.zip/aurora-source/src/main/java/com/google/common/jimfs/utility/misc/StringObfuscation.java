package com.google.common.jimfs.utility.misc;

import com.google.common.jimfs.client.feature.module.property.Property;
import j2cc.Nativeify;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Base64;
import java.util.concurrent.ThreadLocalRandom;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
@Nativeify
public final class StringObfuscation {
   private StringObfuscation() {
   }

   public static StringObfuscation.E a(CharSequence var0) {
      if (var0 != null && !var0.isEmpty()) {
         int var1 = ThreadLocalRandom.current().nextInt(4096, 24096);
         char[] var2 = new char[var0.length()];

         for (int var3 = 0; var3 < var2.length; var3++) {
            var2[var3] = var0.charAt(var3);
         }

         StringObfuscation.E var4 = new StringObfuscation.E(var2, var1);
         Arrays.fill(var2, '\u0000');
         return var4;
      } else {
         return new StringObfuscation.E(new byte[0], 0);
      }
   }

   public static void wipeString(String var0) {
   }

   public static void wipeScratchState() {
   }

   public static StringObfuscation.E a(CharSequence var0, int var1) {
      char[] var2 = new char[var0.length()];

      for (int var3 = 0; var3 < var2.length; var3++) {
         var2[var3] = (char)(var0.charAt(var3) ^ var1);
      }

      int var5 = ThreadLocalRandom.current().nextInt(4096, 24096);
      StringObfuscation.E var4 = new StringObfuscation.E(var2, var5);
      Arrays.fill(var2, '\u0000');
      return var4;
   }

   static char[] decodeChars(byte[] var0, int var1) {
      if (var0 != null && var0.length != 0) {
         byte[] var2 = new byte[var0.length];
         System.arraycopy(var0, 0, var2, 0, var0.length);
         subtractMask(var2, var1);
         reverseBytes(var2);
         var2 = decodeBase64(var2);
         b(var2, var1);
         char[] var3 = new char[var2.length];
         int var4 = 0;
         int var5 = 0;

         while (var5 < var2.length) {
            int var6 = var2[var5] & 255;
            byte var7;
            int var8;
            if (var6 < 128) {
               var8 = var6;
               var7 = 1;
            } else if (var6 < 224) {
               var8 = (var6 & 31) << 6 | var2[var5 + 1] & 63;
               var7 = 2;
            } else if (var6 < 240) {
               var8 = (var6 & 15) << 12 | (var2[var5 + 1] & 63) << 6 | var2[var5 + 2] & 63;
               var7 = 3;
            } else {
               var8 = (var6 & 7) << 18 | (var2[var5 + 1] & 63) << 12 | (var2[var5 + 2] & 63) << 6 | var2[var5 + 3] & 63;
               var7 = 4;
            }

            if (var8 <= 65535) {
               var3[var4++] = (char)var8;
            } else {
               var3[var4++] = (char)((var8 - 65536 >> 10) + 55296);
               var3[var4++] = (char)((var8 - 65536 & 1023) + 56320);
            }

            var5 += var7;
         }

         Arrays.fill(var2, (byte)0);
         if (var4 < var3.length) {
            char[] var11 = new char[var4];
            System.arraycopy(var3, 0, var11, 0, var4);
            Arrays.fill(var3, '\u0000');
            return var11;
         } else {
            return var3;
         }
      } else {
         return new char[0];
      }
   }

   static byte[] a(char[] var0, int var1) {
      byte[] var2 = new byte[var0.length * 3];
      int var3 = 0;

      for (char var7 : var0) {
         if (var7 < 128) {
            var2[var3++] = (byte)var7;
         } else if (var7 < 2048) {
            var2[var3++] = (byte)(192 | var7 >> 6);
            var2[var3++] = (byte)(128 | var7 & '?');
         } else {
            var2[var3++] = (byte)(224 | var7 >> '\f');
            var2[var3++] = (byte)(128 | var7 >> 6 & 63);
            var2[var3++] = (byte)(128 | var7 & '?');
         }
      }

      byte[] var13 = new byte[var3];
      System.arraycopy(var2, 0, var13, 0, var3);
      Arrays.fill(var2, (byte)0);
      byte[] var14 = new byte[var13.length];
      System.arraycopy(var13, 0, var14, 0, var13.length);

      for (int var15 = 0; var15 < var14.length; var15++) {
         var14[var15] = (byte)(var14[var15] ^ var1 + var15 * 7 & 0xFF);
      }

      byte[] var16 = Base64.getEncoder().encode(var14);
      Arrays.fill(var14, (byte)0);
      Arrays.fill(var13, (byte)0);
      int var17 = 0;

      for (int var8 = var16.length - 1; var17 < var8; var8--) {
         byte var9 = var16[var17];
         var16[var17] = var16[var8];
         var16[var8] = var9;
         var17++;
      }

      for (int var18 = 0; var18 < var16.length; var18++) {
         var16[var18] = (byte)((var16[var18] & 255) + (var1 % 31 + var18 & 0xFF) & 0xFF);
      }

      return var16;
   }

   public static String d(String var0, int var1) {
      byte[] var2 = a(var0);
      subtractMask(var2, var1);
      reverseBytes(var2);
      var2 = decodeBase64(var2);
      b(var2, var1);
      String var3 = new String(var2, StandardCharsets.UTF_8);
      Arrays.fill(var2, (byte)0);
      return var3;
   }

   private static byte[] a(String var0) {
      int var1 = var0.length();
      byte[] var2 = new byte[var1 / 2];

      for (int var3 = 0; var3 < var1; var3 += 2) {
         var2[var3 / 2] = (byte)((Character.digit(var0.charAt(var3), 16) << 4) + Character.digit(var0.charAt(var3 + 1), 16));
      }

      return var2;
   }

   private static void subtractMask(byte[] var0, int var1) {
      for (int var2 = 0; var2 < var0.length; var2++) {
         var0[var2] = (byte)((var0[var2] & 255) - (var1 % 31 + var2 & 0xFF));
      }
   }

   private static void reverseBytes(byte[] var0) {
      int var1 = 0;

      for (int var2 = var0.length - 1; var1 < var2; var2--) {
         byte var3 = var0[var1];
         var0[var1] = var0[var2];
         var0[var2] = var3;
         var1++;
      }
   }

   private static byte[] decodeBase64(byte[] var0) {
      return Base64.getDecoder().decode(var0);
   }

   private static void b(byte[] var0, int var1) {
      for (int var2 = 0; var2 < var0.length; var2++) {
         var0[var2] = (byte)(var0[var2] ^ var1 + var2 * 7 & 0xFF);
      }
   }

   @Environment(EnvType.CLIENT)
   public static final class E implements CharSequence {
      private final byte[] encodedBytes;
      private final char[] decodedChars;
      private final int recoveredField149;
      private static boolean recoveredField190 = true;

      public E(byte[] var1, int var2) {
         this.encodedBytes = var1;
         this.recoveredField149 = var2;
         char[] var3 = StringObfuscation.decodeChars(var1, var2);
         this.decodedChars = new char[var3.length];

         for (int var4 = 0; var4 < var3.length; var4++) {
            this.decodedChars[var4] = (char)(var3[var4] ^ var2 + var4 * 7 & 65535);
         }

         Arrays.fill(var3, '\u0000');
      }

      public E(char[] var1, int var2) {
         this.recoveredField149 = var2;
         this.decodedChars = new char[var1.length];

         for (int var3 = 0; var3 < var1.length; var3++) {
            this.decodedChars[var3] = (char)(var1[var3] ^ var2 + var3 * 7 & 65535);
         }

         this.encodedBytes = StringObfuscation.a(var1, var2);
      }

      @Override
      public int length() {
         return this.decodedChars.length;
      }

      @Override
      public char charAt(int var1) {
         return (char)(this.decodedChars[var1] ^ this.recoveredField149 + var1 * 7 & 65535);
      }

      @Override
      public CharSequence subSequence(int var1, int var2) {
         int var4 = var2 - var1;
         char[] var5 = new char[var4];
         int var6 = 0;

         for (boolean var3 = false; var6 < var4; var6++) {
            var5[var6] = this.charAt(var1 + var6);
         }

         var6 = ThreadLocalRandom.current().nextInt(4096, 24096);
         StringObfuscation.E var7 = new StringObfuscation.E(var5, var6);
         Arrays.fill(var5, '\u0000');
         if (!Property.k()) {
            b(true);
         }

         return var7;
      }

      @Override
      public String toString() {
         char[] var2 = new char[this.decodedChars.length];
         int var3 = 0;

         for (boolean var1 = false; var3 < this.decodedChars.length; var3++) {
            var2[var3] = this.charAt(var3);
         }

         String var4 = new String(var2);
         Arrays.fill(var2, '\u0000');
         return var4;
      }

      public String get() {
         return this.toString();
      }

      public byte[] getEncodedBytes() {
         return this.encodedBytes;
      }

      public int getMask() {
         return this.recoveredField149;
      }

      public void d() {
         Arrays.fill(this.encodedBytes, (byte)0);
         Arrays.fill(this.decodedChars, '\u0000');
      }

      public static void b(boolean var0) {
         recoveredField190 = var0;
      }

      public static boolean e() {
         return recoveredField190;
      }

      public static boolean f() {
         boolean var0 = true;
         return false;
      }

   }
}
