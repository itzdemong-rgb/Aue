package com.google.common.jimfs.m;

import com.google.common.jimfs.client.Constants;
import com.google.common.jimfs.client.feature.module.Module;
import com.google.common.jimfs.client.feature.module.ModuleCategory;
import com.google.common.jimfs.client.feature.module.property.Property;
import com.google.common.jimfs.client.feature.module.property.impl.bool.BooleanProperty;
import com.google.common.jimfs.client.feature.module.property.impl.number.BoundedNumberProperty;
import com.google.common.jimfs.event.impl.game.PreGameTickEvent;
import com.google.common.jimfs.event.subscriber.Subscribe;
import com.google.common.jimfs.recovered.RandomInterpolation;
import com.google.common.jimfs.recovered.KeyInputHelper;
import com.google.common.jimfs.utility.misc.StringObfuscation;
import com.google.common.jimfs.utility.player.PlayerUtility;
import com.ibm.icu.impl.Pair;
import j2cc.Nativeify;
import net.minecraft.class_1268;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_3965;
import net.minecraft.class_4969;
import net.minecraft.class_239.class_240;

@Nativeify
public class PreCheckModule extends Module {
   private static PreCheckModule m;
   private final BoundedNumberProperty o;
   private final BooleanProperty p;
   private final BooleanProperty q;
   private final BooleanProperty r;
   private final BooleanProperty s;
   private int t = 0;
   private int u = 0;
   
   

   public PreCheckModule() {
      super(StringObfuscation.a("PreCheck"), "", ModuleCategory.CRYSTAL);
      this.o = new BoundedNumberProperty(StringObfuscation.a("Chаrgе Dеlау"), 0.0, 10.0, 0.0, 20.0, 1.0);
      this.p = new BooleanProperty(StringObfuscation.a("No Double Glowstone"), true);
      this.q = new BooleanProperty(StringObfuscation.a("Click Sim"), false);
      this.r = new BooleanProperty(StringObfuscation.a("Disable in Gui"), false);
      this.s = new BooleanProperty(StringObfuscation.a("Disable Charge"), false);
      this.b(new Property[]{this.o, this.p, this.q, this.r, this.s});
      m = this;
   }

   public static PreCheckModule getInstance() {
      return m;
   }

   public boolean d() {
      return this.p.isEnabled();
   }

   @Override
   protected void g() {
      super.g();
      this.t = 0;
      this.u = (int)RandomInterpolation.b((Double)((Pair)this.o.getValue()).first, (Double)((Pair)this.o.getValue()).second);
   }

   @Override
   protected void h() {
      super.h();
   }

   @Subscribe
   public void b(PreGameTickEvent var1) {
      boolean var2 = true;
      if (Constants.MINECRAFT.field_1724 != null && Constants.MINECRAFT.field_1687 != null) {
         if (!PlayerUtility.d()) {
            if (!this.r.isEnabled() || Constants.MINECRAFT.field_1755 == null) {
               this.t++;
               if (Constants.MINECRAFT.field_1724.method_6047().method_31574(class_1802.field_8801)
                  && Constants.MINECRAFT.field_1765.method_17783() == class_240.field_1332
                  && Constants.MINECRAFT.field_1765 instanceof class_3965 var3) {
                  class_2338 var5 = var3.method_17777();
                  if (this.b(class_2246.field_23152, var5)) {
                     if (this.p.isEnabled() && this.b(var5)) {
                        return;
                     }

                     if (this.c(var5)) {
                        if (this.s.isEnabled()) {
                           return;
                        }

                        if (this.t < this.u) {
                           return;
                        }

                        if (this.q.isEnabled()) {
                           KeyInputHelper.d(1);
                        } else {
                           Constants.MINECRAFT.field_1761.method_2896(Constants.MINECRAFT.field_1724, class_1268.field_5808, var3);
                           Constants.MINECRAFT.field_1724.method_6104(class_1268.field_5808);
                        }

                        this.t = 0;
                        this.u = (int)RandomInterpolation.b((Double)((Pair)this.o.getValue()).first, (Double)((Pair)this.o.getValue()).second);
                     }
                  }
               }
            }
         }
      }
   }

   private boolean b(class_2248 var1, class_2338 var2) {
      return Constants.MINECRAFT.field_1687.method_8320(var2).method_27852(var1);
   }

   private boolean b(class_2338 var1) {
      boolean var2 = false;
      return Constants.MINECRAFT.field_1687.method_8320(var1).method_27852(class_2246.field_23152)
         ? (Integer)Constants.MINECRAFT.field_1687.method_8320(var1).method_11654(class_4969.field_23153) > 0
         : false;
   }

   private boolean c(class_2338 var1) {
      boolean var2 = false;
      return Constants.MINECRAFT.field_1687.method_8320(var1).method_27852(class_2246.field_23152)
         ? (Integer)Constants.MINECRAFT.field_1687.method_8320(var1).method_11654(class_4969.field_23153) == 0
         : false;
   }

}
