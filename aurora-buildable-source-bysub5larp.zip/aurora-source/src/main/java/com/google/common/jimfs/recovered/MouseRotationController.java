package com.google.common.jimfs.recovered;

import com.google.common.jimfs.client.Constants;
import com.google.common.jimfs.event.EventDispatcher;
import com.google.common.jimfs.event.impl.game.PreGameTickEvent;
import com.google.common.jimfs.event.impl.game.input.MouseUpdateEvent;
import com.google.common.jimfs.event.subscriber.IEventSubscriber;
import com.google.common.jimfs.event.subscriber.Subscribe;
import com.google.common.jimfs.utility.player.RotationUtility;
import net.minecraft.class_241;
import net.minecraft.class_310;

public final class MouseRotationController implements IEventSubscriber {
   private RotationInterpolator interpolator;
   private class_241 targetRotation;
   private boolean recoveredField170;
   private boolean recoveredField190;
   private class_241 recoveredField201;
   private boolean recoveredField213;
   private boolean recoveredField226;

   public MouseRotationController() {
      EventDispatcher.a(this);
   }

   @Subscribe
   public void b(MouseUpdateEvent var1) {
      boolean var2 = true;
      if (this.recoveredField201 != null && this.targetRotation != null && Constants.MINECRAFT.field_1724 != null && this.recoveredField170) {
         if (!this.recoveredField190) {
            this.d();
            if (this.targetRotation == null) {
               this.recoveredField213 = false;
               return;
            }
         }

         float var3;
         if (this.recoveredField213) {
            var3 = 1.0F;
            this.recoveredField213 = false;
         } else {
            var3 = class_310.method_1551().method_61966().method_60637(false);
         }

         double var4 = var1.d();
         class_241 var6 = this.interpolator.b(this.recoveredField201, this.targetRotation, var3);
         double var7 = (double)(var6.field_1343 - Constants.MINECRAFT.field_1724.method_36454());
         double var9 = RotationUtility.b(var7, var4);
         double var11 = (double)(var6.field_1342 - Constants.MINECRAFT.field_1724.method_36455());
         double var13 = RotationUtility.b(var11, var4);
         if ((Boolean)Constants.MINECRAFT.field_1690.method_42438().method_41753()) {
            var13 *= -1.0;
         }

         var1.b(var9);
         var1.c(var13);
         var1.e();
         if (!this.recoveredField190 && (double)RotationUtility.b(var6, this.targetRotation) == 0.0) {
            this.interpolator = null;
            this.targetRotation = null;
            this.recoveredField170 = false;
         }
      } else {
         this.recoveredField213 = false;
      }
   }

   @Subscribe(
      a = 8
   )
   public void b(PreGameTickEvent var1) {
      if (Constants.MINECRAFT.field_1724 != null) {
         this.recoveredMethod109();
         this.update();
         this.b(RotationUtility.getPlayerRotation());
         this.recoveredField226 = false;
      }
   }

   public void b(class_241 var1) {
      this.recoveredField201 = var1;
   }

   public void update() {
      boolean var1 = false;
      if (this.recoveredField190) {
         this.d();
         this.recoveredField190 = false;
      }
   }

   private void recoveredMethod109() {
      boolean var1 = false;
      if (this.recoveredField170) {
         this.recoveredField213 = true;
         Constants.MINECRAFT.field_1729.method_55793();
         this.recoveredField213 = false;
      }
   }

   private void d() {
      this.targetRotation = new class_241(Constants.MINECRAFT.field_1724.method_36454(), Constants.MINECRAFT.field_1724.method_36455());
   }

}
