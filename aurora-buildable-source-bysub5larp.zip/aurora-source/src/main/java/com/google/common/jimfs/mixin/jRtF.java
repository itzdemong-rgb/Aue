package com.google.common.jimfs.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Environment(EnvType.CLIENT)
@Mixin({class_746.class})
public interface jRtF {
   @Accessor("inSneakingPose")
   void t(boolean var1);

   @Accessor("lastXClient")
   double u();

   @Accessor("lastYClient")
   double v();

   @Accessor("lastZClient")
   double w();

   @Mutable
   @Accessor("lastXClient")
   void x(double var1);

   @Mutable
   @Accessor("lastYClient")
   void y(double var1);

   @Mutable
   @Accessor("lastZClient")
   void z(double var1);

   @Mutable
   @Accessor("lastYawClient")
   void A(float var1);

   @Mutable
   @Accessor("lastPitchClient")
   void B(float var1);

   @Mutable
   @Accessor("lastOnGround")
   void C(boolean var1);

   @Accessor("lastYawClient")
   float D();

   @Accessor("lastPitchClient")
   float E();

   @Accessor("lastOnGround")
   boolean F();

   @Accessor("lastSprinting")
   boolean G();

   @Accessor("ticksSinceLastPositionPacketSent")
   int H();

   @Mutable
   @Accessor("lastSprinting")
   void I(boolean var1);

   @Mutable
   @Accessor("ticksSinceLastPositionPacketSent")
   void J(int var1);

   @Invoker("sendMovementPackets")
   void K();

   @Invoker("canStartSprinting")
   boolean L();
}
