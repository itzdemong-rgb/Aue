package com.google.common.jimfs.duck;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2338;

@Environment(EnvType.CLIENT)
public interface ClientPlayerInteractionManagerAccess {
   class_2338 jimfs$getCurrentBreakingPos();

   float jimfs$currentBreakingProgress();
}
