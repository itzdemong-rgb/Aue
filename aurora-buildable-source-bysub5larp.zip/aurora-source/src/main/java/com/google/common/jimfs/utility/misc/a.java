package com.google.common.jimfs.utility.misc;

import java.util.Arrays;
import java.util.Base64;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_2583;
import net.minecraft.class_327;
import net.minecraft.class_5224;
import net.minecraft.class_5481;

public final class a implements class_5481 {
   private final StringObfuscation.E recoveredField020;
   private char[] decodedChars;

   public a(StringObfuscation.E var1) {
      this.recoveredField020 = var1;
   }

   public boolean accept(class_5224 var1) {
      char[] var3 = this.decodeChars();
      boolean var2 = true;

      try {
         for (int var4 = 0; var4 < var3.length; var4++) {
            if (!var1.accept(var4, class_2583.field_24360, var3[var4])) {
               return false;
            }
         }

         return true;
      } finally {
         this.clearDecodedChars();
      }
   }

   private char[] decodeChars() {
      byte[] var2 = this.recoveredField020.getEncodedBytes();
      boolean var1 = false;
      int var3 = this.recoveredField020.getMask();
      if (var2 != null && var2.length != 0) {
         byte[] var4 = new byte[var2.length];
         System.arraycopy(var2, 0, var4, 0, var2.length);

         for (int var5 = 0; var5 < var4.length; var5++) {
            var4[var5] = (byte)((var4[var5] & 255) - (var3 % 31 + var5 & 0xFF));
         }

         int var11 = 0;

         for (int var6 = var4.length - 1; var11 < var6; var6--) {
            byte var7 = var4[var11];
            var4[var11] = var4[var6];
            var4[var6] = var7;
            var11++;
         }

         var4 = Base64.getDecoder().decode(var4);

         for (int var12 = 0; var12 < var4.length; var12++) {
            var4[var12] = (byte)(var4[var12] ^ var3 + var12 * 7 & 0xFF);
         }

         this.decodedChars = new char[var4.length];
         var11 = 0;
         int var15 = 0;

         while (var15 < var4.length) {
            int var17 = var4[var15] & 255;
            byte var8;
            int var9;
            if (var17 < 128) {
               var9 = var17;
               var8 = 1;
            } else if (var17 < 224) {
               var9 = (var17 & 31) << 6 | var4[var15 + 1] & 63;
               var8 = 2;
            } else if (var17 < 240) {
               var9 = (var17 & 15) << 12 | (var4[var15 + 1] & 63) << 6 | var4[var15 + 2] & 63;
               var8 = 3;
            } else {
               var9 = (var17 & 7) << 18 | (var4[var15 + 1] & 63) << 12 | (var4[var15 + 2] & 63) << 6 | var4[var15 + 3] & 63;
               var8 = 4;
            }

            if (var9 <= 65535) {
               this.decodedChars[var11++] = (char)var9;
            } else {
               this.decodedChars[var11++] = (char)((var9 - 65536 >> 10) + 55296);
               this.decodedChars[var11++] = (char)((var9 - 65536 & 1023) + 56320);
            }

            var15 += var8;
         }

         Arrays.fill(var4, (byte)0);
         if (var11 < this.decodedChars.length) {
            char[] var16 = new char[var11];
            System.arraycopy(this.decodedChars, 0, var16, 0, var11);
            Arrays.fill(this.decodedChars, '\u0000');
            this.decodedChars = var16;
         }

         return this.decodedChars;
      } else {
         this.decodedChars = new char[0];
         return this.decodedChars;
      }
   }

   private void clearDecodedChars() {
      boolean var1 = true;
      if (this.decodedChars != null) {
         Arrays.fill(this.decodedChars, '\u0000');
         this.decodedChars = null;
      }
   }

   public static int a(class_327 var0, StringObfuscation.E var1) {
      char[] var3 = a(var1);
      boolean var2 = false;

      int var12;
      try {
         int var4 = 0;

         for (char var8 : var3) {
            var4 += var0.method_1727(String.valueOf(var8));
         }

         var12 = var4;
      } finally {
         Arrays.fill(var3, '\u0000');
      }

      return var12;
   }

   private static char[] a(StringObfuscation.E var0) {
      byte[] var2 = var0.getEncodedBytes();
      boolean var1 = false;
      int var3 = var0.getMask();
      if (var2 != null && var2.length != 0) {
         byte[] var4 = new byte[var2.length];
         System.arraycopy(var2, 0, var4, 0, var2.length);

         for (int var5 = 0; var5 < var4.length; var5++) {
            var4[var5] = (byte)((var4[var5] & 255) - (var3 % 31 + var5 & 0xFF));
         }

         int var12 = 0;

         for (int var6 = var4.length - 1; var12 < var6; var6--) {
            byte var7 = var4[var12];
            var4[var12] = var4[var6];
            var4[var6] = var7;
            var12++;
         }

         var4 = Base64.getDecoder().decode(var4);

         for (int var13 = 0; var13 < var4.length; var13++) {
            var4[var13] = (byte)(var4[var13] ^ var3 + var13 * 7 & 0xFF);
         }

         char[] var14 = new char[var4.length];
         int var15 = 0;
         int var17 = 0;

         while (var17 < var4.length) {
            int var8 = var4[var17] & 255;
            byte var9;
            int var10;
            if (var8 < 128) {
               var10 = var8;
               var9 = 1;
            } else if (var8 < 224) {
               var10 = (var8 & 31) << 6 | var4[var17 + 1] & 63;
               var9 = 2;
            } else if (var8 < 240) {
               var10 = (var8 & 15) << 12 | (var4[var17 + 1] & 63) << 6 | var4[var17 + 2] & 63;
               var9 = 3;
            } else {
               var10 = (var8 & 7) << 18 | (var4[var17 + 1] & 63) << 12 | (var4[var17 + 2] & 63) << 6 | var4[var17 + 3] & 63;
               var9 = 4;
            }

            if (var10 <= 65535) {
               var14[var15++] = (char)var10;
            } else {
               var14[var15++] = (char)((var10 - 65536 >> 10) + 55296);
               var14[var15++] = (char)((var10 - 65536 & 1023) + 56320);
            }

            var17 += var9;
         }

         Arrays.fill(var4, (byte)0);
         if (var15 < var14.length) {
            char[] var18 = new char[var15];
            System.arraycopy(var14, 0, var18, 0, var15);
            Arrays.fill(var14, '\u0000');
            return var18;
         } else {
            return var14;
         }
      } else {
         return new char[0];
      }
   }

   public static char[] b(StringObfuscation.E var0) {
      return a(var0);
   }

   public static StringObfuscation.E a(char[] var0) {
      byte[] var2 = new byte[var0.length * 3];
      boolean var1 = false;
      int var3 = 0;

      for (char var7 : var0) {
         if (var7 < 128) {
            var2[var3++] = (byte)var7;
         } else if (var7 < 2048) {
            var2[var3++] = (byte)(192 | var7 >> 6);
            var2[var3++] = (byte)(128 | var7 & '?');
         } else {
            var2[var3++] = (byte)(224 | var7 >> '\f');
            var2[var3++] = (byte)(128 | var7 >> 6 & 63);
            var2[var3++] = (byte)(128 | var7 & '?');
         }
      }

      byte[] var14 = new byte[var3];
      System.arraycopy(var2, 0, var14, 0, var3);
      Arrays.fill(var2, (byte)0);
      int var15 = ThreadLocalRandom.current().nextInt(4096, 24096);
      byte[] var16 = new byte[var14.length];
      System.arraycopy(var14, 0, var16, 0, var14.length);

      for (int var17 = 0; var17 < var16.length; var17++) {
         var16[var17] = (byte)(var16[var17] ^ var15 + var17 * 7 & 0xFF);
      }

      byte[] var18 = Base64.getEncoder().encode(var16);
      Arrays.fill(var16, (byte)0);
      Arrays.fill(var14, (byte)0);
      int var8 = 0;

      for (int var9 = var18.length - 1; var8 < var9; var9--) {
         byte var10 = var18[var8];
         var18[var8] = var18[var9];
         var18[var9] = var10;
         var8++;
      }

      for (int var19 = 0; var19 < var18.length; var19++) {
         var18[var19] = (byte)((var18[var19] & 255) + (var15 % 31 + var19 & 0xFF) & 0xFF);
      }

      return new StringObfuscation.E(var18, var15);
   }

}
