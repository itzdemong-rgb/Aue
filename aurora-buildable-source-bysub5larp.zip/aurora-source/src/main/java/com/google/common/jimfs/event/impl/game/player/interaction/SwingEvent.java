package com.google.common.jimfs.event.impl.game.player.interaction;

import java.util.Objects;
import net.minecraft.class_1268;

public final class SwingEvent {
   private final class_1268 hand;

   public SwingEvent(class_1268 var1) {
      this.hand = var1;
   }

   @Override
   public boolean equals(Object var1) {
      boolean var2 = true;
      if (var1 == this) {
         return true;
      } else if (var1 != null && var1.getClass() == this.getClass()) {
         SwingEvent var3 = (SwingEvent)var1;
         return Objects.equals(this.hand, var3.hand);
      } else {
         return false;
      }
   }

   @Override
   public int hashCode() {
      return Objects.hash(this.hand);
   }

   @Override
   public String toString() {
      return "SwingEvent[hand=" + this.hand + ']';
   }

}
