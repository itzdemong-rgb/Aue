package com.google.common.jimfs.event.impl.render;

public final class ResolutionChangeEvent {
}
