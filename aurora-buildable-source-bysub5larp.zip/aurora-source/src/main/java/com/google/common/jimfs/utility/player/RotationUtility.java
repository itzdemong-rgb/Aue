package com.google.common.jimfs.utility.player;

import com.google.common.jimfs.client.Constants;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_3532;

public final class RotationUtility {
   public static boolean recoveredField045 = false;
   public static boolean recoveredField110 = false;
   public static float recoveredField001 = 0.0F;
   public static float recoveredField063 = 0.0F;
   public static boolean recoveredField141 = false;
   public static volatile boolean recoveredField170 = false;
   public static boolean recoveredField190 = false;
   private static int[] recoveredField214 = new int[]{0, 0, 0, 0, 0};

   public static float b(class_241 var0, class_241 var1) {
      return class_3532.method_15356(var0.field_1343, var1.field_1343) + Math.abs(var0.field_1342 - var1.field_1342);
   }

   public static double b(double var0, double var2) {
      return (double)((float)(var0 / var2) / 0.15F);
   }

   public static float getMouseSensitivityStep() {
      float var0 = ((Double)Constants.MINECRAFT.field_1690.method_42495().method_41753()).floatValue() * 0.6F + 0.2F;
      float var1 = var0 * var0 * var0 * 8.0F;
      return var1 * 0.15F;
   }

   public static float b(float var0, float var1) {
      float var2 = getMouseSensitivityStep();
      float var3 = var0 - var1;
      int var4 = Math.round(var3 / var2);
      return var1 + (float)var4 * var2;
   }

   public static class_241 getPlayerRotation() {
      return new class_241(Constants.MINECRAFT.field_1724.method_36454(), Constants.MINECRAFT.field_1724.method_36455());
   }

   public static class_241 b(class_243 var0) {
      return b(Constants.MINECRAFT.field_1724.method_33571(), var0);
   }

   public static class_241 b(class_243 var0, class_243 var1) {
      double var2 = var1.method_10216() - var0.method_10216();
      double var4 = var1.method_10214() - var0.method_10214();
      double var6 = var1.method_10215() - var0.method_10215();
      double var8 = Math.sqrt(var2 * var2 + var6 * var6);
      float var10 = (float)Math.toDegrees(-Math.atan2(var2, var6));
      float var11 = (float)(-Math.toDegrees(Math.atan2(var4, var8)));
      return new class_241(var10, var11);
   }

   public static void b(int[] var0) {
      recoveredField214 = var0;
   }

   public static int[] d() {
      return recoveredField214;
   }
}
