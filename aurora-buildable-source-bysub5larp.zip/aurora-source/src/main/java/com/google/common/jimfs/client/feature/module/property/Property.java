package com.google.common.jimfs.client.feature.module.property;

import com.google.common.jimfs.event.EventDispatcher;
import com.google.common.jimfs.recovered.PropertyChangeListener;
import com.google.common.jimfs.recovered.PropertyUpdateEvent;
import com.google.common.jimfs.utility.misc.StringObfuscation;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.BooleanSupplier;

public class Property {
   private final StringObfuscation.E recoveredField088;
   private StringObfuscation.E recoveredField128;
   @Expose
   @SerializedName("value")
   private Object value;
   private BooleanSupplier visibilityCondition;
   private List<PropertyChangeListener> listeners;
   private static boolean recoveredField213;

   protected Property(CharSequence var1) {
      if (var1 instanceof StringObfuscation.E) {
         this.recoveredField088 = (StringObfuscation.E)var1;
      } else {
         char[] var2 = new char[var1.length()];

         for (int var3 = 0; var3 < var1.length(); var3++) {
            var2[var3] = var1.charAt(var3);
         }

         this.recoveredField088 = new StringObfuscation.E(var2, ThreadLocalRandom.current().nextInt(4096, 24096));
         Arrays.fill(var2, '\u0000');
      }

      if (var1 instanceof StringObfuscation.E) {
         this.recoveredField128 = (StringObfuscation.E)var1;
      } else {
         char[] var4 = new char[var1.length()];

         for (int var5 = 0; var5 < var1.length(); var5++) {
            var4[var5] = var1.charAt(var5);
         }

         this.recoveredField128 = new StringObfuscation.E(var4, ThreadLocalRandom.current().nextInt(4096, 24096));
         Arrays.fill(var4, '\u0000');
      }
   }

   public final CharSequence getName() {
      return this.recoveredField088;
   }

   public Object getValue() {
      return this.value;
   }

   public void a(Object var1) {
      Object var2 = this.value;
      this.value = var1;
      EventDispatcher.b(new PropertyUpdateEvent(this));
      this.b(var2, var1);
   }

   public final boolean isVisible() {
      boolean var1 = true;
      return this.visibilityCondition != null && this.visibilityCondition.getAsBoolean();
   }

   public final Property b(PropertyChangeListener var1) {
      boolean var2 = false;
      if (this.listeners == null) {
         this.listeners = new ArrayList(1);
      }

      this.listeners.add(var1);
      return this;
   }

   public final void b(Object var1, Object var2) {
      if (this.listeners != null) {
         this.listeners.forEach(var2x -> var2x.a(var1, var2));
      }
   }

   public static void c(boolean var0) {
      recoveredField213 = var0;
   }

   public static boolean j() {
      return recoveredField213;
   }

   public static boolean k() {
      boolean var0 = j();
      return !var0;
   }

}
