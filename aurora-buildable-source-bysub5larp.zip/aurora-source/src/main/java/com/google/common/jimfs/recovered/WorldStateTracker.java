package com.google.common.jimfs.recovered;

import com.google.common.jimfs.client.Constants;
import com.google.common.jimfs.client.renderer.OverlayManager;
import com.google.common.jimfs.event.EventDispatcher;
import com.google.common.jimfs.event.impl.game.PreGameTickEvent;
import com.google.common.jimfs.event.impl.game.packet.ReceivePacketEvent;
import com.google.common.jimfs.event.impl.game.packet.SendPacketEvent;
import com.google.common.jimfs.event.impl.game.player.PlayerCreateEvent;
import com.google.common.jimfs.event.impl.game.player.interaction.HnWqPm;
import com.google.common.jimfs.event.impl.game.player.movement.PostMoveEvent;
import com.google.common.jimfs.event.impl.game.player.movement.step.StepSuccessEvent;
import com.google.common.jimfs.event.impl.game.server.ServerConnectEvent;
import com.google.common.jimfs.event.impl.game.server.ServerDisconnectEvent;
import com.google.common.jimfs.event.subscriber.Subscribe;
import com.google.common.jimfs.mixin.client.ServerCookiesAccessor;
import com.google.common.jimfs.utility.misc.time.Stopwatch;
import com.google.common.jimfs.utility.player.PlayerUtility;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2708;
import net.minecraft.class_2743;
import net.minecraft.class_3545;
import net.minecraft.class_408;
import net.minecraft.class_7439;

public final class WorldStateTracker implements ClientEventSubscriber {
   private final ServerProfileDetector serverProfileDetector = new ServerProfileDetector();
   private TrackedEntityRegistry entities;
   private final List recoveredField161 = new CopyOnWriteArrayList();
   private final List recoveredField186 = new ArrayList();
   public int ticksSinceStep;
   public int ticksSincePositionCorrection;
   public final Stopwatch timer = new Stopwatch(0L);
   public final class_3545 recentLivingEntity = new class_3545(0, null);
   private class_243 j;
   private static WorldStateTracker k;
   
   

   private WorldStateTracker() {
   }

   @Subscribe
   public void b(HnWqPm var1) {
      class_1297 var4 = var1.getEntity();
      boolean var2 = false;
      if (var4 instanceof class_1309 var3) {
         this.recentLivingEntity.method_34964(0);
         this.recentLivingEntity.method_34965(var3);
      }
   }

   @Subscribe
   public void b(ServerConnectEvent var1) {
      RandomInterpolation.refreshRandomValue();
      this.serverProfileDetector.b(var1.getServerInfo());
   }

   @Subscribe
   public void b(ServerDisconnectEvent var1) {
      this.serverProfileDetector.clearActiveProfile();
      boolean var2 = false;
      this.entities = null;
      if (Constants.MINECRAFT.method_1562() != null) {
         ServerCookiesAccessor var3 = (ServerCookiesAccessor)Constants.MINECRAFT.method_1562();
         var3.getServerCookies().clear();
      }
   }

   @Subscribe
   public void b(PlayerCreateEvent var1) {
      this.entities = new TrackedEntityRegistry();
   }

   @Subscribe
   public void b(PreGameTickEvent var1) {
      OverlayManager.refreshWindowOpacity();
      boolean var2 = true;
      if (this.entities != null) {
         this.entities.update();
      }

      this.ticksSinceStep++;
      this.ticksSincePositionCorrection++;
      if (Constants.MINECRAFT.field_1755 == null && Constants.MINECRAFT.method_18506() == null && PlayerUtility.isMouseButtonPressed(46)) {
         Constants.MINECRAFT.method_1507(new class_408(".", false));
      }

      this.recentLivingEntity.method_34964((Integer)this.recentLivingEntity.method_15442() + 1);
      if ((Integer)this.recentLivingEntity.method_15442() > 10) {
         this.recentLivingEntity.method_34965(null);
      }
   }

   @Subscribe
   public void b(StepSuccessEvent var1) {
      this.ticksSinceStep = 0;
   }

   @Subscribe
   public void b(ReceivePacketEvent var1) {
      class_2596 var5 = var1.getPacket();
      boolean var2 = true;
      if (var5 instanceof class_7439 var3) {
         String var6 = var3.comp_763().getString();
      } else if (var1.getPacket() instanceof class_2708) {
         this.ticksSincePositionCorrection = 0;
      } else if (var1.getPacket() instanceof class_2743 var4
         && Constants.MINECRAFT.field_1724 != null
         && var4.method_11818() == Constants.MINECRAFT.field_1724.method_5628()) {
         this.timer.reset();
      }
   }

   @Subscribe
   public void b(SendPacketEvent var1) {
      boolean var3 = false;
      boolean var2 = false;
   }

   @Subscribe(
      a = -10
   )
   public void b(PostMoveEvent var1) {
      this.j = Constants.MINECRAFT.field_1724.method_18798();
   }

   public ServerProfileDetector getServerProfileDetector() {
      return this.serverProfileDetector;
   }

   public static WorldStateTracker getInstance() {
      return k;
   }

   public static void d() {
      k = new WorldStateTracker();
      EventDispatcher.a(k);
   }

}
