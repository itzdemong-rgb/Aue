package com.google.common.jimfs.client.renderer.shader;

import java.nio.ByteBuffer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;

@Environment(EnvType.CLIENT)
public class ItemVisualsShader {
   private static int framebufferId = 0;
   private static int textureId = 0;
   private static int framebufferWidth = -1;
   private static int framebufferHeight = -1;
   private static int shaderProgramId = 0;
   private static int vertexArrayId = 0;
   private static boolean shaderFailed = false;
   private static int renderedFrameCount = 0;
   private static int previousFramebufferId = 0;
   private static boolean renderingToFramebuffer = false;

   public static void initializeShaders() {
      if (shaderProgramId == 0 && !shaderFailed) {
         System.out.println("[ItemVisuals] Initializing shader...");
         String var0 = "#version 330 core\nout vec2 TexCoords;\nvoid main() {\n    float x = -1.0 + float((gl_VertexID & 1) << 2);\n    float y = -1.0 + float((gl_VertexID & 2) << 1);\n    TexCoords = vec2((x + 1.0) * 0.5, (y + 1.0) * 0.5);\n    gl_Position = vec4(x, y, 0.0, 1.0);\n}\n";
         String var1 = "#version 330 core\nout vec4 FragColor;\nin vec2 TexCoords;\nuniform sampler2D image;\nuniform float time;\nuniform float transitionProgress;\nuniform int smokeEnabled;\nuniform int waveEnabled;\n\nfloat hash(vec2 p) {\n    return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);\n}\n\nfloat noise(vec2 p) {\n    vec2 i = floor(p);\n    vec2 f = fract(p);\n    f = f * f * (3.0 - 2.0 * f);\n    float res = mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x),\n                    mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), f.x), f.y);\n    return res;\n}\n\nfloat fbm(vec2 p) {\n    float v = 0.0;\n    float a = 0.5;\n    for (int i = 0; i < 4; i++) {\n        v += a * noise(p);\n        p *= 2.0;\n        a *= 0.5;\n    }\n    return v;\n}\n\nvoid main() {\n    vec4 texColor = texture(image, TexCoords);\n    if (texColor.a < 0.01) discard;\n\n    float effectMask = smoothstep(transitionProgress + 0.05, transitionProgress - 0.05, 1.0 - TexCoords.y);\n\n    vec3 finalColor = texColor.rgb;\n    float finalAlpha = texColor.a;\n\n    if (effectMask > 0.0) {\n        float gray = dot(texColor.rgb, vec3(0.299, 0.587, 0.114));\n        vec3 corruptedColor = vec3(gray * 0.7);\n\n        if (smokeEnabled == 1) {\n            vec2 smokeUv = TexCoords * 10.0 + vec2(time * 0.5, time * -0.8);\n            float n = fbm(smokeUv);\n            corruptedColor += vec3(n * 0.3);\n        }\n\n        if (waveEnabled == 1) {\n            float wavePos = fract(time * 0.5);\n            float waveDist = abs(TexCoords.y - wavePos);\n            float waveIntensity = smoothstep(0.05, 0.0, waveDist);\n            corruptedColor += vec3(0.5, 0.7, 1.0) * waveIntensity * 0.8;\n        }\n\n        float borderLine = smoothstep(0.02, 0.0, abs((1.0 - TexCoords.y) - transitionProgress));\n        corruptedColor += vec3(0.8, 0.9, 1.0) * borderLine;\n\n        finalColor = mix(texColor.rgb, corruptedColor, effectMask);\n    }\n\n    FragColor = vec4(finalColor, finalAlpha);\n}\n";
         int var2 = GL20.glCreateShader(35633);
         GL20.glShaderSource(var2, var0);
         GL20.glCompileShader(var2);
         if (GL20.glGetShaderi(var2, 35713) == 0) {
            System.err.println("[ItemVisuals] Vertex shader compile error: " + GL20.glGetShaderInfoLog(var2));
            shaderFailed = true;
         } else {
            int var3 = GL20.glCreateShader(35632);
            GL20.glShaderSource(var3, var1);
            GL20.glCompileShader(var3);
            if (GL20.glGetShaderi(var3, 35713) == 0) {
               System.err.println("[ItemVisuals] Fragment shader compile error: " + GL20.glGetShaderInfoLog(var3));
               shaderFailed = true;
            } else {
               shaderProgramId = GL20.glCreateProgram();
               GL20.glAttachShader(shaderProgramId, var2);
               GL20.glAttachShader(shaderProgramId, var3);
               GL20.glLinkProgram(shaderProgramId);
               if (GL20.glGetProgrami(shaderProgramId, 35714) == 0) {
                  System.err.println("[ItemVisuals] Shader link error: " + GL20.glGetProgramInfoLog(shaderProgramId));
                  shaderFailed = true;
               } else {
                  GL20.glDeleteShader(var2);
                  GL20.glDeleteShader(var3);
                  vertexArrayId = GL30.glGenVertexArrays();
                  System.out.println("[ItemVisuals] Shader initialized successfully! program=" + shaderProgramId);
               }
            }
         }
      }
   }

   public static void ensureFramebuffer() {
      class_310 var0 = class_310.method_1551();
      int var1 = var0.method_22683().method_4489();
      int var2 = var0.method_22683().method_4506();
      if (var1 > 0 && var2 > 0) {
         if (framebufferId == 0 || textureId == 0 || framebufferWidth != var1 || framebufferHeight != var2) {
            if (framebufferId != 0) {
               GL30.glDeleteFramebuffers(framebufferId);
            }

            if (textureId != 0) {
               GL11.glDeleteTextures(textureId);
            }

            framebufferWidth = var1;
            framebufferHeight = var2;
            framebufferId = GL30.glGenFramebuffers();
            GL30.glBindFramebuffer(36160, framebufferId);
            textureId = GL11.glGenTextures();
            GL11.glBindTexture(3553, textureId);
            GL11.glTexImage2D(3553, 0, 32856, var1, var2, 0, 6408, 5121, (ByteBuffer)null);
            GL11.glTexParameteri(3553, 10241, 9728);
            GL11.glTexParameteri(3553, 10240, 9728);
            GL11.glTexParameteri(3553, 10242, 10496);
            GL11.glTexParameteri(3553, 10243, 10496);
            GL30.glFramebufferTexture2D(36160, 36064, 3553, textureId, 0);
            int var3 = GL30.glGenRenderbuffers();
            GL30.glBindRenderbuffer(36161, var3);
            GL30.glRenderbufferStorage(36161, 36012, var1, var2);
            GL30.glFramebufferRenderbuffer(36160, 36096, 36161, var3);
            int var4 = GL30.glCheckFramebufferStatus(36160);
            if (var4 != 36053) {
               System.err.println("[ItemVisuals] FBO is NOT complete! Status: " + var4);
            } else {
               System.out.println("[ItemVisuals] FBO created: " + var1 + "x" + var2 + " fbo=" + framebufferId);
            }

            GL30.glBindFramebuffer(36160, 0);
         }
      }
   }

   public static void beginRender() {
      if (!shaderFailed) {
         if (shaderProgramId == 0) {
            initializeShaders();
         }

         if (!shaderFailed) {
            ensureFramebuffer();
            if (framebufferId != 0) {
               previousFramebufferId = GL11.glGetInteger(36006);
               GL30.glBindFramebuffer(36160, framebufferId);
               GL11.glClearColor(0.0F, 0.0F, 0.0F, 0.0F);
               GL11.glClearDepth(0.0);
               GL11.glClear(16640);
               renderingToFramebuffer = true;
               if (renderedFrameCount % 300 == 0) {
                  System.out.println("[ItemVisuals] beginRender: bound FBO " + framebufferId + " (savedFbo=" + previousFramebufferId + ")");
               }
            }
         }
      }
   }

   public static void a(float var0, float var1, boolean var2, boolean var3) {
      if (renderingToFramebuffer && framebufferId != 0) {
         renderingToFramebuffer = false;
         if (renderedFrameCount % 300 == 0) {
            ByteBuffer var4 = BufferUtils.createByteBuffer(4);
            GL11.glReadPixels(framebufferWidth / 2, framebufferHeight / 2, 1, 1, 6408, 5121, var4);
            int var5 = var4.get(0) & 255;
            int var6 = var4.get(1) & 255;
            int var7 = var4.get(2) & 255;
            int var8 = var4.get(3) & 255;
            System.out.println("[ItemVisuals] endRender: FBO center pixel RGBA=(" + var5 + "," + var6 + "," + var7 + "," + var8 + ") transition=" + var1);
            int var9 = GL11.glGetInteger(36006);
            System.out.println("[ItemVisuals] Current FBO binding before restore: " + var9 + " (expected our fbo=" + framebufferId + ")");
         }

         renderedFrameCount++;
         GL30.glBindFramebuffer(36160, previousFramebufferId);
         int var10 = GL11.glGetInteger(35725);
         int var11 = GL11.glGetInteger(34229);
         int var12 = GL11.glGetInteger(32873);
         boolean var13 = GL11.glIsEnabled(3042);
         boolean var14 = GL11.glIsEnabled(2929);
         GL11.glEnable(3042);
         GL11.glBlendFunc(770, 771);
         GL11.glDisable(2929);
         GL20.glUseProgram(shaderProgramId);
         GL30.glBindVertexArray(vertexArrayId);
         GL20.glActiveTexture(33984);
         GL11.glBindTexture(3553, textureId);
         GL20.glUniform1i(GL20.glGetUniformLocation(shaderProgramId, "image"), 0);
         GL20.glUniform1f(GL20.glGetUniformLocation(shaderProgramId, "time"), var0);
         GL20.glUniform1f(GL20.glGetUniformLocation(shaderProgramId, "transitionProgress"), var1);
         GL20.glUniform1i(GL20.glGetUniformLocation(shaderProgramId, "smokeEnabled"), var2 ? 1 : 0);
         GL20.glUniform1i(GL20.glGetUniformLocation(shaderProgramId, "waveEnabled"), var3 ? 1 : 0);
         GL11.glDrawArrays(4, 0, 3);
         GL20.glUseProgram(var10);
         GL30.glBindVertexArray(var11);
         GL11.glBindTexture(3553, var12);
         if (var14) {
            GL11.glEnable(2929);
         } else {
            GL11.glDisable(2929);
         }

         if (!var13) {
            GL11.glDisable(3042);
         }
      }
   }
}
