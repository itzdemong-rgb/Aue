package com.google.common.jimfs.utility.misc;

public final class HoverUtility {
   public static boolean a(float var0, float var1, float var2, float var3, double var4, double var6) {
      boolean var8 = true;
      return var4 >= (double)var0 && var6 >= (double)var1 && var4 < (double)(var0 + var2) && var6 < (double)(var1 + var3);
   }

}
