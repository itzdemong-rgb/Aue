package com.google.common.jimfs.recovered;

import com.google.common.jimfs.client.Constants;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public final class TrackedEntityRegistry {
   private final Map entitiesById = new HashMap();

   public void update() {
      if (Constants.MINECRAFT.field_1687 == null) {
         this.entitiesById.clear();
      } else {
         this.removeInvalidEntities();
         this.d();
      }
   }

   private void removeInvalidEntities() {
      Iterator var2 = this.entitiesById.values().iterator();
      boolean var1 = false;

      while (var2.hasNext()) {
         TrackedEntity var3 = (TrackedEntity)var2.next();
         class_1309 var4 = var3.getEntity();
         if (!Constants.MINECRAFT.field_1687.method_62145(var4) || !var4.method_5805() || var4.field_6213 > 0) {
            var2.remove();
         }
      }
   }

   private void d() {
      ServerProfile var2 = WorldStateTracker.getInstance().getServerProfileDetector().getActiveProfile();
      boolean var1 = false;

      for (class_1297 var4 : Constants.MINECRAFT.field_1687.method_18112()) {
         if (var4 instanceof class_1309) {
            class_1309 var5 = (class_1309)var4;
            if (var2 == null || var2.b(var5)) {
               int var6 = var4.method_5628();
               TrackedEntity var7 = this.b(var6, null);
               if (var7 == null) {
                  var7 = this.b(var4);
                  this.entitiesById.put(var6, var7);
               }

               var7.b(var4);
            }
         }
      }
   }

   @NotNull
   private TrackedEntity b(class_1297 var1) {
      Objects.requireNonNull(var1);
      boolean var2 = true;

      return (TrackedEntity)(switch (var1) {
         case class_1657 var5 -> new TrackedPlayerEntity(var5);
         case class_1309 var6 -> new TrackedLivingEntity(var6);
         default -> throw new RuntimeException("This should never happen!");
      });
   }

   public TrackedEntity b(int var1, @Nullable Class var2) {
      TrackedEntity var4 = (TrackedEntity)this.entitiesById.get(var1);
      boolean var3 = true;
      return var2 != null && !var2.isInstance(var4) ? null : var4;
   }

}
