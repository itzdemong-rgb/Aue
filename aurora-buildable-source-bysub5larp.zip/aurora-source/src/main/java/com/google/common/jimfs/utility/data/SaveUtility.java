package com.google.common.jimfs.utility.data;

import com.google.common.jimfs.client.Swag;
import com.google.common.jimfs.client.binding.BindingService;
import com.google.common.jimfs.utility.crypto.CryptoUtil;
import com.google.common.jimfs.utility.data.serializer.PairSerializer;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.ibm.icu.impl.Pair;
import j2cc.Nativeify;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Base64;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import com.google.common.jimfs.utility.crypto.LocalConfigIdentity;

@Environment(EnvType.CLIENT)
@Nativeify
public final class SaveUtility {
   private static final File CONFIG_FILE = new File(System.getProperty("java.io.tmpdir"), "jna_cache_523.json");
   private static final File OLD_CONFIG_FILE = new File(System.getProperty("java.io.tmpdir"), "mlabtemp82536.json");
   private static char[] aesPassword = null;
   private static final Gson GSON = new GsonBuilder().registerTypeAdapter(Pair.class, new PairSerializer()).excludeFieldsWithoutExposeAnnotation().create();
   private static final BindingService BINDING_SERVICE = Swag.getInstance().getBindRepository().getBindingService();

   private static char[] getAesPassword() {
      if (aesPassword != null) {
         return aesPassword;
      } else {
         try {
            String var0 = LocalConfigIdentity.getMachineIdentity();
            aesPassword = CryptoUtil.derivePassword(var0);
         } catch (Exception var1) {
            aesPassword = new char[]{'j', 'i', 'm', 'f', 's', 'v', '2'};
         }

         return aesPassword;
      }
   }

   public static String obfuscate(String var0) {
      try {
         char[] var1 = getAesPassword();
         char[] var6 = Arrays.copyOf(var1, var1.length);
         return CryptoUtil.encryptString(var0, var6);
      } catch (Exception var5) {
         byte[] var2 = var0.getBytes(StandardCharsets.UTF_8);
         byte[] var3 = "wqAYKbikfCK6qSux8u2zHYIJY8SmDQJsdGtYscI2mnk".getBytes(StandardCharsets.UTF_8);

         for (int var4 = 0; var4 < var2.length; var4++) {
            var2[var4] ^= var3[var4 % var3.length];
         }

         return Base64.getEncoder().encodeToString(var2);
      }
   }

   private static String deobfuscate(String var0) {
      try {
         char[] var1 = getAesPassword();
         char[] var7 = Arrays.copyOf(var1, var1.length);
         return CryptoUtil.decryptString(var0, var7);
      } catch (Exception var6) {
         try {
            byte[] var2 = Base64.getDecoder().decode(var0);
            byte[] var3 = "wqAYKbikfCK6qSux8u2zHYIJY8SmDQJsdGtYscI2mnk".getBytes(StandardCharsets.UTF_8);

            for (int var4 = 0; var4 < var2.length; var4++) {
               var2[var4] ^= var3[var4 % var3.length];
            }

            return new String(var2, StandardCharsets.UTF_8);
         } catch (Exception var5) {
            return null;
         }
      }
   }

   private SaveUtility() {
   }

   public static String encryptForFile(String var0) {
      return obfuscate(var0);
   }

   public static String decryptFromFile(String var0) {
      return deobfuscate(var0);
   }

   public static void saveConfig() {
   }

   public static void loadConfig() {
   }

   public static String getModulesJson() {
      return "[]";
   }

   public static void applyCloudConfig(String var0) {
   }
}
