package com.google.common.jimfs.event.impl.game.player.movement;

import net.minecraft.class_243;

public final class PostMoveEvent {
   private final float recoveredField063;
   private final class_243 recoveredField137;

   public PostMoveEvent(float var1, class_243 var2) {
      this.recoveredField063 = var1;
      this.recoveredField137 = var2;
   }
}
