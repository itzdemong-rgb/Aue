package com.google.common.jimfs.mixin.world;

import com.google.common.jimfs.client.feature.helper.impl.render.FrustumHelper;
import com.google.common.jimfs.utility.render.ESPUtility;
import com.llamalad7.mixinextras.sugar.Local;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_11658;
import net.minecraft.class_4184;
import net.minecraft.class_4604;
import net.minecraft.class_761;
import net.minecraft.class_9779;
import net.minecraft.class_9922;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({class_761.class})
public final class WorldRendererMixin {
   @Shadow
   @Final
   private class_11658 field_61737;

   @Redirect(
      method = {"getTransparencyPostEffectProcessor"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/MinecraftClient;usesImprovedTransparency()Z"
      )
   )
   private boolean kW() {
      return true;
   }

   @Inject(
      method = {"render"},
      at = {@At("HEAD")}
   )
   private void xR(
      class_9922 var1,
      class_9779 var2,
      boolean var3,
      class_4184 var4,
      Matrix4f var5,
      Matrix4f var6,
      Matrix4f var7,
      GpuBufferSlice var8,
      Vector4f var9,
      boolean var10,
      CallbackInfo var11
   ) {
      ESPUtility.recoveredField042.set(var7);
      ESPUtility.recoveredField107.set(var5);
      ESPUtility.recoveredField045 = true;
   }

   @Inject(
      method = {"render"},
      at = {@At(
         value = "INVOKE_ASSIGN",
         target = "Lnet/minecraft/client/render/WorldRenderer;setupFrustum(Lorg/joml/Matrix4f;Lorg/joml/Matrix4f;Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/client/render/Frustum;",
         shift = Shift.AFTER
      )}
   )
   private void dG(CallbackInfo var1, @Local class_4604 var2) {
      FrustumHelper.a(var2);
   }
}
