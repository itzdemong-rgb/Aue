package com.google.common.jimfs.mixin.client;

import com.google.common.jimfs.duck.ClientPlayerEntityAccess;
import com.google.common.jimfs.duck.ClientPlayerInteractionManagerAccess;
import com.google.common.jimfs.event.EventDispatcher;
import com.google.common.jimfs.event.impl.game.player.PlayerCreateEvent;
import com.google.common.jimfs.event.impl.game.player.PreUpdateEvent;
import com.google.common.jimfs.event.impl.game.player.interaction.SwingEvent;
import com.google.common.jimfs.event.impl.game.player.interaction.VisualSwingEvent;
import com.google.common.jimfs.event.impl.game.player.movement.PostMovementPacketEvent;
import com.google.common.jimfs.event.impl.game.player.movement.PreMovementPacketEvent;
import com.google.common.jimfs.event.impl.game.player.movement.PushOutOfBlocksEvent;
import com.google.common.jimfs.event.impl.game.player.movement.SlowdownEvent;
import com.google.common.jimfs.event.impl.game.player.movement.SprintEvent;
import com.google.common.jimfs.event.impl.press.KeyPressEvent;
import com.google.common.jimfs.mixin.jRtF;
import com.google.common.jimfs.utility.player.RotationUtility;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.mojang.authlib.GameProfile;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10185;
import net.minecraft.class_1268;
import net.minecraft.class_2338;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_2879;
import net.minecraft.class_299;
import net.minecraft.class_310;
import net.minecraft.class_3469;
import net.minecraft.class_3532;
import net.minecraft.class_634;
import net.minecraft.class_638;
import net.minecraft.class_742;
import net.minecraft.class_744;
import net.minecraft.class_746;
import net.minecraft.class_2828.class_2831;
import net.minecraft.class_2828.class_5911;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({class_746.class})
public abstract class ClientPlayerEntityMixin extends class_742 implements ClientPlayerEntityAccess {
   @Unique
   private float jimfs$lastSentYaw = 0.0F;
   @Unique
   private static final boolean[] jimfs$prevKeyState = new boolean[]{
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false
   };
   @Shadow
   public class_744 field_3913;
   @Shadow
   @Final
   public class_634 field_3944;
   @Unique
   private PreMovementPacketEvent preMovementPacketEvent;
   @Unique
   private boolean prevHandSwinging;
   @Unique
   private int prevHandSwingTicks;

   @Inject(
      method = {"tickMovement"},
      at = {@At("HEAD")}
   )
   private void a(CallbackInfo var1) {
      long var2 = class_310.method_1551().method_22683().method_4490();

      for (int var4 = 32; var4 <= 348; var4++) {
         boolean var5 = GLFW.glfwGetKey(var2, var4) == 1;
         if (var5 && !jimfs$prevKeyState[var4]) {
            EventDispatcher.b(new KeyPressEvent(var4));
         }

         jimfs$prevKeyState[var4] = var5;
      }
   }

   public ClientPlayerEntityMixin(class_638 var1, GameProfile var2) {
      super(var1, var2);
   }

   @Shadow
   protected abstract boolean method_3134();

   @Shadow
   public abstract boolean method_5869();

   @Shadow
   public abstract boolean method_5715();

   @Inject(
      method = {"<init>"},
      at = {@At("TAIL")}
   )
   private void c(class_310 var1, class_638 var2, class_634 var3, class_3469 var4, class_299 var5, class_10185 var6, boolean var7, CallbackInfo var8) {
      EventDispatcher.b(new PlayerCreateEvent());
   }

   @Inject(
      method = {"tickMovementInput"},
      at = {@At("TAIL")}
   )
   private void d(CallbackInfo var1) {
      if (this.method_3134()) {
      }
   }

   @Inject(
      method = {"swingHand"},
      at = {@At("HEAD")}
   )
   private void e(class_1268 var1, CallbackInfo var2) {
      this.prevHandSwinging = this.field_6252;
      this.prevHandSwingTicks = this.field_6279;
   }

   @Inject(
      method = {"swingHand"},
      at = {@At("TAIL")}
   )
   private void f(class_1268 var1, CallbackInfo var2) {
      EventDispatcher.b(new SwingEvent(var1));
      VisualSwingEvent var3 = new VisualSwingEvent(var1);
      EventDispatcher.b(var3);
      if (var3.isCancelled()) {
         this.field_6252 = this.prevHandSwinging;
         this.field_6279 = this.prevHandSwingTicks;
      }
   }

   @Inject(
      method = {"pushOutOfBlocks"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void g(double var1, double var3, CallbackInfo var5) {
      PushOutOfBlocksEvent var6 = new PushOutOfBlocksEvent();
      EventDispatcher.b(var6);
      if (var6.isCancelled()) {
         var5.cancel();
      }
   }

   @Redirect(
      method = {"applyMovementSpeedFactors"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/util/math/Vec2f;multiply(F)Lnet/minecraft/util/math/Vec2f;",
         ordinal = 1
      )
   )
   private class_241 h(class_241 var1, float var2) {
      SlowdownEvent var3 = new SlowdownEvent(var2);
      EventDispatcher.b(var3);
      return var1.method_35582(var3.isCancelled() ? 1.0F : var3.getMultiplier());
   }

   @Inject(
      method = {"sendMovementPackets"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void i(CallbackInfo var1) {
      RotationUtility.recoveredField190 = false;
      float var2 = this.method_36454();
      float var3 = this.method_36455();
      if (RotationUtility.recoveredField045) {
         boolean var4 = false;
         class_310 var5 = class_310.method_1551();
         if (var5.field_1761 != null) {
            class_2338 var6 = ((ClientPlayerInteractionManagerAccess)var5.field_1761).jimfs$getCurrentBreakingPos();
            var4 = var6 != null;
         }

         if (!var4) {
            var2 = RotationUtility.recoveredField001;
            var3 = RotationUtility.recoveredField063;
         }
      }

      this.preMovementPacketEvent = new PreMovementPacketEvent(
         this.method_23317(), this.method_23318(), this.method_23321(), var2, var3, this.method_24828(), this.method_5624(), this.field_5976
      );
      EventDispatcher.b(this.preMovementPacketEvent);
      if (this.preMovementPacketEvent.isCancelled()) {
         RotationUtility.recoveredField170 = false;
         var1.cancel();
      }
   }

   @Redirect(
      method = {"tick"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/util/PlayerInput;equals(Ljava/lang/Object;)Z"
      )
   )
   private boolean j(class_10185 var1, Object var2) {
      return this.preMovementPacketEvent != null && this.preMovementPacketEvent.e() ? false : var1.equals(var2);
   }

   @Redirect(
      method = {"sendMovementPackets"},
      at = @At(
         value = "FIELD",
         target = "Lnet/minecraft/client/network/ClientPlayerEntity;horizontalCollision:Z",
         opcode = 180
      )
   )
   private boolean k(class_746 var1) {
      return this.preMovementPacketEvent == null ? var1.field_5976 : this.preMovementPacketEvent.d();
   }

   @Redirect(
      method = {"sendSprintingPacket"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/network/ClientPlayerEntity;isSprinting()Z"
      )
   )
   private boolean l(class_746 var1) {
      return this.preMovementPacketEvent != null && this.preMovementPacketEvent.recoveredMethod110();
   }

   @Inject(
      method = {"sendMovementPackets"},
      at = {@At("RETURN")}
   )
   private void m(CallbackInfo var1) {
      if (this.preMovementPacketEvent != null && !this.preMovementPacketEvent.isCancelled()) {
         if (this.preMovementPacketEvent.f() && !RotationUtility.recoveredField190) {
            boolean var2 = false;
            float var3 = this.method_36454();
            float var4 = this.method_36455();
            if (RotationUtility.recoveredField045) {
               boolean var5 = false;
               class_310 var6 = class_310.method_1551();
               if (var6.field_1761 != null) {
                  class_2338 var7 = ((ClientPlayerInteractionManagerAccess)var6.field_1761).jimfs$getCurrentBreakingPos();
                  var5 = var7 != null;
               }

               if (!var5) {
                  var2 = true;
                  var3 = RotationUtility.recoveredField001;
                  var4 = RotationUtility.recoveredField063;
               }
            }

            jRtF var10 = (jRtF)this;
            float var11 = var2 ? this.jimfs$lastSentYaw + class_3532.method_15393(var3 - this.jimfs$lastSentYaw) : this.method_36454();
            float var12 = var2 ? var4 : this.method_36455();
            boolean var8 = this.preMovementPacketEvent.isOnGround();
            boolean var9 = this.preMovementPacketEvent.d();
            if (!var2 && var11 == var10.D() && var12 == var10.E()) {
               this.field_3944.method_52787(new class_5911(var8, var9));
            } else {
               this.field_3944.method_52787(new class_2831(var11, var12, var8, var9));
               var10.A(var11);
               var10.B(var12);
               this.jimfs$lastSentYaw = var11;
            }

            var10.C(var8);
            var10.J(var10.H() + 1);
         }

         EventDispatcher.b(
            new PostMovementPacketEvent(
               this.preMovementPacketEvent.getX(),
               this.preMovementPacketEvent.getY(),
               this.preMovementPacketEvent.getZ(),
               this.preMovementPacketEvent.getYaw(),
               this.preMovementPacketEvent.getPitch(),
               this.preMovementPacketEvent.isOnGround(),
               this.preMovementPacketEvent.recoveredMethod110()
            )
         );
      }

      RotationUtility.recoveredField170 = false;
      RotationUtility.recoveredField190 = false;
      this.preMovementPacketEvent = null;
   }

   @Redirect(
      method = {"sendMovementPackets"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/network/ClientPlayerEntity;getYaw()F"
      )
   )
   private float n(class_746 var1) {
      if (this.preMovementPacketEvent == null) {
         float var4 = var1.method_36454();
         this.jimfs$lastSentYaw = var4;
         return var4;
      } else {
         float var2 = this.preMovementPacketEvent.getYaw();
         float var3 = this.jimfs$lastSentYaw + class_3532.method_15393(var2 - this.jimfs$lastSentYaw);
         this.jimfs$lastSentYaw = var3;
         return var3;
      }
   }

   @Redirect(
      method = {"sendMovementPackets"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/network/ClientPlayerEntity;getPitch()F"
      )
   )
   private float o(class_746 var1) {
      return this.preMovementPacketEvent == null ? var1.method_36455() : this.preMovementPacketEvent.getPitch();
   }

   @Redirect(
      method = {"sendMovementPackets"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/network/ClientPlayerEntity;isOnGround()Z"
      )
   )
   private boolean p(class_746 var1) {
      return this.preMovementPacketEvent == null ? var1.method_24828() : this.preMovementPacketEvent.isOnGround();
   }

   @Redirect(
      method = {"sendMovementPackets"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/network/ClientPlayerEntity;getX()D"
      )
   )
   private double q(class_746 var1) {
      return this.preMovementPacketEvent == null ? var1.method_23317() : this.preMovementPacketEvent.getX();
   }

   @Redirect(
      method = {"sendMovementPackets"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/network/ClientPlayerEntity;getY()D"
      )
   )
   private double r(class_746 var1) {
      return this.preMovementPacketEvent == null ? var1.method_23318() : this.preMovementPacketEvent.getY();
   }

   @Redirect(
      method = {"sendMovementPackets"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/network/ClientPlayerEntity;getZ()D"
      )
   )
   private double s(class_746 var1) {
      return this.preMovementPacketEvent == null ? var1.method_23321() : this.preMovementPacketEvent.getZ();
   }

   @Redirect(
      method = {"sendMovementPackets"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/network/ClientPlayerEntity;getEntityPos()Lnet/minecraft/util/math/Vec3d;"
      )
   )
   private class_243 t(class_746 var1) {
      return this.preMovementPacketEvent == null
         ? var1.method_73189()
         : new class_243(
            this.preMovementPacketEvent.getX(),
            this.preMovementPacketEvent.getY(),
            this.preMovementPacketEvent.getZ()
         );
   }

   @Inject(
      method = {"tick"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/util/Cooldown;tick()V"
      )}
   )
   private void u(CallbackInfo var1) {
      EventDispatcher.b(new PreUpdateEvent());
   }

   @Unique
   private boolean v() {
      return Math.abs(this.field_3913.method_3128().field_1342) > 1.0E-5F || Math.abs(this.field_3913.method_3128().field_1343) > 1.0E-5F;
   }

   @ModifyReturnValue(
      method = {"canStartSprinting"},
      at = {@At("RETURN")}
   )
   private boolean w(boolean var1) {
      SprintEvent var2 = new SprintEvent(var1);
      EventDispatcher.b(var2);
      return var2.isSprinting();
   }

   @Unique
   @Override
   public void jimfs$swingHandClientside(class_1268 var1) {
      super.method_6104(var1);
   }

   @Unique
   @Override
   public void jimfs$swingHandServerside(class_1268 var1) {
      this.field_3944.method_52787(new class_2879(var1));
      EventDispatcher.b(new SwingEvent(var1));
   }
}
