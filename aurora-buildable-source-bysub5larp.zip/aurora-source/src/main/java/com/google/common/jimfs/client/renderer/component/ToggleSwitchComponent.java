package com.google.common.jimfs.client.renderer.component;

import com.google.common.jimfs.utility.render.ScreenPosition;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class ToggleSwitchComponent extends ScreenPosition {
}
