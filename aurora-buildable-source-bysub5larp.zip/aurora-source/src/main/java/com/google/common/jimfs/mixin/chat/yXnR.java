package com.google.common.jimfs.mixin.chat;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2583;
import net.minecraft.class_303.class_7590;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin({class_7590.class})
public final class yXnR {
   @Unique
   private static class_2583 dQw;

   @Inject(
      method = {"content"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void hBt(CallbackInfoReturnable var1) {
   }
}
