package com.google.common.jimfs.client.feature.helper.impl.player.rotation;

import com.google.common.jimfs.client.feature.helper.impl.player.rotation.handler.ClientRotationHandler;
import com.google.common.jimfs.recovered.MouseRotationController;

public final class RotationHelper {
   private static final ClientRotationHandler HANDLER = new ClientRotationHandler();
   private static final MouseRotationController MOUSE_ROTATION_CONTROLLER = new MouseRotationController();

   public static ClientRotationHandler getClientRotationHandler() {
      return HANDLER;
   }
}
