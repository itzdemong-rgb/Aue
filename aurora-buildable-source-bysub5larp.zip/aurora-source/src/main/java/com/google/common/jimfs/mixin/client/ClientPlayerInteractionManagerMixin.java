package com.google.common.jimfs.mixin.client;

import com.google.common.jimfs.client.Swag;
import com.google.common.jimfs.client.feature.helper.impl.player.slot.SlotHelper;
import com.google.common.jimfs.duck.ClientPlayerInteractionManagerAccess;
import com.google.common.jimfs.event.EventDispatcher;
import com.google.common.jimfs.event.impl.game.player.interaction.CancelBlockBreakingEvent;
import com.google.common.jimfs.event.impl.game.player.interaction.HnWqPm;
import com.google.common.jimfs.event.impl.game.player.interaction.block.PostBlockInteractEvent;
import com.google.common.jimfs.event.impl.game.player.interaction.block.PreBlockInteractEvent;
import com.google.common.jimfs.m.AutoMace;
import com.google.common.jimfs.m.AutoHitCrystalModule;
import com.google.common.jimfs.m.AnchorMacroModule;
import com.google.common.jimfs.m.AutoCrystalModule;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_636;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin({class_636.class})
public class ClientPlayerInteractionManagerMixin implements ClientPlayerInteractionManagerAccess {
   @Shadow
   private class_2338 field_3714;
   @Shadow
   private float field_3715;
   @Shadow
   private int field_3721;

   private ClientPlayerInteractionManagerMixin() {
   }

   @Inject(
      method = {"attackEntity"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void a(class_1657 var1, class_1297 var2, CallbackInfo var3) {
      EventDispatcher.b(new HnWqPm(var2));
   }

   @Inject(
      method = {"interactBlock"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void b(class_746 var1, class_1268 var2, class_3965 var3, CallbackInfoReturnable var4) {
   }

   @Inject(
      method = {"interactEntity"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void c(class_1657 var1, class_1297 var2, class_1268 var3, CallbackInfoReturnable var4) {
      if (var2 instanceof class_1511) {
         if (Swag.getInstance() != null && Swag.getInstance().getModuleRepository() != null) {
            boolean var5 = Swag.getInstance()
               .getModuleRepository()
               .getModules()
               .stream()
               .anyMatch(
                  var0 -> var0.isEnabled()
                        && (var0 instanceof AutoHitCrystalModule || var0 instanceof AutoCrystalModule || var0 instanceof AutoMace || var0 instanceof AnchorMacroModule)
               );
            if (!var5) {
               return;
            }
         }

         var4.setReturnValue(class_1269.field_5811);
      }
   }

   @Inject(
      method = {"interactEntityAtLocation"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void d(class_1657 var1, class_1297 var2, class_3966 var3, class_1268 var4, CallbackInfoReturnable var5) {
      if (var2 instanceof class_1511) {
         if (Swag.getInstance() != null && Swag.getInstance().getModuleRepository() != null) {
            boolean var6 = Swag.getInstance()
               .getModuleRepository()
               .getModules()
               .stream()
               .anyMatch(
                  var0 -> var0.isEnabled()
                        && (var0 instanceof AutoHitCrystalModule || var0 instanceof AutoCrystalModule || var0 instanceof AutoMace || var0 instanceof AnchorMacroModule)
               );
            if (!var6) {
               return;
            }
         }

         var5.setReturnValue(class_1269.field_5811);
      }
   }

   @Inject(
      method = {"interactBlock"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/network/ClientPlayerInteractionManager;sendSequencedPacket(Lnet/minecraft/client/world/ClientWorld;Lnet/minecraft/client/network/SequencedPacketCreator;)V"
      )}
   )
   private void e(class_746 var1, class_1268 var2, class_3965 var3, CallbackInfoReturnable var4) {
      EventDispatcher.b(new PreBlockInteractEvent());
   }

   @Inject(
      method = {"interactBlock"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/network/ClientPlayerInteractionManager;sendSequencedPacket(Lnet/minecraft/client/world/ClientWorld;Lnet/minecraft/client/network/SequencedPacketCreator;)V",
         shift = Shift.AFTER
      )}
   )
   private void f(class_746 var1, class_1268 var2, class_3965 var3, CallbackInfoReturnable var4) {
      EventDispatcher.b(new PostBlockInteractEvent());
   }

   @Inject(
      method = {"tick"},
      at = {@At("HEAD")}
   )
   private void g(CallbackInfo var1) {
      SlotHelper.getInstance().tick();
   }

   @Override
   public class_2338 jimfs$getCurrentBreakingPos() {
      return this.field_3714;
   }

   @Override
   public float jimfs$currentBreakingProgress() {
      return this.field_3715;
   }

   @Inject(
      method = {"cancelBlockBreaking"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void h(CallbackInfo var1) {
      CancelBlockBreakingEvent var2 = new CancelBlockBreakingEvent();
      EventDispatcher.b(var2);
      if (var2.isCancelled()) {
         var1.cancel();
      }
   }
}
