package com.google.common.jimfs.event.impl.press;

import com.google.common.jimfs.recovered.InputPressEvent;

public class KeyPressEvent extends InputPressEvent {
   public KeyPressEvent(int var1) {
      super(var1);
   }

   @Override
   public int getCode() {
      return super.getCode();
   }
}
