package com.google.common.jimfs.mixin.network;

import com.google.common.jimfs.event.EventDispatcher;
import com.google.common.jimfs.event.impl.game.chat.ChatReceivedEvent;
import com.mojang.authlib.GameProfile;
import java.time.Instant;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_7471;
import net.minecraft.class_7594;
import net.minecraft.class_2556.class_7602;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin({class_7594.class})
public final class jRtF {
   @Inject(
      method = {"processChatMessageInternal"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/gui/hud/InGameHud;getChatHud()Lnet/minecraft/client/gui/hud/ChatHud;",
         ordinal = 0
      )},
      cancellable = true
   )
   private void kS(class_7602 var1, class_7471 var2, class_2561 var3, GameProfile var4, boolean var5, Instant var6, CallbackInfoReturnable var7) {
      this.fT(var3, var7);
   }

   @Inject(
      method = {"processChatMessageInternal"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/gui/hud/InGameHud;getChatHud()Lnet/minecraft/client/gui/hud/ChatHud;",
         ordinal = 1
      )},
      cancellable = true
   )
   private void xR(class_7602 var1, class_7471 var2, class_2561 var3, GameProfile var4, boolean var5, Instant var6, CallbackInfoReturnable var7) {
      class_2561 var8 = var2.comp_981().method_46256(var2.method_44862());
      if (var8 != null) {
         this.fT(var1.method_44837(var8), var7);
      }
   }

   @Inject(
      method = {"method_45745"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void dG(class_7602 var1, class_2561 var2, Instant var3, CallbackInfoReturnable var4) {
      this.fT(var1.method_44837(var2), var4);
   }

   @Unique
   private void fT(class_2561 var1, CallbackInfoReturnable var2) {
      ChatReceivedEvent var3 = new ChatReceivedEvent(var1, false);
      EventDispatcher.b(var3);
      if (var3.isCancelled()) {
         var2.setReturnValue(false);
      }
   }

   @Inject(
      method = {"onGameMessage"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void hT(class_2561 var1, boolean var2, CallbackInfo var3) {
      ChatReceivedEvent var4 = new ChatReceivedEvent(var1, var2);
      EventDispatcher.b(var4);
      if (var4.isCancelled()) {
         var3.cancel();
      }
   }
}
