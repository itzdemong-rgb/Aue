package com.google.common.jimfs.utility.misc.system;

import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.lwjgl.BufferUtils;

@Environment(EnvType.CLIENT)
public final class IOUtility {

   public static ByteBuffer a(InputStream var0, int var1) {
      boolean var2 = false;

      try {
         if (var0 != null) {
            ByteBuffer var4;
            try (ReadableByteChannel var3 = Channels.newChannel(var0)) {
               var4 = BufferUtils.createByteBuffer(var1);

               while (true) {
                  int var5 = var3.read(var4);
                  if (var5 == -1) {
                     break;
                  }

                  if (var4.remaining() == 0) {
                     var4 = b(var4, var4.capacity() * 3 / 2);
                  }
               }
            }

            var4.flip();
            return var4;
         } else {
            throw new IllegalArgumentException("InputStream cannot be null");
         }
      } catch (IOException var9) {
         var9.printStackTrace();
         return null;
      }
   }

   private static ByteBuffer b(ByteBuffer var0, int var1) {
      ByteBuffer var2 = BufferUtils.createByteBuffer(var1);
      var0.flip();
      var2.put(var0);
      return var2;
   }

}
