package com.google.common.jimfs.utility.player;

import com.google.common.jimfs.client.Constants;
import com.google.common.jimfs.mixin.input.KeyBindingAccessor;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import net.minecraft.class_9334;
import org.lwjgl.glfw.GLFW;

public final class PlayerUtility {
   public static final List<class_304> recoveredField092 = List.of(
      Constants.MINECRAFT.field_1690.field_1894,
      Constants.MINECRAFT.field_1690.field_1881,
      Constants.MINECRAFT.field_1690.field_1913,
      Constants.MINECRAFT.field_1690.field_1849,
      Constants.MINECRAFT.field_1690.field_1903
   );
   private static boolean recoveredField141;

   public static boolean isMouseButtonPressed(int var0) {
      return class_3675.method_15987(Constants.MINECRAFT.method_22683(), var0);
   }

   public static boolean b(class_304 var0) {
      return isMouseButtonPressed(((KeyBindingAccessor)var0).xR().method_1444());
   }

   public static boolean c(int var0) {
      boolean var1 = true;
      return GLFW.glfwGetMouseButton(Constants.MINECRAFT.method_22683().method_4490(), var0) == 1;
   }

   public static void restoreKeyStates() {
      recoveredField092.forEach(var0 -> class_304.method_1416(((KeyBindingAccessor)var0).xR(), b(var0)));
   }

   public static void releaseKeyStates() {
      recoveredField092.forEach(var0 -> class_304.method_1416(((KeyBindingAccessor)var0).xR(), false));
   }

   public static boolean d() {
      boolean var0 = true;
      if (Constants.MINECRAFT.field_1724 == null) {
         return false;
      } else {
         if (Constants.MINECRAFT.field_1724.method_6115()) {
            class_1799 var1 = Constants.MINECRAFT.field_1724.method_6030();
            if (!var1.method_7960() && (var1.method_57826(class_9334.field_50075) || var1.method_31574(class_1802.field_8255))) {
               return true;
            }
         }

         return false;
      }
   }

   static {
      b(true);
   }

   public static void b(boolean var0) {
      recoveredField141 = var0;
   }

   public static boolean e() {
      return recoveredField141;
   }

   public static boolean f() {
      boolean var0 = e();
      return !var0;
   }

}
