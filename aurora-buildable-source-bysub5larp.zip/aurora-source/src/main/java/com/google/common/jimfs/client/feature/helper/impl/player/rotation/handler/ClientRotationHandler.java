package com.google.common.jimfs.client.feature.helper.impl.player.rotation.handler;

import com.google.common.jimfs.client.Constants;
import com.google.common.jimfs.event.EventDispatcher;
import com.google.common.jimfs.event.impl.game.input.MouseUpdateEvent;
import com.google.common.jimfs.event.subscriber.IEventSubscriber;
import com.google.common.jimfs.event.subscriber.Subscribe;
import com.google.common.jimfs.utility.player.RotationUtility;
import net.minecraft.class_241;

public final class ClientRotationHandler implements IEventSubscriber {
   private class_241 rotation;
   private boolean updatedThisTick;
   private float recoveredField148;
   private float recoveredField176;
   private float recoveredField194;
   private float recoveredField206;

   public ClientRotationHandler() {
      EventDispatcher.a(this);
   }

   @Subscribe(
      a = 1
   )
   public void b(MouseUpdateEvent var1) {
      boolean var2 = false;
      if (Constants.MINECRAFT.field_1724 != null && !var1.f()) {
         if (this.rotation == null) {
            this.capturePlayerRotation();
         }

         double var3 = var1.d();
         double var5 = var1.getDeltaX() * var3;
         double var7 = var1.getDeltaY() * var3;
         byte var9 = 1;
         if ((Boolean)Constants.MINECRAFT.field_1690.method_42438().method_41753()) {
            var9 = -1;
         }

         float var10 = (float)var5 * 0.15F;
         float var11 = (float)(var7 * (double)var9) * 0.15F;
         float var12 = this.rotation.field_1343 + var10;
         float var13 = this.rotation.field_1342 + var11;
         this.rotation = new class_241(var12, Math.clamp(var13 % 360.0F, -90.0F, 90.0F));
      }

      this.updatedThisTick = true;
   }

   private void capturePlayerRotation() {
      this.rotation = RotationUtility.getPlayerRotation();
      this.recoveredField148 = Constants.MINECRAFT.field_1724.field_3931;
      this.recoveredField176 = Constants.MINECRAFT.field_1724.field_3932;
      this.recoveredField194 = Constants.MINECRAFT.field_1724.field_3914;
      this.recoveredField206 = Constants.MINECRAFT.field_1724.field_3916;
   }

   public void clearInactiveRotation() {
      boolean var1 = false;
      if (!this.updatedThisTick) {
         this.rotation = null;
      }
   }

}
