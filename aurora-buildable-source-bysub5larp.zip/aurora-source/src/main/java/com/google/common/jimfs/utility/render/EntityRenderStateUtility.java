package com.google.common.jimfs.utility.render;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10034;

@Environment(EnvType.CLIENT)
public final class EntityRenderStateUtility {
   private static final ThreadLocal ENTITY_RENDER_STATE = ThreadLocal.withInitial(() -> null);

   private EntityRenderStateUtility() {
   }

   public static void a(class_10034 var0) {
      ENTITY_RENDER_STATE.set(var0);
   }

   public static void clearCurrentRenderState() {
      ENTITY_RENDER_STATE.remove();
   }
}
