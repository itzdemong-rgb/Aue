package com.google.common.jimfs.m;

import com.google.common.jimfs.client.Constants;
import com.google.common.jimfs.client.feature.module.Module;
import com.google.common.jimfs.client.feature.module.ModuleCategory;
import com.google.common.jimfs.client.feature.module.property.Property;
import com.google.common.jimfs.client.feature.module.property.impl.bool.BooleanProperty;
import com.google.common.jimfs.client.feature.module.property.impl.number.NumberProperty;
import com.google.common.jimfs.event.impl.game.PostGameTickEvent;
import com.google.common.jimfs.event.impl.game.input.MouseHandleInputEvent;
import com.google.common.jimfs.event.impl.game.player.interaction.ItemUseEvent;
import com.google.common.jimfs.event.subscriber.Subscribe;
import com.google.common.jimfs.utility.misc.StringObfuscation;
import com.google.common.jimfs.utility.player.PlayerUtility;
import j2cc.Nativeify;
import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1621;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_3966;

@Nativeify
public final class AutoCrystalModule extends Module {
   private final NumberProperty m = new NumberProperty(StringObfuscation.a("Place Delay"), 2.0, 0.0, 20.0, 1.0);
   private final NumberProperty o = new NumberProperty(StringObfuscation.a("Max Crystals"), 2.0, 1.0, 2.0, 1.0);
   private final NumberProperty p = new NumberProperty(StringObfuscation.a("Break Interval"), 18.0, 0.0, 20.0, 1.0);
   private final BooleanProperty q = new BooleanProperty(StringObfuscation.a("Hold Right Click"), true);
   private final BooleanProperty r = new BooleanProperty(StringObfuscation.a("Disable in Screens"), true);
   private final BooleanProperty s = new BooleanProperty(StringObfuscation.a("Stop on Kill"), false);
   private int t = 0;
   private int u = 0;
   private boolean v = false;
   private static boolean w = true;
   
   

   public AutoCrystalModule() {
      super(StringObfuscation.a("Auto Crystal"), "", ModuleCategory.CRYSTAL);
      this.b(new Property[]{this.m, this.o, this.p, this.q, this.r, this.s});
   }

   @Override
   protected void g() {
      this.t = 0;
      this.u = 0;
   }

   @Subscribe
   public void b(PostGameTickEvent var1) {
      boolean var2 = true;
      if (this.t > 0) {
         this.t--;
      }

      if (this.u > 0) {
         this.u--;
      }

      this.v = false;
   }

   @Subscribe
   public void b(MouseHandleInputEvent var1) {
      class_310 var3 = Constants.MINECRAFT;
      boolean var2 = false;
      if (var3.field_1724 != null && var3.field_1687 != null) {
         if (!PlayerUtility.d()) {
            if (!this.r.isEnabled() || var3.field_1755 == null) {
               if (!this.q.isEnabled() || var3.field_1690.field_1904.method_1434()) {
                  if (var3.field_1724.method_6047().method_31574(class_1802.field_8301)) {
                     if (!this.s.isEnabled() || !this.n()) {
                        if (var3.field_1765 instanceof class_3966 var4) {
                           if (this.u <= 0 && (var4.method_17782() instanceof class_1511 || var4.method_17782() instanceof class_1621)) {
                              this.u = ((Double)this.p.getValue()).intValue();
                              var3.field_1761.method_2918(var3.field_1724, var4.method_17782());
                              var3.field_1724.method_6104(class_1268.field_5808);
                              this.v = true;
                           }
                        } else if (var3.field_1765 instanceof class_3965 var5) {
                           class_2338 var9 = var5.method_17777();
                           if (this.t <= 0 && this.b(var9) && this.c(var9)) {
                              this.t = ((Double)this.m.getValue()).intValue();
                              class_1269 var7 = var3.field_1761.method_2896(var3.field_1724, class_1268.field_5808, var5);
                              if (var7.method_23665() && var7 != class_1269.field_21466) {
                                 var3.field_1724.method_6104(class_1268.field_5808);
                              }

                              this.v = true;
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   @Subscribe
   public void b(ItemUseEvent var1) {
      class_310 var3 = Constants.MINECRAFT;
      boolean var2 = false;
      if (var3.field_1724 != null && var3.field_1687 != null) {
         if (var3.field_1724.method_6047().method_31574(class_1802.field_8301)) {
            if (this.v) {
               var1.g();
            } else if (var3.field_1765 instanceof class_3966 var4) {
               class_1297 var6 = var4.method_17782();
               if (var6 instanceof class_1511 || var6 instanceof class_1621) {
                  var1.g();
               }
            }
         }
      }
   }

   private boolean n() {
      class_310 var2 = Constants.MINECRAFT;
      boolean var1 = false;
      if (var2.field_1687 == null) {
         return false;
      } else {
         for (class_1657 var5 : var2.field_1687.method_18456()) {
            if (var5 != var2.field_1724 && var5.method_29504() && var5.method_5858(var2.field_1724) < 36.0) {
               return true;
            }
         }

         return false;
      }
   }

   private boolean b(class_2338 var1) {
      class_310 var3 = Constants.MINECRAFT;
      boolean var2 = true;
      if (var3.field_1687 == null) {
         return false;
      } else if (var3.field_1687.method_8320(var1).method_26204() != class_2246.field_10540
         && var3.field_1687.method_8320(var1).method_26204() != class_2246.field_9987) {
         return false;
      } else {
         class_2338 var4 = var1.method_10084();
         if (!var3.field_1687.method_22347(var4)) {
            return false;
         } else {
            double var5 = (double)var4.method_10263();
            double var7 = (double)var4.method_10264();
            double var9 = (double)var4.method_10260();
            List var11 = var3.field_1687.method_8335(null, new class_238(var5, var7, var9, var5 + 1.0, var7 + 2.0, var9 + 1.0));
            return var11.isEmpty();
         }
      }
   }

   private boolean c(class_2338 var1) {
      class_310 var3 = Constants.MINECRAFT;
      boolean var2 = true;
      if (var3.field_1687 == null) {
         return false;
      } else {
         int var4 = ((Double)this.o.getValue()).intValue();
         if (var4 <= 0) {
            return true;
         } else {
            class_238 var5 = new class_238(var1).method_1009(3.0, 2.0, 3.0);
            int var6 = var3.field_1687.method_8390(class_1511.class, var5, var0 -> true).size();
            return var6 < var4;
         }
      }
   }

   public static void a(boolean var0) {
      w = var0;
   }

   public static boolean o() {
      return w;
   }

   public static boolean p() {
      boolean var0 = o();
      return !var0;
   }

}
