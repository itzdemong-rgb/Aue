package com.google.common.jimfs.utility.render;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_4588;
import net.minecraft.class_4587.class_4665;

@Environment(EnvType.CLIENT)
public final class Emitter {
   public static void a(
      class_4665 var0,
      class_4588 var1,
      float var2,
      float var3,
      float var4,
      float var5,
      float var6,
      float var7,
      float var8,
      float var9,
      float var10,
      float var11,
      float var12,
      float var13,
      float var14,
      float var15,
      float var16,
      float var17,
      float var18,
      float var19,
      float var20,
      float var21,
      float var22,
      float var23,
      float var24,
      float var25,
      float var26,
      float var27,
      float var28,
      float var29,
      float var30,
      float var31,
      float var32,
      float var33,
      float var34,
      float var35,
      float var36,
      float var37,
      float var38,
      float var39,
      float var40,
      float var41,
      float var42,
      float var43,
      float var44,
      float var45,
      float var46,
      float var47,
      float var48,
      float var49,
      float var50,
      float var51,
      float var52,
      float var53,
      float var54,
      float var55,
      float var56,
      float var57
   ) {
      var1.method_56824(var0, var23, var24, var25).method_22915(var26, var27, var28, var29);
      var1.method_56824(var0, var2, var3, var4).method_22915(var5, var6, var7, var8);
      var1.method_56824(var0, var9, var10, var11).method_22915(var12, var13, var14, var15);
      var1.method_56824(var0, var16, var17, var18).method_22915(var19, var20, var21, var22);
      var1.method_56824(var0, var30, var31, var32).method_22915(var33, var34, var35, var36);
      var1.method_56824(var0, var51, var52, var53).method_22915(var54, var55, var56, var57);
      var1.method_56824(var0, var44, var45, var46).method_22915(var47, var48, var49, var50);
      var1.method_56824(var0, var37, var38, var39).method_22915(var40, var41, var42, var43);
      var1.method_56824(var0, var2, var3, var4).method_22915(var5, var6, var7, var8);
      var1.method_56824(var0, var30, var31, var32).method_22915(var33, var34, var35, var36);
      var1.method_56824(var0, var37, var38, var39).method_22915(var40, var41, var42, var43);
      var1.method_56824(var0, var9, var10, var11).method_22915(var12, var13, var14, var15);
      var1.method_56824(var0, var9, var10, var11).method_22915(var12, var13, var14, var15);
      var1.method_56824(var0, var37, var38, var39).method_22915(var40, var41, var42, var43);
      var1.method_56824(var0, var44, var45, var46).method_22915(var47, var48, var49, var50);
      var1.method_56824(var0, var16, var17, var18).method_22915(var19, var20, var21, var22);
      var1.method_56824(var0, var16, var17, var18).method_22915(var19, var20, var21, var22);
      var1.method_56824(var0, var44, var45, var46).method_22915(var47, var48, var49, var50);
      var1.method_56824(var0, var51, var52, var53).method_22915(var54, var55, var56, var57);
      var1.method_56824(var0, var23, var24, var25).method_22915(var26, var27, var28, var29);
      var1.method_56824(var0, var23, var24, var25).method_22915(var26, var27, var28, var29);
      var1.method_56824(var0, var51, var52, var53).method_22915(var54, var55, var56, var57);
      var1.method_56824(var0, var30, var31, var32).method_22915(var33, var34, var35, var36);
      var1.method_56824(var0, var2, var3, var4).method_22915(var5, var6, var7, var8);
   }
}
