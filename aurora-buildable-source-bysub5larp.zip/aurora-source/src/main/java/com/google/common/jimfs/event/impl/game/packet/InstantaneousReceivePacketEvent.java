package com.google.common.jimfs.event.impl.game.packet;

import com.google.common.jimfs.recovered.CancellableEvent;
import net.minecraft.class_2596;

public final class InstantaneousReceivePacketEvent extends CancellableEvent {
   private final class_2596 packet;

   public InstantaneousReceivePacketEvent(class_2596 var1) {
      this.packet = var1;
   }
}
