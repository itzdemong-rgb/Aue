package com.google.common.jimfs.recovered;

import com.google.common.jimfs.client.feature.module.property.Property;
import net.minecraft.class_1309;

public abstract class ServerProfile implements ClientEventSubscriber {
   private final String recoveredField091;
   private static Property[] scratchProperties = new Property[4];

   public ServerProfile(String var1) {
      this.recoveredField091 = var1;
   }

   public boolean b(class_1309 var1) {
      return true;
   }

   @Override
   public boolean e() {
      return this == WorldStateTracker.getInstance().getServerProfileDetector().getActiveProfile();
   }

   public static void b(Property[] var0) {
      scratchProperties = var0;
   }

   public static Property[] getScratchProperties() {
      return scratchProperties;
   }

}
