package com.google.common.jimfs.mixin.render;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_11228;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import net.minecraft.class_758;
import net.minecraft.class_9920;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Environment(EnvType.CLIENT)
@Mixin({class_757.class})
public interface GameRendererAccessor {
   @Accessor("pool")
   class_9920 kW();

   @Invoker("getFov")
   float xR(class_4184 var1, float var2, boolean var3);

   @Invoker("tiltViewWhenHurt")
   void dG(class_4587 var1, float var2);

   @Invoker("bobView")
   void hT(class_4587 var1, float var2);

   @Accessor("guiRenderer")
   class_11228 fT();

   @Accessor("fogRenderer")
   class_758 bN();
}
