package com.google.common.jimfs.recovered;

import com.google.common.jimfs.client.feature.module.Module;
import com.google.common.jimfs.event.subscriber.IEventSubscriber;

public abstract class ModuleModeHandler implements IEventSubscriber {
   protected Module module;
   private boolean active;

   public void onEnabled() {
      boolean var1 = false;
      if (this.module.j() == this) {
         this.active = true;
      }
   }

   public void onDisabled() {
      boolean var1 = false;
      if (this.module.j() == this) {
         this.active = false;
      }
   }

   public abstract Enum d();

}
