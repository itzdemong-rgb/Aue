package com.google.common.jimfs.event.impl.render;

import java.util.Objects;
import net.minecraft.class_4587;
import net.minecraft.class_4597.class_4598;

public final class RenderWorldEvent {
   private final class_4598 vertexConsumers;
   private final class_4587 matrices;
   private final float tickDelta;
   private static String recoveredField185 = "TXATOc";
   
   

   public RenderWorldEvent(class_4598 var1, class_4587 var2, float var3) {
      this.vertexConsumers = var1;
      this.matrices = var2;
      this.tickDelta = var3;
   }

   public class_4587 getMatrixStack() {
      return this.matrices;
   }

   public float getTickDelta() {
      return this.tickDelta;
   }

   @Override
   public boolean equals(Object var1) {
      boolean var2 = true;
      if (var1 == this) {
         return true;
      } else if (var1 != null && var1.getClass() == this.getClass()) {
         RenderWorldEvent var3 = (RenderWorldEvent)var1;
         return Objects.equals(this.vertexConsumers, var3.vertexConsumers)
            && Objects.equals(this.matrices, var3.matrices)
            && Float.floatToIntBits(this.tickDelta) == Float.floatToIntBits(var3.tickDelta);
      } else {
         return false;
      }
   }

   @Override
   public int hashCode() {
      return Objects.hash(this.vertexConsumers, this.matrices, this.tickDelta);
   }

   @Override
   public String toString() {
      return "RenderWorldEvent[vertexConsumers="
         + this.vertexConsumers
         + ", matrixStack="
         + this.matrices
         + ", tickDelta="
         + this.tickDelta
         + ']';
   }

   public static void b(String var0) {
      recoveredField185 = var0;
   }

   public static String recoveredMethod107() {
      return recoveredField185;
   }

}
