package com.google.common.jimfs.m;

import com.google.common.jimfs.client.Constants;
import com.google.common.jimfs.client.feature.module.Module;
import com.google.common.jimfs.client.feature.module.ModuleCategory;
import com.google.common.jimfs.client.feature.module.property.Property;
import com.google.common.jimfs.client.feature.module.property.impl.KeybindProperty;
import com.google.common.jimfs.client.feature.module.property.impl.bool.BooleanProperty;
import com.google.common.jimfs.client.feature.module.property.impl.number.NumberProperty;
import com.google.common.jimfs.event.impl.game.PreGameTickEvent;
import com.google.common.jimfs.event.impl.game.player.interaction.ItemUseEvent;
import com.google.common.jimfs.event.subscriber.Subscribe;
import com.google.common.jimfs.mixin.mWpL;
import com.google.common.jimfs.utility.misc.StringObfuscation;
import com.google.common.jimfs.utility.player.PlayerUtility;
import j2cc.Nativeify;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1268;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2885;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_4969;
import net.minecraft.class_239.class_240;

@Nativeify
public final class AnchorMacroModule extends Module {
   private final BooleanProperty m = new BooleanProperty(StringObfuscation.a("While Use"), true);
   private final BooleanProperty o = new BooleanProperty(StringObfuscation.a("Stop on Kill"), false);
   private final BooleanProperty p = new BooleanProperty(StringObfuscation.a("Click Simulation"), false);
   private final NumberProperty q = new NumberProperty(StringObfuscation.a("Switch Delay"), 0.0, 0.0, 20.0, 1.0);
   private final NumberProperty r = new NumberProperty(StringObfuscation.a("Glowstone Delay"), 0.0, 0.0, 20.0, 1.0);
   private final NumberProperty s = new NumberProperty(StringObfuscation.a("Explode Delay"), 0.0, 0.0, 20.0, 1.0);
   private final NumberProperty t = new NumberProperty(StringObfuscation.a("Explode Slot"), 1.0, 1.0, 9.0, 1.0);
   private final BooleanProperty u = new BooleanProperty(StringObfuscation.a("Only Own"), false);
   private final BooleanProperty v = new BooleanProperty(StringObfuscation.a("Only Charge"), false);
   private final NumberProperty w = new NumberProperty(StringObfuscation.a("Stop at 1 Charge %"), 100.0, 0.0, 100.0, 1.0);
   private final NumberProperty x = new NumberProperty(StringObfuscation.a("Stop at 2 Charge %"), 0.0, 0.0, 100.0, 1.0);
   private final NumberProperty y = new NumberProperty(StringObfuscation.a("Stop at 3 Charge %"), 0.0, 0.0, 100.0, 1.0);
   private final NumberProperty z = new NumberProperty(StringObfuscation.a("Max Charges"), 1.0, 1.0, 3.0, 1.0);
   private final BooleanProperty A = new BooleanProperty(StringObfuscation.a("Enable Jitter"), false);
   private final NumberProperty B = new NumberProperty(StringObfuscation.a("Jitter Intensity"), 0.5, 0.0, 5.0, 0.1);
   private final NumberProperty C = new NumberProperty(StringObfuscation.a("Jitter Exponent"), 1.5, 1.0, 3.0, 0.1);
   private final NumberProperty D = new NumberProperty(StringObfuscation.a("Jitter Start Threshold"), 2.0, 0.0, 10.0, 1.0);
   private final BooleanProperty E = new BooleanProperty(StringObfuscation.a("Show Jitter Graph"), false);
   private final KeybindProperty F = new KeybindProperty(StringObfuscation.a("Double Anchor Key"), -1);
   private final BooleanProperty G = new BooleanProperty(StringObfuscation.a("Allow Player Clicks"), true);
   private int H = 0;
   private int I = 0;
   private int J = 0;
   private boolean K = false;
   private boolean L = false;
   private int M = 0;
   private final Set N = new HashSet();
   private float O = 0.0F;
   private float P = 0.0F;
   private float Q = 0.0F;
   private float R = 0.0F;
   private int S = 0;
   private long T = 0L;
   private class_2338 U;
   private int V;
   
   
   private static final long[] X = new long[]{3177351037912182571L, 4202116235738582420L};
   private static final Long[] Y = new Long[2];

   public AnchorMacroModule() {
      super(StringObfuscation.a("Anchor Macro"), StringObfuscation.a("Advanced race macro"), ModuleCategory.CRYSTAL);
      boolean var1 = false;
      this.U = null;
      this.V = 0;
      this.b(
         new Property[]{
            this.m,
            this.o,
            this.p,
            this.q,
            this.r,
            this.s,
            this.t,
            this.u,
            this.v,
            this.w,
            this.x,
            this.y,
            this.z,
            this.A,
            this.B,
            this.C,
            this.D,
            this.E,
            this.F,
            this.G
         }
      );
      if (!Property.k()) {
         Module.d(true);
      }
   }

   @Override
   protected void g() {
      this.H = 0;
      this.I = 0;
      this.J = 0;
      this.K = false;
      this.L = false;
      this.M = 0;
      this.N.clear();
      this.O = 0.0F;
      this.P = 0.0F;
      this.Q = 0.0F;
      this.R = 0.0F;
      this.S = 0;
      this.T = 0L;
      this.U = null;
      this.V = 0;
      super.g();
   }

   @Override
   protected void h() {
      this.H = 0;
      this.I = 0;
      this.J = 0;
      this.K = false;
      this.L = false;
      this.M = 0;
      this.N.clear();
      this.O = 0.0F;
      this.P = 0.0F;
      this.Q = 0.0F;
      this.R = 0.0F;
      this.S = 0;
      this.T = 0L;
      this.U = null;
      this.V = 0;
      super.h();
   }

   @Subscribe
   public void b(PreGameTickEvent var1) {
      boolean var2 = true;
      if (this.isEnabled()
         && Constants.MINECRAFT.field_1724 != null
         && Constants.MINECRAFT.field_1687 != null
         && Constants.MINECRAFT.field_1755 == null) {
         if (!PlayerUtility.d()) {
            if (!this.o.isEnabled() || !this.q()) {
               if (this.m.isEnabled() || !Constants.MINECRAFT.field_1724.method_6115()) {
                  if (this.n()) {
                     this.o();
                  } else if (!this.p()) {
                     this.K = false;
                     this.L = false;
                     this.M = 0;
                     this.O = 0.0F;
                     this.P = 0.0F;
                     this.Q = 0.0F;
                     this.R = 0.0F;
                     this.V = 0;
                  } else {
                     class_310 var3 = Constants.MINECRAFT;
                     if (var3.field_1765 instanceof class_3965 var4) {
                        if (var4.method_17783() != class_240.field_1332) {
                           this.L = false;
                        } else {
                           class_2338 var11 = var4.method_17777();
                           if (var3.field_1687.method_8320(var11).method_27852(class_2246.field_10036)
                              || var3.field_1687.method_8320(var11).method_27852(class_2246.field_22089)) {
                              class_2338 var6 = var11.method_10074();
                              if (var3.field_1687.method_8320(var6).method_27852(class_2246.field_23152)) {
                                 var11 = var6;
                              }
                           }

                           new class_3965(var4.method_17784(), var4.method_17780(), var11, var4.method_17781());
                           if (!var3.field_1687.method_8320(var11).method_27852(class_2246.field_23152)) {
                              this.L = false;
                           } else if (this.u.isEnabled() && !this.N.contains(var11)) {
                              this.L = false;
                           } else {
                              if (!this.K) {
                                 this.K = true;
                                 if (var3.field_1687.method_8320(var11).method_27852(class_2246.field_23152)) {
                                    this.L = true;
                                 }
                              }

                              if (this.L) {
                                 this.b(var3);
                                 if (this.U != null && !var11.equals(this.U)) {
                                    this.V = 0;
                                 }

                                 int var7 = Math.max(this.b(var11), var11.equals(this.U) ? this.V : 0);
                                 int var8 = ((Double)this.z.getValue()).intValue();
                                 boolean var9 = false;
                                 if (var7 >= var8) {
                                    var9 = true;
                                 } else if (var7 > 0) {
                                    int var10 = ThreadLocalRandom.current().nextInt(1, 101);
                                    if (var7 == 1 && var10 <= ((Double)this.w.getValue()).intValue()) {
                                       var9 = true;
                                    } else if (var7 == 2 && var10 <= ((Double)this.x.getValue()).intValue()) {
                                       var9 = true;
                                    } else if (var7 == 3 && var10 <= ((Double)this.y.getValue()).intValue()) {
                                       var9 = true;
                                    }
                                 }

                                 if (var7 != 0 && (var9 || var7 >= 4)) {
                                    this.b(var3, var4, var11);
                                 } else {
                                    this.b(var3, var4, var11, var7);
                                 }
                              }
                           }
                        }
                     } else {
                        this.L = false;
                     }
                  }
               }
            }
         }
      }
   }

   private void b(class_310 var1, class_3965 var2, class_2338 var3, int var4) {
      boolean var5 = true;
      if (!var1.field_1724.method_6047().method_31574(class_1802.field_8801)) {
         if (this.H < ((Double)this.q.getValue()).intValue()) {
            this.H++;
            return;
         }

         this.H = 0;
         int var6 = this.r();
         if (var6 != -1) {
            this.b(var6);
         }

         if (((Double)this.r.getValue()).intValue() > 0) {
            return;
         }
      }

      if (this.I < ((Double)this.r.getValue()).intValue()) {
         this.I++;
      } else {
         long var11 = System.currentTimeMillis();
         if (!var3.equals(this.U) || var11 - this.T >= 80L) {
            this.I = 0;
            int var8 = ((Double)this.z.getValue()).intValue();
            if (var4 < var8) {
               int var9 = 1;
               if (var4 + var9 > var8) {
                  var9 = Math.max(1, var8 - var4);
               }

               for (int var10 = 0; var10 < var9; var10++) {
                  ((mWpL)var1.field_1761).i(var1.field_1687, var1x -> new class_2885(class_1268.field_5808, var2, var1x));
                  var1.field_1724.method_6104(class_1268.field_5808);
               }

               this.T = var11;
               this.U = var3;
               this.V = var4 + var9;
            }
         }
      }
   }

   private void b(class_310 var1, class_3965 var2, class_2338 var3) {
      int var5 = ((Double)this.t.getValue()).intValue() - 1;
      boolean var4 = false;
      if (var1.field_1724.method_31548().method_67532() != var5) {
         if (this.H < ((Double)this.q.getValue()).intValue()) {
            this.H++;
            return;
         }

         this.H = 0;
         this.b(var5);
         if (((Double)this.s.getValue()).intValue() > 0) {
            return;
         }
      }

      if (this.J < ((Double)this.s.getValue()).intValue()) {
         this.J++;
      } else {
         this.J = 0;
         if (!this.v.isEnabled()) {
            ((mWpL)var1.field_1761).i(var1.field_1687, var1x -> new class_2885(class_1268.field_5808, var2, var1x));
            var1.field_1724.method_6104(class_1268.field_5808);
            this.N.remove(var3);
            this.M++;
            this.V = 4;
         }
      }
   }

   private boolean n() {
      Integer var2 = (Integer)this.F.getValue();
      boolean var1 = false;
      if (var2 != null && var2 != -1) {
         return var2 >= 0 && var2 <= 7 ? PlayerUtility.c(var2) : PlayerUtility.isMouseButtonPressed(var2);
      } else {
         return false;
      }
   }

   private void o() {
      class_310 var2 = Constants.MINECRAFT;
      boolean var1 = false;
      if (var2.field_1724 != null && var2.field_1687 != null) {
         class_2338 var3;
         class_3965 var4;
         label157: {
            if (var2.field_1765 instanceof class_3965 var5 && var5.method_17783() == class_240.field_1332) {
               class_2338 var15 = var5.method_17777();
               if (!var2.field_1687.method_8320(var15).method_27852(class_2246.field_23152)) {
                  var15 = this.b(var5);
               }

               var3 = var15;
               var4 = new class_3965(var5.method_17784(), var5.method_17780(), var15, var5.method_17781());
               break label157;
            }

            var3 = class_2338.method_49638(
               new class_243(var2.field_1724.method_23317(), var2.field_1724.method_23318(), var2.field_1724.method_23321())
                  .method_1019(var2.field_1724.method_5828(1.0F).method_1021(2.0))
            );
            var4 = new class_3965(
               new class_243((double)var3.method_10263() + 0.5, (double)var3.method_10264(), (double)var3.method_10260() + 0.5),
               class_2350.field_11036,
               var3.method_10074(),
               false
            );
         }

         if (var3 != null) {
            this.b(var2);
            if (!var2.field_1687.method_8320(var3).method_27852(class_2246.field_23152)) {
               int var13 = this.s();
               if (var13 != -1) {
                  this.b(var13);
                  ((mWpL)var2.field_1761).i(var2.field_1687, var1x -> new class_2885(class_1268.field_5808, var4, var1x));
                  var2.field_1724.method_6104(class_1268.field_5808);
                  this.N.add(var3);
               }
            } else {
               if (this.U != null && !var3.equals(this.U)) {
                  this.V = 0;
               }

               int var14 = Math.max(this.b(var3), var3.equals(this.U) ? this.V : 0);
               int var16 = ((Double)this.z.getValue()).intValue();
               boolean var7 = false;
               if (var14 > 0) {
                  if (var14 >= var16) {
                     var7 = true;
                  } else if (var14 == 1) {
                     if (ThreadLocalRandom.current().nextInt(1, 101) <= ((Double)this.w.getValue()).intValue()) {
                        var7 = true;
                     }
                  } else if (var14 == 2) {
                     if (ThreadLocalRandom.current().nextInt(1, 101) <= ((Double)this.x.getValue()).intValue()) {
                        var7 = true;
                     }
                  } else if (var14 == 3 && ThreadLocalRandom.current().nextInt(1, 101) <= ((Double)this.y.getValue()).intValue()) {
                     var7 = true;
                  }
               }

               if (var14 == 0 || !var7 && var14 < 4) {
                  int var17 = this.r();
                  if (var17 != -1) {
                     this.b(var17);
                     long var9 = System.currentTimeMillis();
                     if (var3.equals(this.U) && var9 - this.T < 80L) {
                        return;
                     }

                     if (var14 >= var16) {
                        return;
                     }

                     int var11 = 1;
                     if (var14 + var11 > var16) {
                        var11 = Math.max(1, var16 - var14);
                     }

                     for (int var12 = 0; var12 < var11; var12++) {
                        ((mWpL)var2.field_1761).i(var2.field_1687, var1x -> new class_2885(class_1268.field_5808, var4, var1x));
                        var2.field_1724.method_6104(class_1268.field_5808);
                     }

                     this.T = var9;
                     this.U = var3;
                     this.V = var14 + var11;
                  }
               } else {
                  int var8 = ((Double)this.t.getValue()).intValue() - 1;
                  if (var8 >= 0 && var8 <= 8) {
                     this.b(var8);
                     ((mWpL)var2.field_1761).i(var2.field_1687, var1x -> new class_2885(class_1268.field_5808, var4, var1x));
                     var2.field_1724.method_6104(class_1268.field_5808);
                     this.N.remove(var3);
                     this.M++;
                     this.V = 4;
                  }
               }
            }
         }
      }
   }

   private void b(class_310 var1) {
      boolean var2 = false;
      if (this.A.isEnabled() && var1.field_1724 != null) {
         float var3 = ((Double)this.D.getValue()).floatValue();
         if ((float)this.M <= var3) {
            this.O = 0.0F;
            this.P = 0.0F;
            this.Q = 0.0F;
            this.R = 0.0F;
         } else {
            double var4 = (Double)this.B.getValue() * 0.35 * Math.pow((double)((float)this.M - var3), (Double)this.C.getValue());
            this.S++;
            if (this.S >= 3) {
               this.S = 0;
               this.Q = (float)((ThreadLocalRandom.current().nextDouble() - 0.5) * var4);
               this.R = (float)((ThreadLocalRandom.current().nextDouble() - 0.5) * var4);
            }

            this.O = this.O + (this.Q - this.O) * 0.22F;
            this.P = this.P + (this.R - this.P) * 0.22F;
            var1.field_1724.method_36456(var1.field_1724.method_36454() + this.O);
            var1.field_1724.method_36457(var1.field_1724.method_36455() + this.P);
         }
      } else {
         this.O = 0.0F;
         this.P = 0.0F;
         this.Q = 0.0F;
         this.R = 0.0F;
      }
   }

   @Subscribe
   public void b(ItemUseEvent var1) {
      boolean var2 = true;
      if (this.isEnabled() && Constants.MINECRAFT.field_1724 != null) {
         if (this.L && !this.G.isEnabled()) {
            var1.g();
         }

         class_310 var3 = Constants.MINECRAFT;
         if (var3.field_1765 instanceof class_3965 var4
            && var4.method_17783() == class_240.field_1332
            && var3.field_1724.method_6047().method_31574(class_1802.field_23141)) {
            this.N.add(this.b(var4));
         }
      }
   }

   private boolean p() {
      return Constants.MINECRAFT.field_1690.field_1904.method_1434();
   }

   private boolean q() {
      class_310 var2 = Constants.MINECRAFT;
      boolean var1 = false;
      return var2.field_1687 != null && var2.field_1724 != null
         ? var2.field_1687.method_18456().stream().filter(var1x -> var1x != var2.field_1724).filter(var1x -> {
            boolean var2x = false;
            return var1x.method_5739(var2.field_1724) < 6.0F;
         }).anyMatch(var0 -> {
            boolean var1x = false;
            return var0.method_31481() || var0.method_7325() || var0.method_6032() <= 0.0F;
         })
         : false;
   }

   private void b(int var1) {
      class_310 var3 = Constants.MINECRAFT;
      boolean var2 = true;
      if (var3.field_1724 != null && var3.field_1724.method_31548().method_67532() != var1) {
         var3.field_1724.method_31548().method_61496(var1);
         ((mWpL)var3.field_1761).j();
      }
   }

   private int r() {
      class_310 var2 = Constants.MINECRAFT;
      boolean var1 = false;
      if (var2.field_1724 == null) {
         return -1;
      } else {
         for (int var3 = 0; var3 < 9; var3++) {
            if (var2.field_1724.method_31548().method_5438(var3).method_31574(class_1802.field_8801)) {
               return var3;
            }
         }

         return -1;
      }
   }

   private int s() {
      class_310 var2 = Constants.MINECRAFT;
      boolean var1 = false;
      if (var2.field_1724 == null) {
         return -1;
      } else {
         for (int var3 = 0; var3 < 9; var3++) {
            if (var2.field_1724.method_31548().method_5438(var3).method_31574(class_1802.field_23141)) {
               return var3;
            }
         }

         return -1;
      }
   }

   private int b(class_2338 var1) {
      class_310 var3 = Constants.MINECRAFT;
      boolean var2 = false;

      try {
         if (var3.field_1687 != null && var3.field_1687.method_8320(var1).method_27852(class_2246.field_23152)) {
            return (Integer)var3.field_1687.method_8320(var1).method_11654(class_4969.field_23153);
         }
      } catch (Exception var5) {
      }

      return 0;
   }

   private class_2338 b(class_3965 var1) {
      class_2350 var3 = var1.method_17780();
      class_2338 var4 = var1.method_17777();
      boolean var2 = false;
      class_310 var5 = Constants.MINECRAFT;
      if (var5.field_1687 != null && !var5.field_1687.method_8320(var4).method_45474()) {
         return switch (var3) {
            case field_11036 -> var4.method_10069(0, 1, 0);
            case field_11033 -> var4.method_10069(0, -1, 0);
            case field_11043 -> var4.method_10069(0, 0, -1);
            case field_11035 -> var4.method_10069(0, 0, 1);
            case field_11039 -> var4.method_10069(-1, 0, 0);
            case field_11034 -> var4.method_10069(1, 0, 0);
            default -> throw new MatchException(null, null);
         };
      } else {
         return var4;
      }
   }

}
