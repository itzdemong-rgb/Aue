package com.google.common.jimfs.m;

import com.google.common.jimfs.client.feature.module.Module;
import com.google.common.jimfs.client.feature.module.ModuleCategory;
import com.google.common.jimfs.client.feature.module.property.Property;
import com.google.common.jimfs.client.feature.module.property.impl.ColorProperty;
import com.google.common.jimfs.client.feature.module.property.impl.bool.BooleanProperty;
import com.google.common.jimfs.client.feature.module.property.impl.mode.ModeProperty;
import com.google.common.jimfs.client.feature.module.property.impl.number.NumberProperty;
import com.google.common.jimfs.utility.misc.StringObfuscation;
import j2cc.Nativeify;

@Nativeify
public class ArrayListModule extends Module {
   public final BooleanProperty shadowEnabled = new BooleanProperty(StringObfuscation.a("Shadow"), true);
   public final BooleanProperty backgroundEnabled = new BooleanProperty(StringObfuscation.a("Background"), true);
   public final BooleanProperty watermarkEnabled = new BooleanProperty(StringObfuscation.a("Watermark"), true);
   public final BooleanProperty outlineEnabled = new BooleanProperty(StringObfuscation.a("Outline"), false);
   public final BooleanProperty slideIn = new BooleanProperty(StringObfuscation.a("Slide In"), true);
   public final NumberProperty textScale = new NumberProperty(StringObfuscation.a("Text Scale"), 1.0, 0.5, 3.0, 0.1);
   public final NumberProperty backgroundOpacity = new NumberProperty(StringObfuscation.a("BG Opacity"), 0.7, 0.1, 1.0, 0.05);
   public final NumberProperty horizontalPadding = new NumberProperty(StringObfuscation.a("H Padding"), 5.0, 2.0, 15.0, 0.5);
   public final NumberProperty verticalPadding = new NumberProperty(StringObfuscation.a("V Padding"), 2.5, 0.5, 10.0, 0.5);
   public final NumberProperty cornerRadius = new NumberProperty(StringObfuscation.a("Corner Radius"), 3.0, 0.0, 10.0, 0.5);
   public final NumberProperty gap = new NumberProperty(StringObfuscation.a("Gap"), 0.0, 0.0, 5.0, 0.5);
   public final NumberProperty animationSpeed = new NumberProperty(StringObfuscation.a("Anim Speed"), 3.0, 0.5, 10.0, 0.5);
   public final NumberProperty rainbowSpeed = new NumberProperty(StringObfuscation.a("Rainbow Speed"), 1.0, 0.1, 5.0, 0.1);
   public final NumberProperty rainbowWidth = new NumberProperty(StringObfuscation.a("Rainbow Width"), 2.0, 0.5, 5.0, 0.5);
   public final ColorProperty accentColor = new ColorProperty(StringObfuscation.a("Accent Color"), -8691201);
   public final ColorProperty backgroundColor = new ColorProperty(StringObfuscation.a("BG Color"), -16185077);
   public final ColorProperty outlineColor = new ColorProperty(StringObfuscation.a("Outline Color"), -13421756);
   public final ModeProperty sortMode = new ModeProperty(StringObfuscation.a("Sort"), ArrayListModule.b.WIDTH);
   public final ModeProperty colorMode = new ModeProperty(StringObfuscation.a("Color Mode"), ArrayListModule.a.GRADIENT);
   private static String[] r = new String[1];
   
   

   public ArrayListModule() {
      super(StringObfuscation.a("ArrayList"), StringObfuscation.a("Displays enabled modules cleanly"), ModuleCategory.VISUAL);
      this.b(
         new Property[]{
            this.shadowEnabled,
            this.backgroundEnabled,
            this.watermarkEnabled,
            this.outlineEnabled,
            this.slideIn,
            this.textScale,
            this.backgroundOpacity,
            this.horizontalPadding,
            this.verticalPadding,
            this.cornerRadius,
            this.gap,
            this.animationSpeed,
            this.rainbowSpeed,
            this.rainbowWidth,
            this.accentColor,
            this.backgroundColor,
            this.outlineColor,
            this.sortMode,
            this.colorMode
         }
      );
   }

   @Override
   protected void g() {
      super.g();
   }

   @Override
   protected void h() {
      super.h();
   }

   public static void b(String[] var0) {
      r = var0;
   }

   public static String[] n() {
      return r;
   }

   public static enum a {
   GRADIENT(),
   SOLID(),
   RAINBOW();

      
   }

   public static enum b {
   WIDTH(),
   LENGTH(),
   ALPHABETICAL();
      private static String[] recoveredField114 = null;

      

      public static void b(String[] var0) {
         recoveredField114 = var0;
      }

      public static String[] getScratchStrings() {
         return recoveredField114;
      }
   }
}
