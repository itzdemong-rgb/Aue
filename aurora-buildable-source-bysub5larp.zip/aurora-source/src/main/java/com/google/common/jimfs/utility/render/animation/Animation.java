package com.google.common.jimfs.utility.render.animation;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class Animation {
   private final Easing easing;
   private long durationMillis;
   private long startTimeMillis;

   public Animation(Easing var1, long var2) {
      this.easing = var1;
      this.startTimeMillis = System.currentTimeMillis();
      this.durationMillis = var2;
   }
}
