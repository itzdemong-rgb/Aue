package com.google.common.jimfs.fabric;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.api.ModInitializer;

@Environment(EnvType.CLIENT)
public final class FabricMlab implements ModInitializer {
   public void onInitialize() {
   }
}
