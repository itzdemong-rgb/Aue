package com.google.common.jimfs.client.renderer.shader;

import com.google.common.jimfs.client.Constants;
import com.google.common.jimfs.client.renderer.NVGRenderer;
import java.nio.ByteBuffer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10868;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;

@Environment(EnvType.CLIENT)
public class ShaderFramebuffer {
   private static int horizontalFramebufferId = 0;
   private static int horizontalTextureId = 0;
   private static int verticalFramebufferId = 0;
   private static int verticalTextureId = 0;
   private static int blurShaderProgramId = 0;
   private static int vertexArrayId = 0;
   private static int framebufferWidth = 0;
   private static int framebufferHeight = 0;
   private static long lastRenderNanos = 0L;
   private static int backgroundShaderProgramId = 0;
   private static boolean nanoVgImagesRegistered = false;

   private static void initializeBlurShader() {
      if (blurShaderProgramId == 0) {
         String var0 = "#version 330 core\nout vec2 TexCoords;\nvoid main() {\n    float x = -1.0 + float((gl_VertexID & 1) << 2);\n    float y = -1.0 + float((gl_VertexID & 2) << 1);\n    TexCoords = vec2((x + 1.0) * 0.5, (y + 1.0) * 0.5);\n    gl_Position = vec4(x, y, 0.0, 1.0);\n}\n";
         String var1 = "#version 330 core\nout vec4 FragColor;\nin vec2 TexCoords;\nuniform sampler2D image;\nuniform vec2 direction;\nvoid main() {\n    vec4 color = vec4(0.0);\n    float totalWeight = 0.0;\n    float weights[5] = float[](0.227027, 0.1945946, 0.1216216, 0.054054, 0.0162162);\n    color += texture(image, TexCoords) * weights[0];\n    totalWeight += weights[0];\n    for (int i = 1; i < 5; i++) {\n        vec2 offset = direction * float(i);\n        color += texture(image, TexCoords + offset) * weights[i];\n        color += texture(image, TexCoords - offset) * weights[i];\n        totalWeight += weights[i] * 2.0;\n    }\n    FragColor = color / totalWeight;\n}\n";
         int var2 = GL20.glCreateShader(35633);
         GL20.glShaderSource(var2, var0);
         GL20.glCompileShader(var2);
         if (GL20.glGetShaderi(var2, 35713) == 0) {
            System.err.println("Failed to compile vertex shader: " + GL20.glGetShaderInfoLog(var2));
         }

         int var3 = GL20.glCreateShader(35632);
         GL20.glShaderSource(var3, var1);
         GL20.glCompileShader(var3);
         if (GL20.glGetShaderi(var3, 35713) == 0) {
            System.err.println("Failed to compile fragment shader: " + GL20.glGetShaderInfoLog(var3));
         }

         blurShaderProgramId = GL20.glCreateProgram();
         GL20.glAttachShader(blurShaderProgramId, var2);
         GL20.glAttachShader(blurShaderProgramId, var3);
         GL20.glLinkProgram(blurShaderProgramId);
         if (GL20.glGetProgrami(blurShaderProgramId, 35714) == 0) {
            System.err.println("Failed to link shader program: " + GL20.glGetProgramInfoLog(blurShaderProgramId));
         }

         GL20.glDeleteShader(var2);
         GL20.glDeleteShader(var3);
         vertexArrayId = GL30.glGenVertexArrays();
      }
   }

   private static void initializeBackgroundShader() {
      if (backgroundShaderProgramId == 0) {
         String var0 = "#version 330 core\nvoid main() {\n    float x = -1.0 + float((gl_VertexID & 1) << 2);\n    float y = -1.0 + float((gl_VertexID & 2) << 1);\n    gl_Position = vec4(x, y, 0.0, 1.0);\n}\n";
         String var1 = "#version 330 core\nout vec4 FragColor;\nuniform vec2 resolution;\nuniform vec2 mouse;\nuniform float time;\nfloat sdStar(vec2 p, float r) {\n    p = abs(p);\n    return length(p - min(p.x + p.y, r) * 0.5) - 0.01;\n}\nfloat hash(vec2 p) {\n    return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);\n}\nvoid main() {\n    vec2 uv = (gl_FragCoord.xy - 0.5 * resolution.xy) / resolution.y;\n    vec3 color = vec3(0.0);\n    for(float i=0.0; i<3.0; i++) {\n        vec2 gridUv = fract(uv * (5.0 + i * 2.0) + vec2(time * 0.1 * (i+1.0), time * 0.05)) - 0.5;\n        vec2 gridId = floor(uv * (5.0 + i * 2.0) + vec2(time * 0.1 * (i+1.0), time * 0.05));\n        float h = hash(gridId + i);\n        if (h > 0.8) {\n            float size = (sin(time * 2.0 + h * 6.28) * 0.5 + 0.5) * 0.1;\n            float d = sdStar(gridUv, size);\n            float glow = 0.01 / max(d, 0.0001);\n            color += vec3(0.6, 0.4, 1.0) * glow * (h - 0.8) * 5.0;\n        }\n    }\n    FragColor = vec4(color, max(max(color.r, color.g), color.b));\n}\n";
         int var2 = GL20.glCreateShader(35633);
         GL20.glShaderSource(var2, var0);
         GL20.glCompileShader(var2);
         int var3 = GL20.glCreateShader(35632);
         GL20.glShaderSource(var3, var1);
         GL20.glCompileShader(var3);
         backgroundShaderProgramId = GL20.glCreateProgram();
         GL20.glAttachShader(backgroundShaderProgramId, var2);
         GL20.glAttachShader(backgroundShaderProgramId, var3);
         GL20.glLinkProgram(backgroundShaderProgramId);
         GL20.glDeleteShader(var2);
         GL20.glDeleteShader(var3);
      }
   }

   public static void a(int var0, int var1, float var2, float var3, float var4) {
      initializeBackgroundShader();
      if (backgroundShaderProgramId != 0) {
         int var5 = GL11.glGetInteger(35725);
         int var6 = GL11.glGetInteger(34229);
         boolean var7 = GL11.glIsEnabled(3042);
         GL11.glEnable(3042);
         GL11.glBlendFunc(770, 1);
         GL20.glUseProgram(backgroundShaderProgramId);
         GL30.glBindVertexArray(vertexArrayId);
         int var8 = GL20.glGetUniformLocation(backgroundShaderProgramId, "time");
         int var9 = GL20.glGetUniformLocation(backgroundShaderProgramId, "resolution");
         int var10 = GL20.glGetUniformLocation(backgroundShaderProgramId, "mouse");
         GL20.glUniform1f(var8, var2);
         GL20.glUniform2f(var9, (float)var0, (float)var1);
         GL20.glUniform2f(var10, var3, var4);
         GL11.glDrawArrays(4, 0, 3);
         GL20.glUseProgram(var5);
         GL30.glBindVertexArray(var6);
         GL11.glBlendFunc(770, 771);
         if (!var7) {
            GL11.glDisable(3042);
         }
      }
   }

   public static void render() {
      if (Constants.MINECRAFT != null && Constants.MINECRAFT.method_22683() != null && Constants.MINECRAFT.method_1522() != null) {
         long var0 = System.nanoTime();
         if (var0 - lastRenderNanos >= 8000000L) {
            lastRenderNanos = var0;
            initializeBlurShader();
            int var2 = Constants.MINECRAFT.method_22683().method_4489();
            int var3 = Constants.MINECRAFT.method_22683().method_4506();
            if (var2 > 0 && var3 > 0) {
               if (var2 != framebufferWidth || var3 != framebufferHeight) {
                  a(var2, var3);
               }

               if (horizontalFramebufferId != 0 && verticalFramebufferId != 0) {
                  if (!nanoVgImagesRegistered) {
                     NVGRenderer.a(var2, var3, verticalTextureId, NVGRenderer.recoveredField109);
                     NVGRenderer.a(var2, var3, verticalTextureId, NVGRenderer.recoveredField140);
                     if (NVGRenderer.getNanoVGContext() != 0L) {
                        nanoVgImagesRegistered = true;
                     }
                  }

                  int var4 = 0;

                  try {
                     if (Constants.MINECRAFT.method_1522().method_30277() instanceof class_10868 var6) {
                        var4 = var6.method_68427();
                     }
                  } catch (Exception var17) {
                     System.err.println("MlabGL: Failed to get screen texture ID: " + var17.getMessage());
                     return;
                  }

                  if (var4 != 0) {
                     if (var4 != 0) {
                        int var18 = GL11.glGetInteger(36006);
                        int var19 = GL11.glGetInteger(35725);
                        int var7 = GL11.glGetInteger(34229);
                        int var8 = GL11.glGetInteger(32873);
                        int[] var9 = new int[4];
                        GL11.glGetIntegerv(2978, var9);
                        boolean var10 = GL11.glIsEnabled(3042);
                        boolean var11 = GL11.glIsEnabled(2929);
                        boolean var12 = GL11.glIsEnabled(3089);
                        boolean var13 = GL11.glIsEnabled(2960);
                        boolean var14 = GL11.glIsEnabled(2884);
                        GL11.glDisable(3042);
                        GL11.glDisable(2929);
                        GL11.glDisable(3089);
                        GL11.glDisable(2960);
                        GL11.glDisable(2884);
                        GL11.glColorMask(true, true, true, true);
                        GL11.glViewport(0, 0, var2, var3);
                        GL20.glUseProgram(blurShaderProgramId);
                        GL30.glBindVertexArray(vertexArrayId);
                        int var15 = GL20.glGetUniformLocation(blurShaderProgramId, "direction");
                        GL30.glBindFramebuffer(36160, horizontalFramebufferId);
                        GL11.glBindTexture(3553, var4);
                        float var16 = 6.0F;
                        GL20.glUniform2f(var15, var16 / (float)var2, 0.0F);
                        GL11.glDrawArrays(4, 0, 3);
                        GL30.glBindFramebuffer(36160, verticalFramebufferId);
                        GL11.glBindTexture(3553, horizontalTextureId);
                        GL20.glUniform2f(var15, 0.0F, var16 / (float)var3);
                        GL11.glDrawArrays(4, 0, 3);
                        GL30.glBindFramebuffer(36160, var18);
                        GL20.glUseProgram(var19);
                        GL30.glBindVertexArray(var7);
                        GL11.glBindTexture(3553, var8);
                        GL11.glViewport(var9[0], var9[1], var9[2], var9[3]);
                        if (var10) {
                           GL11.glEnable(3042);
                        }

                        if (var11) {
                           GL11.glEnable(2929);
                        }

                        if (var12) {
                           GL11.glEnable(3089);
                        }

                        if (var13) {
                           GL11.glEnable(2960);
                        }

                        if (var14) {
                           GL11.glEnable(2884);
                        }
                     }
                  }
               }
            }
         }
      }
   }

   public static void a(int var0, int var1) {
      if (var0 > 0 && var1 > 0) {
         framebufferWidth = var0;
         framebufferHeight = var1;
         initializeBlurShader();
         if (horizontalFramebufferId != 0) {
            GL30.glDeleteFramebuffers(horizontalFramebufferId);
            GL11.glDeleteTextures(horizontalTextureId);
         }

         if (verticalFramebufferId != 0) {
            GL30.glDeleteFramebuffers(verticalFramebufferId);
            GL11.glDeleteTextures(verticalTextureId);
         }

         horizontalFramebufferId = GL30.glGenFramebuffers();
         horizontalTextureId = GL11.glGenTextures();
         GL11.glBindTexture(3553, horizontalTextureId);
         GL11.glTexImage2D(3553, 0, 6408, var0, var1, 0, 6408, 5121, (ByteBuffer)null);
         GL11.glTexParameteri(3553, 10241, 9729);
         GL11.glTexParameteri(3553, 10240, 9729);
         GL11.glTexParameteri(3553, 10242, 33071);
         GL11.glTexParameteri(3553, 10243, 33071);
         GL30.glBindFramebuffer(36160, horizontalFramebufferId);
         GL30.glFramebufferTexture2D(36160, 36064, 3553, horizontalTextureId, 0);
         verticalFramebufferId = GL30.glGenFramebuffers();
         verticalTextureId = GL11.glGenTextures();
         GL11.glBindTexture(3553, verticalTextureId);
         GL11.glTexImage2D(3553, 0, 6408, var0, var1, 0, 6408, 5121, (ByteBuffer)null);
         GL11.glTexParameteri(3553, 10241, 9729);
         GL11.glTexParameteri(3553, 10240, 9729);
         GL11.glTexParameteri(3553, 10242, 33071);
         GL11.glTexParameteri(3553, 10243, 33071);
         GL30.glBindFramebuffer(36160, verticalFramebufferId);
         GL30.glFramebufferTexture2D(36160, 36064, 3553, verticalTextureId, 0);
         GL30.glBindFramebuffer(36160, 0);
         nanoVgImagesRegistered = false;
      }
   }
}
