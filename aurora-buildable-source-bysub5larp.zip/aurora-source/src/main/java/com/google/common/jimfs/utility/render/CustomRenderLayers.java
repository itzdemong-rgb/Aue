package com.google.common.jimfs.utility.render;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_12249;
import net.minecraft.class_1921;
import org.lwjgl.opengl.GL11;

@Environment(EnvType.CLIENT)
public class CustomRenderLayers {
   public static class_1921 a(boolean var0) {
      return class_12249.method_76019();
   }

   public static class_1921 a(float var0, boolean var1) {
      return class_12249.method_76015();
   }

   public static void beginTransparentRender() {
      GL11.glDisable(2929);
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 771);
   }

   public static void endTransparentRender() {
      GL11.glEnable(2929);
      GL11.glDisable(3042);
   }
}
