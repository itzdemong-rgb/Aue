package com.google.common.jimfs.utility.misc.time;

public final class Stopwatch {
   private long startedAt;

   public Stopwatch(long var1) {
      this.startedAt = var1;
   }

   public Stopwatch() {
      this.reset();
   }

   public void reset() {
      this.startedAt = System.currentTimeMillis();
   }

   public boolean b(long var1, boolean var3) {
      boolean var4 = false;
      if (this.getElapsedMillis() > var1) {
         if (var3) {
            this.reset();
         }

         return true;
      } else {
         return false;
      }
   }

   public boolean a(long var1) {
      return this.b(var1, false);
   }

   public long getElapsedMillis() {
      return System.currentTimeMillis() - this.startedAt;
   }

}
