package com.google.common.jimfs.utility.render;

import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_238;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4587.class_4665;
import org.joml.Matrix4f;

@Environment(EnvType.CLIENT)
public class Draw3DUtility {
   public static void a(class_4587 var0, class_4588 var1, class_238 var2, Color var3) {
      class_4665 var4 = var0.method_23760();
      Matrix4f var5 = var4.method_23761();
      float var6 = (float)var3.getRed() / 255.0F;
      float var7 = (float)var3.getGreen() / 255.0F;
      float var8 = (float)var3.getBlue() / 255.0F;
      float var9 = (float)var3.getAlpha() / 255.0F;
      float var10 = (float)var2.field_1323;
      float var11 = (float)var2.field_1322;
      float var12 = (float)var2.field_1321;
      float var13 = (float)var2.field_1320;
      float var14 = (float)var2.field_1325;
      float var15 = (float)var2.field_1324;
      var1.method_22918(var5, var10, var11, var12).method_22915(var6, var7, var8, var9);
      var1.method_22918(var5, var13, var11, var12).method_22915(var6, var7, var8, var9);
      var1.method_22918(var5, var13, var11, var15).method_22915(var6, var7, var8, var9);
      var1.method_22918(var5, var10, var11, var15).method_22915(var6, var7, var8, var9);
      var1.method_22918(var5, var10, var14, var12).method_22915(var6, var7, var8, var9);
      var1.method_22918(var5, var10, var14, var15).method_22915(var6, var7, var8, var9);
      var1.method_22918(var5, var13, var14, var15).method_22915(var6, var7, var8, var9);
      var1.method_22918(var5, var13, var14, var12).method_22915(var6, var7, var8, var9);
      var1.method_22918(var5, var10, var11, var12).method_22915(var6, var7, var8, var9);
      var1.method_22918(var5, var10, var14, var12).method_22915(var6, var7, var8, var9);
      var1.method_22918(var5, var13, var14, var12).method_22915(var6, var7, var8, var9);
      var1.method_22918(var5, var13, var11, var12).method_22915(var6, var7, var8, var9);
      var1.method_22918(var5, var10, var11, var15).method_22915(var6, var7, var8, var9);
      var1.method_22918(var5, var13, var11, var15).method_22915(var6, var7, var8, var9);
      var1.method_22918(var5, var13, var14, var15).method_22915(var6, var7, var8, var9);
      var1.method_22918(var5, var10, var14, var15).method_22915(var6, var7, var8, var9);
      var1.method_22918(var5, var10, var11, var12).method_22915(var6, var7, var8, var9);
      var1.method_22918(var5, var10, var11, var15).method_22915(var6, var7, var8, var9);
      var1.method_22918(var5, var10, var14, var15).method_22915(var6, var7, var8, var9);
      var1.method_22918(var5, var10, var14, var12).method_22915(var6, var7, var8, var9);
      var1.method_22918(var5, var13, var11, var12).method_22915(var6, var7, var8, var9);
      var1.method_22918(var5, var13, var14, var12).method_22915(var6, var7, var8, var9);
      var1.method_22918(var5, var13, var14, var15).method_22915(var6, var7, var8, var9);
      var1.method_22918(var5, var13, var11, var15).method_22915(var6, var7, var8, var9);
   }

   public static void b(class_4587 var0, class_4588 var1, class_238 var2, Color var3) {
      class_4665 var4 = var0.method_23760();
      Matrix4f var5 = var4.method_23761();
      float var6 = (float)var3.getRed() / 255.0F;
      float var7 = (float)var3.getGreen() / 255.0F;
      float var8 = (float)var3.getBlue() / 255.0F;
      float var9 = (float)var3.getAlpha() / 255.0F;
      float var10 = (float)var2.field_1323;
      float var11 = (float)var2.field_1322;
      float var12 = (float)var2.field_1321;
      float var13 = (float)var2.field_1320;
      float var14 = (float)var2.field_1325;
      float var15 = (float)var2.field_1324;
      var1.method_22918(var5, var10, var11, var12).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 1.0F, 0.0F).method_75298(2.0F);
      var1.method_22918(var5, var13, var11, var12).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 1.0F, 0.0F).method_75298(2.0F);
      var1.method_22918(var5, var13, var11, var12).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 1.0F, 0.0F).method_75298(2.0F);
      var1.method_22918(var5, var13, var11, var15).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 1.0F, 0.0F).method_75298(2.0F);
      var1.method_22918(var5, var13, var11, var15).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 1.0F, 0.0F).method_75298(2.0F);
      var1.method_22918(var5, var10, var11, var15).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 1.0F, 0.0F).method_75298(2.0F);
      var1.method_22918(var5, var10, var11, var15).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 1.0F, 0.0F).method_75298(2.0F);
      var1.method_22918(var5, var10, var11, var12).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 1.0F, 0.0F).method_75298(2.0F);
      var1.method_22918(var5, var10, var14, var12).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 1.0F, 0.0F).method_75298(2.0F);
      var1.method_22918(var5, var13, var14, var12).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 1.0F, 0.0F).method_75298(2.0F);
      var1.method_22918(var5, var13, var14, var12).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 1.0F, 0.0F).method_75298(2.0F);
      var1.method_22918(var5, var13, var14, var15).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 1.0F, 0.0F).method_75298(2.0F);
      var1.method_22918(var5, var13, var14, var15).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 1.0F, 0.0F).method_75298(2.0F);
      var1.method_22918(var5, var10, var14, var15).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 1.0F, 0.0F).method_75298(2.0F);
      var1.method_22918(var5, var10, var14, var15).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 1.0F, 0.0F).method_75298(2.0F);
      var1.method_22918(var5, var10, var14, var12).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 1.0F, 0.0F).method_75298(2.0F);
      var1.method_22918(var5, var10, var11, var12).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 1.0F, 0.0F).method_75298(2.0F);
      var1.method_22918(var5, var10, var14, var12).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 1.0F, 0.0F).method_75298(2.0F);
      var1.method_22918(var5, var13, var11, var12).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 1.0F, 0.0F).method_75298(2.0F);
      var1.method_22918(var5, var13, var14, var12).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 1.0F, 0.0F).method_75298(2.0F);
      var1.method_22918(var5, var13, var11, var15).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 1.0F, 0.0F).method_75298(2.0F);
      var1.method_22918(var5, var13, var14, var15).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 1.0F, 0.0F).method_75298(2.0F);
      var1.method_22918(var5, var10, var11, var15).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 1.0F, 0.0F).method_75298(2.0F);
      var1.method_22918(var5, var10, var14, var15).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 1.0F, 0.0F).method_75298(2.0F);
   }
}
