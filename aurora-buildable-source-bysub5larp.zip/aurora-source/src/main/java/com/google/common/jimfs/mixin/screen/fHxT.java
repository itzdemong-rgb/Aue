package com.google.common.jimfs.mixin.screen;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1041;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Environment(EnvType.CLIENT)
@Mixin({class_1041.class})
public class fHxT {
   @Overwrite
   public static String method_60793() {
      return "Win32";
   }
}
