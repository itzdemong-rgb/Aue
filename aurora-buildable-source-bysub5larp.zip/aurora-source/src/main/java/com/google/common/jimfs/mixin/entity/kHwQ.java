package com.google.common.jimfs.mixin.entity;

import com.google.common.jimfs.utility.render.EntityRenderStateUtility;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10034;
import net.minecraft.class_11659;
import net.minecraft.class_4587;
import net.minecraft.class_970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({class_970.class})
public abstract class kHwQ {
   @Inject(
      method = {"render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;ILnet/minecraft/client/render/entity/state/BipedEntityRenderState;FF)V"},
      at = {@At("HEAD")}
   )
   private void a(class_4587 var1, class_11659 var2, int var3, class_10034 var4, float var5, float var6, CallbackInfo var7) {
      EntityRenderStateUtility.a(var4);
   }

   @Inject(
      method = {"render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;ILnet/minecraft/client/render/entity/state/BipedEntityRenderState;FF)V"},
      at = {@At("TAIL")}
   )
   private void b(class_4587 var1, class_11659 var2, int var3, class_10034 var4, float var5, float var6, CallbackInfo var7) {
      EntityRenderStateUtility.clearCurrentRenderState();
   }
}
