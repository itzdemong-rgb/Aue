package com.google.common.jimfs.mixin.entity;

import com.google.common.jimfs.client.Constants;
import com.google.common.jimfs.event.EventDispatcher;
import com.google.common.jimfs.event.impl.game.player.movement.JumpEvent;
import com.google.common.jimfs.event.impl.game.player.movement.JumpingCooldownEvent;
import com.google.common.jimfs.event.impl.game.player.movement.step.StepEvent;
import com.google.common.jimfs.utility.player.RotationUtility;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({class_1309.class})
public abstract class LivingEntityMovementMixin extends class_1297 {
   @Shadow
   private int field_6228;
   @Unique
   private float jimfs$originalTravelYaw;
   @Unique
   private float jimfs$originalTravelPitch;

   private LivingEntityMovementMixin(class_1299 var1, class_1937 var2) {
      super(var1, var2);
   }

   @ModifyReturnValue(
      method = {"getStepHeight"},
      at = {@At("RETURN")}
   )
   private float applyStepEvent(float var1) {
      if ((Object)this == Constants.MINECRAFT.field_1724) {
         StepEvent var2 = new StepEvent(var1);
         EventDispatcher.b(var2);
         return var2.getHeight();
      } else {
         return var1;
      }
   }

   @Redirect(
      method = {"tickMovement"},
      at = @At(
         value = "FIELD",
         target = "Lnet/minecraft/entity/LivingEntity;jumpingCooldown:I",
         opcode = 181,
         ordinal = 1
      )
   )
   private void b(class_1309 var1, int var2) {
      if (var1 == Constants.MINECRAFT.field_1724) {
         JumpingCooldownEvent var3 = new JumpingCooldownEvent(var2);
         EventDispatcher.b(var3);
         this.field_6228 = var3.getCooldown();
      } else {
         this.field_6228 = 10;
      }
   }

   @ModifyVariable(
      method = {"jump"},
      at = @At("STORE"),
      index = 3,
      require = 0
   )
   private float c(float yawRadians) {
      return (Object)this == Constants.MINECRAFT.field_1724 && RotationUtility.recoveredField045
         ? RotationUtility.recoveredField001 * 0.017453292F
         : yawRadians;
   }

   @Inject(
      method = {"jump"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void d(CallbackInfo var1) {
      if ((Object)this == Constants.MINECRAFT.field_1724) {
         JumpEvent var2 = new JumpEvent(this.method_5624());
         EventDispatcher.b(var2);
         if (var2.isCancelled()) {
            var1.cancel();
         }
      }
   }

   @Inject(
      method = {"travel"},
      at = {@At("HEAD")}
   )
   private void e(class_243 var1, CallbackInfo var2) {
      if ((Object)this == Constants.MINECRAFT.field_1724 && RotationUtility.recoveredField045) {
         this.jimfs$originalTravelYaw = this.method_36454();
         this.jimfs$originalTravelPitch = this.method_36455();
         this.method_36456(RotationUtility.recoveredField001);
         this.method_36457(RotationUtility.recoveredField063);
      }
   }

   @Inject(
      method = {"travel"},
      at = {@At("RETURN")}
   )
   private void f(class_243 var1, CallbackInfo var2) {
      if ((Object)this == Constants.MINECRAFT.field_1724 && RotationUtility.recoveredField045) {
         this.method_36456(this.jimfs$originalTravelYaw);
         this.method_36457(this.jimfs$originalTravelPitch);
      }
   }
}
