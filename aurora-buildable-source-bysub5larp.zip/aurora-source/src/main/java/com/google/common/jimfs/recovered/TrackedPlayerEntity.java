package com.google.common.jimfs.recovered;

import net.minecraft.class_1657;

public final class TrackedPlayerEntity extends TrackedLivingEntity {
   public TrackedPlayerEntity(class_1657 var1) {
      super(var1);
   }
}
