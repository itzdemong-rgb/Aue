package com.google.common.jimfs.fabric.compat;

import com.google.common.jimfs.client.screen.settings.SettingsScreen;
import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class ModMenuIntegration implements ModMenuApi {
   public ConfigScreenFactory getModConfigScreenFactory() {
      return var0 -> new SettingsScreen();
   }
}
