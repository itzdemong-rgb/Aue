package com.google.common.jimfs.mixin.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_3881;
import net.minecraft.class_3882;
import net.minecraft.class_572;
import net.minecraft.class_583;
import net.minecraft.class_630;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Environment(EnvType.CLIENT)
@Mixin({class_572.class})
public abstract class gNmP extends class_583 implements class_3881, class_3882 {
   @Final
   @Shadow
   public class_630 field_3398;

   private gNmP(class_630 var1) {
      super(var1);
   }
}
