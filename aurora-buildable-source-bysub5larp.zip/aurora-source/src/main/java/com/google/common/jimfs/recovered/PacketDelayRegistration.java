package com.google.common.jimfs.recovered;

import java.util.Objects;
import org.jetbrains.annotations.Nullable;

public final class PacketDelayRegistration {
   @Nullable
   private PacketTransformer transformer;
   @Nullable
   private final PacketPredicate predicate;
   private final boolean recoveredField170;
   private final long registrationSequence;
   private final long createdAt = System.currentTimeMillis();

   public PacketDelayRegistration(@Nullable PacketTransformer var1, @Nullable PacketPredicate var2, boolean var3, long var4) {
      this.transformer = var1;
      this.predicate = var2;
      this.recoveredField170 = var3;
      this.registrationSequence = var4;
   }

   @Nullable
   public PacketTransformer getTransformer() {
      return this.transformer;
   }

   @Nullable
   public PacketPredicate getPredicate() {
      return this.predicate;
   }

   public long d() {
      return this.registrationSequence;
   }

   public boolean e() {
      return this.recoveredField170;
   }

   @Override
   public boolean equals(Object var1) {
      boolean var2 = false;
      if (var1 != null && this.getClass() == var1.getClass()) {
         PacketDelayRegistration var3 = (PacketDelayRegistration)var1;
         return this.registrationSequence == var3.registrationSequence;
      } else {
         return false;
      }
   }

   @Override
   public int hashCode() {
      return Objects.hashCode(this.registrationSequence);
   }

}
