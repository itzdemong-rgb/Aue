package com.google.common.jimfs.mixin.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10017;
import net.minecraft.class_897;
import net.minecraft.class_898;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Environment(EnvType.CLIENT)
@Mixin({class_898.class})
public abstract class wXkL {
   @Shadow
   public abstract class_897 method_68832(class_10017 var1);

   private wXkL() {
   }
}
