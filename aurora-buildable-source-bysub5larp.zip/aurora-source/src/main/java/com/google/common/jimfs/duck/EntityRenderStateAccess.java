package com.google.common.jimfs.duck;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;

@Environment(EnvType.CLIENT)
public interface EntityRenderStateAccess {
   class_1297 jimfs$getEntity();

   void jimfs$setEntity(class_1297 var1);
}
