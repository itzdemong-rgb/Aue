package com.google.common.jimfs.m;

import com.google.common.jimfs.client.feature.module.Module;
import com.google.common.jimfs.client.feature.module.ModuleCategory;
import com.google.common.jimfs.client.feature.module.property.Property;
import com.google.common.jimfs.client.feature.module.property.impl.bool.BooleanProperty;
import com.google.common.jimfs.event.impl.game.PreGameTickEvent;
import com.google.common.jimfs.event.subscriber.Subscribe;
import com.google.common.jimfs.utility.misc.StringObfuscation;
import com.google.common.jimfs.utility.render.animation.AnimatedValue;
import com.google.common.jimfs.utility.render.animation.Easing;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_310;

public class ItemVisuals extends Module {
   public final BooleanProperty smokeOverlay = new BooleanProperty(StringObfuscation.a("Smoke Overlay"), true);
   public final BooleanProperty ambientParticles = new BooleanProperty(StringObfuscation.a("Ambient Particles"), true);
   public final BooleanProperty scanWave = new BooleanProperty(StringObfuscation.a("Scan Wave"), true);
   public final AnimatedValue transitionAnimation = new AnimatedValue(0.0F, Easing.EASE_OUT_CUBIC, 400.0F);
   private String lastItemId = "";
   public class_243 position = null;
   
   

   public ItemVisuals() {
      super(
         StringObfuscation.a("Item Visuals"), StringObfuscation.a("Adds corrupted/smoky effects to held items with a wave transition."), ModuleCategory.VISUAL
      );
      this.b(new Property[]{this.smokeOverlay, this.ambientParticles, this.scanWave});
   }

   @Override
   protected void g() {
      super.g();
      this.transitionAnimation.b(0.0F);
      this.transitionAnimation.animateTo(1.0F);
   }

   @Override
   protected void h() {
      super.h();
      this.transitionAnimation.animateTo(0.0F);
   }

   @Override
   public boolean e() {
      boolean var1 = true;
      return super.e() || this.transitionAnimation.getValue() > 0.0F;
   }

   @Subscribe
   public void b(PreGameTickEvent var1) {
      boolean var2 = true;
      if (!(this.transitionAnimation.getValue() <= 0.01F) && this.ambientParticles.isEnabled() && this.position != null) {
         class_310 var3 = class_310.method_1551();
         if (var3.field_1724 != null && var3.field_1687 != null && var3.field_1690.method_31044().method_31034()) {
            if (Math.random() < 0.6) {
               double var4 = this.position.field_1352 + (Math.random() - 0.5) * 0.3;
               double var6 = this.position.field_1351 + (Math.random() - 0.5) * 0.4;
               double var8 = this.position.field_1350 + (Math.random() - 0.5) * 0.3;
               var3.field_1713.method_3056(class_2398.field_22247, var4, var6, var8, 0.0, 0.015, 0.0);
            }
         }
      }
   }

   public void a(String var1) {
      boolean var2 = false;
      if (!this.isEnabled()) {
         this.transitionAnimation.animateTo(0.0F);
         this.transitionAnimation.b(0.0F);
      } else {
         if (!var1.equals(this.lastItemId)) {
            this.lastItemId = var1;
            this.transitionAnimation.b(0.0F);
            this.transitionAnimation.animateTo(1.0F);
         } else {
            this.transitionAnimation.animateTo(1.0F);
         }

         this.transitionAnimation.c(16.0F);
      }
   }

}
