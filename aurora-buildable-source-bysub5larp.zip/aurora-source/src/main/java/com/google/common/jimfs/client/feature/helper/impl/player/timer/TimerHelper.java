package com.google.common.jimfs.client.feature.helper.impl.player.timer;

public final class TimerHelper {
   public float timerSpeed = 1.0F;
   private static TimerHelper instance;

   private TimerHelper() {
   }

   public static TimerHelper getInstance() {
      return instance;
   }

   public static void initialize() {
      instance = new TimerHelper();
   }
}
