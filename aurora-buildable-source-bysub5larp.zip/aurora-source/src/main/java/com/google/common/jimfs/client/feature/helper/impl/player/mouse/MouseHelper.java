package com.google.common.jimfs.client.feature.helper.impl.player.mouse;

import com.google.common.jimfs.client.Constants;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_304;

public final class MouseHelper {
   private final Map buttons = new HashMap();
   private final MouseButton leftButton = this.b(new MouseButton(Constants.MINECRAFT.field_1690.field_1886));
   private final MouseButton rightButton = this.b(new MouseButton(Constants.MINECRAFT.field_1690.field_1904));
   private static MouseHelper instance;
   private static int[] recoveredField203;

   private MouseHelper() {
   }

   private MouseButton b(MouseButton var1) {
      this.buttons.put(var1.e(), var1);
      return var1;
   }

   public void tick() {
      this.leftButton.tick();
      this.rightButton.tick();
   }

   public static MouseButton a(class_304 var0) {
      return (MouseButton)instance.buttons.get(var0);
   }

   public static MouseButton getLeftMouseButton() {
      return instance.leftButton;
   }

   public static MouseButton getRightMouseButton() {
      return instance.rightButton;
   }

   public static void d() {
      instance = new MouseHelper();
   }

   public static MouseHelper getInstance() {
      return instance;
   }

   public static void b(int[] var0) {
      recoveredField203 = var0;
   }

   public static int[] e() {
      return recoveredField203;
   }
}
