package com.google.common.jimfs.event.impl.game.player.interaction.block;

import net.minecraft.class_2680;

public final class BlockBreakCanHarvestEvent {
   private final class_2680 blockState;
   private boolean canHarvest;

   public BlockBreakCanHarvestEvent(class_2680 var1, boolean var2) {
      this.blockState = var1;
      this.canHarvest = var2;
   }

   public boolean canHarvest() {
      return this.canHarvest;
   }
}
