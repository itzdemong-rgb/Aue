package com.google.common.jimfs.utility.render;

import com.google.common.jimfs.utility.render.animation.Animation;
import com.google.common.jimfs.utility.render.animation.Easing;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class Scroller {
   private final Animation scrollAnimation = new Animation(Easing.EASE_OUT_EXPO, 250L);
}
