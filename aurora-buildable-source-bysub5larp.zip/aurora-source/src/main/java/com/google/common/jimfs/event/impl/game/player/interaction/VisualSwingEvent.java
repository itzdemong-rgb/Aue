package com.google.common.jimfs.event.impl.game.player.interaction;

import com.google.common.jimfs.recovered.CancellableEvent;
import net.minecraft.class_1268;

public final class VisualSwingEvent extends CancellableEvent {
   public final class_1268 hand;

   public VisualSwingEvent(class_1268 var1) {
      this.hand = var1;
   }

   public class_1268 getHand() {
      return this.hand;
   }
}
