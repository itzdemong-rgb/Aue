package com.google.common.jimfs.recovered;

import com.google.common.jimfs.client.Constants;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_5250;

public final class ErrorMessageHelper {
   
   

   public static void b(Object var0) {
      class_5250 var1 = class_2561.method_43470("[")
         .method_27692(class_124.field_1080)
         .method_10852(class_2561.method_43470("✖").method_27692(class_124.field_1061))
         .method_10852(class_2561.method_43470("] ").method_27692(class_124.field_1080))
         .method_27693(var0.toString());
      b((class_2561)var1);
   }

   public static void b(class_2561 var0) {
      boolean var1 = true;
      if (Constants.MINECRAFT.field_1724 != null) {
         Constants.MINECRAFT.field_1705.method_1743().method_1812(var0);
      }
   }

}
