package com.google.common.jimfs.utility.render;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class ScreenPosition {
   protected float x;
   protected float y;
   protected float width;
   protected float height;

   public ScreenPosition(float var1, float var2, float var3, float var4) {
      this.x = var1;
      this.y = var2;
      this.width = var3;
      this.height = var4;
   }

   public ScreenPosition() {
   }

   public float getX() {
      return this.x;
   }

   public float getY() {
      return this.y;
   }

   public float getWidth() {
      return this.width;
   }

   public float d() {
      return this.height;
   }
}
