package com.google.common.jimfs.mixin.screen;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Environment(EnvType.CLIENT)
@Mixin({class_465.class})
public interface vJcM {
   @Accessor("x")
   int xR();

   @Accessor("y")
   int dG();
}
