package com.google.common.jimfs.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1661;
import net.minecraft.class_2371;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Environment(EnvType.CLIENT)
@Mixin({class_1661.class})
public interface eQyS {
   @Accessor("main")
   class_2371 M();

   @Accessor("selectedSlot")
   int N();

   @Accessor("selectedSlot")
   void O(int var1);
}
