package com.google.common.jimfs.duck;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1309;

@Environment(EnvType.CLIENT)
public interface BipedEntityRenderStateAccess {
   class_1309 jimfs$getEntity();

   void jimfs$setEntity(class_1309 var1);
}
