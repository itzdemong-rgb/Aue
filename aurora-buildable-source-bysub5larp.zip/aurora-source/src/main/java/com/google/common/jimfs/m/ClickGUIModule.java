package com.google.common.jimfs.m;

import com.google.common.jimfs.client.Constants;
import com.google.common.jimfs.client.feature.module.Module;
import com.google.common.jimfs.client.feature.module.ModuleCategory;
import com.google.common.jimfs.client.feature.module.property.Property;
import com.google.common.jimfs.client.feature.module.property.impl.ColorProperty;
import com.google.common.jimfs.client.feature.module.property.impl.bool.BooleanProperty;
import com.google.common.jimfs.client.feature.module.property.impl.number.NumberProperty;
import com.google.common.jimfs.client.screen.settings.SettingsScreen;
import com.google.common.jimfs.event.impl.game.PreGameTickEvent;
import com.google.common.jimfs.event.subscriber.Subscribe;
import com.google.common.jimfs.utility.misc.StringObfuscation;
import com.google.common.jimfs.utility.player.PlayerUtility;
import j2cc.Nativeify;
import java.awt.Color;

@Nativeify
public final class ClickGUIModule extends Module {
   private final BooleanProperty allowMovement = new BooleanProperty(StringObfuscation.a("Allow Movement"), true);
   public final BooleanProperty defaultBind = new BooleanProperty(StringObfuscation.a("Default Bind"), false);
   public final BooleanProperty clientIndicator = new BooleanProperty(StringObfuscation.a("Client Indicator"), true);
   public static final ColorProperty accentColor = new ColorProperty(StringObfuscation.a("Accent color"), new Color(153, 102, 255).getRGB());
   public static final ColorProperty secondaryColor = new ColorProperty(StringObfuscation.a("Sесоndаrу соlоr"), new Color(58, 42, 85).getRGB());
   public static final NumberProperty cornerRoundness = new NumberProperty(StringObfuscation.a("Corner Roundness"), 8.0, 0.0, 12.0, 0.5);
   private static boolean p = false;
   private static final String[] q = new String[]{
      "\u001fÕf;+\u0003 D²êò¼·\u0094ÿ0:$á.\u0097¹ú.º!ÒÑ³¢\u007f\u0012(Râ\u0094\u009a\u0003\u0095Ht÷H\u0016Ïî0\u009e!5\u0002NFáïþÔ\u009b|&i\u00adÅy\u0091¶\u0082²%\"®~\u007fhÄ\u00882òaL\u000b\u0010FaàäÚ\u0091",
      "&¤Ïá|`ifÅ7\u0092ñ×\u0002\u001fsfñ*È¬â\u0092\u001f[\u0004®@s\u000bÊÀ½\u000e\u001dÞ\u008bõ¹\u00990H\u000e¥(O\fû",
      "vUeC«asîDÍ\u0003aF~Â\u0014ó²x¨' ,\u0098\u008dÏY{\u0002:¨*2\\`jRJ?oáÎ\u001aXEf\u0081ÀÙ}=¯\u008e58¢\rC\nSIíÁ\u0018",
      "\u0081{÷`\u0017#è\u0015º8Ñ\u0003¿,\u0011\u008bÆ^sÌe\u0095+\u0086À¥Ü½\u001c\u007f&è\r\u0010\u0088\u0014ö\u009a\u001a\u0095Éu0GÏäßªób\u0097\u0011ô=¹Ñ\u001d\u0011'ì#E\u0080û",
      "\u0015Ý\u0004½*\u009dmee'¥\u008er+\u0089\b×_\u0012\u0095j\u0086\u008bü´°2\u000b®Rò\u0083!J\bì{Z\u008büÚ\u0007\\§\u008c\u0091\u0097=Ú\u008b\u0092<-û\u00893\u001dz\u008c\tÞ4 ¨Ý|Ä\u0010â¤ì0æ¶\u0015ª\u0084u\u0097\u001a",
      "\u001cI\u0089B\u0095\u0090[\u0014a\u0085\u0089\u0093÷ö8\u0019ÀÂðY6Ì\u0001\fÈ}?^¹×Bì@\u0082¸ubëDZaL*üc\u0083k2d\u008fEÚ\u0080ªÖBKg\u0012Â\u0084q\u0001Í\u000fü®½ùGD\u0083\u001a¬\f\u0016ôì\u0096»",
      "Å\u00829RD\u009cMC\u0002gJ¹î\b\\QéãØ\u0015\u009ck7\u0000\u0001\u001aäÆ\u001bhÈ#\u0012\tÄ<\u0012åI\b£ý~Nd\u0082\u008büydÊ\u009eÜOs/G\"\u0000¤'áÂ*^Hã\u0019µù\u009e.\u001bm=Ð\u008b\u001c\u000bÖ\u0086°\u0019½\u000bÿ¨d"
   };
   

   public ClickGUIModule() {
      super(StringObfuscation.a("Click GUI"), "", ModuleCategory.CLIENT);
      this.b(new Property[]{this.allowMovement, this.clientIndicator, accentColor, cornerRoundness, this.defaultBind});
      this.k().a(344);
   }

   @Override
   protected void g() {
      Constants.MINECRAFT.method_1507(new SettingsScreen());
   }

   @Override
   protected void h() {
      boolean var1 = true;
      if (Constants.MINECRAFT.field_1755 instanceof SettingsScreen) {
         Constants.MINECRAFT.method_1507(null);
      }
   }

   @Subscribe
   public void b(PreGameTickEvent var1) {
      boolean var2 = false;
      if (this.k().getValue() != null && (Integer)this.k().getValue() == -1) {
         this.k().a(344);
      }

      if (this.defaultBind.isEnabled()) {
         this.k().a(344);
         this.defaultBind.a(Boolean.valueOf(false));
      }

      if (this.allowMovement.isEnabled() && Constants.MINECRAFT.field_1755 instanceof SettingsScreen) {
         if (!SettingsScreen.editingKeybindActive && !SettingsScreen.recoveredField110) {
            PlayerUtility.restoreKeyStates();
         } else {
            PlayerUtility.releaseKeyStates();
         }
      }
   }

   @Override
   public boolean e() {
      boolean var1 = true;
      return this.isEnabled() && (Constants.MINECRAFT.field_1755 == null || Constants.MINECRAFT.field_1755 instanceof SettingsScreen);
   }

   static {
      short var0 = 169;
      byte var1 = 88;
      String var2 = "j+¯\u001e\u0086\u008d%b\u0003£Õ\u0080ê\u0088N{æ\u009eãDHºc*\u0094n\" Ïµd°S\u009fÆ\u0003\u0000Í\u0018I|2\\\u009eEßx/\u001aù'üÜ¹Ë<=\u00054\u009e\u0097l\u007f»mÚò®ä92á<ð\u001f\u000b\u008a\u009aô\u009dX³à\u001f\u000eW\u008135`A\u0016ªóv*3Ï¿Ë\bâ\u001dU&]\tù¸m\nî\u007f\u0001\u0014ºJpÃ\u0015\u001b¾\u0083\b,BÞ\u0098á\u0007\u0012¨¸\u0080\\nQ1@&ø4ü¼\\<n¿\n¨\u0087èL=1.ÍõjiðÚ£\u0004Ã}\u009d\u008e8";
      byte var3 = 7;
      short var4 = 169;
      String[] var5 = q;
      byte var6 = 88;
   }

   public static void a(boolean var0) {
      p = var0;
   }

   public static boolean n() {
      return p;
   }

   public static boolean o() {
      boolean var0 = n();
      return !var0;
   }

}
