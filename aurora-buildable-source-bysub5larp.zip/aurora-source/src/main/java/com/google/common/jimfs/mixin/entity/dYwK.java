package com.google.common.jimfs.mixin.entity;

import com.google.common.jimfs.duck.BipedEntityRenderStateAccess;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10034;
import net.minecraft.class_1309;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Environment(EnvType.CLIENT)
@Mixin({class_10034.class})
public final class dYwK implements BipedEntityRenderStateAccess {
   @Unique
   public class_1309 entity;

   @Override
   public class_1309 jimfs$getEntity() {
      return this.entity;
   }

   @Override
   public void jimfs$setEntity(class_1309 var1) {
      this.entity = var1;
   }
}
