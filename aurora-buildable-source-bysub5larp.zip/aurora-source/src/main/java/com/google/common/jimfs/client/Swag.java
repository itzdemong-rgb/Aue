package com.google.common.jimfs.client;

import com.google.common.jimfs.client.binding.repository.BindRepository;
import com.google.common.jimfs.client.feature.helper.impl.player.mouse.MouseHelper;
import com.google.common.jimfs.client.feature.helper.impl.player.slot.SlotHelper;
import com.google.common.jimfs.client.feature.helper.impl.player.timer.TimerHelper;
import com.google.common.jimfs.client.feature.helper.impl.render.FadingBlockHelper;
import com.google.common.jimfs.client.feature.helper.impl.render.RingHelper;
import com.google.common.jimfs.client.feature.helper.impl.render.ScreenPositionManager;
import com.google.common.jimfs.client.feature.module.Module;
import com.google.common.jimfs.client.feature.module.repository.ModuleRepository;
import com.google.common.jimfs.event.EventDispatcher;
import com.google.common.jimfs.m.ArrayListModule;
import com.google.common.jimfs.m.AutoMace;
import com.google.common.jimfs.m.NameTagsModule;
import com.google.common.jimfs.m.AutoHitCrystalModule;
import com.google.common.jimfs.m.ItemVisuals;
import com.google.common.jimfs.m.AnchorMacroModule;
import com.google.common.jimfs.m.AutoCrystalModule;
import com.google.common.jimfs.m.PreCheckModule;
import com.google.common.jimfs.m.ESPModule;
import com.google.common.jimfs.m.ClickGUIModule;
import com.google.common.jimfs.recovered.StorageESPModule;
import com.google.common.jimfs.recovered.BlockHelperModule;
import com.google.common.jimfs.recovered.HoverTotemModule;
import com.google.common.jimfs.recovered.AutoInvTotemModule;
import com.google.common.jimfs.recovered.DoubleAnchorModule;
import com.google.common.jimfs.recovered.FastXPModule;
import com.google.common.jimfs.recovered.MaceSwapModule;
import com.google.common.jimfs.recovered.SelfDestructModule;
import com.google.common.jimfs.recovered.ShieldBreakerModule;
import com.google.common.jimfs.recovered.AutoTotemHitModule;
import com.google.common.jimfs.recovered.SafeAnchorModule;
import com.google.common.jimfs.recovered.ClientState;
import com.google.common.jimfs.recovered.ClientInitializedEvent;
import com.google.common.jimfs.recovered.SwingInputGuard;
import com.google.common.jimfs.recovered.WorldStateTracker;
import com.google.common.jimfs.recovered.TargetFilterSettings;
import com.google.common.jimfs.recovered.ClientTickSubscriber;
import com.google.common.jimfs.recovered.LootYeeterModule;
import com.google.common.jimfs.utility.data.SaveUtility;

public final class Swag {
   private final ClientState clientState;
   private final BindRepository bindRepository;
   private ModuleRepository moduleRepository;
   private String displayName = "User";
   private boolean initialized;
   private boolean selfDestructed;
   private static Swag instance;
   private static String[] scratchStrings;

   public boolean isSelfDestructed() {
      return this.selfDestructed;
   }

   public void b(boolean var1) {
      this.selfDestructed = var1;
   }

   private Swag() {
      this.clientState = new ClientState();
      this.bindRepository = new BindRepository();
   }

   public void initialize() {
      boolean var1 = true;
      if (!this.initialized) {
         this.initializeHelpers();
         if (this.moduleRepository == null) {
            this.moduleRepository = ModuleRepository.b(
               new Module[]{
                  new AutoTotemHitModule(),
                  new AutoInvTotemModule(),
                  new BlockHelperModule(),
                  new HoverTotemModule(),
                  new ShieldBreakerModule(),
                  new SelfDestructModule(),
                  new FastXPModule(),
                  new AutoMace(),
                  new MaceSwapModule(),
                  new DoubleAnchorModule(),
                  new AutoHitCrystalModule(),
                  new AutoCrystalModule(),
                  new PreCheckModule(),
                  new AnchorMacroModule(),
                  new SafeAnchorModule(),
                  new LootYeeterModule(),
                  new ClickGUIModule(),
                  new ESPModule(),
                  new ArrayListModule(),
                  new NameTagsModule(),
                  new StorageESPModule(),
                  new ItemVisuals()
               }
            );
         }

         SaveUtility.loadConfig();
         this.initialized = true;
         EventDispatcher.b(new ClientInitializedEvent());
      }
   }

   private void initializeHelpers() {
      WorldStateTracker.d();
      MouseHelper.d();
      ClientTickSubscriber.initialize();
      SlotHelper.initialize();
      TargetFilterSettings.initialize();
      TimerHelper.initialize();
      FadingBlockHelper.initialize();
      RingHelper.initialize();
      ScreenPositionManager.initialize();
      SwingInputGuard.initialize();
   }

   public ModuleRepository getModuleRepository() {
      return this.moduleRepository;
   }

   public BindRepository getBindRepository() {
      return this.bindRepository;
   }

   public static Swag getInstance() {
      if (instance == null) {
         instance = new Swag();
      }

      return instance;
   }

   public static void b(String[] var0) {
      scratchStrings = var0;
   }

   public static String[] d() {
      return scratchStrings;
   }

}
