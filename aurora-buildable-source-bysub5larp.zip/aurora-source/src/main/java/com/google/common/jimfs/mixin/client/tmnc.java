package com.google.common.jimfs.mixin.client;

import com.google.common.jimfs.client.Swag;
import com.google.common.jimfs.m.ItemVisuals;
import com.llamalad7.mixinextras.sugar.Local;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_746;
import net.minecraft.class_757;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(value = class_757.class, priority = 1100)
public class tmnc {
   @Inject(
      method = {"renderHand"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/item/HeldItemRenderer;renderItem(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/network/ClientPlayerEntity;I)V"
      ),
      require = 0
   )
   private void updateItemVisuals(float tickDelta, boolean renderItem, Matrix4f positionMatrix, CallbackInfo ci, @Local(index = 4) class_4587 matrices) {
      if (Swag.getInstance() != null && Swag.getInstance().getModuleRepository() != null) {
         ItemVisuals var7 = (ItemVisuals)Swag.getInstance().getModuleRepository().a(ItemVisuals.class);
         class_746 player = class_310.method_1551().field_1724;
         if (var7 != null && player != null) {
            String var8 = player.method_6047().method_7909().method_7876();
            var7.a(var8);
            Vector4f var9 = new Vector4f(0.0F, 0.0F, 0.0F, 1.0F);
            var9.mul(matrices.method_23760().method_23761());
            class_243 var10 = player.method_5836(tickDelta);
            Vector3f var11 = new Vector3f(var9.x(), var9.y(), var9.z());
            var11.rotate(class_310.method_1551().field_1773.method_19418().method_23767());
            var7.position = var10.method_1031((double)var11.x(), (double)var11.y(), (double)var11.z());
         }
      }
   }
}
