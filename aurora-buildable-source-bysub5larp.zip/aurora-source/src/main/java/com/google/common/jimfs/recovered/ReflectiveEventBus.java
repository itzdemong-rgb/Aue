package com.google.common.jimfs.recovered;

import com.google.common.jimfs.event.subscriber.IEventSubscriber;
import com.google.common.jimfs.event.subscriber.Subscribe;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class ReflectiveEventBus {
   private final Map<Class<?>, List<EventListenerBinding>> listenersByEvent = new HashMap();

   private void b(Object var1, Class var2) {
      IEventSubscriber var3 = (IEventSubscriber)var1;

      for (Method var7 : var2.getDeclaredMethods()) {
         Subscribe var8 = var7.getDeclaredAnnotation(Subscribe.class);
         if (var8 != null && !Modifier.isStatic(var7.getModifiers())) {
            Class var9 = var7.getParameterTypes()[0];

            try {
               var7.setAccessible(true);
               EventListenerBinding var10 = new EventListenerBinding(var8.a(), var7, var3);
               this.listenersByEvent.computeIfAbsent(var9, var0 -> new ArrayList<>()).add(var10);
            } catch (Exception var11) {
               throw new RuntimeException("Error subscribing event: " + var7.getName(), var11);
            }
         }
      }
   }

   public void b(Object var1) {
      this.b(var1, var1.getClass());

      for (Class var2 = var1.getClass().getSuperclass(); var2 != Object.class; var2 = var2.getSuperclass()) {
         this.b(var1, var2);
      }

      this.sortListeners();
   }

   private void sortListeners() {
      for (List<EventListenerBinding> var2 : this.listenersByEvent.values()) {
         var2.sort(Comparator.comparingInt(EventListenerBinding::getPriority));
      }
   }

   public void c(Object var1) {
      List var2 = (List)this.listenersByEvent.get(var1.getClass());
      if (var2 != null) {
         for (int var3 = 0; var3 < var2.size(); var3++) {
            EventListenerBinding var4 = (EventListenerBinding)var2.get(var3);
            if (var4.b(var1)) {
               break;
            }
         }
      }
   }

}
