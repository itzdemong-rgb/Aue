package com.google.common.jimfs.event.impl.game.server;

import com.google.common.jimfs.recovered.CancellableEvent;
import net.minecraft.class_639;

public final class ServerConnectEvent extends CancellableEvent {
   private final class_639 serverInfo;

   public ServerConnectEvent(class_639 var1) {
      this.serverInfo = var1;
   }

   public class_639 getServerInfo() {
      return this.serverInfo;
   }
}
