package com.google.common.jimfs.client.feature.module;

import com.google.common.jimfs.client.feature.module.property.Property;
import com.google.common.jimfs.utility.misc.StringObfuscation;

public enum ModuleCategory {
   VISUAL("Visual", "\ue8f4"),
   CRYSTAL("Crystal", "\ue83a"),
   COMBAT("Combat", "\uf889"),
   CLIENT("Settings", "\ue8b8"),
   CONFIGS("Configs", "\ue2c7"),
   UPDATES("Updates", "\ue8e2");
   private final StringObfuscation.E recoveredField020;
   private final StringObfuscation.E recoveredField088;
   private int recoveredField117;
   public static final ModuleCategory[] VALUES = values();
   private static Property[] scratchProperties = new Property[1];

   private ModuleCategory(CharSequence var3, CharSequence var4) {
      this.recoveredField020 = StringObfuscation.a(var3);
      this.recoveredField088 = StringObfuscation.a(var4);
   }

   public CharSequence getName() {
      return this.recoveredField088;
   }

   

   public static void b(Property[] var0) {
      scratchProperties = var0;
   }

   public static Property[] getScratchProperties() {
      return scratchProperties;
   }
}
