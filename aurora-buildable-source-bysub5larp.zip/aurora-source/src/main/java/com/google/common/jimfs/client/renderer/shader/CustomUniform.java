package com.google.common.jimfs.client.renderer.shader;

import com.google.common.jimfs.utility.misc.StringObfuscation;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.Std140SizeCalculator;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class CustomUniform {
   public static final int uniformBlockSize = new Std140SizeCalculator().putVec2().putFloat().putFloat().putInt().get();
   private final GpuBuffer uniformBuffer = RenderSystem.getDevice()
      .createBuffer(() -> StringObfuscation.a("Sigma25 UBO").get(), 136, (long)uniformBlockSize);
}
