package com.google.common.jimfs.mixin.chat;

import com.google.common.jimfs.client.Constants;
import com.google.common.jimfs.client.screen.settings.SettingsScreen;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_338;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({class_338.class})
public class ChatHudRenderMixin {
   @Inject(
      method = {"render"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void cRj(CallbackInfo var1) {
      if (Constants.MINECRAFT.field_1755 instanceof SettingsScreen) {
         var1.cancel();
      }
   }
}
