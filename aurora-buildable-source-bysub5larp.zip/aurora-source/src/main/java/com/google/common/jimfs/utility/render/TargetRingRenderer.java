package com.google.common.jimfs.utility.render;

import com.google.common.jimfs.client.Constants;
import com.google.common.jimfs.client.renderer.NVGRenderer;
import com.google.common.jimfs.utility.misc.math.MathUtility;
import java.util.ArrayList;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1309;
import net.minecraft.class_243;

@Environment(EnvType.CLIENT)
public final class TargetRingRenderer {
   private TargetRingRenderer() {
   }

   public static void a(class_1309 var0, float var1, int var2) {
      if (var0 != null && !(var1 <= 0.0F) && Constants.MINECRAFT.field_1724 != null) {
         float var3 = Constants.MINECRAFT.method_61966().method_60637(false);
         class_243 var4 = MathUtility.a(var0, var3);
         double var5 = var4.field_1352;
         double var7 = var4.field_1350;
         float var9 = 0.7F;
         byte var10 = 48;
         double var11 = (double)var0.method_17682();
         double var13 = (double)System.currentTimeMillis() / 800.0;
         double var15 = Math.sin(var13) * var11 * 0.12;
         double var17 = var4.field_1351 + var11 * 0.5 + var15;
         int var19 = (Integer)ColorUtility.getThemeColors().first;
         int var20 = (Integer)ColorUtility.getThemeColors().second;
         ArrayList var21 = new ArrayList();

         for (int var22 = 0; var22 <= var10; var22++) {
            double var23 = (double)var22 * Math.PI * 2.0 / (double)var10;
            double var25 = var5 + (double)var9 * Math.cos(var23);
            double var27 = var7 + (double)var9 * Math.sin(var23);
            class_243 var29 = ESPUtility.a(new class_243(var25, var17, var27));
            if (var29 != null) {
               var21.add(new float[]{(float)var29.field_1352, (float)var29.field_1351});
            } else {
               var21.add(null);
            }
         }

         for (int var31 = 3; var31 >= 0; var31--) {
            float var34 = 2.5F + (float)var31 * 2.5F;
            float var24 = var1 * (0.15F - (float)var31 * 0.03F);
            int var39 = ColorUtility.a(var19, (int)(255.0F * var24));

            for (int var26 = 0; var26 < var10; var26++) {
               float[] var42 = (float[])var21.get(var26);
               float[] var28 = (float[])var21.get(var26 + 1);
               if (var42 != null && var28 != null) {
                  double var47 = (double)((var42[0] - var28[0]) * (var42[0] - var28[0]) + (var42[1] - var28[1]) * (var42[1] - var28[1]));
                  if (!(var47 > 10000.0)) {
                     NVGRenderer.b(var42[0], var42[1], var28[0], var28[1], var34, var39);
                  }
               }
            }
         }

         for (int var32 = 0; var32 < var10; var32++) {
            float[] var35 = (float[])var21.get(var32);
            float[] var37 = (float[])var21.get(var32 + 1);
            if (var35 != null && var37 != null) {
               double var40 = (double)((var35[0] - var37[0]) * (var35[0] - var37[0]) + (var35[1] - var37[1]) * (var35[1] - var37[1]));
               if (!(var40 > 10000.0)) {
                  float var43 = (float)var32 / (float)var10;
                  int var45 = ColorUtility.a(var19, var20, var43);
                  int var48 = ColorUtility.a(var45, (int)(216.75F * var1));
                  NVGRenderer.b(var35[0], var35[1], var37[0], var37[1], 2.5F, var48);
               }
            }
         }

         for (int var33 = 0; var33 < var10; var33++) {
            float[] var36 = (float[])var21.get(var33);
            float[] var38 = (float[])var21.get(var33 + 1);
            if (var36 != null && var38 != null) {
               double var41 = (double)((var36[0] - var38[0]) * (var36[0] - var38[0]) + (var36[1] - var38[1]) * (var36[1] - var38[1]));
               if (!(var41 > 10000.0)) {
                  float var44 = (float)var33 / (float)var10;
                  int var46 = ColorUtility.a(-1, var19, var44);
                  int var49 = ColorUtility.a(var46, (int)(102.0F * var1));
                  NVGRenderer.b(var36[0], var36[1], var38[0], var38[1], 1.0F, var49);
               }
            }
         }
      }
   }
}
