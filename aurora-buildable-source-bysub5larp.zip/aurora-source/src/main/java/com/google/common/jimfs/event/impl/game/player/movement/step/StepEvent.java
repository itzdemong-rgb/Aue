package com.google.common.jimfs.event.impl.game.player.movement.step;

public final class StepEvent {
   private float height;

   public StepEvent(float var1) {
      this.height = var1;
   }

   public float getHeight() {
      return this.height;
   }
}
