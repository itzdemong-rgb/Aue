package com.google.common.jimfs.mixin.entity;

import com.google.common.jimfs.client.Constants;
import com.google.common.jimfs.client.feature.helper.impl.player.slot.SlotHelper;
import com.google.common.jimfs.utility.player.BlockUtility;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10426;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Environment(EnvType.CLIENT)
@Mixin({class_10426.class})
public final class tVrX {
   @Redirect(
      method = {"updateRenderState"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/entity/LivingEntity;getStackInArm(Lnet/minecraft/util/Arm;)Lnet/minecraft/item/ItemStack;"
      )
   )
   private static class_1799 a(class_1309 var0, class_1306 var1) {
      return var0 == Constants.MINECRAFT.field_1724
            && var1 == Constants.MINECRAFT.field_1724.method_6068()
            && BlockUtility.recoveredMethod038()
         ? SlotHelper.getInstance().a(Constants.MINECRAFT.field_1724)
         : var0.method_61420(var1);
   }
}
