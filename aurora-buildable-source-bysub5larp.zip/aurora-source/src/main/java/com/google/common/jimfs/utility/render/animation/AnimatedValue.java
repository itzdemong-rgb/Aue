package com.google.common.jimfs.utility.render.animation;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class AnimatedValue {
   private float value;
   private float targetValue;
   private final Easing easing;
   private float elapsedMillis;
   private float durationMillis;
   private float startValue;
   private boolean animating;

   public AnimatedValue(float var1, Easing var2, float var3) {
      this.value = var1;
      this.targetValue = var1;
      this.startValue = var1;
      this.easing = var2;
      this.durationMillis = var3;
      this.elapsedMillis = var3;
   }

   public void animateTo(float var1) {
      if (this.targetValue != var1) {
         this.startValue = this.value;
         this.targetValue = var1;
         this.elapsedMillis = 0.0F;
         this.animating = true;
      }
   }

   public float getValue() {
      return this.value;
   }

   public void b(float var1) {
      this.value = var1;
      this.targetValue = var1;
      this.startValue = var1;
      this.elapsedMillis = this.durationMillis;
      this.animating = false;
   }

   public void c(float var1) {
      if (this.animating) {
         this.elapsedMillis += var1;
         if (this.elapsedMillis >= this.durationMillis) {
            this.elapsedMillis = this.durationMillis;
            this.value = this.targetValue;
            this.animating = false;
         } else {
            float var2 = this.elapsedMillis / this.durationMillis;
            float var3 = (Float)this.easing.getFunction().apply(var2);
            this.value = this.startValue + (this.targetValue - this.startValue) * var3;
         }
      }
   }
}
