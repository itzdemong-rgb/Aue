package com.google.common.jimfs.client.screen.click;

import com.google.common.jimfs.utility.render.ScreenPosition;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public abstract class MlabPanelComponent extends ScreenPosition implements IMlabComponent {
}
