package com.google.common.jimfs.recovered;

import com.google.common.jimfs.event.EventDispatcher;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_639;

public final class ServerProfileDetector {
   private ServerProfile activeProfile;
   private static final ServerProfileMatcher[] MATCHERS;
   

   public void b(class_639 var1) {
      ServerProfileMatcher[] var3 = MATCHERS;
      int var4 = var3.length;
      int var5 = 0;

      for (boolean var2 = false; var5 < var4; var5++) {
         ServerProfileMatcher var6 = var3[var5];
         ServerProfile var7 = var6.a(var1);
         if (var7 != null) {
            this.activeProfile = var7;
            EventDispatcher.a(var7);
            return;
         }
      }

      this.activeProfile = null;
   }

   public ServerProfile getActiveProfile() {
      return this.activeProfile;
   }

   public void clearActiveProfile() {
      this.activeProfile = null;
   }

   private static boolean b(class_639 var0, String var1, boolean var2) {
      String var3 = var0.method_2952().toLowerCase();
      String var4 = Pattern.quote(var1) + "(\\.*)$";
      if (var2) {
         var4 = "^(?:[a-zA-Z0-9-]+\\.)*" + var4;
      }

      Pattern var5 = Pattern.compile(var4);
      Matcher var6 = var5.matcher(var3);
      return var6.matches();
   }

   static {
      MATCHERS = new ServerProfileMatcher[]{var0x -> {
         boolean var1x = true;
         return var0x.method_2954() != 25565 || !b(var0x, "cubecraft.net", false) && !b(var0x, "play.cubecraft.net", false) ? null : new CubeCraftProfile();
      }, var0x -> {
         boolean var1x = true;
         return var0x.method_2954() == 25565 && b(var0x, "liquidproxy.net", true) ? new LiquidProxyProfile() : null;
      }};
   }

}
