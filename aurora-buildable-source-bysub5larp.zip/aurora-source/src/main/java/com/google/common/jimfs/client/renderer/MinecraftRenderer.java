package com.google.common.jimfs.client.renderer;

import java.util.LinkedList;
import java.util.Queue;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class MinecraftRenderer {
   private static final Queue renderQueue = new LinkedList();

   private MinecraftRenderer() {
   }
}
