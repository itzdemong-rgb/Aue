package com.google.common.jimfs.utility.player;

import net.minecraft.class_10426;

public final class BlockUtility {
   public static boolean a(class_10426 var0) {
      return false;
   }

   public static boolean recoveredMethod038() {
      return false;
   }
}
