package com.google.common.jimfs.client.feature.module.property.impl;

import com.google.common.jimfs.client.feature.module.property.Property;
import java.awt.Color;

public final class ColorProperty extends Property {
   private final float[] hsv = new float[3];
   private static int recoveredField233 = 77;

   public ColorProperty(CharSequence var1, int var2) {
      super(var1);
      this.a(Integer.valueOf(var2));
   }

   public float[] getHsv() {
      return this.hsv;
   }

   public void setHue(float var1) {
      this.hsv[0] = var1;
   }

   public void b(float var1) {
      this.hsv[1] = var1;
   }

   public void c(float var1) {
      this.hsv[2] = var1;
   }

   public void updateColorFromHsv() {
      this.a(Integer.valueOf(Color.HSBtoRGB(this.hsv[0], this.hsv[1], this.hsv[2])));
   }

   public static void b(int var0) {
      recoveredField233 = var0;
   }

   public static int recoveredMethod101() {
      return recoveredField233;
   }

   public static int d() {
      byte var0 = 77;
      return var0 == 0 ? 105 : 0;
   }
}
