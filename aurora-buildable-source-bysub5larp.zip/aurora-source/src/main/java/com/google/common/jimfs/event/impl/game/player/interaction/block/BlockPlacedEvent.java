package com.google.common.jimfs.event.impl.game.player.interaction.block;

import net.minecraft.class_3965;

public final class BlockPlacedEvent {
   private final class_3965 hitResult;

   public BlockPlacedEvent(class_3965 var1) {
      this.hitResult = var1;
   }
}
