package com.google.common.jimfs.mixin.client;

import com.google.common.jimfs.client.Constants;
import com.google.common.jimfs.m.PreCheckModule;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import net.minecraft.class_4969;
import net.minecraft.class_636;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin({class_636.class})
public class pBkN {
   @Inject(
      method = {"interactBlock"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void a(class_746 var1, class_1268 var2, class_3965 var3, CallbackInfoReturnable var4) {
      PreCheckModule var5 = PreCheckModule.getInstance();
      if (var5 != null && var5.isEnabled() && var5.d()) {
         class_1799 var6 = var1.method_5998(var2);
         if (var6.method_31574(class_1802.field_8801)) {
            class_2338 var7 = var3.method_17777();
            class_2680 var8 = Constants.MINECRAFT.field_1687.method_8320(var7);
            if (var8.method_27852(class_2246.field_23152)) {
               int var9 = (Integer)var8.method_11654(class_4969.field_23153);
               if (var9 > 0) {
                  var4.setReturnValue(class_1269.field_5814);
               }
            }
         }
      }
   }
}
