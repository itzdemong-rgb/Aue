package com.google.common.jimfs.mixin.input;

import com.google.common.jimfs.utility.player.RotationUtility;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_744;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin({class_744.class})
public class InputForwardMovementMixin {
   @Inject(
      method = {"hasForwardMovement"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void dG(CallbackInfoReturnable var1) {
      if (RotationUtility.recoveredField045) {
         var1.setReturnValue(RotationUtility.recoveredField110);
      }
   }
}
