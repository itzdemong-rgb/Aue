package com.google.common.jimfs.m;

import com.google.common.jimfs.client.Constants;
import com.google.common.jimfs.client.feature.helper.impl.render.RingHelper;
import com.google.common.jimfs.client.feature.module.Module;
import com.google.common.jimfs.client.feature.module.ModuleCategory;
import com.google.common.jimfs.client.feature.module.property.Property;
import com.google.common.jimfs.client.feature.module.property.impl.bool.BooleanProperty;
import com.google.common.jimfs.client.feature.module.property.impl.mode.ModeProperty;
import com.google.common.jimfs.client.renderer.NVGRenderer;
import com.google.common.jimfs.client.renderer.Overlay;
import com.google.common.jimfs.client.renderer.repository.FontRepository;
import com.google.common.jimfs.event.impl.render.RenderHudEvent;
import com.google.common.jimfs.event.impl.render.RenderWorldEvent;
import com.google.common.jimfs.event.subscriber.Subscribe;
import com.google.common.jimfs.recovered.FriendRegistry;
import com.google.common.jimfs.utility.misc.StringObfuscation;
import com.google.common.jimfs.utility.misc.math.MathUtility;
import com.google.common.jimfs.utility.render.ColorUtility;
import com.google.common.jimfs.utility.render.CustomRenderLayers;
import com.google.common.jimfs.utility.render.Draw3DUtility;
import com.google.common.jimfs.utility.render.ESPUtility;
import com.google.common.jimfs.utility.render.TargetRingRenderer;
import j2cc.Nativeify;
import java.awt.Color;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.function.BiConsumer;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_9799;
import net.minecraft.class_4597.class_4598;
import org.joml.Vector4d;
import org.lwjgl.opengl.GL11;

@Nativeify
public class ESPModule extends Module {
   private final ModeProperty m = new ModeProperty(StringObfuscation.a("Box Mode"), ESPModule.a.Normal);
   private final ModeProperty o = new ModeProperty(StringObfuscation.a("Health Bar"), ESPModule.b.Health);
   private final BooleanProperty p = new BooleanProperty(StringObfuscation.a("Armor Bar"), false);
   private final BooleanProperty q = new BooleanProperty(StringObfuscation.a("Players"), true);
   private final BooleanProperty r = new BooleanProperty(StringObfuscation.a("Invisibles"), true);
   private final BooleanProperty s = new BooleanProperty(StringObfuscation.a("Mobs"), false);
   private static ESPModule t;
   private static boolean u = false;
   private static final String[] recoveredField060 = new String[]{
      "@ú\u008eÒ[ªa\u007f\u0089iùª6ñ\u000e\u008bÊ Ý3~Ih_\u0087\u0092öÒõ\u0018\u0015\u0091«$²\u0082¾\u007fðÌ5I\u00026¦ã0l¬\u0006¾ûrþ\u0087¸Ù\u0002Ü=]£:6<\u0005@Âá¿:28ç+ë\u0010\u0010\nH©\u0083J:e\u009eÙ§3ËÖzõäñ\u0092\u0011|; \u008f;×:üQ¶#>¬à\u00925\u000e\u0016¬íØ¤q'ßýüY\u0099\u0098N\u0005õý\u008d¨yh`5'\u0015(î\u0097Ë¨%½ÊÂ,RÙïUh\u0083ó¡\u009cNñ\u0018Ö\u007fó£\u00999÷Lz\u0002Ü-ðê\u0093sÞ\u0000 ,\u0012«]\u001b\u0089LÄÂ\u0005õC3-Í\u0080õ]ó\u0086\u0012æ(·®&\u0098Â",
      "ç±\u0019)§\u000b1\u001b\u0082î¶p1\u0087àÞÚå\u009c\u0099w!H¼®\u0087Q{îYV\u0005í \u009b\u0082uÈ\u0089\f\u0018øêÌZ¶AÎ",
      "\u0015{$ù\u0003¦Ä¶\u007f7+àâ\u0013ø\u0019û\u008fÚ\r\u009c\u0007zJ",
      "s?È1½ü_ØÃ\u007f¼Ï\u001d\u001f¤\u0001\u0092F{¤\u008b¹Ô\u0000]\u0019L\u0093@[!çÃr°\u0086\u001e\u009a*ÞL#@\u0015!<ÂT±þ0¢y9Z?",
      "²ð7×a\u0096\u0088íöê\u0016 ÎV»\u0015\u0093KÔ7<\u0093,\u007f",
      "8#\u0083Å´®\u0011\u009d\u0084/6#b\u00ad©\u0093¿zýý\u0014\u0085\u0085\u0010",
      "\u0016\u0086EÚ\u000e«e\u001cI\u0019¯\"r÷éâ¹\u0018òSõù¶E3\"á\b\u009b\u0017ùä8º\f\u000e\u0005Sd3",
      "w\bHÆ¢;^\"o6\u000b:\u0086°\u0018Ç\n\u0087\u0084\u00844½nÓêUzödµ*=àÊÚ\u0013\u009c³{[F\n,\u0097!/Â\u0013",
      "N©Á\u0012Ü:0\u008e\u0001¿*\u0083àZÔÏ",
      "\u0017ÉD\u008b#NoÇfñæ¯XÞÃH\u007f!çã\u0014\u0099©´\u0090<Ôü]cB\u009dBùìãtý\u0086Ý8XxL#ä\u0011\u0094* \u00adj\u009d6zT"
   };
   private static final String[] v = new String[10];

   public ESPModule() {
      super(StringObfuscation.a("ESP"), StringObfuscation.a("2D projection ESP with premium visuals"), ModuleCategory.VISUAL);
      this.b(new Property[]{this.m, this.o, this.p, this.q, this.r, this.s});
      t = this;
   }

   public static boolean recoveredMethod057(class_1297 var0) {
      return false;
   }

   public static int getEntityColor(class_1297 var0) {
      boolean var1 = false;
      if (t != null && var0 instanceof class_1309 var2) {
         if (var2 instanceof class_1657 var3 && FriendRegistry.getInstance().b(var3.method_5477().getString())) {
            return -11141291;
         }

         float var4 = var2.method_6032() / Math.max(1.0F, var2.method_6063());
         if (var4 > 0.66F) {
            return -11141291;
         } else {
            return var4 > 0.33F ? -171 : -43691;
         }
      } else {
         return -65281;
      }
   }

   @Subscribe(
      a = -100
   )
   public void b(RenderHudEvent var1) {
      boolean var2 = true;
      if (this.isEnabled() && Constants.MINECRAFT.field_1724 != null && Constants.MINECRAFT.field_1687 != null) {
         boolean var3 = NVGRenderer.beginWindowFrame();
         if (var3) {
            Object var4 = null;
            if (RingHelper.getInstance() != null) {
               var4 = RingHelper.getInstance().getTarget();
               float var5 = RingHelper.getInstance().getOpacity();
               if (var4 != null && var5 > 0.0F) {
                  TargetRingRenderer.a((class_1309)var4, var5, RingHelper.getInstance().getColor());
               }
            }

            HashSet var31 = new HashSet();

            for (class_1297 var7 : Constants.MINECRAFT.field_1687.method_18112()) {
               if (this.c(var7) && var31.add(var7.method_5628())) {
                  class_243 var8 = Constants.MINECRAFT.field_1724.method_33571();
                  class_243 var9 = var7.method_33571();
                  class_243 var10 = var9.method_1020(var8);
                  class_243 var11 = Constants.MINECRAFT.field_1724.method_5828(1.0F);
                  if (!(var10.method_1026(var11) < 0.0)) {
                     Vector4d var12 = ESPUtility.a((class_1309)var7, Constants.MINECRAFT.method_61966().method_60637(false));
                     if (var12 != null) {
                        float var13 = (float)var12.x;
                        float var14 = (float)var12.y;
                        float var15 = (float)(var12.z - var12.x);
                        float var16 = (float)(var12.w - var12.y);
                        float var17 = 2.5F;
                        var13 -= var17;
                        var14 -= var17;
                        var15 += var17 * 2.0F;
                        var16 += var17 * 2.0F;
                        if (!(var15 < 2.0F) && !(var16 < 2.0F) && !(var15 > 1000.0F) && !(var16 > 1000.0F) && !(var13 < -500.0F) && !(var14 < -500.0F)) {
                           int var18 = (Integer)ColorUtility.getThemeColors().first;
                           if (var7 instanceof class_1657) {
                              class_1657 var19 = (class_1657)var7;
                              if (FriendRegistry.getInstance().b(var19.method_5477().getString())) {
                                 var18 = -11141291;
                              }
                           }

                           int var36 = ColorUtility.a(0, 0.75F);
                           int var20 = ColorUtility.a(var18, 0.9F);
                           if (this.m.getValue() == ESPModule.a.Normal) {
                              NVGRenderer.c(var13, var14, var15, var16, 2.0F, ColorUtility.a(var18, 0.14F));
                              NVGRenderer.a(var13 - 1.0F, var14 - 1.0F, var15 + 2.0F, var16 + 2.0F, 2.0F, 3.0F, var36);
                              NVGRenderer.a(var13, var14, var15, var16, 2.0F, 1.5F, var20);
                           } else if (this.m.getValue() == ESPModule.a.CS) {
                              float var22 = var15 / 4.0F;
                              float var23 = var15 / 4.0F;
                              float var24 = 1.5F;
                              float var25 = 3.5F;
                              NVGRenderer.c(var13, var14, var15, var16, 0.0F, ColorUtility.a(var18, 0.1F));
                              NVGRenderer.b(var13, var14, var13 + var22, var14, var25, var36);
                              NVGRenderer.b(var13, var14, var13, var14 + var23, var25, var36);
                              NVGRenderer.b(var13 + var15 - var22, var14, var13 + var15, var14, var25, var36);
                              NVGRenderer.b(var13 + var15, var14, var13 + var15, var14 + var23, var25, var36);
                              NVGRenderer.b(var13, var14 + var16, var13 + var22, var14 + var16, var25, var36);
                              NVGRenderer.b(var13, var14 + var16 - var23, var13, var14 + var16, var25, var36);
                              NVGRenderer.b(var13 + var15 - var22, var14 + var16, var13 + var15, var14 + var16, var25, var36);
                              NVGRenderer.b(var13 + var15, var14 + var16 - var23, var13 + var15, var14 + var16, var25, var36);
                              NVGRenderer.b(var13, var14, var13 + var22, var14, var24, var20);
                              NVGRenderer.b(var13, var14, var13, var14 + var23, var24, var20);
                              NVGRenderer.b(var13 + var15 - var22, var14, var13 + var15, var14, var24, var20);
                              NVGRenderer.b(var13 + var15, var14, var13 + var15, var14 + var23, var24, var20);
                              NVGRenderer.b(var13, var14 + var16, var13 + var22, var14 + var16, var24, var20);
                              NVGRenderer.b(var13, var14 + var16 - var23, var13, var14 + var16, var24, var20);
                              NVGRenderer.b(var13 + var15 - var22, var14 + var16, var13 + var15, var14 + var16, var24, var20);
                              NVGRenderer.b(var13 + var15, var14 + var16 - var23, var13 + var15, var14 + var16, var24, var20);
                           } else if (this.m.getValue() == ESPModule.a.Skeleton && var7 instanceof class_1309 var21) {
                              this.b(var21, var13, var14, var15, var16, var20, var36);
                           }

                           if (this.o.getValue() != ESPModule.b.None && var7 instanceof class_1309) {
                              class_1309 var37 = (class_1309)var7;
                              float var39 = var37.method_6032() / Math.max(1.0F, var37.method_6063());
                              var39 = Math.min(1.0F, Math.max(0.0F, var39));
                              float var42 = 3.0F;
                              float var44 = var13 - var42 - 4.5F;
                              NVGRenderer.c(var44 - 0.5F, var14 - 0.5F, var42 + 1.0F, var16 + 1.0F, 1.0F, var36);
                              NVGRenderer.c(var44, var14, var42, var16, 1.0F, ColorUtility.a(0, 0.4F));
                              float var46 = var16 * var39;
                              float var26 = var14 + var16 - var46;
                              int var27;
                              if (this.o.getValue() == ESPModule.b.Health) {
                                 var27 = Color.HSBtoRGB(var39 / 3.0F, 0.9F, 0.95F);
                              } else if (this.o.getValue() == ESPModule.b.Gradient) {
                                 int var28 = (Integer)ColorUtility.getThemeColors().second;
                                 var27 = ColorUtility.a(var18, var28, var39);
                              } else {
                                 var27 = var18;
                              }

                              NVGRenderer.c(var44, var26, var42, var46, 1.0F, ColorUtility.a(var27, 0.95F));
                              if (var39 < 0.98F) {
                                 String var50 = String.valueOf((int)(var37.method_6032() + var37.method_6067()));
                                 float var29 = Math.max(6.0F, Math.min(8.5F, var16 * 0.18F));
                                 FontRepository.a(StringObfuscation.d(a(18995, -31376), 6357))
                                    .b(var50, var44 - FontRepository.a("monument").a(var50, var29) - 2.0F, var26 - var29 / 2.0F, var29, var27);
                              }
                           }

                           if (this.p.isEnabled() && var7 instanceof class_1309) {
                              class_1309 var38 = (class_1309)var7;
                              float var41 = Math.min(1.0F, Math.max(0.0F, (float)var38.method_6096() / 20.0F));
                              if (var41 > 0.0F) {
                                 float var43 = 3.0F;
                                 float var45 = var13 + var15 + 4.5F;
                                 NVGRenderer.c(var45 - 0.5F, var14 - 0.5F, var43 + 1.0F, var16 + 1.0F, 1.0F, var36);
                                 NVGRenderer.c(var45, var14, var43, var16, 1.0F, ColorUtility.a(0, 0.4F));
                                 float var47 = var16 * var41;
                                 float var48 = var14 + var16 - var47;
                                 int var49 = -16725761;
                                 NVGRenderer.c(var45, var48, var43, var47, 1.0F, ColorUtility.a(var49, 0.95F));
                              }
                           }
                        }
                     }
                  }
               }
            }

            NVGRenderer.a(true);
         }
      } else {
         if (Overlay.recoveredMethod038()) {
            Overlay.a(new ArrayList());
            Overlay.recoveredMethod037();
         }
      }
   }

   @Subscribe
   public void b(RenderWorldEvent var1) {
      boolean var2 = true;
      if (this.isEnabled() && Constants.MINECRAFT.field_1724 != null && Constants.MINECRAFT.field_1687 != null) {
         if (this.m.getValue() == ESPModule.a.Mode3D) {
            try {
               class_9799 var3 = new class_9799(16384);

               try {
                  class_4587 var4 = var1.getMatrixStack();

                  for (class_1297 var6 : Constants.MINECRAFT.field_1687.method_18112()) {
                     if (this.c(var6)) {
                        int var7 = (Integer)ColorUtility.getThemeColors().first;
                        if (var6 instanceof class_1657) {
                           class_1657 var8 = (class_1657)var6;
                           if (FriendRegistry.getInstance().b(var8.method_5477().getString())) {
                              var7 = -11141291;
                           }
                        }

                        Color var25 = new Color(var7, true);
                        class_4598 var9 = class_4597.method_22991(var3);
                        class_243 var10 = Constants.MINECRAFT.field_1773.method_19418().method_71156();
                        double var11 = class_3532.method_16436((double)var1.getTickDelta(), var6.field_6038, var6.method_23317());
                        double var13 = class_3532.method_16436((double)var1.getTickDelta(), var6.field_5971, var6.method_23318());
                        double var15 = class_3532.method_16436((double)var1.getTickDelta(), var6.field_5989, var6.method_23321());
                        float var17 = var6.method_17681();
                        float var18 = var6.method_17682();
                        class_238 var19 = new class_238(
                              var11 - (double)var17 / 2.0,
                              var13,
                              var15 - (double)var17 / 2.0,
                              var11 + (double)var17 / 2.0,
                              var13 + (double)var18 + 0.1,
                              var15 + (double)var17 / 2.0
                           )
                           .method_989(-var10.field_1352, -var10.field_1351, -var10.field_1350);
                        class_4588 var20 = var9.method_73477(CustomRenderLayers.a(2.0F, true));
                        Draw3DUtility.b(var4, var20, var19, var25);
                        class_4588 var21 = var9.method_73477(CustomRenderLayers.a(true));
                        Draw3DUtility.a(var4, var21, var19, new Color(var25.getRed(), var25.getGreen(), var25.getBlue(), 60));
                        GL11.glDisable(2929);
                        GL11.glEnable(3042);
                        GL11.glBlendFunc(770, 771);
                        var9.method_22993();
                        GL11.glEnable(2929);
                        GL11.glDisable(3042);
                     }
                  }
               } catch (Throwable var23) {
                  try {
                     var3.close();
                  } catch (Throwable var22) {
                     var23.addSuppressed(var22);
                  }

                  throw var23;
               }

               var3.close();
            } catch (Throwable var24) {
               GL11.glEnable(2929);
            }
         }
      }
   }

   private void b(class_1309 var1, float var2, float var3, float var4, float var5, int var6, int var7) {
      float var9 = Constants.MINECRAFT.method_61966().method_60637(false);
      class_243 var10 = MathUtility.a(var1, var9);
      float var11 = var1.method_17682();
      boolean var8 = false;
      float var12 = var1.method_17681();
      double var13 = var1.method_23317() - var1.field_6038 + var1.method_23321() - var1.field_5989;
      float var15 = (float)Math.min(1.0, Math.abs(var13) * 5.0);
      float var16 = ((float)var1.field_6012 + var9) * 0.4F;
      float var17 = (float)Math.sin((double)var16) * var15;
      float var18 = var1.method_73188() != 0.0F ? var1.method_73188() : var1.method_5705(var9);
      class_243 var19 = class_243.method_1030(0.0F, var18).method_1029();
      class_243 var20 = var19.method_1036(new class_243(0.0, 1.0, 0.0)).method_1029();
      class_243 var21 = new class_243(0.0, 1.0, 0.0);
      class_243 var23 = var10.method_1031(0.0, (double)var11 * 0.75, 0.0);
      class_243 var24 = var10.method_1031(0.0, (double)var11 * 0.45, 0.0);
      class_243 var25 = var23.method_1019(var20.method_1021((double)var12 * 0.6));
      class_243 var26 = var23.method_1020(var20.method_1021((double)var12 * 0.6));
      class_243 var27 = var25.method_1020(var21.method_1021((double)var11 * 0.35)).method_1019(var19.method_1021((double)(var17 * var11) * 0.3));
      class_243 var28 = var26.method_1020(var21.method_1021((double)var11 * 0.35)).method_1020(var19.method_1021((double)(var17 * var11) * 0.3));
      class_243 var29 = var24.method_1019(var20.method_1021((double)var12 * 0.3));
      class_243 var30 = var24.method_1020(var20.method_1021((double)var12 * 0.3));
      class_243 var31 = var10.method_1019(var20.method_1021((double)var12 * 0.3)).method_1020(var19.method_1021((double)(var17 * var11) * 0.35));
      class_243 var32 = var10.method_1020(var20.method_1021((double)var12 * 0.3)).method_1019(var19.method_1021((double)(var17 * var11) * 0.35));
      class_243 var33 = var10.method_1031(0.0, (double)var11 * 0.9, 0.0);
      class_243[] var34 = new class_243[]{var23, var24, var25, var26, var27, var28, var29, var30, var31, var32, var33};
      class_243[] var35 = new class_243[var34.length];

      for (int var36 = 0; var36 < var34.length; var36++) {
         var35[var36] = ESPUtility.a(var34[var36]);
      }

      if (var35[0] != null && var35[1] != null) {
         float var39 = 3.0F;
         float var37 = 1.5F;
         BiConsumer<Integer, Integer> var38 = (var5x, var6x) -> {
            boolean var7x = true;
            if (var35[var5x] != null && var35[var6x] != null) {
               NVGRenderer.b(
                  (float)var35[var5x].field_1352, (float)var35[var5x].field_1351, (float)var35[var6x].field_1352, (float)var35[var6x].field_1351, var39, var7
               );
               NVGRenderer.b(
                  (float)var35[var5x].field_1352, (float)var35[var5x].field_1351, (float)var35[var6x].field_1352, (float)var35[var6x].field_1351, var37, var6
               );
            }
         };
         var38.accept(0, 1);
         var38.accept(2, 4);
         var38.accept(3, 5);
         var38.accept(6, 8);
         var38.accept(7, 9);
         var38.accept(0, 2);
         var38.accept(0, 3);
         var38.accept(1, 6);
         var38.accept(1, 7);
         var38.accept(0, 10);
      }
   }

   private boolean c(class_1297 var1) {
      boolean var2 = true;
      if (var1 == null || var1.method_31481() || !var1.method_5805()) {
         return false;
      } else if (Constants.MINECRAFT.field_1724 == null) {
         return false;
      } else if (var1 == Constants.MINECRAFT.field_1724 && Constants.MINECRAFT.field_1690.method_31044().method_31034()) {
         return false;
      } else if (var1.method_5767() && !this.r.isEnabled()) {
         return false;
      } else {
         if (var1 instanceof class_1657) {
            if (!this.q.isEnabled()) {
               return false;
            }
         } else {
            if (!(var1 instanceof class_1309)) {
               return false;
            }

            if (!this.s.isEnabled()) {
               return false;
            }
         }

         return Constants.MINECRAFT.field_1724.method_5739(var1) <= 64.0F;
      }
   }

   public static void a(boolean var0) {
      u = var0;
   }

   public static boolean n() {
      return u;
   }

   public static boolean o() {
      boolean var0 = n();
      return !var0;
   }

   private static String a(int var0, int var1) {
      int var2 = (var0 ^ 18999) & 65535;
      if (v[var2] == null) {
         char[] var3 = recoveredField060[var2].toCharArray();

         short var4 = switch (var3[0] & 0xFF) {
            case 0 -> 11;
            case 1 -> 132;
            case 2 -> 121;
            case 3 -> 211;
            case 4 -> 17;
            case 5 -> 135;
            case 6 -> 82;
            case 7 -> 51;
            case 8 -> 66;
            case 9 -> 108;
            case 10 -> 75;
            case 11 -> 87;
            case 12 -> 81;
            case 13 -> 95;
            case 14 -> 169;
            case 15 -> 184;
            case 16 -> 114;
            case 17 -> 105;
            case 18 -> 118;
            case 19 -> 154;
            case 20 -> 151;
            case 21 -> 136;
            case 22 -> 29;
            case 23 -> 199;
            case 24 -> 19;
            case 25 -> 212;
            case 26 -> 97;
            case 27 -> 186;
            case 28 -> 248;
            case 29 -> 63;
            case 30 -> 181;
            case 31 -> 122;
            case 32 -> 123;
            case 33 -> 220;
            case 34 -> 101;
            case 35 -> 195;
            case 36 -> 253;
            case 37 -> 119;
            case 38 -> 24;
            case 39 -> 5;
            case 40 -> 254;
            case 41 -> 177;
            case 42 -> 246;
            case 43 -> 67;
            case 44 -> 58;
            case 45 -> 164;
            case 46 -> 126;
            case 47 -> 142;
            case 48 -> 80;
            case 49 -> 86;
            case 50 -> 182;
            case 51 -> 226;
            case 52 -> 217;
            case 53 -> 61;
            case 54 -> 112;
            case 55 -> 117;
            case 56 -> 144;
            case 57 -> 180;
            case 58 -> 26;
            case 59 -> 15;
            case 60 -> 78;
            case 61 -> 178;
            case 62 -> 92;
            case 63 -> 43;
            case 64 -> 242;
            case 65 -> 192;
            case 66 -> 90;
            case 67 -> 131;
            case 68 -> 234;
            case 69 -> 79;
            case 70 -> 28;
            case 71 -> 72;
            case 72 -> 244;
            case 73 -> 224;
            case 74 -> 59;
            case 75 -> 158;
            case 76 -> 229;
            case 77 -> 30;
            case 78 -> 197;
            case 79 -> 183;
            case 80 -> 45;
            case 81 -> 34;
            case 82 -> 225;
            case 83 -> 236;
            case 84 -> 145;
            case 85 -> 179;
            case 86 -> 104;
            case 87 -> 109;
            case 88 -> 198;
            case 89 -> 174;
            case 90 -> 99;
            case 91 -> 189;
            case 92 -> 49;
            case 93 -> 153;
            case 94 -> 250;
            case 95 -> 206;
            case 96 -> 107;
            case 97 -> 194;
            case 98 -> 218;
            case 99 -> 4;
            case 100 -> 106;
            case 101 -> 130;
            case 102 -> 10;
            case 103 -> 42;
            case 104 -> 205;
            case 105 -> 46;
            case 106 -> 128;
            case 107 -> 69;
            case 108 -> 44;
            case 109 -> 85;
            case 110 -> 228;
            case 111 -> 175;
            case 112 -> 7;
            case 113 -> 143;
            case 114 -> 39;
            case 115 -> 215;
            case 116 -> 161;
            case 117 -> 148;
            case 118 -> 1;
            case 119 -> 249;
            case 120 -> 163;
            case 121 -> 6;
            case 122 -> 9;
            case 123 -> 35;
            case 124 -> 150;
            case 125 -> 103;
            case 126 -> 83;
            case 127 -> 31;
            case 128 -> 222;
            case 129 -> 124;
            case 130 -> 52;
            case 131 -> 221;
            case 132 -> 77;
            case 133 -> 227;
            case 134 -> 160;
            case 135 -> 235;
            case 136 -> 140;
            case 137 -> 176;
            case 138 -> 156;
            case 139 -> 238;
            case 140 -> 91;
            case 141 -> 16;
            case 142 -> 125;
            case 143 -> 149;
            case 144 -> 110;
            case 145 -> 65;
            case 146 -> 13;
            case 147 -> 62;
            case 148 -> 203;
            case 149 -> 2;
            case 150 -> 214;
            case 151 -> 231;
            case 152 -> 209;
            case 153 -> 84;
            case 154 -> 64;
            case 155 -> 115;
            case 156 -> 18;
            case 157 -> 159;
            case 158 -> 71;
            case 159 -> 196;
            case 160 -> 190;
            case 161 -> 247;
            case 162 -> 60;
            case 163 -> 162;
            case 164 -> 152;
            case 165 -> 53;
            case 166 -> 208;
            case 167 -> 37;
            case 168 -> 102;
            case 169 -> 47;
            case 170 -> 50;
            case 171 -> 191;
            case 172 -> 113;
            case 173 -> 210;
            case 174 -> 8;
            case 175 -> 32;
            case 176 -> 171;
            case 177 -> 237;
            case 178 -> 239;
            case 179 -> 245;
            case 180 -> 127;
            case 181 -> 166;
            case 182 -> 27;
            case 183 -> 88;
            case 184 -> 187;
            case 185 -> 12;
            case 186 -> 141;
            case 187 -> 200;
            case 188 -> 40;
            case 189 -> 25;
            case 190 -> 204;
            case 191 -> 73;
            case 192 -> 48;
            case 193 -> 233;
            case 194 -> 173;
            case 195 -> 223;
            case 196 -> 146;
            case 197 -> 147;
            case 198 -> 54;
            case 199 -> 167;
            case 200 -> 36;
            case 201 -> 98;
            case 202 -> 185;
            case 203 -> 68;
            case 204 -> 70;
            case 205 -> 57;
            case 206 -> 219;
            case 207 -> 38;
            case 208 -> 74;
            case 209 -> 157;
            case 210 -> 3;
            case 211 -> 251;
            case 212 -> 23;
            case 213 -> 56;
            case 214 -> 21;
            case 215 -> 193;
            case 216 -> 22;
            case 217 -> 133;
            case 218 -> 116;
            case 219 -> 216;
            case 220 -> 14;
            case 221 -> 138;
            case 222 -> 111;
            case 223 -> 100;
            case 224 -> 94;
            case 225 -> 89;
            case 226 -> 241;
            case 227 -> 41;
            case 228 -> 165;
            case 229 -> 213;
            case 230 -> 0;
            case 231 -> 255;
            case 232 -> 230;
            case 233 -> 252;
            case 234 -> 240;
            case 235 -> 93;
            case 236 -> 155;
            case 237 -> 202;
            case 238 -> 33;
            case 239 -> 188;
            case 240 -> 139;
            case 241 -> 137;
            case 242 -> 243;
            case 243 -> 170;
            case 244 -> 96;
            case 245 -> 120;
            case 246 -> 207;
            case 247 -> 201;
            case 248 -> 76;
            case 249 -> 232;
            case 250 -> 168;
            case 251 -> 134;
            case 252 -> 172;
            case 253 -> 20;
            case 254 -> 55;
            default -> 129;
         };
         int var5 = (var1 & 0xFF) - var4;
         if (var5 < 0) {
            var5 += 256;
         }

         int var6 = ((var1 & 65535) >>> 8) - var4;
         if (var6 < 0) {
            var6 += 256;
         }

         for (int var7 = 0; var7 < var3.length; var7++) {
            int var8 = var7 % 2;
            char var10002 = var3[var7];
            if (var8 == 0) {
               var3[var7] = (char)(var10002 ^ var5);
               var5 = ((var5 >>> 3 | var5 << 5) ^ var3[var7]) & 0xFF;
            } else {
               var3[var7] = (char)(var10002 ^ var6);
               var6 = ((var6 >>> 3 | var6 << 5) ^ var3[var7]) & 0xFF;
            }
         }

         v[var2] = new String(var3).intern();
      }

      return v[var2];
   }

   public static enum a {
   Normal(),
   CS(),
   Skeleton(),
   Mode3D(),
   None();

      
   }

   public static enum b {
   Health(),
   Standard(),
   Gradient(),
   None();

      
   }
}
