package com.google.common.jimfs.client.renderer.shader;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class CheckPost {
}
