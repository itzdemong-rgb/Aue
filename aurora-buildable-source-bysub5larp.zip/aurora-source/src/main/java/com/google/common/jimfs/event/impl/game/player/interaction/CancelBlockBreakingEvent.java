package com.google.common.jimfs.event.impl.game.player.interaction;

import com.google.common.jimfs.recovered.CancellableEvent;

public final class CancelBlockBreakingEvent extends CancellableEvent {
}
