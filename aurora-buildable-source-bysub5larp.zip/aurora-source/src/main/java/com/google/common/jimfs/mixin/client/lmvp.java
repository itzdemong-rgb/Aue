package com.google.common.jimfs.mixin.client;

import com.google.common.jimfs.client.Swag;
import com.google.common.jimfs.client.renderer.shader.ItemVisualsShader;
import com.google.common.jimfs.m.ItemVisuals;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_11687;
import net.minecraft.class_11788;
import net.minecraft.class_4618;
import net.minecraft.class_4597.class_4598;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({class_11687.class})
public class lmvp {
   @Inject(
      method = {"render"},
      at = {@At("HEAD")}
   )
   private void beforeRender(class_11788 var1, class_4598 var2, class_4618 var3, CallbackInfo var4) {
      if (Swag.getInstance() != null && Swag.getInstance().getModuleRepository() != null) {
         ItemVisuals var5 = (ItemVisuals)Swag.getInstance().getModuleRepository().a(ItemVisuals.class);
         if (var5 != null && var5.isEnabled() && var5.transitionAnimation.getValue() > 0.0F) {
            var2.method_22993();
            ItemVisualsShader.beginRender();
         }
      }
   }

   @Inject(
      method = {"render"},
      at = {@At("TAIL")}
   )
   private void afterRender(class_11788 var1, class_4598 var2, class_4618 var3, CallbackInfo var4) {
      if (Swag.getInstance() != null && Swag.getInstance().getModuleRepository() != null) {
         ItemVisuals var5 = (ItemVisuals)Swag.getInstance().getModuleRepository().a(ItemVisuals.class);
         if (var5 != null && var5.isEnabled() && var5.transitionAnimation.getValue() > 0.0F) {
            var2.method_22993();
            float var6 = (float)(System.currentTimeMillis() % 1000000L) / 1000.0F;
            ItemVisualsShader.a(
               var6, var5.transitionAnimation.getValue(), var5.smokeOverlay.isEnabled(), var5.scanWave.isEnabled()
            );
         }
      }
   }
}
