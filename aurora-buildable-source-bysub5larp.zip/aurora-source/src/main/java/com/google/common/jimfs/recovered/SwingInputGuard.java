package com.google.common.jimfs.recovered;

import com.google.common.jimfs.client.feature.helper.impl.player.mouse.MouseButton;
import com.google.common.jimfs.client.feature.helper.impl.player.mouse.MouseHelper;
import com.google.common.jimfs.event.EventDispatcher;
import com.google.common.jimfs.event.impl.game.PreGameTickEvent;
import com.google.common.jimfs.event.impl.game.player.interaction.VisualSwingEvent;
import com.google.common.jimfs.event.subscriber.Subscribe;
import net.minecraft.class_1268;

public final class SwingInputGuard implements ClientEventSubscriber {
   private static SwingInputGuard instance;
   private boolean recoveredField141 = false;

   private SwingInputGuard() {
      EventDispatcher.a(this);
   }

   public static void initialize() {
      boolean var0 = false;
      if (instance == null) {
         instance = new SwingInputGuard();
      }
   }

   @Subscribe
   public void b(VisualSwingEvent var1) {
      MouseButton var3 = MouseHelper.getLeftMouseButton();
      boolean var2 = true;
      MouseButton var4 = MouseHelper.getRightMouseButton();
      if (var1.getHand() == class_1268.field_5808) {
         if (!var3.d() || !var4.d()) {
            var1.g();
         }
      } else if (var1.getHand() == class_1268.field_5810 && !var4.d()) {
         var1.g();
      }
   }

   @Subscribe
   public void b(PreGameTickEvent var1) {
      this.recoveredField141 = false;
   }

}
