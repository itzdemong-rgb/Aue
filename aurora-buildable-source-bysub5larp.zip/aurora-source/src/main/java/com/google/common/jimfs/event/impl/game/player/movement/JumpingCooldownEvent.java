package com.google.common.jimfs.event.impl.game.player.movement;

public final class JumpingCooldownEvent {
   private int cooldownTicks;

   public JumpingCooldownEvent(int var1) {
      this.cooldownTicks = var1;
   }

   public int getCooldown() {
      return this.cooldownTicks;
   }
}
