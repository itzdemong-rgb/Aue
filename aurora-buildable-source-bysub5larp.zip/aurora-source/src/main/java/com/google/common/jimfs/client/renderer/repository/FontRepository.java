package com.google.common.jimfs.client.renderer.repository;

import com.google.common.jimfs.client.renderer.text.NVGTextRenderer;
import java.io.InputStream;
import java.util.HashMap;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class FontRepository {
   private static final HashMap fontsByName = new HashMap();

   public static NVGTextRenderer a(String var0) {
      if (fontsByName.containsKey(var0)) {
         return (NVGTextRenderer)fontsByName.get(var0);
      } else {
         InputStream var1 = FontRepository.class.getClassLoader().getResourceAsStream("assets/jimfs/fonts/" + var0 + ".ttf");
         if (var1 != null) {
            fontsByName.put(var0, new NVGTextRenderer(var0, var1));
            return (NVGTextRenderer)fontsByName.get(var0);
         } else if (!var0.equals("comfortaa-regular")) {
            return a("comfortaa-regular");
         } else {
            throw new RuntimeException("Font not found: " + var0);
         }
      }
   }
}
