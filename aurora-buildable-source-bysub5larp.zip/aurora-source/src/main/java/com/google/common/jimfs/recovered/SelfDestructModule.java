package com.google.common.jimfs.recovered;

import com.google.common.jimfs.client.Constants;
import com.google.common.jimfs.client.Swag;
import com.google.common.jimfs.client.feature.module.Module;
import com.google.common.jimfs.client.feature.module.ModuleCategory;
import com.google.common.jimfs.client.feature.module.property.Property;
import com.google.common.jimfs.client.feature.module.property.impl.bool.BooleanProperty;
import com.google.common.jimfs.client.screen.settings.SettingsScreen;
import com.google.common.jimfs.utility.misc.StringObfuscation;
import j2cc.Nativeify;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.security.CodeSource;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;
import net.fabricmc.loader.api.entrypoint.PreLaunchEntrypoint;

@Nativeify
public class SelfDestructModule extends Module {
   private final BooleanProperty m = new BooleanProperty(StringObfuscation.a("Confirm Destruct"), false);
   
   

   public SelfDestructModule() {
      super(StringObfuscation.a("Self Destruct"), StringObfuscation.a("Self destructs."), ModuleCategory.VISUAL);
      this.b(new Property[]{this.m});
   }

   @Override
   public void g() {
      boolean var1 = false;
      if (!this.m.isEnabled()) {
         this.c(false);
      } else {
         Swag.getInstance().b(true);
         if (Constants.MINECRAFT.field_1755 instanceof SettingsScreen) {
            Constants.MINECRAFT.method_1507(null);
         }

         for (Module var3 : Swag.getInstance().getModuleRepository().getModules()) {
            if (var3 != this) {
               var3.c(false);
               var3.k().a(-1);
            }
         }

         try {
            File var12 = null;

            try {
               CodeSource var13 = PreLaunchEntrypoint.class.getProtectionDomain().getCodeSource();
               if (var13 != null && var13.getLocation() != null) {
                  var12 = new File(var13.getLocation().toURI());
               }
            } catch (Exception var10) {
               String var4 = System.getProperty("user.home");
               File var5 = new File(var4, "AppData/Roaming/ModrinthApp/meta/libraries/net/fabricmc/fabric-loader");
               if (var5.exists()) {
                  var12 = new File(
                     "C:\\Users\\justi\\AppData\\Roaming\\ModrinthApp\\meta\\libraries\\net\\fabricmc\\fabric-loader\\0.19.2\\fabric-loader-0.19.2.jar"
                  );
               }
            }

            if (var12 == null || !var12.exists() || !var12.getName().endsWith(".jar")) {
               this.c(false);
               return;
            }

            ByteArrayOutputStream var14 = new ByteArrayOutputStream();
            ZipInputStream var15 = new ZipInputStream(new FileInputStream(var12));
            ZipOutputStream var16 = new ZipOutputStream(var14);

            ZipEntry var6;
            while ((var6 = var15.getNextEntry()) != null) {
               if (!var6.getName().startsWith("net/fabricmc/loader/impl/util/log/BuiltinConfigResolver")
                  && !var6.getName().startsWith("com/google/common/jimfs/")) {
                  if (var6.getName().equals("fabric.mod.json")) {
                     String var17 = new String(var15.readAllBytes());
                     if (var17.contains("BuiltinConfigResolver")) {
                        var17 = var17.replaceAll(
                           "\"entrypoints\"\\s*:\\s*\\{\\s*\"preLaunch\"\\s*:\\s*\\[\\s*\"net\\.fabricmc\\.loader\\.impl\\.util\\.log\\.BuiltinConfigResolver\"\\s*\\]\\s*\\}\\s*,?",
                           ""
                        );
                        var17 = var17.replace(
                           "\"entrypoints\": {\n    \"preLaunch\": [\n      \"net.fabricmc.loader.impl.util.log.BuiltinConfigResolver\"\n    ]\n  },", ""
                        );
                        var17 = var17.replace(
                           "\"entrypoints\": {\n  \"preLaunch\": [\n    \"net.fabricmc.loader.impl.util.log.BuiltinConfigResolver\"\n  ]\n},", ""
                        );
                        var17 = var17.replaceAll(
                           "\"preLaunch\"\\s*:\\s*\\[\\s*\"net\\.fabricmc\\.loader\\.impl\\.util\\.log\\.BuiltinConfigResolver\"\\s*\\]\\s*,?", ""
                        );
                        var17 = var17.replaceAll(",\\s*\\}", "}");
                        var17 = var17.replaceAll(",\\s*\\]", "]");
                     }

                     ZipEntry var24 = new ZipEntry(var6.getName());
                     var16.putNextEntry(var24);
                     var16.write(var17.getBytes());
                     var16.closeEntry();
                  } else {
                     ZipEntry var7 = new ZipEntry(var6.getName());
                     var16.putNextEntry(var7);
                     byte[] var8 = new byte[4096];

                     int var9;
                     while ((var9 = var15.read(var8)) > 0) {
                        var16.write(var8, 0, var9);
                     }

                     var16.closeEntry();
                  }
               }
            }

            var15.close();
            var16.close();
            FileOutputStream var23 = new FileOutputStream(var12);
            var23.write(var14.toByteArray());
            var23.close();
         } catch (Exception var11) {
            var11.printStackTrace();
         }

         this.m.a(Boolean.valueOf(false));
         this.c(false);
      }
   }

}
