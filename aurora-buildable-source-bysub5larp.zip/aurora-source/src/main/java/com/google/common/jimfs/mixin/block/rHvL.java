package com.google.common.jimfs.mixin.block;

import com.google.common.collect.AbstractIterator;
import com.google.common.jimfs.event.EventDispatcher;
import com.google.common.jimfs.event.impl.game.world.BlockShapeEvent;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BiFunction;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_238;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_5329;
import net.minecraft.class_2338.class_2339;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin({class_5329.class})
public abstract class rHvL extends AbstractIterator {
   @Shadow
   @Final
   private class_2339 field_25172;
   @Shadow
   @Final
   private class_238 field_25169;
   @Shadow
   @Final
   private BiFunction field_44787;
   @Unique
   private List gMn;

   private rHvL() {
   }

   @ModifyExpressionValue(
      method = {"computeNext"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/block/ShapeContext;getCollisionShape(Lnet/minecraft/block/BlockState;Lnet/minecraft/world/CollisionView;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/util/shape/VoxelShape;"
      )}
   )
   private class_265 pSd(class_265 var1, @Local class_2680 var2) {
      if (this.field_25172 != null) {
         BlockShapeEvent var3 = new BlockShapeEvent(this.field_25172, var2, var1, this.gMn);
         EventDispatcher.b(var3);
         return var3.getShape();
      } else {
         return var1;
      }
   }

   @Inject(
      method = {"computeNext"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void wFc(CallbackInfoReturnable var1) {
      this.tLz(var1);
   }

   @Inject(
      method = {"computeNext"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void bJk(CallbackInfoReturnable var1) {
      if (var1.getReturnValue() == null) {
         this.tLz(var1);
      }
   }

   @Unique
   private void tLz(CallbackInfoReturnable var1) {
      if (this.gMn == null) {
         this.gMn = new ArrayList();
      }

      if (!this.gMn.isEmpty()) {
         class_265 var2 = (class_265)(Object)this.gMn.removeFirst();
         var1.setReturnValue(this.field_44787.apply(this.field_25172, var2));
      }
   }
}
