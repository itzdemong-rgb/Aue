package com.google.common.jimfs.event.impl.render;

import java.util.Objects;
import net.minecraft.class_332;

public final class RenderScreenEvent {
   private RenderScreenEvent(class_332 recoveredField104, float recoveredField116, double recoveredField147, double recoveredField175) {
      this.drawContext = recoveredField104;
      this.tickDelta = recoveredField116;
      this.mouseX = recoveredField147;
      this.mouseY = recoveredField175;
   }

   private final class_332 drawContext;
   private final float tickDelta;
   private final double mouseX;
   private final double mouseY;
   
   

   public double getMouseX() {
      return this.mouseX;
   }

   public double getMouseY() {
      return this.mouseY;
   }

   @Override
   public boolean equals(Object var1) {
      boolean var2 = false;
      if (var1 == this) {
         return true;
      } else if (var1 != null && var1.getClass() == this.getClass()) {
         RenderScreenEvent var3 = (RenderScreenEvent)var1;
         return Objects.equals(this.drawContext, var3.drawContext)
            && Float.floatToIntBits(this.tickDelta) == Float.floatToIntBits(var3.tickDelta)
            && Double.doubleToLongBits(this.mouseX) == Double.doubleToLongBits(var3.mouseX)
            && Double.doubleToLongBits(this.mouseY) == Double.doubleToLongBits(var3.mouseY);
      } else {
         return false;
      }
   }

   @Override
   public int hashCode() {
      return Objects.hash(this.drawContext, this.tickDelta, this.mouseX, this.mouseY);
   }

   @Override
   public String toString() {
      return "RenderScreenEvent[drawContext="
         + this.drawContext
         + ", tickDelta="
         + this.tickDelta
         + ", mouseX="
         + this.mouseX
         + ", mouseY="
         + this.mouseY
         + ']';
   }

}
