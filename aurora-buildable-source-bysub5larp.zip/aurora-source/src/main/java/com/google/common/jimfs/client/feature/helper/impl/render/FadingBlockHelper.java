package com.google.common.jimfs.client.feature.helper.impl.render;

import com.google.common.jimfs.client.renderer.world.WorldRenderer;
import com.google.common.jimfs.event.EventDispatcher;
import com.google.common.jimfs.event.impl.render.RenderWorldEvent;
import com.google.common.jimfs.event.subscriber.Subscribe;
import com.google.common.jimfs.recovered.ClientEventSubscriber;
import com.google.common.jimfs.utility.misc.time.Stopwatch;
import com.google.common.jimfs.utility.render.ColorUtility;
import com.google.common.jimfs.utility.render.CustomRenderLayers;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_4597;
import net.minecraft.class_9799;
import net.minecraft.class_4597.class_4598;

@Environment(EnvType.CLIENT)
public final class FadingBlockHelper implements ClientEventSubscriber {
   private final List<FadingBlock> fadingBlocks = new ArrayList();
   private static FadingBlockHelper instance;

   private FadingBlockHelper() {
   }

   @Subscribe
   public void a(RenderWorldEvent var1) {
      this.fadingBlocks.removeIf(FadingBlockHelper.FadingBlock::isExpired);

      try {
         class_9799 var2 = new class_9799(1024);

         try {
            class_4598 var3 = class_4597.method_22991(var2);
            WorldRenderer var4 = new WorldRenderer(var3);

            for (FadingBlockHelper.FadingBlock var6 : this.fadingBlocks) {
               float var7 = (float)var6.getRemainingMillis() / (float)var6.durationMillis;
               float var8 = (float)(var6.fillColor >> 24 & 0xFF) / 255.0F;
               float var9 = (float)(var6.outlineColor >> 24 & 0xFF) / 255.0F;
               class_243 var10 = new class_243(
                  (double)var6.blockPosition.method_10263(), (double)var6.blockPosition.method_10264(), (double)var6.blockPosition.method_10260()
               );
               class_243 var11 = new class_243(1.0, 1.0, 1.0);
               var4.a(var1.getMatrixStack(), CustomRenderLayers.a(true), var10, var11, ColorUtility.a(var6.fillColor, var8 * var7));
            }

            var3.method_22993();
         } catch (Throwable var13) {
            try {
               var2.close();
            } catch (Throwable var12) {
               var13.addSuppressed(var12);
            }

            throw var13;
         }

         var2.close();
      } catch (Throwable var14) {
      }
   }

   public static void initialize() {
      instance = new FadingBlockHelper();
      EventDispatcher.a(instance);
   }

   @Environment(EnvType.CLIENT)
   public static class FadingBlock {
      private final Stopwatch fadeTimer;
      final class_2338 blockPosition;
      final int outlineColor;
      final int fillColor;
      final long durationMillis;

      private FadingBlock(Stopwatch stopwatch, class_2338 position, int outlineColor, int fillColor, long duration) {
         this.fadeTimer = stopwatch;
         this.blockPosition = position;
         this.outlineColor = outlineColor;
         this.fillColor = fillColor;
         this.durationMillis = duration;
      }

      public long getRemainingMillis() {
         return Math.max(0L, this.durationMillis - this.fadeTimer.getElapsedMillis());
      }

      public boolean isExpired() {
         return this.fadeTimer.a(this.durationMillis);
      }
   }
}
