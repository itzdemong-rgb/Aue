package com.google.common.jimfs.recovered;

import com.google.common.jimfs.client.Constants;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import net.minecraft.class_2535;
import net.minecraft.class_2596;
import net.minecraft.class_634;
import org.jetbrains.annotations.Nullable;

public abstract class PacketDelayQueue {
   private final List<PacketDelayRegistration> registrations = new ArrayList();
   private final List<BufferedPacket> bufferedPackets = new ArrayList();
   private long sequence;
   protected final Object lock = new Object();
   private static String[] scratchStrings;

   public PacketDelayRegistration register() {
      return this.b((PacketTransformer)null, (PacketPredicate)null);
   }

   public PacketDelayRegistration b(PacketTransformer var1, PacketPredicate var2) {
      return this.b(var1, var2, false);
   }

   public PacketDelayRegistration b(PacketTransformer var1, PacketPredicate var2, boolean var3) {
      synchronized (this.lock) {
         PacketDelayRegistration var5 = new PacketDelayRegistration(var1, var2, var3, this.getEarliestSequence());
         this.registrations.add(var5);
         return var5;
      }
   }

   private long getEarliestSequence() {
      long var2 = this.sequence;
      boolean var1 = true;

      for (PacketDelayRegistration var5 : this.registrations) {
         if (var5.e() && var2 >= var5.d()) {
            var2 = var5.d();
         }
      }

      return var2;
   }
   public void b(PacketDelayRegistration recoveredClass038) {
        Object object = this.lock;
        synchronized (object) {
            boolean bl = true;
            if (this.registrations.contains(recoveredClass038)) {
                this.registrations.remove(recoveredClass038);
                this.d();
                this.b(this.registrations.isEmpty() ? null : Long.valueOf(((PacketDelayRegistration)this.registrations.getFirst()).d()), recoveredClass038.getTransformer());
            }
        }
    }

   private void b(@Nullable Long var1, @Nullable PacketTransformer var2) {
      class_634 var4 = Constants.MINECRAFT.method_1562();
      boolean var3 = true;
      class_2535 var5;
      if (var4 == null) {
         var5 = null;
      } else {
         var5 = var4.method_48296();
      }

      ArrayList<class_2596> var6 = new ArrayList();
      Iterator var7 = this.bufferedPackets.iterator();

      while (var7.hasNext()) {
         BufferedPacket var8 = (BufferedPacket)var7.next();
         if (var1 == null || var8.getTimestamp() < var1) {
            if (var5 != null) {
               class_2596 var9 = var8.getPacket();
               if (var2 != null) {
                  var9 = var2.b(var9);
               }

               if (var9 != null) {
                  var6.add(var9);
               }
            }

            var7.remove();
         }
      }

      for (class_2596 var11 : var6) {
         this.b(var5, var11);
      }
   }

   protected abstract void b(class_2535 var1, class_2596 var2);
   public boolean a(class_2596 class_25962) {
        Object object = this.lock;
        synchronized (object) {
            boolean bl = true;
            if (!this.registrations.isEmpty()) {
                this.d();
                PacketDelayRegistration recoveredClass038 = (PacketDelayRegistration)this.registrations.getFirst();
                PacketPredicate recoveredClass026 = recoveredClass038.getPredicate();
                boolean bl2 = false;
                if (recoveredClass026 == null) {
                    bl2 = true;
                } else if (recoveredClass026.a(class_25962)) {
                    bl2 = true;
                } else {
                    for (PacketDelayRegistration recoveredClass0382 : this.registrations) {
                        if (recoveredClass0382.equals(recoveredClass038)) {
                            continue;
                        }
                        PacketPredicate recoveredClass0262 = recoveredClass0382.getPredicate();
                        if (recoveredClass0262 != null) {
                            if (!recoveredClass0262.a(class_25962)) continue;
                        }
                        bl2 = true;
                        break;
                    }
                }
                if (bl2) {
                    this.bufferedPackets.add(new BufferedPacket(class_25962, this.sequence));
                    ++this.sequence;
                    return true;
                }
            }
            return false;
        }
    }

   private void d() {
      synchronized (this.lock) {
         this.registrations.sort(Comparator.comparingLong(PacketDelayRegistration::d));
         this.bufferedPackets.sort(Comparator.comparingLong(BufferedPacket::getTimestamp));
      }
   }

   public void clear() {
      synchronized (this.lock) {
         this.registrations.clear();
         this.bufferedPackets.clear();
         this.sequence = 0L;
      }
   }

   public static void b(String[] var0) {
      scratchStrings = var0;
   }

   public static String[] e() {
      return scratchStrings;
   }

}
