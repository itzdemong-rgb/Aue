package com.google.common.jimfs.mixin.screen;

import com.google.common.jimfs.client.Constants;
import com.google.common.jimfs.client.Swag;
import com.google.common.jimfs.client.feature.helper.impl.player.slot.SlotHelper;
import com.google.common.jimfs.client.feature.helper.impl.render.ArrayListRenderer;
import com.google.common.jimfs.client.feature.helper.impl.render.IndicatorRenderer;
import com.google.common.jimfs.client.feature.module.Module;
import com.google.common.jimfs.client.screen.settings.SettingsScreen;
import com.google.common.jimfs.event.EventDispatcher;
import com.google.common.jimfs.event.impl.render.RenderHudEvent;
import com.google.common.jimfs.m.ArrayListModule;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({class_329.class})
public abstract class InGameHudMixin {
   @Redirect(
      method = {"tick()V"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/entity/player/PlayerInventory;getSelectedStack()Lnet/minecraft/item/ItemStack;"
      )
   )
   private class_1799 kS(class_1661 var1) {
      SlotHelper var2 = SlotHelper.getInstance();
      return var2.isSlotOverrideActive() && var2.getSlotMode() == SlotHelper.a.FULL ? var2.a(Constants.MINECRAFT.field_1724) : var1.method_7391();
   }

   @Redirect(
      method = {"renderHotbar"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/entity/player/PlayerInventory;getSelectedSlot()I"
      )
   )
   private int xR(class_1661 var1) {
      return SlotHelper.getInstance().a(var1);
   }

   @Inject(
      method = {"render"},
      at = {@At("TAIL")}
   )
   private void dG(class_332 var1, class_9779 var2, CallbackInfo var3) {
      RenderHudEvent var4 = new RenderHudEvent(var1);
      EventDispatcher.b(var4);
      if (Constants.MINECRAFT.field_1755 == null) {
         try {
            IndicatorRenderer.render(var2.method_60637(true));
         } catch (Throwable var7) {
         }

         try {
            ArrayListRenderer.render();
         } catch (Throwable var6) {
            System.err.println("[ArrayList] render failed: " + var6.getMessage());
            var6.printStackTrace();
         }
      }
   }

   @Inject(
      method = {"renderCrosshair"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void hT(class_332 var1, class_9779 var2, CallbackInfo var3) {
      if (!(Constants.MINECRAFT.field_1755 instanceof SettingsScreen)) {
         boolean var10000 = false;
      } else {
         var3.cancel();
      }
   }

   @Inject(
      method = {"renderHotbar"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void fT(class_332 var1, class_9779 var2, CallbackInfo var3) {
      if (!(Constants.MINECRAFT.field_1755 instanceof SettingsScreen)) {
         boolean var10000 = false;
      } else {
         var3.cancel();
      }
   }

   @Inject(
      method = {"renderStatusEffectOverlay"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void bN(class_332 var1, class_9779 var2, CallbackInfo var3) {
      Module var4 = Swag.getInstance().getModuleRepository().a(ArrayListModule.class);
      if (var4 != null && var4.isEnabled()) {
         var3.cancel();
      }
   }
}
