package com.google.common.jimfs.mixin.screen;

import com.google.common.jimfs.client.Swag;
import com.google.common.jimfs.m.ArrayListModule;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_332;
import net.minecraft.class_374;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({class_374.class})
public class bLpK {
   @Inject(
      method = {"draw"},
      at = {@At("HEAD")}
   )
   private void kW(class_332 var1, CallbackInfo var2) {
      ArrayListModule var3 = (ArrayListModule)Swag.getInstance().getModuleRepository().a(ArrayListModule.class);
      if (var3 != null && var3.isEnabled()) {
         var1.method_51448().pushMatrix();
         var1.method_51448().translate(-150.0F, 0.0F);
      }
   }

   @Inject(
      method = {"draw"},
      at = {@At("TAIL")}
   )
   private void xR(class_332 var1, CallbackInfo var2) {
      ArrayListModule var3 = (ArrayListModule)Swag.getInstance().getModuleRepository().a(ArrayListModule.class);
      if (var3 != null && var3.isEnabled()) {
         var1.method_51448().popMatrix();
      }
   }
}
