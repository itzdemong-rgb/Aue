package com.google.common.jimfs.recovered;

import com.google.common.jimfs.client.feature.module.property.Property;
import java.util.Objects;

public final class PropertyUpdateEvent {
   private final Property property;

   public PropertyUpdateEvent(Property var1) {
      this.property = var1;
   }

   @Override
   public boolean equals(Object var1) {
      boolean var2 = false;
      if (var1 == this) {
         return true;
      } else if (var1 != null && var1.getClass() == this.getClass()) {
         PropertyUpdateEvent var3 = (PropertyUpdateEvent)var1;
         return Objects.equals(this.property, var3.property);
      } else {
         return false;
      }
   }

   @Override
   public int hashCode() {
      return Objects.hash(this.property);
   }

   @Override
   public String toString() {
      return "PropertyUpdateEvent[property=" + this.property + ']';
   }

}
