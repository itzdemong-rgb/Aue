package com.google.common.jimfs.recovered;

public class GenericServerProfile extends ServerProfile {
   public GenericServerProfile(String var1) {
      super(var1);
   }
}
