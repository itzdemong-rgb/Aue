package com.google.common.jimfs.event.impl.game.player.movement;

import com.google.common.jimfs.recovered.CancellableEvent;

public final class PreMovementPacketEvent extends CancellableEvent {
   private double x;
   private double y;
   private double z;
   private float yaw;
   private float pitch;
   private boolean recoveredField241;
   private boolean j;
   private boolean k;
   private boolean l;
   private boolean m;

   public PreMovementPacketEvent(double var1, double var3, double var5, float var7, float var8, boolean var9, boolean var10, boolean var11) {
      this.x = var1;
      this.y = var3;
      this.z = var5;
      this.yaw = var7;
      this.pitch = var8;
      this.k = var9;
      this.l = var10;
      this.m = var11;
   }

   public double getX() {
      return this.x;
   }

   public double getY() {
      return this.y;
   }

   public double getZ() {
      return this.z;
   }

   public float getYaw() {
      return this.yaw;
   }

   public float getPitch() {
      return this.pitch;
   }

   public void b(float var1) {
      this.yaw = var1;
   }

   public void c(float var1) {
      this.pitch = var1;
   }

   public boolean isOnGround() {
      return this.k;
   }

   public boolean recoveredMethod110() {
      return this.l;
   }

   public boolean d() {
      return this.m;
   }

   public boolean e() {
      return this.recoveredField241;
   }

   public boolean f() {
      return this.j;
   }
}
