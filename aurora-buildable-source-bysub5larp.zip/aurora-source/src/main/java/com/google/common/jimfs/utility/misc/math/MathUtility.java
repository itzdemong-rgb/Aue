package com.google.common.jimfs.utility.misc.math;

import java.util.Objects;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_3532;

public final class MathUtility {
   private static boolean recoveredField110 = true;

   public static Number b(Number var0, Number var1, Number var2, Number var3) {
      Objects.requireNonNull(var0);
      switch (var0) {
         case Double var6:
            Double var11 = (double)Math.round(var6 / var3.doubleValue()) * var3.doubleValue();
            return class_3532.method_15350(var11, var1.doubleValue(), var2.doubleValue());
         case Float var7:
            Float var12 = (float)Math.round(var7 / var3.floatValue()) * var3.floatValue();
            return class_3532.method_15363(var12, var1.floatValue(), var2.floatValue());
         case Long var8:
            Long var13 = (long)Math.round((float)var8.longValue() / (float)var3.longValue()) * var3.longValue();
            return class_3532.method_53062(var13, var1.longValue(), var2.longValue());
         default:
            int var9 = var0.intValue();
            var9 = Math.round((float)var9 / (float)var3.intValue()) * var3.intValue();
            int var10 = Math.round((float)var9 / (float)var3.intValue()) * var3.intValue();
            var10 = class_3532.method_15340(var10, var1.intValue(), var2.intValue());
            return var10;
      }
   }

   public static class_243 a(class_1297 var0, float var1) {
      return new class_243(
         class_3532.method_16436((double)var1, var0.field_6038, var0.method_23317()),
         class_3532.method_16436((double)var1, var0.field_5971, var0.method_23318()),
         class_3532.method_16436((double)var1, var0.field_5989, var0.method_23321())
      );
   }

   public static float a(float var0, float var1, float var2) {
      return var0 + (var1 - var0) * var2;
   }

   public static void b(boolean var0) {
      recoveredField110 = var0;
   }

   public static boolean recoveredMethod084() {
      return recoveredField110;
   }

   public static boolean recoveredMethod110() {
      boolean var0 = recoveredMethod084();
      return !var0;
   }
}
