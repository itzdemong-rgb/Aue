package com.google.common.jimfs.event.impl.game.input;

public final class MoveInputEvent {
   private float sideways;
   private float forward;
   private boolean jumping;
   private boolean sneaking;

   public MoveInputEvent(float var1, float var2, boolean var3, boolean var4) {
      this.sideways = var1;
      this.forward = var2;
      this.jumping = var3;
      this.sneaking = var4;
   }

   public float getSideways() {
      return this.sideways;
   }

   public boolean isJumping() {
      return this.jumping;
   }

   public float getForward() {
      return this.forward;
   }

   public boolean isSneaking() {
      return this.sneaking;
   }

   public void b(boolean var1) {
      this.sneaking = var1;
   }
}
