package com.google.common.jimfs.client.renderer;

import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class Overlay {
   private static boolean recoveredField045 = false;

   public static boolean recoveredMethod038() {
      return recoveredField045;
   }

   public static void a(List var0) {
   }

   public static void recoveredMethod037() {
   }

   @Environment(EnvType.CLIENT)
   public static class Box {
   }
}
