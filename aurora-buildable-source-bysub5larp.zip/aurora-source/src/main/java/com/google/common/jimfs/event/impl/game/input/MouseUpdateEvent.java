package com.google.common.jimfs.event.impl.game.input;

public final class MouseUpdateEvent {
   private double deltaX;
   private double deltaY;
   private final double sensitivity;
   private final boolean synthetic;
   private boolean handled;

   public MouseUpdateEvent(double var1, double var3, double var5, boolean var7) {
      this.sensitivity = var5;
      this.deltaY = var3;
      this.deltaX = var1;
      this.synthetic = var7;
   }

   public double getDeltaX() {
      return this.deltaX;
   }

   public void b(double var1) {
      this.deltaX = var1;
   }

   public double getDeltaY() {
      return this.deltaY;
   }

   public void c(double var1) {
      this.deltaY = var1;
   }

   public double d() {
      return this.sensitivity;
   }

   public boolean isHandled() {
      return this.handled;
   }

   public void e() {
      this.handled = true;
   }

   public boolean f() {
      return this.synthetic;
   }
}
