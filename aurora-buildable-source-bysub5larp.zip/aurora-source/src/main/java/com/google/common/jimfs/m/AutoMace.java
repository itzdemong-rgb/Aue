package com.google.common.jimfs.m;

import com.google.common.jimfs.client.Constants;
import com.google.common.jimfs.client.feature.module.Module;
import com.google.common.jimfs.client.feature.module.ModuleCategory;
import com.google.common.jimfs.client.feature.module.property.Property;
import com.google.common.jimfs.client.feature.module.property.impl.bool.BooleanProperty;
import com.google.common.jimfs.client.feature.module.property.impl.mode.ModeProperty;
import com.google.common.jimfs.client.feature.module.property.impl.number.NumberProperty;
import com.google.common.jimfs.event.impl.game.PreGameTickEvent;
import com.google.common.jimfs.event.impl.game.input.PreHandleInputEvent;
import com.google.common.jimfs.event.impl.game.player.movement.PostMovementPacketEvent;
import com.google.common.jimfs.event.subscriber.Subscribe;
import com.google.common.jimfs.utility.misc.StringObfuscation;
import com.google.common.jimfs.utility.player.RotationUtility;
import j2cc.Nativeify;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_238;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_3966;

@Nativeify
public final class AutoMace extends Module {
   private final NumberProperty m = new NumberProperty(StringObfuscation.a("Fall Distance"), 3.0, 0.0, 10.0, 0.5);
   private final NumberProperty o = new NumberProperty(StringObfuscation.a("Range"), 2.5, 1.0, 3.5, 0.1);
   private final NumberProperty p = new NumberProperty(StringObfuscation.a("Min CPS"), 8.0, 1.0, 20.0, 1.0);
   private final NumberProperty q = new NumberProperty(StringObfuscation.a("Max CPS"), 12.0, 1.0, 20.0, 1.0);
   private final NumberProperty r = new NumberProperty(StringObfuscation.a("Rotation Speed"), 40.0, 10.0, 120.0, 5.0);
   private final ModeProperty s = new ModeProperty(StringObfuscation.a("Target"), AutoMace.a.NEAREST);
   private final BooleanProperty t = new BooleanProperty(StringObfuscation.a("Disable In Screen"), true);
   private long u = 0L;
   private float v = 0.0F;
   private float w = 0.0F;
   private float x = 0.0F;
   private float y = 0.0F;
   private float z = 0.0F;
   private float A = 0.0F;
   private class_1657 B = null;
   private boolean C = false;
   private boolean D = false;
   
   

   public AutoMace() {
      super(StringObfuscation.a("Auto Mace"), StringObfuscation.a("Automatically attacks while holding a mace."), ModuleCategory.COMBAT);
      this.b(new Property[]{this.m, this.o, this.p, this.q, this.r, this.s, this.t});
   }

   @Override
   protected void g() {
      super.g();
      this.u = 0L;
      boolean var1 = false;
      this.z = 0.0F;
      this.A = 0.0F;
      this.C = false;
      this.D = false;
      if (Constants.MINECRAFT.field_1724 != null) {
         this.v = Constants.MINECRAFT.field_1724.method_36454();
         this.w = Constants.MINECRAFT.field_1724.method_36455();
      }
   }

   @Override
   protected void h() {
      RotationUtility.recoveredField045 = false;
      this.C = false;
      this.D = false;
      this.B = null;
      super.h();
   }

   @Subscribe
   public void b(PreGameTickEvent var1) {
      boolean var2 = false;
      if (Constants.MINECRAFT.field_1724 != null && Constants.MINECRAFT.field_1687 != null && Constants.MINECRAFT.field_1761 != null) {
         if (this.B == null || !this.C) {
            this.D = false;
         } else if (this.B.method_5805() && !this.B.method_29504()) {
            long var3 = System.currentTimeMillis();
            double var5 = 1000.0 / (Double)this.p.getValue();
            double var7 = 1000.0 / (Double)this.q.getValue();
            double var9 = var5 + Math.random() * (var7 - var5);
            this.D = (double)(var3 - this.u) >= var9;
         } else {
            this.B = null;
            this.D = false;
         }

         if (this.t.isEnabled() && Constants.MINECRAFT.field_1755 != null) {
            this.C = false;
            this.B = null;
            this.D = false;
         } else {
            this.x = Constants.MINECRAFT.field_1724.method_36454();
            this.y = Constants.MINECRAFT.field_1724.method_36455();
            class_1799 var21 = Constants.MINECRAFT.field_1724.method_6047();
            boolean var4 = var21.method_31574(class_1802.field_49814);
            if (var4 && !(Constants.MINECRAFT.field_1724.field_6017 < (double)((Double)this.m.getValue()).floatValue())) {
               class_1657 var22 = this.d();
               if (var22 != null
                  && !(
                     b(Constants.MINECRAFT.field_1724.method_5829(), var22.method_5829()) > (double)((Double)this.o.getValue()).floatValue()
                  )) {
                  this.B = var22;
                  class_243 var6 = new class_243(
                     Constants.MINECRAFT.field_1724.method_23317(),
                     Constants.MINECRAFT.field_1724.method_23320(),
                     Constants.MINECRAFT.field_1724.method_23321()
                  );
                  class_238 var23 = var22.method_5829();
                  double var8 = Math.min(Math.max(var6.field_1352, var23.field_1323), var23.field_1320);
                  double var10 = Math.min(Math.max(var6.field_1351, var23.field_1322), var23.field_1325);
                  double var12 = Math.min(Math.max(var6.field_1350, var23.field_1321), var23.field_1324);
                  class_243 var14 = new class_243(var8, var10, var12);
                  class_241 var15 = RotationUtility.b(var6, var14);
                  float var16 = ((Double)this.r.getValue()).floatValue();
                  float var17 = class_3532.method_15393(var15.field_1343 - this.v);
                  float var18 = var15.field_1342 - this.w;
                  float var19 = this.v + this.b(var17, var16, true);
                  float var20 = this.w + this.b(var18, var16, false);
                  var20 = class_3532.method_15363(var20, -90.0F, 90.0F);
                  this.v = var19;
                  this.w = var20;
                  this.C = true;
               } else {
                  this.C = false;
                  this.B = null;
               }
            } else {
               this.C = false;
               this.B = null;
            }
         }
      }
   }

   @Subscribe
   public void b(PreHandleInputEvent var1) {
      if (this.C && Constants.MINECRAFT.field_1724 != null) {
         RotationUtility.recoveredField045 = true;
         RotationUtility.recoveredField001 = this.v;
         RotationUtility.recoveredField063 = this.w;
      }
   }

   @Subscribe
   public void b(PostMovementPacketEvent var1) {
      boolean var2 = false;
      if (this.C && Constants.MINECRAFT.field_1724 != null && Constants.MINECRAFT.field_1761 != null && this.D && this.B != null) {
         if (this.B.method_5805() && !this.B.method_29504()) {
            double var3 = b(Constants.MINECRAFT.field_1724.method_5829(), this.B.method_5829());
            if (var3 <= (double)((Double)this.o.getValue()).floatValue()) {
               Constants.MINECRAFT.field_1765 = new class_3966(this.B);
               Constants.MINECRAFT.field_1692 = this.B;
               Constants.MINECRAFT.field_1761.method_2918(Constants.MINECRAFT.field_1724, this.B);
               this.u = System.currentTimeMillis();
            }
         }

         this.B = null;
         this.D = false;
      }

      if (this.C && Constants.MINECRAFT.field_1724 != null) {
         Constants.MINECRAFT.field_1724.method_36456(this.x);
         Constants.MINECRAFT.field_1724.method_36457(this.y);
      }

      RotationUtility.recoveredField045 = false;
   }

   private float b(float var1, float var2, boolean var3) {
      float var5 = ((Double)Constants.MINECRAFT.field_1690.method_42495().method_41753()).floatValue() * 0.6F + 0.2F;
      boolean var4 = true;
      float var6 = var5 * var5 * var5 * 1.2F;
      float var7 = (var3 ? this.z : this.A) + var1;
      float var8 = var6 <= 0.0F ? var7 : (float)((int)(var7 / var6)) * var6;
      float var9 = var7 - var8;
      if (var3) {
         this.z = var9;
      } else {
         this.A = var9;
      }

      return Math.abs(var8) <= var2 ? var8 : Math.signum(var8) * var2;
   }

   private static double b(class_238 var0, class_238 var1) {
      double var2 = Math.max(0.0, Math.max(var1.field_1323 - var0.field_1320, var0.field_1323 - var1.field_1320));
      double var4 = Math.max(0.0, Math.max(var1.field_1322 - var0.field_1325, var0.field_1322 - var1.field_1325));
      double var6 = Math.max(0.0, Math.max(var1.field_1321 - var0.field_1324, var0.field_1321 - var1.field_1324));
      return Math.sqrt(var2 * var2 + var4 * var4 + var6 * var6);
   }

   private class_1657 d() {
        double d = (Double)this.o.getValue();
        java.util.List<class_1657> list = Constants.MINECRAFT.field_1687.method_8390(class_1657.class, Constants.MINECRAFT.field_1724.method_5829().method_1014(d), class_16572 -> {
            boolean bl = false;
            if (class_16572 == Constants.MINECRAFT.field_1724) return false;
            if (!class_16572.method_5805()) return false;
            if (class_16572.method_29504()) return false;
            if (!Constants.MINECRAFT.field_1724.method_6057((net.minecraft.class_1297)class_16572)) return false;
            if (!(AutoMace.b(Constants.MINECRAFT.field_1724.method_5829(), class_16572.method_5829()) <= d)) return false;
            return true;
        });
        boolean bl = false;
        if (list.isEmpty()) {
            return null;
        }
        return switch (((a)((Object)this.s.getValue())).ordinal()) {
            default -> throw new MatchException(null, null);
            case 0 -> list.stream().min(java.util.Comparator.comparingDouble(class_16572 -> AutoMace.b(Constants.MINECRAFT.field_1724.method_5829(), class_16572.method_5829()))).orElse(null);
            case 1 -> list.stream().min(java.util.Comparator.comparingDouble(net.minecraft.class_1309::method_6032)).orElse(null);
            case 2 -> list.stream().min(java.util.Comparator.comparingDouble(class_16572 -> {
                class_243 class_2432 = new class_243(Constants.MINECRAFT.field_1724.method_23317(), Constants.MINECRAFT.field_1724.method_23320(), Constants.MINECRAFT.field_1724.method_23321());
                class_243 class_2433 = new class_243(class_16572.method_23317(), class_16572.method_23320(), class_16572.method_23321());
                class_241 class_2412 = RotationUtility.b(class_2432, class_2433);
                float f = class_3532.method_15393((float)(Constants.MINECRAFT.field_1724.method_36454() - class_2412.field_1343));
                float f2 = Constants.MINECRAFT.field_1724.method_36455() - class_2412.field_1342;
                return Math.sqrt(f * f + f2 * f2);
            })).orElse(null);
        };
    }

   public static enum a {
   NEAREST(),
   LOWEST_HEALTH(),
   FOV();

      
   }
}
