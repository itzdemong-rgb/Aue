package com.google.common.jimfs.mixin.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Environment(EnvType.CLIENT)
@Mixin({class_1297.class})
public interface EntityRotationAccessor {
   @Accessor("lastYaw")
   float getLastYaw();

   @Accessor("lastYaw")
   void b(float var1);

   @Accessor("lastPitch")
   float getLastPitch();

   @Accessor("lastPitch")
   void d(float var1);
}
