package com.google.common.jimfs.recovered;

import com.google.common.jimfs.client.Constants;
import com.google.common.jimfs.mixin.input.MouseAccessor;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import net.minecraft.class_11910;

public final class KeyInputHelper {
   public static Map pressedButtons = new HashMap();
   public static ExecutorService EXECUTOR = Executors.newCachedThreadPool();

   public static MouseAccessor getKeyboardAccessor() {
      return (MouseAccessor)Constants.MINECRAFT.field_1729;
   }

   public static void b(int var0) {
      pressedButtons.put(var0, true);
      getKeyboardAccessor().hT(Constants.MINECRAFT.method_22683().method_4490(), new class_11910(var0, 0), 1);
   }

   public static void c(int var0) {
      getKeyboardAccessor().hT(Constants.MINECRAFT.method_22683().method_4490(), new class_11910(var0, 0), 0);
      pressedButtons.put(var0, false);
   }

   public static void b(int var0, int var1) {
      EXECUTOR.submit(() -> {
         try {
            b(var0);
            Thread.sleep((long)var1);
            c(var0);
         } catch (InterruptedException var3) {
         }
      });
   }

   public static void d(int var0) {
      b(var0, 35);
   }
}
