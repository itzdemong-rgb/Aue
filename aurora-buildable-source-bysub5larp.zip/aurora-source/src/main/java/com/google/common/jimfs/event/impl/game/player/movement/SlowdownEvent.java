package com.google.common.jimfs.event.impl.game.player.movement;

import com.google.common.jimfs.recovered.CancellableEvent;

public final class SlowdownEvent extends CancellableEvent {
   private float multiplier;

   public SlowdownEvent(float var1) {
      this.multiplier = var1;
   }

   public float getMultiplier() {
      return this.multiplier;
   }
}
