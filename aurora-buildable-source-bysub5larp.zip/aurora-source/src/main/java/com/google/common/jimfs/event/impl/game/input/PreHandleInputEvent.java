package com.google.common.jimfs.event.impl.game.input;

public final class PreHandleInputEvent {
}
