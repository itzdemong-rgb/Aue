package com.google.common.jimfs.mixin.network;

import com.mojang.authlib.yggdrasil.YggdrasilUserApiService;
import com.mojang.authlib.yggdrasil.response.UserAttributesResponse.Privileges;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Environment(EnvType.CLIENT)
@Mixin({YggdrasilUserApiService.class})
public final class eQyS {
   private eQyS() {
   }

   @Redirect(
      method = {"fetchProperties"},
      at = @At(
         value = "INVOKE",
         target = "Lcom/mojang/authlib/yggdrasil/response/UserAttributesResponse$Privileges;getTelemetry()Z",
         remap = false
      ),
      remap = false,
      require = 0
   )
   private boolean kW(Privileges var1) {
      return false;
   }
}
