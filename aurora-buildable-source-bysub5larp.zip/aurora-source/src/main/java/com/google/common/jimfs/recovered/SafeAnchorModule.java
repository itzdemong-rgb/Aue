package com.google.common.jimfs.recovered;

import com.google.common.jimfs.client.Constants;
import com.google.common.jimfs.client.feature.module.Module;
import com.google.common.jimfs.client.feature.module.ModuleCategory;
import com.google.common.jimfs.client.feature.module.property.Property;
import com.google.common.jimfs.client.feature.module.property.impl.KeybindProperty;
import com.google.common.jimfs.client.feature.module.property.impl.bool.BooleanProperty;
import com.google.common.jimfs.client.feature.module.property.impl.number.NumberProperty;
import com.google.common.jimfs.event.impl.game.PreGameTickEvent;
import com.google.common.jimfs.event.impl.game.input.MoveInputEvent;
import com.google.common.jimfs.event.impl.game.player.interaction.ItemUseEvent;
import com.google.common.jimfs.event.impl.game.player.movement.PreMovementPacketEvent;
import com.google.common.jimfs.event.subscriber.Subscribe;
import com.google.common.jimfs.mixin.eQyS;
import com.google.common.jimfs.utility.misc.StringObfuscation;
import com.google.common.jimfs.utility.player.PlayerUtility;
import com.google.common.jimfs.utility.player.RotationUtility;
import j2cc.Nativeify;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_4969;
import net.minecraft.class_239.class_240;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;

@Nativeify
public final class SafeAnchorModule extends Module {
   private final KeybindProperty m = new KeybindProperty(StringObfuscation.a("Activation Key"), 1);
   private final KeybindProperty o = new KeybindProperty(StringObfuscation.a("Obsidian Key"), -1);
   private final NumberProperty p = new NumberProperty(StringObfuscation.a("Explode Slot"), 1.0, 1.0, 9.0, 1.0);
   private final BooleanProperty q = new BooleanProperty(StringObfuscation.a("Enable Jitter"), false);
   private final NumberProperty r = new NumberProperty(StringObfuscation.a("Jitter Intensity"), 0.5, 0.0, 5.0, 0.1);
   private final NumberProperty s = new NumberProperty(StringObfuscation.a("Jitter Exponent"), 1.5, 1.0, 3.0, 0.1);
   private final NumberProperty t = new NumberProperty(StringObfuscation.a("Jitter Start Thresh"), 2.0, 0.0, 10.0, 1.0);
   private final NumberProperty u = new NumberProperty(StringObfuscation.a("Place Delay"), 0.0, 0.0, 5.0, 1.0);
   private final NumberProperty v = new NumberProperty(StringObfuscation.a("Shield Delay"), 0.0, 0.0, 5.0, 1.0);
   private final NumberProperty w = new NumberProperty(StringObfuscation.a("Charge Delay"), 0.0, 0.0, 5.0, 1.0);
   private final NumberProperty x = new NumberProperty(StringObfuscation.a("Explode Delay"), 0.0, 0.0, 5.0, 1.0);
   private final NumberProperty y = new NumberProperty(StringObfuscation.a("Aim Speed"), 1.0, 0.01, 1.0, 0.01);
   private final NumberProperty z = new NumberProperty(StringObfuscation.a("Charge Limit MS"), 0.0, 0.0, 300.0, 10.0);
   private final NumberProperty A = new NumberProperty(StringObfuscation.a("Min Align Ticks"), 0.0, 0.0, 5.0, 1.0);
   private final BooleanProperty B = new BooleanProperty(StringObfuscation.a("Silent Aim"), true);
   private final BooleanProperty C = new BooleanProperty(StringObfuscation.a("Smooth Aim"), false);
   private final BooleanProperty D = new BooleanProperty(StringObfuscation.a("Auto Repeat"), false);
   private final NumberProperty E = new NumberProperty(StringObfuscation.a("Repeat Delay"), 1.0, 1.0, 20.0, 1.0);
   public SafeAnchorModule.b F = SafeAnchorModule.b.IDLE;
   private boolean G = true;
   private boolean H = false;
   private int I = 0;
   private int J = 0;
   private SafeAnchorModule.b K = SafeAnchorModule.b.IDLE;
   private int L = 0;
   private class_2338 M = null;
   private class_2338 N = null;
   private class_3965 O = null;
   private class_3965 P = null;
   private class_3965 Q = null;
   private class_3965 R = null;
   private class_243 S = null;
   private class_2350 T = null;
   private class_2338 U = null;
   private int V = 0;
   public float W;
   public float X;
   public boolean Y;
   private float Z = 0.0F;
   private float aa = 0.0F;
   private boolean ab = false;
   private float ac;
   private float ad;
   public boolean ae;
   public boolean af;
   public boolean ag;
   public boolean ah;
   private boolean ai;
   private int aj;
   private int ak;
   private int al;
   private int am;
   private long an;
   private class_2338 ao;
   private boolean ap;
   private int aq;
   private boolean ar;
   
   

   public SafeAnchorModule() {
      super(StringObfuscation.a("Safe Anchor"), StringObfuscation.a("Charge anchor when locking down, lock up to detonate"), ModuleCategory.CRYSTAL);
      boolean var1 = false;
      this.ac = 0.0F;
      this.ad = 0.0F;
      this.aj = 0;
      this.ak = 0;
      this.al = 0;
      this.am = 0;
      this.an = 0L;
      this.ao = null;
      this.ap = false;
      this.aq = 0;
      this.ar = false;
      this.b(
         new Property[]{
            this.m, this.o, this.p, this.q, this.r, this.s, this.t, this.u, this.v, this.w, this.x, this.y, this.z, this.A, this.B, this.C, this.D, this.E
         }
      );
   }

   @Override
   protected void g() {
      super.g();
      this.n();
   }

   @Override
   protected void h() {
      this.n();
      super.h();
   }

   private void n() {
      boolean var2 = this.Y;
      boolean var1 = true;
      boolean var3 = this.ab;
      if (!var2 && !var3) {
         float var10000 = 0.0F;
      }

      if (!var2 && !var3) {
         float var7 = 0.0F;
      }

      this.M = null;
      this.N = null;
      this.O = null;
      this.P = null;
      this.Q = null;
      this.R = null;
      this.S = null;
      this.T = null;
      this.U = null;
      this.V = 0;
      this.ae = false;
      this.af = false;
      this.ag = false;
      this.ah = false;
      this.ap = false;
      this.ai = false;
      this.an = 0L;
      this.ao = null;
      this.F = SafeAnchorModule.b.IDLE;
      this.H = false;
      this.I = 0;
      this.aj = 0;
      this.ak = 0;
      this.al = 0;
      this.am = 0;
      this.J = 0;
      this.K = SafeAnchorModule.b.IDLE;
      this.L = 0;
      this.aq = 0;
      this.ar = false;
      if (!var2 && !var3) {
         this.Y = false;
         this.ab = false;
         RotationUtility.recoveredField045 = false;
      } else {
         this.Y = true;
         this.ab = false;
         RotationUtility.recoveredField045 = true;
         class_310 var6 = Constants.MINECRAFT;
         if (var6.field_1724 != null) {
            this.W = var6.field_1724.method_36454();
            this.X = var6.field_1724.method_36455();
            RotationUtility.recoveredField001 = this.W;
            RotationUtility.recoveredField063 = this.X;
         }
      }
   }

   private boolean o() {
      Integer var2 = (Integer)this.m.getValue();
      boolean var1 = true;
      if (var2 != null && var2 != -1) {
         return var2 >= 0 && var2 <= 7 ? PlayerUtility.c(var2) : PlayerUtility.isMouseButtonPressed(var2);
      } else {
         return false;
      }
   }

   private boolean p() {
      Integer var2 = (Integer)this.o.getValue();
      boolean var1 = false;
      if (var2 != null && var2 != -1) {
         return var2 >= 0 && var2 <= 7 ? PlayerUtility.c(var2) : PlayerUtility.isMouseButtonPressed(var2);
      } else {
         return false;
      }
   }

   private boolean q() {
      class_310 var2 = Constants.MINECRAFT;
      boolean var1 = false;
      if (var2.field_1724 == null) {
         return false;
      } else {
         boolean var3 = this.s() != -1;
         boolean var4 = this.t() != -1;
         return var3 && var4 ? !this.ar || this.u() != -1 : false;
      }
   }

   private boolean r() {
      class_310 var2 = Constants.MINECRAFT;
      boolean var1 = true;
      if (var2.field_1724 != null && this.M != null && this.N != null) {
         double var3 = var2.field_1724
            .method_5649((double)this.M.method_10263() + 0.5, (double)this.M.method_10264() + 0.5, (double)this.M.method_10260() + 0.5);
         boolean var5 = new class_238(this.N).method_994(var2.field_1724.method_5829());
         boolean var6 = this.N.method_10263() == this.M.method_10263()
            && this.N.method_10260() == this.M.method_10260()
            && this.N.method_10264() != this.M.method_10264();
         return var3 < 3.24 || var5 || var6;
      } else {
         return true;
      }
   }

   @Subscribe
   public void b(ItemUseEvent var1) {
      boolean var2 = false;
      if (this.isEnabled() && (this.H || this.o() || this.p())) {
         var1.g();
      }
   }

   @Subscribe
   public void b(MoveInputEvent var1) {
      boolean var2 = true;
      if (this.isEnabled() && this.F == SafeAnchorModule.b.PLACING_SHIELD) {
         boolean var3 = this.U != null
            && Constants.MINECRAFT.field_1687 != null
            && Constants.MINECRAFT.field_1687.method_8320(this.U).method_27852(class_2246.field_23152);
         if (var3) {
            var1.b(true);
         }
      }
   }

   @Subscribe
   public void b(PreGameTickEvent var1) {
      boolean var2 = false;
      if (this.isEnabled()) {
         if (!this.B.isEnabled()) {
            this.Y = false;
         }

         class_310 var3 = Constants.MINECRAFT;
         if (var3.field_1687 != null && var3.field_1724 != null && var3.field_1755 == null) {
            if (PlayerUtility.d()) {
               this.n();
               this.G = true;
            } else {
               boolean var4 = this.o();
               boolean var5 = this.p();
               boolean var6 = var4 || var5;
               if (var6) {
                  if (this.G) {
                     if (this.ap) {
                        this.ap = false;
                        this.F = SafeAnchorModule.b.IDLE;
                        this.H = true;
                        this.G = false;
                        this.I = 0;
                        this.J = 0;
                        return;
                     }

                     this.n();
                     this.ar = var5 && !var4;
                     if (!this.q()) {
                        this.G = false;
                        return;
                     }

                     this.H = true;
                     this.G = false;
                     this.I = 0;
                  }
               } else {
                  this.G = true;
               }

               if (this.H && this.F == SafeAnchorModule.b.IDLE && this.aq > 0) {
                  this.aq--;
                  if (this.aq == 0) {
                     this.n();
                     this.ar = this.p();
                     if (!this.q()) {
                        this.G = false;
                     } else {
                        this.H = true;
                        this.G = false;
                        this.I = 0;
                     }
                  }
               } else if (!this.H) {
                  this.n();
               } else {
                  this.I++;
                  if (this.I > 100) {
                     this.n();
                  } else {
                     if (this.F == this.K) {
                        this.L++;
                     } else {
                        this.K = this.F;
                        this.L = 0;
                     }

                     if (this.F != SafeAnchorModule.b.IDLE && this.L > 20) {
                        this.n();
                     } else {
                        if (this.M != null) {
                           double var7 = var3.field_1724.method_23317() - ((double)this.M.method_10263() + 0.5);
                           double var9 = var3.field_1724.method_23320() - ((double)this.M.method_10264() + 0.5);
                           double var11 = var3.field_1724.method_23321() - ((double)this.M.method_10260() + 0.5);
                           double var13 = var7 * var7 + var9 * var9 + var11 * var11;
                           boolean var15 = this.F == SafeAnchorModule.b.CHARGING || this.F == SafeAnchorModule.b.EXPLODING;
                           if (var13 > 25.0
                              || var15 && !var3.field_1687.method_8320(this.M).method_27852(class_2246.field_23152)
                              || !var15
                                 && !var3.field_1687.method_8320(this.M).method_27852(class_2246.field_23152)
                                 && !var3.field_1687.method_8320(this.M).method_45474()) {
                              this.n();
                              return;
                           }
                        }

                        if (this.M == null && var3.field_1765 instanceof class_3965 var16 && var16.method_17783() == class_240.field_1332) {
                           class_2338 var19 = var16.method_17777();
                           if (var3.field_1687.method_8320(var19).method_27852(class_2246.field_23152)) {
                              this.M = var19;
                              this.F = SafeAnchorModule.b.IDLE;
                              this.J = 0;
                              this.G = false;
                           } else {
                              class_2338 var22 = this.b(var16);
                              if (var3.field_1687.method_8320(var22).method_45474()) {
                                 int var10 = this.s();
                                 if (var10 != -1) {
                                    this.M = var22;
                                    this.O = this.c(var22);
                                    if (this.O == null) {
                                       this.O = var16;
                                    }

                                    this.F = SafeAnchorModule.b.PLACING_ANCHOR;
                                    this.J = 0;
                                    this.G = false;
                                 }
                              }
                           }
                        }

                        if (this.M != null) {
                           boolean var17 = var3.field_1687.method_8320(this.M).method_27852(class_2246.field_23152);
                           boolean var20 = this.N != null
                              && var3.field_1687.method_8320(this.N).method_27852(this.ar ? class_2246.field_10540 : class_2246.field_10171);
                           if (this.F == SafeAnchorModule.b.PLACING_ANCHOR && var17) {
                              this.aj++;
                              if (this.aj >= Math.max(0, ((Double)this.v.getValue()).intValue())) {
                                 this.c(var3);
                                 if (var3.field_1687.method_8320(this.N).method_45474() && !this.r()) {
                                    this.F = SafeAnchorModule.b.PLACING_SHIELD;
                                    this.J = 0;
                                    this.ak = 0;
                                    this.P = null;
                                 } else {
                                    this.F = SafeAnchorModule.b.CHARGING;
                                    this.J = 0;
                                    this.am = 0;
                                    this.al = 0;
                                    this.Q = null;
                                 }
                              }
                           }

                           if (this.F == SafeAnchorModule.b.PLACING_SHIELD && var20) {
                              this.ak++;
                              if (this.ak >= Math.max(0, ((Double)this.w.getValue()).intValue())) {
                                 this.F = SafeAnchorModule.b.CHARGING;
                                 this.J = 0;
                                 this.am = 0;
                                 this.al = 0;
                                 this.Q = null;
                              }
                           }

                           if (this.F == SafeAnchorModule.b.CHARGING) {
                              int var23 = Math.max(this.d(this.M), this.am);
                              if (var23 >= 1) {
                                 this.al++;
                                 if (this.al >= Math.max(0, ((Double)this.x.getValue()).intValue())) {
                                    this.F = SafeAnchorModule.b.EXPLODING;
                                    this.J = 0;
                                    this.R = null;
                                 }
                              }
                           }

                           if (this.F == SafeAnchorModule.b.IDLE && var17) {
                              this.c(var3);
                              if (var3.field_1687.method_8320(this.N).method_45474() && !this.r()) {
                                 this.F = SafeAnchorModule.b.PLACING_SHIELD;
                                 this.J = 0;
                                 this.ak = 0;
                                 this.P = null;
                              } else {
                                 int var24 = this.d(this.M);
                                 if (var24 == 0) {
                                    this.F = SafeAnchorModule.b.CHARGING;
                                    this.J = 0;
                                    this.am = 0;
                                    this.al = 0;
                                    this.Q = null;
                                 } else {
                                    this.F = SafeAnchorModule.b.EXPLODING;
                                    this.J = 0;
                                    this.R = null;
                                 }
                              }
                           }

                           class_241 var25 = null;
                           if (this.F == SafeAnchorModule.b.PLACING_SHIELD) {
                              if (this.P == null) {
                                 this.P = this.c(this.N);
                              }

                              if (this.P != null) {
                                 var25 = RotationUtility.b(this.P.method_17784());
                              }
                           } else if (this.F == SafeAnchorModule.b.CHARGING) {
                              if (this.Q == null) {
                                 this.Q = this.b(this.M);
                              }

                              if (this.Q != null) {
                                 var25 = RotationUtility.b(this.Q.method_17784());
                              }
                           } else if (this.F == SafeAnchorModule.b.EXPLODING) {
                              if (this.R == null) {
                                 this.R = this.b(this.M);
                              }

                              if (this.R != null) {
                                 var25 = RotationUtility.b(this.R.method_17784());
                              }
                           } else if (this.F == SafeAnchorModule.b.PLACING_ANCHOR) {
                              if (this.O == null && this.M != null) {
                                 this.O = this.c(this.M);
                              }

                              if (this.O != null) {
                                 var25 = RotationUtility.b(this.O.method_17784());
                              }
                           }

                           if (var25 != null) {
                              boolean var27 = this.B.isEnabled();
                              boolean var29 = this.C.isEnabled();
                              if (var27) {
                                 this.Y = true;
                                 float var12 = RotationUtility.b(var25.field_1343, this.W != 0.0F ? this.W : var3.field_1724.method_36454());
                                 float var38 = class_3532.method_15363(
                                    RotationUtility.b(var25.field_1342, this.X != 0.0F ? this.X : var3.field_1724.method_36455()), -90.0F, 90.0F
                                 );
                                 this.W = var12;
                                 this.X = var38;
                                 RotationUtility.recoveredField045 = true;
                                 RotationUtility.recoveredField001 = this.W;
                                 RotationUtility.recoveredField063 = this.X;
                                 this.ab = false;
                              } else if (var29) {
                                 if (!this.ab) {
                                    this.Z = var3.field_1724.method_36454();
                                    this.aa = var3.field_1724.method_36455();
                                    this.ab = true;
                                 }

                                 float var32 = ((Double)this.y.getValue()).floatValue() * 0.1F;
                                 this.Z = this.Z + class_3532.method_15393(var25.field_1343 - this.Z) * var32;
                                 this.aa = class_3532.method_15363(
                                    this.aa + class_3532.method_15363(var25.field_1342 - this.aa, -90.0F, 90.0F) * var32, -90.0F, 90.0F
                                 );
                                 var3.field_1724.method_36456(this.Z);
                                 var3.field_1724.method_36457(this.aa);
                                 this.Y = false;
                                 RotationUtility.recoveredField045 = false;
                              } else {
                                 if (!this.Y && !this.ab) {
                                    this.ab = true;
                                    this.Z = var3.field_1724.method_36454();
                                    this.aa = var3.field_1724.method_36455();
                                 }

                                 float var33 = ((Double)this.y.getValue()).floatValue() * 0.1F;
                                 this.Z = this.Z + class_3532.method_15393(var25.field_1343 - this.Z) * var33;
                                 this.aa = class_3532.method_15363(
                                    this.aa + class_3532.method_15363(var25.field_1342 - this.aa, -90.0F, 90.0F) * var33, -90.0F, 90.0F
                                 );
                                 var3.field_1724.method_36456(this.Z);
                                 var3.field_1724.method_36457(this.aa);
                                 this.Y = false;
                                 RotationUtility.recoveredField045 = false;
                              }
                           }
                        }

                        this.ae = false;
                        this.af = false;
                        this.ag = false;
                        this.ah = false;
                        if (this.F != SafeAnchorModule.b.IDLE) {
                           this.J++;
                           int var18 = ((Double)this.u.getValue()).intValue();
                           int var21 = var18 == 0 ? 0 : ThreadLocalRandom.current().nextInt(0, 2);
                           int var26 = ((Double)this.A.getValue()).intValue();
                           if (this.J >= Math.max(var26, var18 + var21)) {
                              class_241 var28 = null;
                              if (this.F == SafeAnchorModule.b.PLACING_SHIELD && this.P != null) {
                                 var28 = RotationUtility.b(this.P.method_17784());
                              } else if (this.F == SafeAnchorModule.b.CHARGING && this.Q != null) {
                                 var28 = RotationUtility.b(this.Q.method_17784());
                              } else if (this.F == SafeAnchorModule.b.EXPLODING && this.R != null) {
                                 var28 = RotationUtility.b(this.R.method_17784());
                              } else if (this.F == SafeAnchorModule.b.PLACING_ANCHOR && this.O != null) {
                                 var28 = RotationUtility.b(this.O.method_17784());
                              }

                              boolean var30 = false;
                              if (var28 != null) {
                                 float var34 = this.B.isEnabled() ? this.W : (this.C.isEnabled() ? this.Z : var3.field_1724.method_36454());
                                 float var39 = this.B.isEnabled() ? this.X : (this.C.isEnabled() ? this.aa : var3.field_1724.method_36455());
                                 float var14 = 8.0F + (float)ThreadLocalRandom.current().nextDouble() * 4.0F;
                                 var30 = Math.abs(class_3532.method_15393(var28.field_1343 - var34)) < var14 && Math.abs(var28.field_1342 - var39) < var14;
                              } else {
                                 var30 = true;
                              }

                              if (var30) {
                                 if (this.F == SafeAnchorModule.b.PLACING_ANCHOR && !var3.field_1687.method_8320(this.M).method_27852(class_2246.field_23152)) {
                                    int var37 = this.s();
                                    if (var37 != -1) {
                                       this.b(var37);
                                    }

                                    this.ae = true;
                                 } else if (this.F == SafeAnchorModule.b.PLACING_SHIELD) {
                                    int var35 = this.ar ? this.u() : this.t();
                                    if (var35 != -1) {
                                       this.b(var35);
                                    }

                                    this.af = true;
                                 } else if (this.F == SafeAnchorModule.b.CHARGING) {
                                    int var36 = this.t();
                                    if (var36 != -1) {
                                       this.b(var36);
                                    }

                                    this.ag = true;
                                 } else if (this.F == SafeAnchorModule.b.EXPLODING) {
                                    this.ah = true;
                                 }
                              }
                           }
                        } else {
                           this.J = 0;
                        }
                     }
                  }
               }
            }
         } else {
            this.n();
            this.G = true;
         }
      }
   }

   @Subscribe(
      a = -100
   )
   public void b(PreMovementPacketEvent var1) {
      boolean var2 = false;
      if (this.isEnabled()) {
         class_310 var3 = Constants.MINECRAFT;
         if (var3.field_1724 != null && var3.field_1687 != null && this.M != null) {
            boolean var4 = this.ae || this.af || this.ag || this.ah;
            boolean var5 = !var3.field_1690.field_1894.method_1434()
               && !var3.field_1690.field_1881.method_1434()
               && !var3.field_1690.field_1913.method_1434()
               && !var3.field_1690.field_1849.method_1434();
            this.ac = var4 && var5 ? (ThreadLocalRandom.current().nextFloat() - 0.5F) * 0.12F : 0.0F;
            this.ad = var4 && var5 ? (ThreadLocalRandom.current().nextFloat() - 0.5F) * 0.06F : 0.0F;
            if (this.Y) {
               var1.b(this.W + this.ac);
               var1.c(class_3532.method_15363(this.X + this.ad, -90.0F, 90.0F));
            } else if (this.ab) {
               var1.b(this.Z + this.ac);
               var1.c(class_3532.method_15363(this.aa + this.ad, -90.0F, 90.0F));
            }

            this.ai = false;
            if (var4) {
               this.b(var3);
            }
         }
      }
   }

   private void b(class_310 var1) {
      boolean var2 = false;
      if (this.ae) {
         this.ae = false;
         if (this.O != null) {
            this.b(var1, this.O);
         }
      } else if (this.af) {
         this.af = false;
         if (this.P != null) {
            this.b(var1, this.P);
            if (var1.field_1687 != null
               && this.N != null
               && !var1.field_1687.method_8320(this.N).method_27852(this.ar ? class_2246.field_10540 : class_2246.field_10171)) {
               this.ap = true;
               this.F = SafeAnchorModule.b.IDLE;
               this.H = false;
               return;
            }
         }
      } else if (this.ag) {
         this.ag = false;
         if (Math.max(this.d(this.M), this.am) >= 1) {
            return;
         }

         long var3 = System.currentTimeMillis();
         if (this.M.equals(this.ao) && var3 - this.an < ((Double)this.z.getValue()).longValue()) {
            return;
         }

         if (this.Q != null) {
            this.b(var1, this.Q);
            this.an = var3;
            this.ao = this.M;
            this.am = 1;
            this.al = 0;
            this.F = SafeAnchorModule.b.EXPLODING;
         }
      } else if (this.ah) {
         this.ah = false;
         if (this.R != null) {
            class_1268 var5 = this.x();
            if (var1.field_1761 != null) {
               if (var1.field_1724 != null) {
                  var1.field_1724.method_5728(false);
               }

               RotationUtility.recoveredField141 = true;
               this.b((Runnable)(() -> {
                  boolean var3x = false;

                  try {
                     class_1269 var4 = var1.field_1761.method_2896(var1.field_1724, var5, this.R);
                     if (var4.method_23665()) {
                        var1.field_1724.method_6104(var5);
                        this.ai = true;
                        this.V++;
                     }
                  } catch (Exception var5x) {
                  }
               }));
            }
         }

         this.M = null;
         this.N = null;
         this.S = null;
         this.T = null;
         this.F = SafeAnchorModule.b.IDLE;
         this.am = 0;
         this.aj = 0;
         this.ak = 0;
         this.al = 0;
         this.Y = false;
         this.ab = false;
         if (!this.D.isEnabled() || (this.ar ? !this.p() : !this.o())) {
            this.H = false;
            this.I = 0;
         } else {
            this.aq = Math.max(1, ((Double)this.E.getValue()).intValue());
            this.H = true;
         }
      }
   }

   private void c(class_310 var1) {
      double var3 = var1.field_1724.method_23317() - ((double)this.M.method_10263() + 0.5);
      double var5 = var1.field_1724.method_23321() - ((double)this.M.method_10260() + 0.5);
      double var7 = Math.abs(var3);
      boolean var2 = true;
      double var9 = Math.abs(var5);
      class_2350 var11;
      class_2338 var12;
      if (var9 / var7 < 0.414) {
         class_2350 var13 = var3 > 0.0 ? class_2350.field_11034 : class_2350.field_11039;
         this.N = this.M.method_10093(var13);
         var11 = var13;
         var12 = this.M;
      } else if (var7 / var9 < 0.414) {
         class_2350 var20 = var5 > 0.0 ? class_2350.field_11035 : class_2350.field_11043;
         this.N = this.M.method_10093(var20);
         var11 = var20;
         var12 = this.M;
      } else {
         int var21 = var3 > 0.0 ? 1 : -1;
         int var14 = var5 > 0.0 ? 1 : -1;
         class_2338 var15 = this.M.method_10069(var21, 0, var14);
         class_2338 var16 = var15.method_10074();
         if (var1.field_1687 != null && !var1.field_1687.method_8320(var16).method_45474()) {
            this.N = var15;
            var11 = class_2350.field_11036;
            var12 = var16;
         } else {
            class_2350 var17 = var7 > var9
               ? (var3 > 0.0 ? class_2350.field_11034 : class_2350.field_11039)
               : (var5 > 0.0 ? class_2350.field_11035 : class_2350.field_11043);
            this.N = this.M.method_10093(var17);
            var11 = var17;
            var12 = this.M;
         }
      }

      class_2338 var22 = this.N.method_10074();
      if (var1.field_1687 != null && !var1.field_1687.method_8320(var22).method_45474()) {
         var12 = var22;
         var11 = class_2350.field_11036;
      }

      if (this.N.method_10263() == this.M.method_10263() && this.N.method_10260() == this.M.method_10260() && this.N.method_10264() != this.M.method_10264()) {
         double var23 = Math.abs(var1.field_1724.method_23317() - ((double)this.M.method_10263() + 0.5));
         double var24 = Math.abs(var1.field_1724.method_23321() - ((double)this.M.method_10260() + 0.5));
         class_2350 var18 = var23 > var24
            ? (var1.field_1724.method_23317() > (double)this.M.method_10263() ? class_2350.field_11034 : class_2350.field_11039)
            : (var1.field_1724.method_23321() > (double)this.M.method_10260() ? class_2350.field_11035 : class_2350.field_11043);
         this.N = this.M.method_10093(var18);
         var11 = var18;
         var12 = this.M;
         class_2338 var19 = this.N.method_10074();
         if (var1.field_1687 != null && !var1.field_1687.method_8320(var19).method_45474()) {
            var12 = var19;
            var11 = class_2350.field_11036;
         }
      }

      this.T = var11;
      this.U = var12;
   }

   private class_3965 b(class_2338 var1, class_2350 var2) {
      double var3 = (double)var1.method_10263() + 0.5 + (double)var2.method_10148() * 0.49;
      double var5 = (double)var1.method_10264() + 0.5 + (double)var2.method_10164() * 0.49;
      double var7 = (double)var1.method_10260() + 0.5 + (double)var2.method_10165() * 0.49;
      return new class_3965(new class_243(var3, var5, var7), var2, var1, false);
   }

   private class_3965 b(class_2338 var1) {
      class_310 var3 = Constants.MINECRAFT;
      boolean var2 = false;
      if (var3.field_1687 != null && var3.field_1724 != null) {
         class_243 var4 = var3.field_1724.method_33571();
         class_2350[] var5 = new class_2350[]{
            class_2350.field_11036, class_2350.field_11043, class_2350.field_11035, class_2350.field_11039, class_2350.field_11034, class_2350.field_11033
         };

         for (class_2350 var9 : var5) {
            if ((var9 != class_2350.field_11036 || !(var4.field_1351 < (double)var1.method_10264() + 1.0))
               && (var9 != class_2350.field_11033 || !(var4.field_1351 > (double)var1.method_10264()))
               && (var9 != class_2350.field_11043 || !(var4.field_1350 >= (double)var1.method_10260()))
               && (var9 != class_2350.field_11035 || !(var4.field_1350 <= (double)var1.method_10260() + 1.0))
               && (var9 != class_2350.field_11039 || !(var4.field_1352 >= (double)var1.method_10263()))
               && (var9 != class_2350.field_11034 || !(var4.field_1352 <= (double)var1.method_10263() + 1.0))) {
               class_2338 var10 = var1.method_10093(var9);
               if (!var3.field_1687.method_8320(var10).method_45474()) {
                  class_243 var11 = new class_243(
                     (double)var1.method_10263() + 0.5 + (double)var9.method_10148() * 0.49,
                     (double)var1.method_10264() + 0.5 + (double)var9.method_10164() * 0.49,
                     (double)var1.method_10260() + 0.5 + (double)var9.method_10165() * 0.49
                  );
                  if (var4.method_1025(var11) <= 18.0625) {
                     class_3965 var12 = var3.field_1687
                        .method_17742(new class_3959(var4, var11, class_3960.field_17558, class_242.field_1348, var3.field_1724));
                     if (var12.method_17783() == class_240.field_1333 || var12.method_17783() == class_240.field_1332 && var12.method_17777().equals(var1)) {
                        return new class_3965(var11, var9, var1, false);
                     }
                  }
               }
            }
         }

         return this.b(var1, class_2350.field_11036);
      } else {
         return this.b(var1, class_2350.field_11036);
      }
   }

   private class_3965 c(class_2338 var1) {
      class_310 var3 = Constants.MINECRAFT;
      boolean var2 = true;
      if (var3.field_1687 != null && var3.field_1724 != null) {
         class_243 var4 = var3.field_1724.method_33571();
         class_2350[] var5 = new class_2350[]{
            class_2350.field_11033, class_2350.field_11036, class_2350.field_11043, class_2350.field_11035, class_2350.field_11039, class_2350.field_11034
         };
         class_2338 var6 = null;
         class_2350 var7 = null;

         for (class_2350 var11 : var5) {
            class_2338 var12 = var1.method_10093(var11);
            if (!var3.field_1687.method_8320(var12).method_45474() && !var3.field_1687.method_8320(var12).method_51176()) {
               class_2350 var13 = var11.method_10153();
               if ((var13 != class_2350.field_11036 || !(var4.field_1351 < (double)var12.method_10264() + 1.0))
                  && (var13 != class_2350.field_11033 || !(var4.field_1351 > (double)var12.method_10264()))
                  && (var13 != class_2350.field_11043 || !(var4.field_1350 >= (double)var12.method_10260()))
                  && (var13 != class_2350.field_11035 || !(var4.field_1350 <= (double)var12.method_10260() + 1.0))
                  && (var13 != class_2350.field_11039 || !(var4.field_1352 >= (double)var12.method_10263()))
                  && (var13 != class_2350.field_11034 || !(var4.field_1352 <= (double)var12.method_10263() + 1.0))) {
                  class_243 var14 = new class_243(
                     (double)var12.method_10263() + 0.5 + (double)var13.method_10148() * 0.49,
                     (double)var12.method_10264() + 0.5 + (double)var13.method_10164() * 0.49,
                     (double)var12.method_10260() + 0.5 + (double)var13.method_10165() * 0.49
                  );
                  if (!(var4.method_1025(var14) > 18.0625)) {
                     if (var6 == null) {
                        var6 = var12;
                        var7 = var13;
                     }

                     class_3965 var15 = var3.field_1687
                        .method_17742(new class_3959(var4, var14, class_3960.field_17558, class_242.field_1348, var3.field_1724));
                     if (var15.method_17783() == class_240.field_1333 || var15.method_17783() == class_240.field_1332 && var15.method_17777().equals(var12)) {
                        return new class_3965(var14, var13, var12, false);
                     }
                  }
               }
            }
         }

         if (var6 != null) {
            class_243 var16 = new class_243(
               (double)var6.method_10263() + 0.5 + (double)var7.method_10148() * 0.49,
               (double)var6.method_10264() + 0.5 + (double)var7.method_10164() * 0.49,
               (double)var6.method_10260() + 0.5 + (double)var7.method_10165() * 0.49
            );
            return new class_3965(var16, var7, var6, false);
         } else {
            return null;
         }
      } else {
         return null;
      }
   }

   private void b(Runnable var1) {
      class_310 var3 = Constants.MINECRAFT;
      boolean var2 = false;
      if (var3.field_1724 != null) {
         float var4 = var3.field_1724.method_36454();
         float var5 = var3.field_1724.method_36455();
         if (this.Y) {
            var3.field_1724.method_36456(this.W + this.ac);
            var3.field_1724.method_36457(class_3532.method_15363(this.X + this.ad, -90.0F, 90.0F));
         } else if (this.ab) {
            var3.field_1724.method_36456(this.Z + this.ac);
            var3.field_1724.method_36457(class_3532.method_15363(this.aa + this.ad, -90.0F, 90.0F));
         }

         try {
            var1.run();
         } finally {
            if (this.Y || this.ab) {
               var3.field_1724.method_36456(var4);
               var3.field_1724.method_36457(var5);
            }
         }
      }
   }

   private void b(class_310 var1, class_3965 var2) {
      boolean var3 = true;
      if (!this.ai && var1.field_1761 != null && var1.field_1724 != null) {
         if (var1.field_1724 != null) {
            var1.field_1724.method_5728(false);
         }

         RotationUtility.recoveredField141 = true;
         this.b((Runnable)(() -> {
            try {
               var1.field_1761.method_2896(var1.field_1724, class_1268.field_5808, var2);
               var1.field_1724.method_6104(class_1268.field_5808);
               this.ai = true;
            } catch (Exception var4) {
            }
         }));
      }
   }

   private void b(int var1) {
      class_310 var3 = Constants.MINECRAFT;
      boolean var2 = false;
      if (var3.field_1724 != null && var3.field_1724.method_31548().method_67532() != var1) {
         RotationUtility.recoveredField141 = true;
         ((eQyS)var3.field_1724.method_31548()).O(var1);
      }
   }

   private int s() {
      class_310 var2 = Constants.MINECRAFT;
      boolean var1 = false;
      if (var2.field_1724 == null) {
         return -1;
      } else {
         for (int var3 = 0; var3 < 9; var3++) {
            if (var2.field_1724.method_31548().method_5438(var3).method_31574(class_1802.field_23141)) {
               return var3;
            }
         }

         return -1;
      }
   }

   private int t() {
      class_310 var2 = Constants.MINECRAFT;
      boolean var1 = true;
      if (var2.field_1724 == null) {
         return -1;
      } else {
         for (int var3 = 0; var3 < 9; var3++) {
            if (var2.field_1724.method_31548().method_5438(var3).method_31574(class_1802.field_8801)) {
               return var3;
            }
         }

         return -1;
      }
   }

   private int u() {
      class_310 var2 = Constants.MINECRAFT;
      boolean var1 = false;
      if (var2.field_1724 == null) {
         return -1;
      } else {
         for (int var3 = 0; var3 < 9; var3++) {
            if (var2.field_1724.method_31548().method_5438(var3).method_31574(class_1802.field_8281)) {
               return var3;
            }
         }

         return -1;
      }
   }

   private int v() {
      class_310 var2 = Constants.MINECRAFT;
      boolean var1 = false;
      if (var2.field_1724 == null) {
         return -1;
      } else {
         for (int var3 = 0; var3 < 9; var3++) {
            if (var2.field_1724.method_31548().method_5438(var3).method_31574(class_1802.field_8288)) {
               return var3;
            }
         }

         return -1;
      }
   }

   private int w() {
      class_310 var2 = Constants.MINECRAFT;
      boolean var1 = true;
      if (var2.field_1724 == null) {
         return -1;
      } else {
         for (int var3 = 0; var3 < 9; var3++) {
            class_1799 var4 = var2.field_1724.method_31548().method_5438(var3);
            if (!var4.method_31574(class_1802.field_8801) && !var4.method_31574(class_1802.field_23141)) {
               return var3;
            }
         }

         return -1;
      }
   }

   private class_1268 x() {
      int var2 = this.v();
      boolean var1 = true;
      if (var2 != -1) {
         this.b(var2);
         return class_1268.field_5808;
      } else {
         int var3 = ((Double)this.p.getValue()).intValue() - 1;
         class_310 var4 = Constants.MINECRAFT;
         boolean var5 = var3 >= 0
            && var3 <= 8
            && var4.field_1724 != null
            && !var4.field_1724.method_31548().method_5438(var3).method_31574(class_1802.field_8801)
            && !var4.field_1724.method_31548().method_5438(var3).method_31574(class_1802.field_23141);
         if (var5) {
            this.b(var3);
         } else {
            int var6 = this.w();
            if (var6 != -1) {
               this.b(var6);
            }
         }

         return var4.field_1724 != null && var4.field_1724.method_6079().method_31574(class_1802.field_8288) ? class_1268.field_5810 : class_1268.field_5808;
      }
   }

   private int d(class_2338 var1) {
      class_310 var3 = Constants.MINECRAFT;
      boolean var2 = true;

      try {
         if (var3.field_1687 != null && var3.field_1687.method_8320(var1).method_27852(class_2246.field_23152)) {
            return (Integer)var3.field_1687.method_8320(var1).method_11654(class_4969.field_23153);
         }
      } catch (Exception var5) {
      }

      return 0;
   }

   private class_2338 b(class_3965 var1) {
      class_2350 var3 = var1.method_17780();
      boolean var2 = true;
      class_2338 var4 = var1.method_17777();
      class_310 var5 = Constants.MINECRAFT;
      if (var5.field_1687 != null && !var5.field_1687.method_8320(var4).method_45474()) {
         return switch (var3) {
            case field_11036 -> var4.method_10069(0, 1, 0);
            case field_11033 -> var4.method_10069(0, -1, 0);
            case field_11043 -> var4.method_10069(0, 0, -1);
            case field_11035 -> var4.method_10069(0, 0, 1);
            case field_11039 -> var4.method_10069(-1, 0, 0);
            case field_11034 -> var4.method_10069(1, 0, 0);
            default -> throw new MatchException(null, null);
         };
      } else {
         return var4;
      }
   }

   public static enum b {
   IDLE(),
   PLACING_ANCHOR(),
   PLACING_SHIELD(),
   CHARGING(),
   EXPLODING();

      
   }
}
