package com.google.common.jimfs.event.impl.game.player.interaction;

import net.minecraft.class_1297;

public final class HnWqPm {
   private final class_1297 entity;

   public HnWqPm(class_1297 var1) {
      this.entity = var1;
   }

   public class_1297 getEntity() {
      return this.entity;
   }
}
