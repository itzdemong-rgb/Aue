package com.google.common.jimfs.m;

import com.google.common.jimfs.client.Constants;
import com.google.common.jimfs.client.Swag;
import com.google.common.jimfs.client.feature.module.Module;
import com.google.common.jimfs.client.feature.module.ModuleCategory;
import com.google.common.jimfs.client.feature.module.property.Property;
import com.google.common.jimfs.client.feature.module.property.impl.KeybindProperty;
import com.google.common.jimfs.client.feature.module.property.impl.bool.BooleanProperty;
import com.google.common.jimfs.client.feature.module.property.impl.number.NumberProperty;
import com.google.common.jimfs.event.impl.game.PreGameTickEvent;
import com.google.common.jimfs.event.subscriber.Subscribe;
import com.google.common.jimfs.mixin.eQyS;
import com.google.common.jimfs.mixin.hVnK;
import com.google.common.jimfs.recovered.KeyInputHelper;
import com.google.common.jimfs.utility.misc.StringObfuscation;
import com.google.common.jimfs.utility.player.PlayerUtility;
import j2cc.Nativeify;
import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2868;
import net.minecraft.class_3489;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_239.class_240;

@Nativeify
public class AutoHitCrystalModule extends Module {
   private final BooleanProperty m;
   private final BooleanProperty o;
   private final BooleanProperty p;
   private final NumberProperty q;
   private final NumberProperty r;
   private final KeybindProperty s;
   private final BooleanProperty t;
   private final BooleanProperty u;
   private long v = 0L;
   private long w = 0L;
   private long x = 0L;
   private boolean y = false;
   private boolean z = false;
   public boolean restoreAutoCrystal = false;
   private int A = -1;
   
   

   public AutoHitCrystalModule() {
      super(StringObfuscation.a("Auto Hit Crystal"), "", ModuleCategory.CRYSTAL);
      this.m = new BooleanProperty(StringObfuscation.a("W Totem"), true);
      this.o = new BooleanProperty(StringObfuscation.a("W Sword"), true);
      this.p = new BooleanProperty(StringObfuscation.a("W Crystal"), true);
      this.q = new NumberProperty(StringObfuscation.a("Place Delay (ms)"), 0.0, 1.0, 100.0, 1.0);
      this.r = new NumberProperty(StringObfuscation.a("Switch Delay (ms)"), 0.0, 1.0, 100.0, 1.0);
      this.s = new KeybindProperty(StringObfuscation.a("Activate Key"), 1);
      this.t = new BooleanProperty(StringObfuscation.a("Click Sim"), false);
      this.u = new BooleanProperty("Work With Anything", false);
      this.b(new Property[]{this.m, this.o, this.p, this.q, this.r, this.s, this.t, this.u});
   }

   @Override
   protected void g() {
      super.g();
      this.o();
   }

   @Override
   protected void h() {
      this.o();
      super.h();
   }

   private void n() {
      boolean var1 = false;
      if (this.restoreAutoCrystal) {
         Module var2 = Swag.getInstance().getModuleRepository().a(AutoCrystalModule.class);
         if (var2 != null) {
            var2.c(true);
         }

         this.restoreAutoCrystal = false;
      }
   }

   private void o() {
      this.y = false;
      this.z = false;
      this.v = 0L;
      this.w = 0L;
      this.x = 0L;
      this.A = -1;
      this.n();
   }

   @Subscribe
   public void b(PreGameTickEvent var1) {
      boolean var2 = true;
      if (Constants.MINECRAFT.field_1724 != null
         && Constants.MINECRAFT.field_1687 != null
         && Constants.MINECRAFT.field_1761 != null
         && Constants.MINECRAFT.field_1755 == null) {
         if (PlayerUtility.d()) {
            this.o();
         } else {
            int var3 = (Integer)this.s.getValue();
            boolean var4;
            if (var3 >= 0 && var3 <= 7) {
               var4 = PlayerUtility.c(var3);
            } else {
               var4 = PlayerUtility.isMouseButtonPressed(var3);
            }

            if (!var4) {
               this.o();
            } else if (!this.z) {
               if (this.y) {
                  int var5 = ((eQyS)Constants.MINECRAFT.field_1724.method_31548()).N();
                  if (this.A != -1 && var5 != this.A) {
                     this.o();
                     return;
                  }
               }

               if (!this.y) {
                  class_1799 var13 = Constants.MINECRAFT.field_1724.method_6047();
                  int var6 = (Integer)this.s.getValue();
                  boolean var7 = var6 == 0 || var6 == 1 || var6 == 0 || var6 == 1;
                  boolean var8 = false;
                  if (!this.u.isEnabled() && var7) {
                     if (this.o.isEnabled() && var13.method_31573(class_3489.field_42611)) {
                        var8 = true;
                     }

                     if (this.m.isEnabled() && var13.method_31574(class_1802.field_8288)) {
                        var8 = true;
                     }

                     if (this.p.isEnabled() && var13.method_31574(class_1802.field_8301)) {
                        var8 = true;
                     }
                  } else {
                     var8 = true;
                  }

                  if (!var8) {
                     return;
                  }

                  this.y = true;
                  this.A = ((eQyS)Constants.MINECRAFT.field_1724.method_31548()).N();
                  Module var9 = Swag.getInstance().getModuleRepository().a(AutoCrystalModule.class);
                  if (var9 != null && var9.isEnabled()) {
                     this.restoreAutoCrystal = true;
                     var9.c(false);
                  }
               }

               long var14 = System.currentTimeMillis();
               if (Constants.MINECRAFT.field_1765 instanceof class_3966 var15 && var15.method_17782() instanceof class_1511) {
                  class_1511 var18 = (class_1511)var15.method_17782();
                  if (var14 - this.x >= (long)((Double)this.q.getValue()).intValue()) {
                     if (this.t.isEnabled()) {
                        KeyInputHelper.d(0);
                     } else {
                        Constants.MINECRAFT.field_1761.method_2918(Constants.MINECRAFT.field_1724, var18);
                        Constants.MINECRAFT.field_1724.method_6104(class_1268.field_5808);
                     }

                     this.x = var14;
                     return;
                  }
               }

               if (Constants.MINECRAFT.field_1765 instanceof class_3965 var16 && var16.method_17783() != class_240.field_1333) {
                  class_2338 var20 = var16.method_17777();
                  List var21 = Constants.MINECRAFT.field_1687.method_8390(class_1511.class, new class_238(var20.method_10084()), var0 -> true);
                  if (!var21.isEmpty()) {
                     if (var14 - this.x >= (long)((Double)this.q.getValue()).intValue()) {
                        if (this.t.isEnabled()) {
                           KeyInputHelper.d(0);
                        } else {
                           Constants.MINECRAFT.field_1761.method_2918(Constants.MINECRAFT.field_1724, (class_1297)var21.get(0));
                           Constants.MINECRAFT.field_1724.method_6104(class_1268.field_5808);
                        }

                        this.x = var14;
                     }

                     return;
                  }

                  if (this.b(var20)) {
                     return;
                  }

                  if (!this.b(class_2246.field_10540, var20) && !this.b(class_2246.field_9987, var20)) {
                     boolean var22 = Constants.MINECRAFT.field_1724.method_6047().method_31574(class_1802.field_8281);
                     if (!var22 && var14 - this.w >= (long)((Double)this.r.getValue()).intValue()) {
                        int var23 = this.b(class_1802.field_8281);
                        if (var23 != -1) {
                           this.b(var23);
                           this.w = var14;
                           var22 = true;
                        }
                     }

                     if (var22
                        && var14 - this.v >= (long)((Double)this.q.getValue()).intValue()
                        && Constants.MINECRAFT.field_1765 instanceof class_3965 var24
                        && var24.method_17777().equals(var20)) {
                        if (this.t.isEnabled()) {
                           KeyInputHelper.d(1);
                        } else {
                           Constants.MINECRAFT.field_1761.method_2896(Constants.MINECRAFT.field_1724, class_1268.field_5808, var24);
                           Constants.MINECRAFT.field_1724.method_6104(class_1268.field_5808);
                           ((hVnK)Constants.MINECRAFT).q(4);

                           while (Constants.MINECRAFT.field_1690.field_1904.method_1436()) {
                           }
                        }

                        this.v = var14;
                     }

                     return;
                  }

                  boolean var10 = Constants.MINECRAFT.field_1724.method_6047().method_31574(class_1802.field_8301);
                  if (!var10 && var14 - this.w >= (long)((Double)this.r.getValue()).intValue()) {
                     int var11 = this.b(class_1802.field_8301);
                     if (var11 != -1) {
                        this.b(var11);
                        this.w = var14;
                        var10 = true;
                     }
                  }

                  if (var10 && var14 - this.v >= (long)((Double)this.q.getValue()).intValue()) {
                     if (this.t.isEnabled()) {
                        KeyInputHelper.d(1);
                     } else {
                        Constants.MINECRAFT.field_1761.method_2896(Constants.MINECRAFT.field_1724, class_1268.field_5808, var16);
                        Constants.MINECRAFT.field_1724.method_6104(class_1268.field_5808);
                        ((hVnK)Constants.MINECRAFT).q(4);

                        while (Constants.MINECRAFT.field_1690.field_1904.method_1436()) {
                        }
                     }

                     this.v = var14;
                     this.z = true;
                     this.n();
                  }

                  return;
               }
            }
         }
      }
   }

   private void b(int var1) {
      boolean var2 = false;
      if (var1 != -1) {
         eQyS var3 = (eQyS)Constants.MINECRAFT.field_1724.method_31548();
         if (var3.N() != var1) {
            var3.O(var1);
            this.A = var1;
            if (Constants.MINECRAFT.method_1562() != null) {
               Constants.MINECRAFT.method_1562().method_52787(new class_2868(var1));
            }
         }
      }
   }

   private boolean b(class_2338 var1) {
      boolean var2 = true;
      return this.b(class_2246.field_23152, var1)
         || this.b(class_2246.field_10494, var1)
         || this.b(class_2246.field_10057, var1)
         || this.b(class_2246.field_10066, var1)
         || this.b(class_2246.field_10417, var1)
         || this.b(class_2246.field_10553, var1)
         || this.b(class_2246.field_10278, var1)
         || this.b(class_2246.field_10493, var1)
         || this.b(class_2246.field_37559, var1)
         || this.b(class_2246.field_42743, var1)
         || this.b(class_2246.field_40286, var1)
         || this.b(class_2246.field_22100, var1)
         || this.b(class_2246.field_22101, var1)
         || this.b(class_2246.field_23864, var1)
         || this.b(class_2246.field_10363, var1)
         || this.b(class_2246.field_10034, var1)
         || this.b(class_2246.field_10380, var1)
         || this.b(class_2246.field_10443, var1)
         || this.b(class_2246.field_10181, var1)
         || this.b(class_2246.field_16333, var1)
         || this.b(class_2246.field_16334, var1)
         || this.b(class_2246.field_9980, var1)
         || this.b(class_2246.field_10485, var1)
         || this.b(class_2246.field_10535, var1)
         || this.b(class_2246.field_10105, var1)
         || this.b(class_2246.field_10414, var1);
   }

   private int b(class_1792 var1) {
      int var3 = 0;

      for (boolean var2 = true; var3 < 9; var3++) {
         class_1799 var4 = (class_1799)Constants.MINECRAFT.field_1724.method_31548().method_67533().get(var3);
         if (var4.method_7909() == var1 && var4.method_7947() > 0) {
            return var3;
         }
      }

      return -1;
   }

   private boolean b(class_2248 var1, class_2338 var2) {
      return Constants.MINECRAFT.field_1687.method_8320(var2).method_27852(var1);
   }

}
