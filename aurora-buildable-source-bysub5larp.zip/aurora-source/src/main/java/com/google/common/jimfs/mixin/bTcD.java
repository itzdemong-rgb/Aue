package com.google.common.jimfs.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2828;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Environment(EnvType.CLIENT)
@Mixin({class_2828.class})
public interface bTcD {
   @Mutable
   @Accessor("x")
   void a(double var1);

   @Mutable
   @Accessor("y")
   void b(double var1);

   @Mutable
   @Accessor("z")
   void c(double var1);

   @Mutable
   @Accessor("onGround")
   void d(boolean var1);

   @Mutable
   @Accessor("yaw")
   void e(float var1);

   @Mutable
   @Accessor("pitch")
   void f(float var1);

   @Mutable
   @Accessor("changePosition")
   void g(boolean var1);

   @Mutable
   @Accessor("changeLook")
   void h(boolean var1);
}
