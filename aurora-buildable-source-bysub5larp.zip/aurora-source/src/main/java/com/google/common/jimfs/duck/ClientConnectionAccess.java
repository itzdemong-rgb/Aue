package com.google.common.jimfs.duck;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2596;

@Environment(EnvType.CLIENT)
public interface ClientConnectionAccess {
   void jimfs$channelReadSilent(class_2596 var1);
}
