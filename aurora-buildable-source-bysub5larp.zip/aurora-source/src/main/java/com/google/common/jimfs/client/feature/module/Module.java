package com.google.common.jimfs.client.feature.module;

import com.google.common.jimfs.client.Constants;
import com.google.common.jimfs.client.Swag;
import com.google.common.jimfs.client.feature.helper.impl.render.ScreenPositionManager;
import com.google.common.jimfs.client.feature.module.property.Property;
import com.google.common.jimfs.client.feature.module.property.impl.KeybindProperty;
import com.google.common.jimfs.client.feature.module.property.impl.ScreenPositionProperty;
import com.google.common.jimfs.client.feature.module.property.impl.mode.ModeProperty;
import com.google.common.jimfs.event.EventDispatcher;
import com.google.common.jimfs.event.subscriber.IEventSubscriber;
import com.google.common.jimfs.recovered.PropertyList;
import com.google.common.jimfs.recovered.ModuleModeHandler;
import com.google.common.jimfs.recovered.ModuleToggleEvent;
import com.google.common.jimfs.recovered.BindAction;
import com.google.common.jimfs.recovered.InputDevice;
import com.google.common.jimfs.utility.misc.StringObfuscation;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class Module implements IEventSubscriber, BindAction {
   private final StringObfuscation.E displayName;
   private final StringObfuscation.E description;
   private final StringObfuscation.E encodedName;
   private final ModuleCategory category;
   @Expose
   @SerializedName("enabled")
   private boolean enabled;
   @Expose
   @SerializedName("visible")
   private boolean recoveredField213 = true;
   @Expose
   @SerializedName("favorited")
   private boolean favorite = false;
   @Expose
   @SerializedName("properties")
   private final List<Property> properties = new ArrayList();
   private final List<ModuleModeHandler> j;
   private ModeProperty k;
   private final KeybindProperty l;
   private static boolean n = true;

   protected Module(CharSequence var1, CharSequence var2, ModuleCategory var3) {
      boolean var4 = false;
      this.j = new ArrayList();
      if (var1 instanceof StringObfuscation.E) {
         this.displayName = (StringObfuscation.E)var1;
      } else {
         char[] var5 = new char[var1.length()];

         for (int var6 = 0; var6 < var1.length(); var6++) {
            var5[var6] = var1.charAt(var6);
         }

         this.displayName = new StringObfuscation.E(var5, ThreadLocalRandom.current().nextInt(4096, 24096));
         Arrays.fill(var5, '\u0000');
      }

      if (var2 instanceof StringObfuscation.E) {
         this.description = (StringObfuscation.E)var2;
      } else {
         char[] var8 = new char[var2.length()];

         for (int var10 = 0; var10 < var2.length(); var10++) {
            var8[var10] = var2.charAt(var10);
         }

         this.description = new StringObfuscation.E(var8, ThreadLocalRandom.current().nextInt(4096, 24096));
         Arrays.fill(var8, '\u0000');
      }

      char[] var9 = new char[var1.length()];

      for (int var11 = 0; var11 < var1.length(); var11++) {
         char var7 = var1.charAt(var11);
         if (var7 >= 'A' && var7 <= 'Z') {
            var7 = (char)(var7 + ' ');
         }

         if (var7 == ' ') {
            var7 = '_';
         }

         var9[var11] = var7;
      }

      this.encodedName = new StringObfuscation.E(var9, ThreadLocalRandom.current().nextInt(4096, 24096));
      Arrays.fill(var9, '\u0000');
      this.category = var3;
      this.l = new KeybindProperty("Keybind", -1);
      this.l.b((var1x, var2x) -> {
         Swag.getInstance().getBindRepository().getBindingService().b(this);
         boolean var3x = true;
         if (var2x != null && (Integer)var2x != -1) {
            InputDevice var4x = (Integer)var2x < 10 ? InputDevice.MOUSE : InputDevice.KEYBOARD;
            Swag.getInstance().getBindRepository().getBindingService().b((Integer)var2x, this, var4x);
         }
      });
      this.b(new Property[]{this.l});
      EventDispatcher.a(this);
   }

   public final void c(boolean var1) {
      boolean var2 = false;
      if (!var1 || !Swag.getInstance().isSelfDestructed()) {
         if (this.enabled != var1) {
            ModuleToggleEvent var3 = new ModuleToggleEvent(this, var1);
            EventDispatcher.b(var3);
            if (!var3.isCancelled()) {
               this.enabled = var1;
               if (var1) {
                  this.g();
               } else {
                  this.h();
               }
            }
         }
      }
   }

   public final void toggle() {
      boolean var1 = true;
      this.c(!this.isEnabled());
   }

   protected void g() {
      boolean var1 = false;
      if (this.j() != null) {
         this.j().onEnabled();
      }
   }

   protected void h() {
      boolean var1 = false;
      if (this.j() != null) {
         this.j().onDisabled();
      }
   }

   public final CharSequence getName() {
      return this.displayName;
   }

   public final ModuleCategory getCategory() {
      return this.category;
   }

   public final boolean isEnabled() {
      return this.enabled;
   }

   public final boolean isFavorite() {
      return this.favorite;
   }

   public final void b(boolean var1) {
      this.favorite = var1;
   }

   public final void b(Property[] var1) {
      Property[] var3 = var1;
      int var4 = var1.length;
      int var5 = 0;

      for (boolean var2 = false; var5 < var4; var5++) {
         Property var6 = var3[var5];
         if (var6 != null) {
            this.properties.add(var6);
            if (var6 instanceof ScreenPositionProperty var7) {
               ScreenPositionManager.getInstance().a(this, var7);
            } else if (var6 instanceof PropertyList) {
               PropertyList var8 = (PropertyList)var6;

               for (Property var10 : var8.getProperties()) {
                  if (var10 instanceof ScreenPositionProperty var11) {
                     ScreenPositionManager.getInstance().a(this, var11);
                  }
               }
            }
         }
      }
   }

   public final List<ModuleModeHandler> i() {
      return this.j;
   }

   public final ModuleModeHandler j() {
      return this.j.stream().filter(var1 -> var1.d().equals(this.k.getValue())).findFirst().orElse(null);
   }

   public final KeybindProperty k() {
      return this.l;
   }

   public final List<Property> getProperties() {
      return this.properties;
   }

   @Override
   public final void f() {
      this.toggle();
   }

   @Override
   public boolean e() {
      return this.enabled && Constants.MINECRAFT.field_1755 == null;
   }

   public static void d(boolean var0) {
      n = var0;
   }

   public static boolean l() {
      return n;
   }

   public static boolean m() {
      boolean var0 = true;
      return false;
   }

}
