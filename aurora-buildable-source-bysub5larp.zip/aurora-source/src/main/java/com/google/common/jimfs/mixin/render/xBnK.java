package com.google.common.jimfs.mixin.render;

import com.google.common.jimfs.client.feature.helper.impl.player.timer.TimerHelper;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_9779.class_9781;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin({class_9781.class})
public final class xBnK {
   @Shadow
   private float field_51958;

   private xBnK() {
   }

   @Inject(
      at = {@At(
         value = "FIELD",
         target = "Lnet/minecraft/client/render/RenderTickCounter$Dynamic;lastTimeMillis:J",
         opcode = 181,
         ordinal = 0
      )},
      method = {"beginRenderTick(J)I"}
   )
   public void kW(long var1, CallbackInfoReturnable var3) {
      float var4 = TimerHelper.getInstance().timerSpeed;
      if (var4 > 0.0F) {
         this.field_51958 *= var4;
      }
   }
}
