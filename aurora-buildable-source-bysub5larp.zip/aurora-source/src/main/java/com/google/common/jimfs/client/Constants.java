package com.google.common.jimfs.client;

import com.google.common.jimfs.client.renderer.NVGRenderer;
import com.google.common.jimfs.utility.misc.StringObfuscation;
import java.io.File;
import net.minecraft.class_310;

public final class Constants {
   public static final class_310 MINECRAFT = class_310.method_1551();
   public static final File modDirectory;
   private static int recoveredField117 = 65;

   public static long getNanoVGContext() {
      return NVGRenderer.getNanoVGContext();
   }

   static {
      String var0 = "4a4b7687547c477e4d48898e";
      byte var1 = 24;
      modDirectory = new File(MINECRAFT.field_1697, File.separator + StringObfuscation.d(var0, 9933) + File.separator);
   }

   public static void b(int var0) {
      recoveredField117 = var0;
   }

   public static int recoveredMethod101() {
      return recoveredField117;
   }

   public static int d() {
      byte var0 = 65;
      return var0 == 0 ? 125 : 0;
   }
}
