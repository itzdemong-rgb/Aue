package com.google.common.jimfs.event.impl.game;

public final class ScheduledExecutablesEvent {
   private final boolean recoveredField110;

   public ScheduledExecutablesEvent(boolean var1) {
      this.recoveredField110 = var1;
   }
}
