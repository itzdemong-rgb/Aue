package com.google.common.jimfs.event.impl.game.player;

public final class PreUpdateEvent {
}
