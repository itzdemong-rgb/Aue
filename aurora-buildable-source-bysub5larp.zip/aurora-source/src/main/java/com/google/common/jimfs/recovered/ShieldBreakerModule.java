package com.google.common.jimfs.recovered;

import com.google.common.jimfs.client.Constants;
import com.google.common.jimfs.client.feature.module.Module;
import com.google.common.jimfs.client.feature.module.ModuleCategory;
import com.google.common.jimfs.client.feature.module.property.Property;
import com.google.common.jimfs.client.feature.module.property.impl.bool.BooleanProperty;
import com.google.common.jimfs.client.feature.module.property.impl.number.NumberProperty;
import com.google.common.jimfs.event.impl.game.PreGameTickEvent;
import com.google.common.jimfs.event.subscriber.Subscribe;
import com.google.common.jimfs.utility.misc.StringObfuscation;
import j2cc.Nativeify;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1743;
import net.minecraft.class_1799;

@Nativeify
public class ShieldBreakerModule extends Module {
   private final NumberProperty m = new NumberProperty(StringObfuscation.a("Delay MS"), 80.0, 0.0, 500.0, 5.0);
   private final NumberProperty o = new NumberProperty(StringObfuscation.a("Hit Delay MS"), 300.0, 50.0, 1000.0, 10.0);
   private final BooleanProperty p = new BooleanProperty(StringObfuscation.a("Visual Swap"), true);
   private final BooleanProperty q = new BooleanProperty(StringObfuscation.a("Auto Revert"), true);
   private long r;
   private long s;
   private int t;
   private class_1297 u;
   private int v = -1;
   private boolean w = false;
   
   
   private static final long y = 200L;

   public ShieldBreakerModule() {
      super(StringObfuscation.a("Shield Breaker"), "", ModuleCategory.COMBAT);
      this.b(new Property[]{this.m, this.o, this.p, this.q});
   }

   @Subscribe
   public void b(PreGameTickEvent var1) {
      boolean var2 = false;
      if (this.isEnabled()) {
         if (Constants.MINECRAFT.field_1724 != null && Constants.MINECRAFT.field_1687 != null) {
            long var3 = System.currentTimeMillis();
            class_1297 var5 = Constants.MINECRAFT.field_1692;
            if (var5 != null && var5 instanceof class_1309) {
               if (var5 != this.u) {
                  this.u = var5;
                  this.t = 0;
               }

               class_1309 var6 = (class_1309)var5;
               if (!var6.method_6039()) {
                  this.n();
                  if (this.w) {
                     this.t = 0;
                  }
               } else if (this.t >= 2) {
                  this.n();
               } else if (var3 - this.s < (long)((Double)this.o.getValue()).intValue()) {
                  if (this.q.isEnabled() && this.w && var3 - this.s > y) {
                     this.n();
                  }
               } else if (var3 - this.r >= (long)((Double)this.m.getValue()).intValue()) {
                  int var7 = this.p();
                  if (var7 != -1) {
                     this.b(var6, var7);
                     this.r = var3;
                     this.s = var3;
                     this.t++;
                  }
               }
            } else {
               this.o();
               this.n();
            }
         }
      }
   }

   private void b(class_1309 var1, int var2) {
      int var4 = Constants.MINECRAFT.field_1724.method_31548().method_67532();
      boolean var3 = true;
      if (this.v == -1) {
         this.v = var4;
      }

      if (var4 != var2) {
         Constants.MINECRAFT.field_1724.method_31548().method_61496(var2);
         this.w = true;
      }

      Constants.MINECRAFT.field_1761.method_2918(Constants.MINECRAFT.field_1724, var1);
      Constants.MINECRAFT.field_1724.method_6104(class_1268.field_5808);
   }

   private void n() {
      boolean var1 = false;
      if (this.v != -1 && this.q.isEnabled() && this.w) {
         Constants.MINECRAFT.field_1724.method_31548().method_61496(this.v);
         this.w = false;
         this.v = -1;
      }
   }

   private void o() {
      this.u = null;
      this.t = 0;
      this.n();
   }

   private int p() {
      int var2 = 0;

      for (boolean var1 = true; var2 < 9; var2++) {
         class_1799 var3 = Constants.MINECRAFT.field_1724.method_31548().method_5438(var2);
         if (!var3.method_7960() && var3.method_7909() instanceof class_1743) {
            return var2;
         }
      }

      return -1;
   }

}
