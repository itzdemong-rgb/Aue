package com.google.common.jimfs.mixin.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_989;
import org.spongepowered.asm.mixin.Mixin;

@Environment(EnvType.CLIENT)
@Mixin({class_989.class})
public abstract class tLmR extends class_3887 {
   public tLmR(class_3883 var1) {
      super(var1);
   }
}
