package com.google.common.jimfs.recovered;

import net.minecraft.class_1297;
import net.minecraft.class_1309;

public abstract class TrackedEntity {
   protected class_1309 entity;
   private static int recoveredField117 = 66;

   public TrackedEntity(class_1309 var1) {
      this.entity = var1;
   }

   public class_1309 getEntity() {
      return this.entity;
   }

   public void b(class_1297 var1) {
      this.entity = (class_1309)var1;
   }

   public static void b(int var0) {
      recoveredField117 = var0;
   }

   public static int recoveredMethod101() {
      return recoveredField117;
   }

   public static int d() {
      byte var0 = 66;
      return var0 == 0 ? 103 : 0;
   }
}
