package com.google.common.jimfs.client.renderer;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class HighDPIRenderer {
   private HighDPIRenderer() {
   }
}
