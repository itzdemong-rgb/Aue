package com.google.common.jimfs.mixin.screen;

import com.google.common.jimfs.event.EventDispatcher;
import com.google.common.jimfs.event.impl.game.server.ServerConnectEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_412;
import net.minecraft.class_639;
import net.minecraft.class_642;
import net.minecraft.class_9112;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({class_412.class})
public final class nLxT {
   private nLxT() {
   }

   @Inject(
      method = {"connect(Lnet/minecraft/client/MinecraftClient;Lnet/minecraft/client/network/ServerAddress;Lnet/minecraft/client/network/ServerInfo;Lnet/minecraft/client/network/CookieStorage;)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void kS(class_310 var1, class_639 var2, class_642 var3, class_9112 var4, CallbackInfo var5) {
      ServerConnectEvent var6 = new ServerConnectEvent(var2);
      EventDispatcher.b(var6);
      if (var6.isCancelled()) {
         var5.cancel();
      }
   }
}
