package com.google.common.jimfs.duck;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1735;

@Environment(EnvType.CLIENT)
public interface HandledScreenAccess {
   class_1735 jimfs$getFocusedSlot();
}
