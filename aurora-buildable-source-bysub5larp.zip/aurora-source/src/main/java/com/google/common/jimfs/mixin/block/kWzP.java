package com.google.common.jimfs.mixin.block;

import com.google.common.jimfs.event.EventDispatcher;
import com.google.common.jimfs.event.impl.game.player.interaction.block.BlockBreakHardnessEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_4970.class_4971;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin({class_4971.class})
public final class kWzP {
   @Inject(
      method = {"getHardness"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void nYq(class_1922 var1, class_2338 var2, CallbackInfoReturnable var3) {
      class_4971 var5 = (class_4971)(Object)this;
      if (var5 instanceof class_2680 var4) {
         BlockBreakHardnessEvent var6 = new BlockBreakHardnessEvent(var4, (Float)var3.getReturnValue());
         EventDispatcher.b(var6);
         var3.setReturnValue(var6.getHardness());
      }
   }
}
