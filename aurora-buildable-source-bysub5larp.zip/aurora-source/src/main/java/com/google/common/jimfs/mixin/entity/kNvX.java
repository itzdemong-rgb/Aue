package com.google.common.jimfs.mixin.entity;

import com.google.common.jimfs.client.Constants;
import com.google.common.jimfs.duck.BipedEntityRenderStateAccess;
import com.google.common.jimfs.utility.player.BlockUtility;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10055;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_591;
import net.minecraft.class_572.class_573;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Environment(EnvType.CLIENT)
@Mixin({class_591.class})
public final class kNvX {
   @ModifyVariable(
      method = {"setAngles(Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;)V"},
      at = @At("HEAD"),
      argsOnly = true
   )
   private class_10055 a(class_10055 var1) {
      class_1309 var2 = ((BipedEntityRenderStateAccess)var1).jimfs$getEntity();
      if (var2 == Constants.MINECRAFT.field_1724 && BlockUtility.a(var1)) {
         var1.field_53414 = true;
         var1.field_53409 = class_1268.field_5808;
         if (var1.field_55303 == class_1306.field_6183) {
            var1.field_55306 = class_573.field_3409;
            var1.field_55304 = class_573.field_3406;
         } else {
            var1.field_55306 = class_573.field_3406;
            var1.field_55304 = class_573.field_3409;
         }
      }

      return var1;
   }
}
