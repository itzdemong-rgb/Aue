package com.google.common.jimfs.utility.render.animation;

import java.util.function.Function;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_3532;

@Environment(EnvType.CLIENT)
public enum Easing {
   LINEAR(f -> f),
   DECELERATE(f -> Float.valueOf(1.0f - (f.floatValue() - 1.0f) * (f.floatValue() - 1.0f))),
   SMOOTH_STEP(f -> Float.valueOf((float)(-2.0 * Math.pow(f.floatValue(), 3.0) + 3.0 * Math.pow(f.floatValue(), 2.0)))),
   EASE_IN_QUAD(f -> Float.valueOf(f.floatValue() * f.floatValue())),
   EASE_OUT_QUAD(f -> Float.valueOf(f.floatValue() * (2.0f - f.floatValue()))),
   EASE_IN_OUT_QUAD(f -> Float.valueOf((double)f.floatValue() < 0.5 ? 2.0f * f.floatValue() * f.floatValue() : -1.0f + (4.0f - 2.0f * f.floatValue()) * f.floatValue())),
   EASE_IN_CUBIC(f -> Float.valueOf(f.floatValue() * f.floatValue() * f.floatValue())),
   EASE_OUT_CUBIC(f -> {
        f = Float.valueOf(f.floatValue() - 1.0f);
        return Float.valueOf(f.floatValue() * f.floatValue() * f.floatValue() + 1.0f);
    }),
   EASE_IN_OUT_CUBIC(f -> Float.valueOf((double)f.floatValue() < 0.5 ? 4.0f * f.floatValue() * f.floatValue() * f.floatValue() : (f.floatValue() - 1.0f) * (2.0f * f.floatValue() - 2.0f) * (2.0f * f.floatValue() - 2.0f) + 1.0f)),
   EASE_IN_QUART(f -> Float.valueOf(f.floatValue() * f.floatValue() * f.floatValue() * f.floatValue())),
   EASE_OUT_QUART(f -> {
        f = Float.valueOf(f.floatValue() - 1.0f);
        return Float.valueOf(1.0f - f.floatValue() * f.floatValue() * f.floatValue() * f.floatValue());
    }),
   EASE_IN_OUT_QUART(f -> {
        float f2;
        if ((double)f.floatValue() < 0.5) {
            f2 = 8.0f * f.floatValue() * f.floatValue() * f.floatValue() * f.floatValue();
        } else {
            f = Float.valueOf(f.floatValue() - 1.0f);
            f2 = 1.0f - 8.0f * f.floatValue() * f.floatValue() * f.floatValue() * f.floatValue();
        }
        return Float.valueOf(f2);
    }),
   EASE_IN_QUINT(f -> Float.valueOf(f.floatValue() * f.floatValue() * f.floatValue() * f.floatValue() * f.floatValue())),
   EASE_OUT_QUINT(f -> {
        f = Float.valueOf(f.floatValue() - 1.0f);
        return Float.valueOf(1.0f + f.floatValue() * f.floatValue() * f.floatValue() * f.floatValue() * f.floatValue());
    }),
   EASE_IN_OUT_QUINT(f -> {
        float f2;
        if ((double)f.floatValue() < 0.5) {
            f2 = 16.0f * f.floatValue() * f.floatValue() * f.floatValue() * f.floatValue() * f.floatValue();
        } else {
            f = Float.valueOf(f.floatValue() - 1.0f);
            f2 = 1.0f + 16.0f * f.floatValue() * f.floatValue() * f.floatValue() * f.floatValue() * f.floatValue();
        }
        return Float.valueOf(f2);
    }),
   EASE_IN_SINE(f -> Float.valueOf(1.0f - class_3532.method_15362((double)((float)((double)f.floatValue() * Math.PI * 0.5))))),
   EASE_OUT_SINE(f -> Float.valueOf(class_3532.method_15374((double)((float)((double)f.floatValue() * Math.PI * 0.5))))),
   EASE_IN_OUT_SINE(f -> Float.valueOf(1.0f - class_3532.method_15362((double)((float)(Math.PI * (double)f.floatValue() * 0.5))))),
   EASE_IN_EXPO(f -> Float.valueOf(f.floatValue() == 0.0f ? 0.0f : (float)Math.pow(2.0, 10.0f * f.floatValue() - 10.0f))),
   EASE_OUT_EXPO(f -> Float.valueOf(f.floatValue() == 1.0f ? 1.0f : 1.0f - (float)Math.pow(2.0, -10.0f * f.floatValue()))),
   EASE_IN_OUT_EXPO(f -> Float.valueOf(f.floatValue() == 0.0f ? 0.0f : (f.floatValue() == 1.0f ? 1.0f : ((double)f.floatValue() < 0.5 ? (float)Math.pow(2.0, 20.0f * f.floatValue() - 10.0f) * 0.5f : (2.0f - (float)Math.pow(2.0, -20.0f * f.floatValue() + 10.0f)) * 0.5f)))),
   EASE_IN_CIRC(f -> Float.valueOf(1.0f - (float)Math.sqrt(1.0f - f.floatValue() * f.floatValue()))),
   EASE_OUT_CIRC(f -> {
        f = Float.valueOf(f.floatValue() - 1.0f);
        return Float.valueOf((float)Math.sqrt(1.0f - f.floatValue() * f.floatValue()));
    }),
   EASE_IN_OUT_CIRC(f -> Float.valueOf((double)f.floatValue() < 0.5 ? (1.0f - (float)Math.sqrt(1.0f - 4.0f * f.floatValue() * f.floatValue())) * 0.5f : ((float)Math.sqrt(1.0f - 4.0f * (f.floatValue() - 1.0f) * f.floatValue()) + 1.0f) * 0.5f)),
   SIGMOID(f -> Float.valueOf(1.0f / (1.0f + (float)Math.exp(-f.floatValue())))),
   EASE_OUT_ELASTIC(f -> Float.valueOf(f.floatValue() == 0.0f ? 0.0f : (f.floatValue() == 1.0f ? 1.0f : (float)(Math.pow(2.0, -10.0f * f.floatValue()) * Math.sin(((double)(f.floatValue() * 10.0f) - 0.75) * 2.0943951023931953) * 0.5 + 1.0)))),
   EASE_IN_BACK(f -> Float.valueOf(2.70158f * f.floatValue() * f.floatValue() * f.floatValue() - 1.70158f * f.floatValue() * f.floatValue())),
   EASE_OUT_BACK(f -> {
        float f2 = f.floatValue() - 1.0f;
        return Float.valueOf(1.0f + 2.70158f * f2 * f2 * f2 + 1.70158f * f2 * f2);
    }),
   DYNAMIC_ISLAND(f -> Float.valueOf((float)(1.0 - Math.cos((double)f.floatValue() * Math.PI * (0.2 + 2.5 * Math.pow(f.floatValue(), 3.0))) * Math.exp(-f.floatValue() * 5.0f))));
   private final Function<Float, Float> function;

   private Easing(Function<Float, Float> var3) {
      this.function = var3;
   }

   public Function<Float, Float> getFunction() {
      return this.function;
   }
}
