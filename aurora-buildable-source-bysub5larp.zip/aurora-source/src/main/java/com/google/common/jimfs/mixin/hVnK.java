package com.google.common.jimfs.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Environment(EnvType.CLIENT)
@Mixin({class_310.class})
public interface hVnK {
   @Accessor("attackCooldown")
   int n();

   @Accessor("attackCooldown")
   void o(int var1);

   @Accessor("itemUseCooldown")
   int p();

   @Accessor("itemUseCooldown")
   void q(int var1);

   @Invoker("doItemUse")
   void r();

   @Invoker("doAttack")
   boolean s();
}
