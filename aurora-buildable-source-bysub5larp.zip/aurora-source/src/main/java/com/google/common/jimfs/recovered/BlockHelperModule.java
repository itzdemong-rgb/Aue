package com.google.common.jimfs.recovered;

import com.google.common.jimfs.client.Constants;
import com.google.common.jimfs.client.feature.module.Module;
import com.google.common.jimfs.client.feature.module.ModuleCategory;
import com.google.common.jimfs.client.feature.module.property.Property;
import com.google.common.jimfs.client.feature.module.property.impl.bool.BooleanProperty;
import com.google.common.jimfs.client.feature.module.property.impl.number.NumberProperty;
import com.google.common.jimfs.event.impl.game.PreGameTickEvent;
import com.google.common.jimfs.event.subscriber.Subscribe;
import com.google.common.jimfs.mixin.hVnK;
import com.google.common.jimfs.utility.misc.StringObfuscation;
import j2cc.Nativeify;
import net.minecraft.class_1747;
import net.minecraft.class_1799;

@Nativeify
public class BlockHelperModule extends Module {
   private final NumberProperty m = new NumberProperty(StringObfuscation.a("Delay Ticks"), 0.0, 0.0, 4.0, 1.0);
   private final BooleanProperty o = new BooleanProperty(StringObfuscation.a("Blocks Only"), true);
   
   

   public BlockHelperModule() {
      super(StringObfuscation.a("Block Helper"), "", ModuleCategory.COMBAT);
      this.b(new Property[]{this.m, this.o});
   }

   @Override
   protected void h() {
      boolean var1 = false;
      if (Constants.MINECRAFT.field_1724 != null) {
         ((hVnK)Constants.MINECRAFT).q(4);
      }
   }

   @Subscribe
   public void b(PreGameTickEvent var1) {
      boolean var2 = true;
      if (this.isEnabled() && Constants.MINECRAFT.field_1724 != null) {
         if (!this.o.isEnabled() || this.n()) {
            int var3 = Math.max(0, ((Double)this.m.getValue()).intValue());
            if (((hVnK)Constants.MINECRAFT).p() > var3) {
               ((hVnK)Constants.MINECRAFT).q(var3);
            }
         }
      }
   }

   private boolean n() {
      class_1799 var2 = Constants.MINECRAFT.field_1724.method_6047();
      boolean var1 = false;
      return !var2.method_7960() && var2.method_7909() instanceof class_1747;
   }

}
