package com.google.common.jimfs.client.feature.module.property.impl.number;

import com.google.common.jimfs.client.feature.module.property.Property;
import com.google.common.jimfs.utility.misc.math.MathUtility;
import org.jetbrains.annotations.NotNull;

public final class NumberProperty extends Property {
   private final Double minimum;
   private final Double maximum;
   private final Double j;
   private static Property[] k = new Property[5];

   public NumberProperty(CharSequence var1, double var2, double var4, double var6, double var8) {
      super(var1);
      this.minimum = var4;
      this.maximum = var6;
      this.j = var8;
      this.a(var2);
   }

   public double getMaximum() {
      return this.maximum;
   }

   public double getMinimum() {
      return this.minimum;
   }

   public void a(@NotNull Double var1) {
      super.a(MathUtility.b(var1, this.minimum, this.maximum, this.j).doubleValue());
   }

   @Override
   public void a(@NotNull Object var1) {
      this.a((Double)var1);
   }

   public static void b(Property[] var0) {
      k = var0;
   }

   public static Property[] d() {
      return k;
   }
}
