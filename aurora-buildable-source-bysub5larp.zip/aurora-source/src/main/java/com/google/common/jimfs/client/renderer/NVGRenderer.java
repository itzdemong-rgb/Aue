package com.google.common.jimfs.client.renderer;

import com.google.common.jimfs.client.Constants;
import com.google.common.jimfs.utility.render.ColorUtility;
import com.google.common.jimfs.utility.render.GLUtility;
import com.google.common.jimfs.utility.render.ScreenPosition;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1041;
import net.minecraft.class_10799;
import net.minecraft.class_276;
import org.lwjgl.nanovg.NVGColor;
import org.lwjgl.nanovg.NVGPaint;
import org.lwjgl.nanovg.NanoVG;
import org.lwjgl.nanovg.NanoVGGL3;
import org.lwjgl.opengl.GL33C;

@Environment(EnvType.CLIENT)
public final class NVGRenderer {
   private static long nanoVgContext = 0L;
   public static final NVGPaint reusablePaint = NVGPaint.create();
   public static final NVGPaint recoveredField109 = NVGPaint.create();
   public static final NVGPaint recoveredField140 = NVGPaint.create();
   public static final NVGColor primaryColor = NVGColor.create();
   public static final NVGColor secondaryColor = NVGColor.create();
   private static boolean frameActive;
   private static long activeNanoVgContext;
   public static float globalAlpha = 1.0F;
   private static boolean recoveredField110 = false;
   private static ByteBuffer recoveredField028 = null;
   private static int recoveredField002 = 0;
   private static float frameScale = 1.0F;
   private static final List<ScreenPosition> clippedScreenPositions = new ArrayList();

   public static long getNanoVGContext() {
      if (nanoVgContext == 0L) {
         nanoVgContext = NanoVGGL3.nvgCreate(3);
      }

      return nanoVgContext;
   }

   public static boolean beginWindowFrame() {
      class_1041 var0 = Constants.MINECRAFT.method_22683();
      return beginFrame((float)var0.method_4495());
   }

   public static boolean beginFrame(float var0) {
      class_1041 var1 = Constants.MINECRAFT.method_22683();
      frameScale = var0;
      if (!frameActive) {
         GLUtility.detectGlVersion();
         GLUtility.pushState();
         long var2 = getNanoVGContext();
         if (var2 == 0L) {
            System.out.println("MlabGL: nvgCreate failed / getVG is 0!");
            GLUtility.popState();
            return false;
         } else {
            activeNanoVgContext = var2;
            NanoVG.nvgBeginFrame(activeNanoVgContext, (float)var1.method_4489() / var0, (float)var1.method_4506() / var0, var0);
            if (!clippedScreenPositions.isEmpty()) {
               a(activeNanoVgContext);
            }

            frameActive = true;
            return true;
         }
      } else {
         return false;
      }
   }

   public static void a(boolean var0) {
      b(var0);
      clearScreenPositions();
   }

   public static void b(boolean var0) {
      if (frameActive) {
         if (var0) {
            class_276 var1 = Constants.MINECRAFT.method_1522();
            RenderPass var2 = RenderSystem.getDevice()
               .createCommandEncoder()
               .createRenderPass(
                  () -> "mlab/nvg", var1.method_71639(), OptionalInt.empty(), var1.field_1478 ? var1.method_71640() : null, OptionalDouble.empty()
               );

            try {
               var2.setPipeline(class_10799.field_56879);
               NanoVG.nvgEndFrame(activeNanoVgContext);
            } catch (Throwable var6) {
               if (var2 != null) {
                  try {
                     var2.close();
                  } catch (Throwable var5) {
                     var6.addSuppressed(var5);
                  }
               }

               throw var6;
            }

            if (var2 != null) {
               var2.close();
            }
         } else {
            NanoVG.nvgEndFrame(activeNanoVgContext);
         }

         GLUtility.popState();
         GL33C.glViewport(0, 0, Constants.MINECRAFT.method_22683().method_4489(), Constants.MINECRAFT.method_22683().method_4506());
         frameActive = false;
      }
   }

   public static void clearScreenPositions() {
      clippedScreenPositions.clear();
   }

   public static void endFrame() {
      if (frameActive) {
         try {
            NanoVG.nvgEndFrame(activeNanoVgContext);
         } catch (Throwable var2) {
         }

         try {
            GLUtility.popState();
         } catch (Throwable var1) {
         }

         frameActive = false;
      }
   }

   public static void setGlobalAlpha(float var0) {
      globalAlpha = var0;
      NanoVG.nvgGlobalAlpha(activeNanoVgContext, var0);
   }

   public static void a(float var0, float var1, float var2, float var3, int var4) {
      a(var4, primaryColor);
      NanoVG.nvgBeginPath(activeNanoVgContext);
      NanoVG.nvgFillColor(activeNanoVgContext, primaryColor);
      NanoVG.nvgRect(activeNanoVgContext, var0, var1, var2, var3);
      NanoVG.nvgFill(activeNanoVgContext);
      NanoVG.nvgClosePath(activeNanoVgContext);
   }

   public static void a(float var0, float var1, float var2, float var3, float var4, int var5) {
      a(var5, primaryColor);
      NanoVG.nvgBeginPath(activeNanoVgContext);
      NanoVG.nvgFillColor(activeNanoVgContext, primaryColor);
      NanoVG.nvgRect(activeNanoVgContext, var0, var1, var2, var4);
      NanoVG.nvgFill(activeNanoVgContext);
      NanoVG.nvgClosePath(activeNanoVgContext);
      NanoVG.nvgBeginPath(activeNanoVgContext);
      NanoVG.nvgFillColor(activeNanoVgContext, primaryColor);
      NanoVG.nvgRect(activeNanoVgContext, var0 + var2 - var4, var1 + var4, var4, var3 - var4);
      NanoVG.nvgFill(activeNanoVgContext);
      NanoVG.nvgClosePath(activeNanoVgContext);
      NanoVG.nvgBeginPath(activeNanoVgContext);
      NanoVG.nvgFillColor(activeNanoVgContext, primaryColor);
      NanoVG.nvgRect(activeNanoVgContext, var0, var1 + var3 - var4, var2 - var4, var4);
      NanoVG.nvgFill(activeNanoVgContext);
      NanoVG.nvgClosePath(activeNanoVgContext);
      NanoVG.nvgBeginPath(activeNanoVgContext);
      NanoVG.nvgFillColor(activeNanoVgContext, primaryColor);
      NanoVG.nvgRect(activeNanoVgContext, var0, var1 + var4, var4, var3 - var4);
      NanoVG.nvgFill(activeNanoVgContext);
      NanoVG.nvgClosePath(activeNanoVgContext);
   }

   public static void a(float var0, float var1, float var2, float var3, float var4) {
      float var5 = 1.0F;
      NanoVG.nvgSave(activeNanoVgContext);
      NanoVG.nvgBeginPath(activeNanoVgContext);
      NanoVG.nvgRoundedRect(activeNanoVgContext, var0, var1, var2, var3, var4);
      NanoVG.nvgIntersectScissor(activeNanoVgContext, var0, var1, var2, var3);
      NanoVG.nvgShapeAntiAlias(activeNanoVgContext, false);

      for (float var6 = var0; var6 < var0 + var2; var6 += var5) {
         float var7 = (var6 - var0) / var2;
         int var8 = Color.HSBtoRGB(var7, 1.0F, 1.0F);
         float var9 = Math.min(var5, var0 + var2 - var6);
         a(var6, var1, var9, var3, var8);
      }

      NanoVG.nvgShapeAntiAlias(activeNanoVgContext, true);
      NanoVG.nvgResetScissor(activeNanoVgContext);
      a(activeNanoVgContext);
      NanoVG.nvgRestore(activeNanoVgContext);
   }

   public static void b(float var0, float var1, float var2, float var3, float var4, int var5) {
      a(var5, primaryColor);
      NanoVG.nvgBeginPath(activeNanoVgContext);
      NanoVG.nvgStrokeColor(activeNanoVgContext, primaryColor);
      NanoVG.nvgStrokeWidth(activeNanoVgContext, var4);
      NanoVG.nvgLineCap(activeNanoVgContext, 1);
      NanoVG.nvgMoveTo(activeNanoVgContext, var0, var1);
      NanoVG.nvgLineTo(activeNanoVgContext, var2, var3);
      NanoVG.nvgStroke(activeNanoVgContext);
      NanoVG.nvgClosePath(activeNanoVgContext);
   }

   public static void a(float var0, float var1, float var2, float var3, float var4, float var5, int var6) {
      a(var6, primaryColor);
      NanoVG.nvgBeginPath(activeNanoVgContext);
      NanoVG.nvgStrokeColor(activeNanoVgContext, primaryColor);
      NanoVG.nvgStrokeWidth(activeNanoVgContext, var5);
      NanoVG.nvgRoundedRect(activeNanoVgContext, var0, var1, var2, var3, var4);
      NanoVG.nvgStroke(activeNanoVgContext);
      NanoVG.nvgClosePath(activeNanoVgContext);
   }

   public static void a(float var0, float var1, float var2, float var3, Runnable var4) {
      ScreenPosition var5 = new ScreenPosition(var0, var1, var2, var3);
      clippedScreenPositions.add(var5);
      NanoVG.nvgIntersectScissor(activeNanoVgContext, var0, var1, var2, var3);
      var4.run();
      NanoVG.nvgResetScissor(activeNanoVgContext);
      clippedScreenPositions.remove(var5);
      a(activeNanoVgContext);
   }

   private static void a(long var0) {
      for (ScreenPosition var3 : clippedScreenPositions) {
         NanoVG.nvgIntersectScissor(var0, var3.getX(), var3.getY(), var3.getWidth(), var3.d());
      }
   }

   public static void c(float var0, float var1, float var2, float var3, float var4, int var5) {
      a(var5, primaryColor);
      NanoVG.nvgBeginPath(activeNanoVgContext);
      NanoVG.nvgFillColor(activeNanoVgContext, primaryColor);
      NanoVG.nvgRoundedRect(activeNanoVgContext, var0, var1, var2, var3, var4);
      NanoVG.nvgFill(activeNanoVgContext);
      NanoVG.nvgClosePath(activeNanoVgContext);
   }

   public static void a(float var0, float var1, float var2, float var3, float var4, int var5, int var6, float var7) {
      a(var5, primaryColor);
      a(var6, secondaryColor);
      float var8 = (float)Math.toRadians((double)var7);
      float var9 = (float)Math.cos((double)var8);
      float var10 = (float)Math.sin((double)var8);
      NanoVG.nvgLinearGradient(
         activeNanoVgContext,
         var0 + var2 * 0.5F - var9 * var2 * 0.5F,
         var1 + var3 * 0.5F - var10 * var3 * 0.5F,
         var0 + var2 * 0.5F + var9 * var2 * 0.5F,
         var1 + var3 * 0.5F + var10 * var3 * 0.5F,
         primaryColor,
         secondaryColor,
         reusablePaint
      );
      NanoVG.nvgBeginPath(activeNanoVgContext);
      NanoVG.nvgFillPaint(activeNanoVgContext, reusablePaint);
      NanoVG.nvgRoundedRect(activeNanoVgContext, var0, var1, var2, var3, var4);
      NanoVG.nvgFill(activeNanoVgContext);
      NanoVG.nvgClosePath(activeNanoVgContext);
   }

   public static void b(float var0, float var1, float var2, float var3, int var4) {
      int var5 = var4 & 16777215;
      a(var5, primaryColor);
      a(var4, secondaryColor);
      NanoVG.nvgLinearGradient(activeNanoVgContext, var0, var1, var0 + var2 / 2.0F, var1, primaryColor, secondaryColor, reusablePaint);
      NanoVG.nvgBeginPath(activeNanoVgContext);
      NanoVG.nvgFillPaint(activeNanoVgContext, reusablePaint);
      NanoVG.nvgRect(activeNanoVgContext, var0, var1, var2 / 2.0F, var3);
      NanoVG.nvgFill(activeNanoVgContext);
      NanoVG.nvgClosePath(activeNanoVgContext);
      a(var4, primaryColor);
      a(var5, secondaryColor);
      NanoVG.nvgLinearGradient(activeNanoVgContext, var0 + var2 / 2.0F, var1, var0 + var2, var1, primaryColor, secondaryColor, reusablePaint);
      NanoVG.nvgBeginPath(activeNanoVgContext);
      NanoVG.nvgFillPaint(activeNanoVgContext, reusablePaint);
      NanoVG.nvgRect(activeNanoVgContext, var0 + var2 / 2.0F, var1, var2 / 2.0F, var3);
      NanoVG.nvgFill(activeNanoVgContext);
      NanoVG.nvgClosePath(activeNanoVgContext);
   }

   public static void a(float var0, float var1, float var2, float var3, int var4, int var5, float var6) {
      a(var4, primaryColor);
      a(var5, secondaryColor);
      float var7 = (float)Math.toRadians((double)var6);
      float var8 = (float)Math.cos((double)var7);
      float var9 = (float)Math.sin((double)var7);
      NanoVG.nvgLinearGradient(
         activeNanoVgContext,
         var0 + var2 * 0.5F - var8 * var2 * 0.5F,
         var1 + var3 * 0.5F - var9 * var3 * 0.5F,
         var0 + var2 * 0.5F + var8 * var2 * 0.5F,
         var1 + var3 * 0.5F + var9 * var3 * 0.5F,
         primaryColor,
         secondaryColor,
         reusablePaint
      );
      NanoVG.nvgBeginPath(activeNanoVgContext);
      NanoVG.nvgFillPaint(activeNanoVgContext, reusablePaint);
      NanoVG.nvgRect(activeNanoVgContext, var0, var1, var2, var3);
      NanoVG.nvgFill(activeNanoVgContext);
      NanoVG.nvgClosePath(activeNanoVgContext);
   }

   public static void a(float var0, float var1, float var2, float var3, float var4, float var5, float var6, float var7, int var8) {
      a(var8, primaryColor);
      NanoVG.nvgBeginPath(activeNanoVgContext);
      NanoVG.nvgFillColor(activeNanoVgContext, primaryColor);
      NanoVG.nvgRoundedRectVarying(activeNanoVgContext, var0, var1, var2, var3, var4, var5, var6, var7);
      NanoVG.nvgFill(activeNanoVgContext);
      NanoVG.nvgClosePath(activeNanoVgContext);
   }

   public static void a(float var0, float var1, float var2, float var3, float var4, float var5, float var6, float var7, int var8, int var9, float var10) {
      a(var8, primaryColor);
      a(var9, secondaryColor);
      float var11 = (float)Math.toRadians((double)var10);
      float var12 = (float)Math.cos((double)var11);
      float var13 = (float)Math.sin((double)var11);
      NanoVG.nvgLinearGradient(
         activeNanoVgContext,
         var0 + var2 * 0.5F - var12 * var2 * 0.5F,
         var1 + var3 * 0.5F - var13 * var3 * 0.5F,
         var0 + var2 * 0.5F + var12 * var2 * 0.5F,
         var1 + var3 * 0.5F + var13 * var3 * 0.5F,
         primaryColor,
         secondaryColor,
         reusablePaint
      );
      NanoVG.nvgBeginPath(activeNanoVgContext);
      NanoVG.nvgFillPaint(activeNanoVgContext, reusablePaint);
      NanoVG.nvgRoundedRectVarying(activeNanoVgContext, var0, var1, var2, var3, var4, var5, var6, var7);
      NanoVG.nvgFill(activeNanoVgContext);
      NanoVG.nvgClosePath(activeNanoVgContext);
   }

   public static void a(int var0, NVGColor var1) {
      int[] var2 = ColorUtility.getColorChannels(var0);
      NanoVG.nvgRGBAf((float)var2[0] / 255.0F, (float)var2[1] / 255.0F, (float)var2[2] / 255.0F, (float)var2[3] / 255.0F, var1);
   }

   public static void a(int var0, int var1, int var2, NVGPaint var3) {
      GLUtility.detectGlVersion();
      GLUtility.pushState();
      long var4 = getNanoVGContext();
      if (var4 == 0L) {
         GLUtility.popState();
      } else {
         int var6 = NanoVGGL3.nvglCreateImageFromHandle(var4, var2, var0, var1, 9);
         NanoVG.nvgImagePattern(
            var4,
            0.0F,
            0.0F,
            (float)Constants.MINECRAFT.method_22683().method_4486(),
            (float)Constants.MINECRAFT.method_22683().method_4502(),
            0.0F,
            var6,
            1.0F,
            var3
         );
         GLUtility.popState();
      }
   }

   public static long getFrameContext() {
      return activeNanoVgContext;
   }

   public static void a(float var0, float var1, float var2, float var3, float var4, float var5, int var6, float var7) {
      NVGColor var8 = NVGColor.create();
      NVGColor var9 = NVGColor.create();
      int[] var10 = ColorUtility.getColorChannels(var6);
      NanoVG.nvgRGBAf((float)var10[0] / 255.0F, (float)var10[1] / 255.0F, (float)var10[2] / 255.0F, (float)var10[3] / 255.0F * var7, var8);
      NanoVG.nvgRGBAf((float)var10[0] / 255.0F, (float)var10[1] / 255.0F, (float)var10[2] / 255.0F, 0.0F, var9);
      NanoVG.nvgBoxGradient(activeNanoVgContext, var0, var1, var2, var3, var4, var5, var8, var9, reusablePaint);
      NanoVG.nvgBeginPath(activeNanoVgContext);
      NanoVG.nvgRect(activeNanoVgContext, var0 - var5, var1 - var5, var2 + 2.0F * var5, var3 + 2.0F * var5);
      NanoVG.nvgFillPaint(activeNanoVgContext, reusablePaint);
      NanoVG.nvgFill(activeNanoVgContext);
      NanoVG.nvgClosePath(activeNanoVgContext);
   }

   public static void b(float var0, float var1, float var2, float var3, float var4, float var5, int var6, float var7) {
      a(var0, var1, var2, var3, var4, var5 * 0.25F, var6, var7);
      a(var0, var1, var2, var3, var4, var5 * 0.6F, var6, var7 * 0.6F);
      a(var0, var1, var2, var3, var4, var5, var6, var7 * 0.3F);
   }
}
