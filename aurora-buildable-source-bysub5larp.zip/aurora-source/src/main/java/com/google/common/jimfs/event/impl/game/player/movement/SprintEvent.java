package com.google.common.jimfs.event.impl.game.player.movement;

public final class SprintEvent {
   private boolean sprinting;

   public SprintEvent(boolean var1) {
      this.sprinting = var1;
   }

   public boolean isSprinting() {
      return this.sprinting;
   }
}
