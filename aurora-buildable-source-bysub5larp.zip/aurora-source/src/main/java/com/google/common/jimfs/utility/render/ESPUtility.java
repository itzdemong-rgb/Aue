package com.google.common.jimfs.utility.render;

import com.google.common.jimfs.client.Constants;
import com.google.common.jimfs.mixin.render.GameRendererAccessor;
import com.google.common.jimfs.utility.misc.math.MathUtility;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1309;
import net.minecraft.class_1893;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_7833;
import org.joml.Matrix4f;
import org.joml.Vector4d;
import org.joml.Vector4f;

@Environment(EnvType.CLIENT)
public class ESPUtility {
   public static final Matrix4f recoveredField042 = new Matrix4f();
   public static final Matrix4f recoveredField107 = new Matrix4f();
   public static boolean recoveredField045 = false;
   public static final Map recoveredField031 = new HashMap() {
      {
         this.put(class_1893.field_9111, "Pr");
         this.put(class_1893.field_9095, "Fp");
         this.put(class_1893.field_9129, "Ff");
         this.put(class_1893.field_9107, "Bp");
         this.put(class_1893.field_9096, "Pp");
         this.put(class_1893.field_9127, "Re");
         this.put(class_1893.field_9105, "Aa");
         this.put(class_1893.field_9097, "Th");
         this.put(class_1893.field_9128, "Ds");
         this.put(class_1893.field_9122, "Fw");
         this.put(class_1893.field_9113, "Bc");
         this.put(class_1893.field_23071, "Ss");
         this.put(class_1893.field_38223, "Sn");
         this.put(class_1893.field_9118, "Sh");
         this.put(class_1893.field_9123, "Sm");
         this.put(class_1893.field_9112, "BoA");
         this.put(class_1893.field_9121, "Kb");
         this.put(class_1893.field_9124, "Fa");
         this.put(class_1893.field_9110, "Lo");
         this.put(class_1893.field_9115, "Sw");
         this.put(class_1893.field_9131, "Ef");
         this.put(class_1893.field_9099, "St");
         this.put(class_1893.field_9119, "Un");
         this.put(class_1893.field_9130, "Fo");
         this.put(class_1893.field_9103, "Po");
         this.put(class_1893.field_9116, "Pu");
         this.put(class_1893.field_9126, "Fl");
         this.put(class_1893.field_9125, "In");
         this.put(class_1893.field_9114, "Lu");
         this.put(class_1893.field_9100, "Lr");
         this.put(class_1893.field_9120, "Ly");
         this.put(class_1893.field_9106, "Ip");
         this.put(class_1893.field_9104, "Ri");
         this.put(class_1893.field_9117, "Ch");
         this.put(class_1893.field_9108, "Mu");
         this.put(class_1893.field_9098, "Qc");
         this.put(class_1893.field_9132, "Pi");
         this.put(class_1893.field_9101, "Me");
         this.put(class_1893.field_9109, "Vc");
      }
   };

   private ESPUtility() {
   }

   public static Vector4d a(class_1309 var0, float var1) {
      int[] var2 = new int[]{0, 0, Constants.MINECRAFT.method_22683().method_4489(), Constants.MINECRAFT.method_22683().method_4506()};
      class_4587 var3 = createWorldMatrixStack(var1);
      Matrix4f var4 = var3.method_23760().method_23761();
      class_243 var5 = MathUtility.a(var0, var1);
      float var6 = var0.method_17681() / 2.0F;
      float var7 = var0.method_17682() + (var0.method_18276() ? 0.1F : 0.2F);
      class_238 var8 = new class_238(
         var5.field_1352 - (double)var6,
         var5.field_1351,
         var5.field_1350 - (double)var6,
         var5.field_1352 + (double)var6,
         var5.field_1351 + (double)var7,
         var5.field_1350 + (double)var6
      );
      Vector4d var9 = a(var2, var4, var8);
      if (var9 == null) {
         return null;
      } else {
         var9.div((double)Constants.MINECRAFT.method_22683().method_4495());
         return var9;
      }
   }

   public static Vector4d a(int[] var0, Matrix4f var1, class_238 var2) {
      Vector4f var3 = new Vector4f();
      List<class_243> var4 = a(var2);
      Vector4d var5 = null;
      int var6 = 0;

      for (class_243 var8 : var4) {
         var1.project(var8.method_46409(), var0, var3);
         var3.y = (float)var0[3] - var3.y;
         if (!(var3.w < 0.001F)) {
            var6++;
            if (var5 == null) {
               var5 = new Vector4d((double)var3.x, (double)var3.y, (double)var3.x, (double)var3.y);
            } else {
               double var9 = (double)var3.x;
               double var11 = (double)var3.y;
               var5.x = Math.min(var9, var5.x);
               var5.y = Math.min(var11, var5.y);
               var5.z = Math.max(var9, var5.z);
               var5.w = Math.max(var11, var5.w);
            }
         }
      }

      return var6 == 0 ? null : var5;
   }

   public static class_243 a(class_243 var0) {
      if (Constants.MINECRAFT.field_1724 == null) {
         return null;
      } else {
         class_243 var1 = Constants.MINECRAFT.field_1724.method_33571();
         class_243 var2 = var0.method_1020(var1);
         class_243 var3 = Constants.MINECRAFT.field_1724.method_5828(1.0F);
         if (var2.method_1026(var3) < 0.0) {
            return null;
         } else {
            int[] var4 = new int[]{0, 0, Constants.MINECRAFT.method_22683().method_4489(), Constants.MINECRAFT.method_22683().method_4506()};
            float var5 = Constants.MINECRAFT.method_61966().method_60637(false);
            class_4587 var6 = createWorldMatrixStack(var5);
            Matrix4f var7 = var6.method_23760().method_23761();
            Vector4f var8 = new Vector4f();
            var7.project(var0.method_46409(), var4, var8);
            var8.y = (float)var4[3] - var8.y;
            double var9 = (double)Constants.MINECRAFT.method_22683().method_4495();
            return new class_243((double)var8.x / var9, (double)var8.y / var9, 0.0);
         }
      }
   }

   public static class_4587 createWorldMatrixStack(float var0) {
      class_4587 var1 = new class_4587();
      if (recoveredField045) {
         var1.method_34425(new Matrix4f(recoveredField042).mul(recoveredField107));
         if (Constants.MINECRAFT.field_1773 != null && Constants.MINECRAFT.field_1773.method_19418() != null) {
            class_243 var6 = Constants.MINECRAFT.field_1773.method_19418().method_71156();
            var1.method_22904(-var6.field_1352, -var6.field_1351, -var6.field_1350);
         }

         return var1;
      } else {
         GameRendererAccessor var2 = (GameRendererAccessor)Constants.MINECRAFT.field_1773;
         class_4184 var3 = Constants.MINECRAFT.field_1773.method_19418();
         float var4 = var2.xR(var3, var0, true);
         var1.method_34425(Constants.MINECRAFT.field_1773.method_22973(var4));
         var2.dG(var1, var3.method_55437());
         if ((Boolean)Constants.MINECRAFT.field_1690.method_42448().method_41753()) {
            var2.hT(var1, var3.method_55437());
         }

         var1.method_22907(class_7833.field_40714.rotationDegrees(var3.method_19329()));
         var1.method_22907(class_7833.field_40716.rotationDegrees(var3.method_19330() + 180.0F));
         class_243 var5 = var3.method_71156();
         var1.method_22904(-var5.field_1352, -var5.field_1351, -var5.field_1350);
         return var1;
      }
   }

   public static List a(class_238 var0) {
      return Arrays.asList(
         new class_243(var0.field_1323, var0.field_1322, var0.field_1321),
         new class_243(var0.field_1323, var0.field_1325, var0.field_1321),
         new class_243(var0.field_1320, var0.field_1322, var0.field_1321),
         new class_243(var0.field_1320, var0.field_1325, var0.field_1321),
         new class_243(var0.field_1323, var0.field_1322, var0.field_1324),
         new class_243(var0.field_1323, var0.field_1325, var0.field_1324),
         new class_243(var0.field_1320, var0.field_1322, var0.field_1324),
         new class_243(var0.field_1320, var0.field_1325, var0.field_1324)
      );
   }
}
