package com.google.common.jimfs.recovered;

public final class ClientInitializedEvent {
}
