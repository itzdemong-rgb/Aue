package com.google.common.jimfs.event.impl.game.player.movement;

public final class PostMovementPacketEvent {
   private final double x;
   private final double y;
   private final double z;
   private final float yaw;
   private final float pitch;
   private final boolean recoveredField213;
   private final boolean recoveredField226;

   public PostMovementPacketEvent(double var1, double var3, double var5, float var7, float var8, boolean var9, boolean var10) {
      this.x = var1;
      this.y = var3;
      this.z = var5;
      this.yaw = var7;
      this.pitch = var8;
      this.recoveredField213 = var9;
      this.recoveredField226 = var10;
   }
}
