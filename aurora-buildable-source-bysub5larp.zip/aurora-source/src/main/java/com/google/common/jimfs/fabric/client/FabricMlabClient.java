package com.google.common.jimfs.fabric.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class FabricMlabClient implements ClientModInitializer {
   public void onInitializeClient() {
   }
}
