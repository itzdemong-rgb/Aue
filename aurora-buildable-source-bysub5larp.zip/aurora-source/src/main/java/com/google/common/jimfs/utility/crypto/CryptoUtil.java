package com.google.common.jimfs.utility.crypto;

import com.google.common.jimfs.client.feature.module.property.Property;
import com.google.common.jimfs.utility.misc.StringObfuscation;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class CryptoUtil {

   private static final int recoveredField117 = 256;
   private static final int recoveredField149 = 16;
   private static final int recoveredField177 = 100000;
   private static int recoveredField195 = 8;
   private static final String[] encodedStrings = new String[]{
      "Ñ\u0013\u009d@6ù#tà\"Ùè\u0090æ\u0018Í¦C\u0011X\u0087ð8[\u000eN\t\u0085'¶ÌÿP\u0016-Ì\u008d¶yÐ)=\f\u008ah5\u0005\u0088Gk!¼\rºH3",
      "\u0005|*óMY@/\u000f¤è6Õæ±9²¥\u0090çÔ\u0005_¦L\u0086\u0003\u0000g\u000eç´w\u008eÆ@\u0010s\u000b¬¦Ñ=5 Ù\u001d\u0014",
      "UÜ,r\u0002\u0015ä}xFªÅ\u0091ø·\u0094\u0010îåÄtq\u0089u",
      "`Ë\u0088 ÒÈ8Òá&Þ±»yÓ[\u009f\u0017vù'\u0098ï\u0090x<èªÚ2¿\u0000\\A\u0082Ø\u0098w\u0019Ò\u0088=\u0019çÇ/R\u0090l\u0019\u008aðWkÃg",
      "º\u0001óm\u009b\u0084öq9zã\u0003ø*Ù\u0099ó°wg)tÂÃ\u009fP\u001bÈH[\u00ad®Sp\u008cÆw\u0081\b£æX\u0019\u001a\u0088º\u0019\u0004\u0093|\b)çÔL\u0082",
      "º\u009bó_\u0096©úö\u0098»õwY(ìÄu¼\u0088ú\u0017SË\f\u009f²\u001b\u0098H\u0099¢.S¡bEª7¼LÉ¤Bó\u00803\u0017M",
      "\u0012i«\u007f}7H³",
      "e\u0011\u0096à¨\u0094}·Ôw\u0083\u009fn\u009a?mÎ,_¦",
      "¶µÇø\u009cáJ!\u0080\b¢\tt\u0082\u0090\u0017j\u0091\u0011p"
   };
   private static final String[] decodedStrings = new String[]{null, null, null, null, null, null, null, "AES/CBC/PKCS5Padding", "PBKDF2WithHmacSHA256"};

   private CryptoUtil() {
   }

   public static byte[] a(byte[] var0, char[] var1, byte[] var2) {
      byte var3 = 0;

      byte[] var10000;
      try {
         SecretKey var4 = a(var1, var2);
         byte[] var5 = new byte[16];
         new SecureRandom().nextBytes(var5);
         Cipher var6 = Cipher.getInstance(StringObfuscation.d(a(-13324, -2473), 12411));
         var6.init(1, var4, new IvParameterSpec(var5));
         byte[] var7 = var6.doFinal(var0);
         byte[] var8 = new byte[var5.length + var7.length];
         System.arraycopy(var5, 0, var8, 0, var5.length);
         System.arraycopy(var7, 0, var8, var5.length, var7.length);
         Arrays.fill(var1, '\u0000');
         var10000 = var8;
      } catch (Exception var9) {
         throw new RuntimeException("Encryption failed", var9);
      }

      if (var3 != 0) {
         Property.c(!Property.j());
      }

      return var10000;
   }

   public static byte[] b(byte[] var0, char[] var1, byte[] var2) {
      try {
         SecretKey var3 = a(var1, var2);
         byte[] var4 = Arrays.copyOfRange(var0, 0, 16);
         byte[] var5 = Arrays.copyOfRange(var0, 16, var0.length);
         Cipher var6 = Cipher.getInstance(StringObfuscation.d(a(-13321, -7773), 23301));
         var6.init(2, var3, new IvParameterSpec(var4));
         byte[] var7 = var6.doFinal(var5);
         Arrays.fill(var1, '\u0000');
         return var7;
      } catch (Exception var8) {
         throw new RuntimeException("Decryption failed", var8);
      }
   }

   public static String encryptString(String var0, char[] var1) {
      byte[] var3 = new byte[16];
      new SecureRandom().nextBytes(var3);
      byte[] var4 = a(var0.getBytes(StandardCharsets.UTF_8), var1, var3);
      int var2 = 0;
      byte[] var5 = new byte[var3.length + var4.length];
      System.arraycopy(var3, 0, var5, 0, var3.length);
      System.arraycopy(var4, 0, var5, var3.length, var4.length);
      String var10000 = Base64.getEncoder().encodeToString(var5);
      if (Property.j()) {
         b(++var2);
      }

      return var10000;
   }

   public static String decryptString(String var0, char[] var1) {
      byte[] var2 = Base64.getDecoder().decode(var0);
      byte[] var3 = Arrays.copyOfRange(var2, 0, 16);
      byte[] var4 = Arrays.copyOfRange(var2, 16, var2.length);
      byte[] var5 = b(var4, var1, var3);
      return new String(var5, StandardCharsets.UTF_8);
   }

   private static SecretKey a(char[] var0, byte[] var1) throws Exception {
      PBEKeySpec var2 = new PBEKeySpec(var0, var1, 100000, 256);
      SecretKeyFactory var3 = SecretKeyFactory.getInstance(StringObfuscation.d(a(-13325, -29721), 10220));
      byte[] var4 = var3.generateSecret(var2).getEncoded();
      return new SecretKeySpec(var4, "AES");
   }

   public static char[] derivePassword(String var0) {
      byte var1 = 8;

      try {
         MessageDigest var2 = MessageDigest.getInstance("SHA-512");
         byte[] var3 = var2.digest(var0.getBytes(StandardCharsets.UTF_8));
         char[] var4 = new char[var3.length / 2];
         int var5 = 0;

         char[] var10000;
         while (true) {
            if (var5 < var4.length) {
               var10000 = var4;
               if (var1 == 0) {
                  break;
               }

               var4[var5] = (char)((var3[var5 * 2] & 255) << 8 | var3[var5 * 2 + 1] & 255);
               var5++;
               if (var1 != 0) {
                  continue;
               }
            }

            var10000 = var4;
            break;
         }

         return var10000;
      } catch (Exception var6) {
         return new char[]{'j', 'i', 'm', 'f', 's'};
      }
   }

   public static void b(int var0) {
      recoveredField195 = var0;
   }

   public static int recoveredMethod064() {
      return recoveredField195;
   }

   public static int recoveredMethod101() {
      byte var0 = 8;
      return var0 == 0 ? 82 : 0;
   }

   private static String a(int var0, int var1) {
      int var2 = (var0 ^ -13321) & 65535;
      if (decodedStrings[var2] == null) {
         char[] var3 = encodedStrings[var2].toCharArray();

         short var4 = switch (var3[0] & 0xFF) {
            case 0 -> 47;
            case 1 -> 250;
            case 2 -> 108;
            case 3 -> 248;
            case 4 -> 206;
            case 5 -> 52;
            case 6 -> 246;
            case 7 -> 35;
            case 8 -> 221;
            case 9 -> 156;
            case 10 -> 120;
            case 11 -> 159;
            case 12 -> 177;
            case 13 -> 113;
            case 14 -> 179;
            case 15 -> 249;
            case 16 -> 217;
            case 17 -> 4;
            case 18 -> 210;
            case 19 -> 53;
            case 20 -> 116;
            case 21 -> 80;
            case 22 -> 234;
            case 23 -> 157;
            case 24 -> 213;
            case 25 -> 104;
            case 26 -> 107;
            case 27 -> 152;
            case 28 -> 60;
            case 29 -> 241;
            case 30 -> 190;
            case 31 -> 34;
            case 32 -> 151;
            case 33 -> 91;
            case 34 -> 14;
            case 35 -> 115;
            case 36 -> 207;
            case 37 -> 147;
            case 38 -> 254;
            case 39 -> 215;
            case 40 -> 164;
            case 41 -> 17;
            case 42 -> 203;
            case 43 -> 123;
            case 44 -> 49;
            case 45 -> 61;
            case 46 -> 86;
            case 47 -> 247;
            case 48 -> 57;
            case 49 -> 68;
            case 50 -> 110;
            case 51 -> 251;
            case 52 -> 51;
            case 53 -> 200;
            case 54 -> 19;
            case 55 -> 40;
            case 56 -> 128;
            case 57 -> 127;
            case 58 -> 140;
            case 59 -> 237;
            case 60 -> 111;
            case 61 -> 82;
            case 62 -> 240;
            case 63 -> 135;
            case 64 -> 45;
            case 65 -> 98;
            case 66 -> 137;
            case 67 -> 15;
            case 68 -> 87;
            case 69 -> 218;
            case 70 -> 199;
            case 71 -> 58;
            case 72 -> 26;
            case 73 -> 168;
            case 74 -> 16;
            case 75 -> 136;
            case 76 -> 81;
            case 77 -> 192;
            case 78 -> 244;
            case 79 -> 38;
            case 80 -> 165;
            case 81 -> 48;
            case 82 -> 7;
            case 83 -> 27;
            case 84 -> 23;
            case 85 -> 93;
            case 86 -> 71;
            case 87 -> 131;
            case 88 -> 67;
            case 89 -> 106;
            case 90 -> 220;
            case 91 -> 0;
            case 92 -> 31;
            case 93 -> 64;
            case 94 -> 197;
            case 95 -> 75;
            case 96 -> 3;
            case 97 -> 97;
            case 98 -> 105;
            case 99 -> 125;
            case 100 -> 183;
            case 101 -> 145;
            case 102 -> 222;
            case 103 -> 171;
            case 104 -> 223;
            case 105 -> 189;
            case 106 -> 252;
            case 107 -> 139;
            case 108 -> 245;
            case 109 -> 89;
            case 110 -> 175;
            case 111 -> 13;
            case 112 -> 198;
            case 113 -> 55;
            case 114 -> 10;
            case 115 -> 112;
            case 116 -> 155;
            case 117 -> 39;
            case 118 -> 231;
            case 119 -> 9;
            case 120 -> 66;
            case 121 -> 62;
            case 122 -> 227;
            case 123 -> 178;
            case 124 -> 130;
            case 125 -> 153;
            case 126 -> 225;
            case 127 -> 166;
            case 128 -> 202;
            case 129 -> 102;
            case 130 -> 133;
            case 131 -> 77;
            case 132 -> 73;
            case 133 -> 101;
            case 134 -> 224;
            case 135 -> 92;
            case 136 -> 69;
            case 137 -> 129;
            case 138 -> 63;
            case 139 -> 219;
            case 140 -> 109;
            case 141 -> 46;
            case 142 -> 42;
            case 143 -> 173;
            case 144 -> 76;
            case 145 -> 196;
            case 146 -> 230;
            case 147 -> 95;
            case 148 -> 29;
            case 149 -> 18;
            case 150 -> 79;
            case 151 -> 21;
            case 152 -> 160;
            case 153 -> 184;
            case 154 -> 162;
            case 155 -> 28;
            case 156 -> 6;
            case 157 -> 150;
            case 158 -> 239;
            case 159 -> 44;
            case 160 -> 43;
            case 161 -> 148;
            case 162 -> 54;
            case 163 -> 59;
            case 164 -> 8;
            case 165 -> 20;
            case 166 -> 70;
            case 167 -> 193;
            case 168 -> 169;
            case 169 -> 118;
            case 170 -> 65;
            case 171 -> 100;
            case 172 -> 211;
            case 173 -> 204;
            case 174 -> 121;
            case 175 -> 146;
            case 176 -> 50;
            case 177 -> 180;
            case 178 -> 25;
            case 179 -> 182;
            case 180 -> 83;
            case 181 -> 24;
            case 182 -> 187;
            case 183 -> 78;
            case 184 -> 154;
            case 185 -> 12;
            case 186 -> 88;
            case 187 -> 181;
            case 188 -> 214;
            case 189 -> 144;
            case 190 -> 232;
            case 191 -> 194;
            case 192 -> 238;
            case 193 -> 216;
            case 194 -> 103;
            case 195 -> 114;
            case 196 -> 2;
            case 197 -> 72;
            case 198 -> 5;
            case 199 -> 229;
            case 200 -> 37;
            case 201 -> 142;
            case 202 -> 242;
            case 203 -> 172;
            case 204 -> 176;
            case 205 -> 122;
            case 206 -> 119;
            case 207 -> 167;
            case 208 -> 32;
            case 209 -> 191;
            case 210 -> 253;
            case 211 -> 74;
            case 212 -> 84;
            case 213 -> 185;
            case 214 -> 228;
            case 215 -> 209;
            case 216 -> 170;
            case 217 -> 235;
            case 218 -> 36;
            case 219 -> 124;
            case 220 -> 30;
            case 221 -> 96;
            case 222 -> 141;
            case 223 -> 163;
            case 224 -> 243;
            case 225 -> 94;
            case 226 -> 208;
            case 227 -> 126;
            case 228 -> 22;
            case 229 -> 212;
            case 230 -> 56;
            case 231 -> 117;
            case 232 -> 201;
            case 233 -> 186;
            case 234 -> 149;
            case 235 -> 33;
            case 236 -> 174;
            case 237 -> 132;
            case 238 -> 41;
            case 239 -> 85;
            case 240 -> 188;
            case 241 -> 233;
            case 242 -> 226;
            case 243 -> 143;
            case 244 -> 161;
            case 245 -> 158;
            case 246 -> 138;
            case 247 -> 99;
            case 248 -> 195;
            case 249 -> 236;
            case 250 -> 205;
            case 251 -> 90;
            case 252 -> 1;
            case 253 -> 11;
            case 254 -> 255;
            default -> 134;
         };
         int var5 = (var1 & 0xFF) - var4;
         if (var5 < 0) {
            var5 += 256;
         }

         int var6 = ((var1 & 65535) >>> 8) - var4;
         if (var6 < 0) {
            var6 += 256;
         }

         for (int var7 = 0; var7 < var3.length; var7++) {
            int var8 = var7 % 2;
            char var10002 = var3[var7];
            if (var8 == 0) {
               var3[var7] = (char)(var10002 ^ var5);
               var5 = ((var5 >>> 3 | var5 << 5) ^ var3[var7]) & 0xFF;
            } else {
               var3[var7] = (char)(var10002 ^ var6);
               var6 = ((var6 >>> 3 | var6 << 5) ^ var3[var7]) & 0xFF;
            }
         }

         decodedStrings[var2] = new String(var3).intern();
      }

      return decodedStrings[var2];
   }
}
