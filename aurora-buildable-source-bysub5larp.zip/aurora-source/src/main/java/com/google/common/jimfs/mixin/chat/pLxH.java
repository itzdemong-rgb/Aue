package com.google.common.jimfs.mixin.chat;

import com.google.common.jimfs.client.feature.helper.impl.render.ScreenPositionManager;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_11909;
import net.minecraft.class_4069;
import net.minecraft.class_408;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin({class_408.class})
public abstract class pLxH implements class_4069 {
   @Inject(
      method = {"mouseClicked"},
      at = {@At("HEAD")}
   )
   private void eNf(class_11909 var1, boolean var2, CallbackInfoReturnable var3) {
      ScreenPositionManager.getInstance().a(var1.comp_4798(), var1.comp_4799(), var1.method_74245());
   }

   public boolean method_25402(class_11909 var1, boolean var2) {
      if (var1.method_74245() == 0) {
         ScreenPositionManager.getInstance().reset();
      }

      return class_4069.super.method_25402(var1, var2);
   }
}
