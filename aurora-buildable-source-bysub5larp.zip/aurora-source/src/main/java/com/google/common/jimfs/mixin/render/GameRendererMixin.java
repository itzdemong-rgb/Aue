package com.google.common.jimfs.mixin.render;

import com.google.common.jimfs.client.feature.helper.impl.render.IndicatorRenderer;
import com.google.common.jimfs.client.renderer.shader.ShaderFramebuffer;
import com.google.common.jimfs.event.EventDispatcher;
import com.google.common.jimfs.event.impl.render.RenderWorldEvent;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.opengl.GlStateManager;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4599;
import net.minecraft.class_751;
import net.minecraft.class_757;
import net.minecraft.class_761;
import net.minecraft.class_766;
import net.minecraft.class_9779;
import net.minecraft.class_9922;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({class_757.class})
public abstract class GameRendererMixin {
   @Final
   @Shadow
   private class_4599 field_20948;
   @Unique
   private boolean kW;
   @Mutable
   @Shadow
   @Final
   protected class_751 field_60579;
   @Mutable
   @Shadow
   @Final
   protected class_766 field_60580;

   @Inject(
      method = {"onResized"},
      at = {@At("HEAD")}
   )
   private void xR(int var1, int var2, CallbackInfo var3) {
      ShaderFramebuffer.a(var1, var2);
   }

   @WrapOperation(
      method = {"renderWorld"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/WorldRenderer;render(Lnet/minecraft/client/util/ObjectAllocator;Lnet/minecraft/client/render/RenderTickCounter;ZLnet/minecraft/client/render/Camera;Lorg/joml/Matrix4f;Lorg/joml/Matrix4f;Lorg/joml/Matrix4f;Lcom/mojang/blaze3d/buffers/GpuBufferSlice;Lorg/joml/Vector4f;Z)V"
      )}
   )
   private void dG(
      class_761 var1,
      class_9922 var2,
      class_9779 var3,
      boolean var4,
      class_4184 var5,
      Matrix4f var6,
      Matrix4f var7,
      Matrix4f var8,
      GpuBufferSlice var9,
      Vector4f var10,
      boolean var11,
      Operation var12,
      @Local(ordinal = 1) Matrix4f var13
   ) {
      var12.call(new Object[]{var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11});

      try {
         class_4587 var14 = new class_4587();
         var14.method_34425(var6);
         EventDispatcher.b(new RenderWorldEvent(this.field_20948.method_23000(), var14, var3.method_60637(false)));
         this.field_20948.method_23000().method_22993();
      } catch (Throwable var15) {
      }

      GlStateManager._depthMask(true);
      GlStateManager._disableBlend();
   }

   @Inject(
      method = {"render"},
      at = {@At("TAIL")}
   )
   private void hT(class_9779 var1, boolean var2, CallbackInfo var3) {
      IndicatorRenderer.recoveredField001 = var1.method_60637(var2);
   }
}
