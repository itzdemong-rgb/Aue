package com.google.common.jimfs.client.feature.module.property.impl;

import com.google.common.jimfs.client.Swag;
import com.google.common.jimfs.client.feature.module.property.Property;

public class KeybindProperty extends Property {
   private static boolean recoveredField045 = false;
   
   

   public KeybindProperty(CharSequence var1, int var2) {
      super(var1);
      this.a(var2);
   }

   public void a(Integer var1) {
      super.a(var1);
   }

   public String getDisplayName() {
      boolean var1 = false;
      if (this.getValue() != null && (Integer)this.getValue() == Integer.MAX_VALUE) {
         return "HOME + F9";
      } else if (this.getValue() != null && (Integer)this.getValue() != -1) {
         String var2 = Swag.getInstance().getBindRepository().b((Integer)this.getValue());
         return var2 != null ? var2 : "None";
      } else {
         return "None";
      }
   }

   @Override
   public void a(Object var1) {
      this.a((Integer)var1);
   }

   public static void b(boolean var0) {
      recoveredField045 = var0;
   }

   public static boolean recoveredMethod110() {
      return recoveredField045;
   }

   public static boolean d() {
      boolean var0 = recoveredMethod110();
      return !var0;
   }

}
