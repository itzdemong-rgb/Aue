package com.google.common.jimfs.recovered;

import com.google.common.jimfs.client.feature.module.Module;

public final class ModuleToggleEvent extends CancellableEvent {
   private final Module module;
   private final boolean recoveredField190;

   public ModuleToggleEvent(Module var1, boolean var2) {
      this.module = var1;
      this.recoveredField190 = var2;
   }
}
