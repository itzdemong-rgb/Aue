package com.google.common.jimfs.utility.render;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_124;
import net.minecraft.class_2583;
import net.minecraft.class_5224;

@Environment(EnvType.CLIENT)
public final class OrderedTextVisitor implements class_5224 {
   private final StringBuilder textBuilder = new StringBuilder();
   private class_124 currentStyle = null;

   public boolean accept(int var1, class_2583 var2, int var3) {
      if (var2.method_10984()) {
         this.textBuilder.append(class_124.field_1067);
         this.currentStyle = class_124.field_1067;
      }

      if (var2.method_10973() != null) {
         for (class_124 var7 : class_124.values()) {
            if (var7.method_543() && var7.method_532() == var2.method_10973().method_27716() && var7 != this.currentStyle) {
               this.textBuilder.append(var7);
               this.currentStyle = var7;
               break;
            }
         }
      }

      this.textBuilder.append(new String(Character.toChars(var3)));
      return true;
   }
}
