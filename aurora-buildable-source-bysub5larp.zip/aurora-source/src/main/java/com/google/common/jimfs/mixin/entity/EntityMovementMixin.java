package com.google.common.jimfs.mixin.entity;

import com.google.common.jimfs.client.Constants;
import com.google.common.jimfs.client.feature.helper.impl.player.rotation.RotationHelper;
import com.google.common.jimfs.event.EventDispatcher;
import com.google.common.jimfs.event.impl.game.player.movement.PostMoveEvent;
import com.google.common.jimfs.event.impl.game.player.movement.PreMoveEvent;
import com.google.common.jimfs.event.impl.game.player.movement.step.StepSuccessEvent;
import com.google.common.jimfs.m.ESPModule;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin({class_1297.class})
public abstract class EntityMovementMixin {
   @Shadow
   private class_1937 field_6002;

   private EntityMovementMixin() {
   }

   @Inject(
      method = {"setYaw"},
      at = {@At("HEAD")}
   )
   private void a(float var1, CallbackInfo var2) {
      this.g();
   }

   @Inject(
      method = {"setPitch"},
      at = {@At("HEAD")}
   )
   private void b(float var1, CallbackInfo var2) {
      this.g();
   }

   @Redirect(
      method = {"updateVelocity"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/entity/Entity;getYaw()F"
      )
   )
   private float c(class_1297 var1) {
      boolean var2 = Constants.MINECRAFT.field_1724 != null && (Object)this == Constants.MINECRAFT.field_1724;
      return var2 ? var1.method_36454() : var1.method_36454();
   }

   @Inject(
      method = {"updateVelocity"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void d(float var1, class_243 var2, CallbackInfo var3) {
      if ((Object)this == Constants.MINECRAFT.field_1724) {
         PreMoveEvent var4 = new PreMoveEvent(var1, var2);
         EventDispatcher.b(var4);
         if (var4.isCancelled()) {
            var3.cancel();
         }
      }
   }

   @Inject(
      method = {"updateVelocity"},
      at = {@At("TAIL")}
   )
   private void e(float var1, class_243 var2, CallbackInfo var3) {
      if ((Object)this == Constants.MINECRAFT.field_1724) {
         EventDispatcher.b(new PostMoveEvent(var1, var2));
      }
   }

   @Inject(
      method = {"adjustMovementForCollisions(Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/Vec3d;"},
      at = {@At(
         value = "RETURN",
         ordinal = 0
      )},
      cancellable = true
   )
   private void f(class_243 var1, CallbackInfoReturnable var2) {
      if ((Object)this == Constants.MINECRAFT.field_1724) {
         StepSuccessEvent var3 = new StepSuccessEvent(var1, (class_243)var2.getReturnValue());
         EventDispatcher.b(var3);
         var2.setReturnValue(var3.getPosition());
      }
   }

   @Unique
   private void g() {
      if (Constants.MINECRAFT.field_1724 != null && (Object)this == Constants.MINECRAFT.field_1724 && this.field_6002.method_8608()) {
         RotationHelper.getClientRotationHandler().clearInactiveRotation();
      }
   }

   @ModifyExpressionValue(
      method = {"move"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/entity/Entity;isLogicalSideForUpdatingMovement()Z"
      )}
   )
   private boolean h(boolean var1) {
      return (Object)this == Constants.MINECRAFT.field_1724 ? true : var1;
   }

   @Inject(
      method = {"isGlowing"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void i(CallbackInfoReturnable var1) {
      class_1297 var2 = (class_1297)(Object)this;
      if (ESPModule.recoveredMethod057(var2)) {
         var1.setReturnValue(true);
      }
   }

   @Inject(
      method = {"getTeamColorValue"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void j(CallbackInfoReturnable var1) {
      class_1297 var2 = (class_1297)(Object)this;
      if (ESPModule.recoveredMethod057(var2)) {
         var1.setReturnValue(ESPModule.getEntityColor(var2));
      }
   }
}
