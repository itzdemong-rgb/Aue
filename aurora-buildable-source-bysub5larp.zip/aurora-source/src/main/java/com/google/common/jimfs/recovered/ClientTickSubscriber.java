package com.google.common.jimfs.recovered;

import com.google.common.jimfs.event.EventDispatcher;
import com.google.common.jimfs.utility.misc.time.Stopwatch;

public final class ClientTickSubscriber implements ClientEventSubscriber {
   private final Stopwatch timer = new Stopwatch();
   private static ClientTickSubscriber instance;

   public static void initialize() {
      instance = new ClientTickSubscriber();
      EventDispatcher.a(instance);
   }
}
