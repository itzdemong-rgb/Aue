package com.google.common.jimfs.recovered;

import net.minecraft.class_639;

public interface ServerProfileMatcher {
   ServerProfile a(class_639 var1);
}
