package com.google.common.jimfs.recovered;

import net.minecraft.class_241;

public interface RotationInterpolator {
   class_241 b(class_241 var1, class_241 var2, float var3);
}
