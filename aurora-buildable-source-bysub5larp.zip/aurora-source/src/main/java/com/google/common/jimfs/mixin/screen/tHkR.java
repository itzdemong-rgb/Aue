package com.google.common.jimfs.mixin.screen;

import com.google.common.jimfs.client.Constants;
import com.google.common.jimfs.duck.HandledScreenAccess;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1263;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_332;
import net.minecraft.class_465;
import net.minecraft.class_476;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({class_465.class})
public abstract class tHkR implements HandledScreenAccess {
   @Shadow
   @Final
   protected class_1703 field_2797;
   @Shadow
   protected class_1735 field_2787;

   @Override
   public class_1735 jimfs$getFocusedSlot() {
      return this.field_2787;
   }

   @Inject(
      method = {"drawSlot"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/gui/DrawContext;drawStackOverlay(Lnet/minecraft/client/font/TextRenderer;Lnet/minecraft/item/ItemStack;IILjava/lang/String;)V"
      )}
   )
   private void kW(class_332 var1, class_1735 var2, int var3, int var4, CallbackInfo var5) {
      if (Constants.MINECRAFT.field_1755 instanceof class_476 var6) {
         if (this.field_2797 instanceof class_1707 var10) {
            if (Constants.MINECRAFT.field_1724.method_31548() != null && var2.field_7871 != Constants.MINECRAFT.field_1724.method_31548()) {
               if (var6.method_25440().getString().toLowerCase().contains("chest")) {
                  class_1799 var11 = var2.method_7677();
                  class_1263 var9 = var10.method_7629();
               }
            }
         }
      }
   }
}
