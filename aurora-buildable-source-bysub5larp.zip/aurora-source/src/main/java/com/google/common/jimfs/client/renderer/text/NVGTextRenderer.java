package com.google.common.jimfs.client.renderer.text;

import com.google.common.jimfs.client.Constants;
import com.google.common.jimfs.client.renderer.NVGRenderer;
import com.google.common.jimfs.utility.misc.system.IOUtility;
import com.google.common.jimfs.utility.render.ColorUtility;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.lwjgl.nanovg.NanoVG;

@Environment(EnvType.CLIENT)
public final class NVGTextRenderer {
   public static boolean recoveredField045;
   private final String fontName;
   private final ByteBuffer fontData;
   private static final int[] colorLookup = new int[]{
      0,
      170,
      43520,
      43690,
      11141120,
      11141290,
      16755200,
      11184810,
      5592405,
      5592575,
      5635925,
      5636095,
      16733525,
      16733695,
      16777045,
      16777215,
      0,
      42,
      10752,
      10794,
      2752512,
      2752554,
      2763264,
      2763306,
      1381653,
      1381695,
      1392405,
      1392447,
      4134165,
      4134207,
      4144917,
      4144959
   };
   private static final byte[] ASCII_GLYPH_LOOKUP = new byte[]{
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      0,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1
   };

   public static String a(String var0) {
      return var0 == null
         ? null
         : var0.replace('а', 'a')
            .replace('с', 'c')
            .replace('е', 'e')
            .replace('о', 'o')
            .replace('р', 'p')
            .replace('х', 'x')
            .replace('у', 'y')
            .replace('А', 'A')
            .replace('С', 'C')
            .replace('Е', 'E')
            .replace('О', 'O')
            .replace('Р', 'P')
            .replace('Х', 'X')
            .replace('У', 'Y')
            .replace('і', 'i')
            .replace('ѕ', 's')
            .replace('Т', 'T')
            .replace('М', 'M')
            .replace('B', 'B')
            .replace('Н', 'H')
            .replace('К', 'K')
            .replace('І', 'I')
            .replace('Ѕ', 'S');
   }

   private static char normalizeConfusable(char var0) {
      switch (var0) {
         case 'Ѕ':
            return 'S';
         case 'І':
            return 'I';
         case 'Ї':
         case 'Ј':
         case 'Љ':
         case 'Њ':
         case 'Ћ':
         case 'Ќ':
         case 'Ѝ':
         case 'Ў':
         case 'Џ':
         case 'Б':
         case 'В':
         case 'Г':
         case 'Д':
         case 'Ж':
         case 'З':
         case 'И':
         case 'Й':
         case 'Л':
         case 'П':
         case 'Ф':
         case 'Ц':
         case 'Ч':
         case 'Ш':
         case 'Щ':
         case 'Ъ':
         case 'Ы':
         case 'Ь':
         case 'Э':
         case 'Ю':
         case 'Я':
         case 'б':
         case 'в':
         case 'г':
         case 'д':
         case 'ж':
         case 'з':
         case 'и':
         case 'й':
         case 'к':
         case 'л':
         case 'м':
         case 'н':
         case 'п':
         case 'т':
         case 'ф':
         case 'ц':
         case 'ч':
         case 'ш':
         case 'щ':
         case 'ъ':
         case 'ы':
         case 'ь':
         case 'э':
         case 'ю':
         case 'я':
         case 'ѐ':
         case 'ё':
         case 'ђ':
         case 'ѓ':
         case 'є':
         default:
            return var0;
         case 'А':
            return 'A';
         case 'Е':
            return 'E';
         case 'К':
            return 'K';
         case 'М':
            return 'M';
         case 'Н':
            return 'H';
         case 'О':
            return 'O';
         case 'Р':
            return 'P';
         case 'С':
            return 'C';
         case 'Т':
            return 'T';
         case 'У':
            return 'Y';
         case 'Х':
            return 'X';
         case 'а':
            return 'a';
         case 'е':
            return 'e';
         case 'о':
            return 'o';
         case 'р':
            return 'p';
         case 'с':
            return 'c';
         case 'у':
            return 'y';
         case 'х':
            return 'x';
         case 'ѕ':
            return 's';
         case 'і':
            return 'i';
      }
   }

   public NVGTextRenderer(String var1, InputStream var2) {
      this.fontName = var1;
      this.fontData = IOUtility.a(var2, 524288);
      if (this.fontData != null) {
         NanoVG.nvgCreateFontMem(Constants.getNanoVGContext(), this.fontName, this.fontData, false);
      }
   }

   public float a(String var1, float var2, float var3, float var4, int var5) {
      var1 = a(var1);
      this.a(var1, var2 + 0.5F, var3 + 0.5F, var4, var5, true, 3);
      return this.a(var1, var2, var3, var4, var5, false, 3);
   }

   public float b(String var1, float var2, float var3, float var4, int var5) {
      var1 = a(var1);
      return this.a(var1, var2, var3, var4, var5, false, 3);
   }

   public float a(CharSequence var1, float var2, float var3, float var4, int var5) {
      return this.a(var1, var2, var3, var4, var5, false, 3);
   }

   public float a(CharSequence var1, float var2, float var3, float var4, int var5, boolean var6, int var7) {
      if (var1 != null && !recoveredField045) {
         NanoVG.nvgFontFace(Constants.getNanoVGContext(), this.fontName);
         NanoVG.nvgFontSize(Constants.getNanoVGContext(), var4);
         NanoVG.nvgTextAlign(Constants.getNanoVGContext(), var7);
         boolean var8 = false;
         boolean var9 = false;
         NVGRenderer.a(var6 ? ColorUtility.darkenColor(var5) : var5, NVGRenderer.primaryColor);
         NanoVG.nvgFillColor(Constants.getNanoVGContext(), NVGRenderer.primaryColor);

         for (int var10 = 0; var10 < var1.length(); var10++) {
            char var11 = normalizeConfusable(var1.charAt(var10));
            if (var11 == 167 && var1.length() > var10 + 1) {
               int var14 = this.getAsciiGlyphIndex(Character.toLowerCase(normalizeConfusable(var1.charAt(var10 + 1))));
               if (var14 >= 0) {
                  if (var14 < 16) {
                     NanoVG.nvgFontFace(Constants.getNanoVGContext(), this.fontName);
                     var9 = false;
                     var8 = false;
                     int var13 = colorLookup[var14];
                     if (var6) {
                        var13 = ColorUtility.darkenColor(var13);
                     }

                     NVGRenderer.a(ColorUtility.a(var13, var5 >> 24 & 0xFF), NVGRenderer.secondaryColor);
                     NanoVG.nvgFillColor(Constants.getNanoVGContext(), NVGRenderer.secondaryColor);
                  } else {
                     switch (var14) {
                        case 17:
                        case 20:
                           break;
                        case 18:
                           var9 = true;
                           break;
                        case 19:
                           var8 = true;
                           break;
                        default:
                           var9 = false;
                           var8 = false;
                           NanoVG.nvgFillColor(Constants.getNanoVGContext(), NVGRenderer.primaryColor);
                     }
                  }
               }

               var10++;
            } else {
               String var12 = String.valueOf(var11);
               this.a(var12, var2, var3, var4, var8, var9);
               var2 += NanoVG.nvgTextBounds(Constants.getNanoVGContext(), 0.0F, 0.0F, var12, (FloatBuffer)null);
            }
         }

         return var2;
      } else {
         return var2;
      }
   }

   public void a(String var1, float var2, float var3, float var4, int var5, int var6, boolean var7) {
      var1 = a(var1);
      if (!recoveredField045) {
         float var8 = 0.0F;

         for (int var9 = 0; var9 < var1.length(); var9++) {
            char var10 = var1.charAt(var9);
            String var11 = String.valueOf(var10);
            float var12 = this.a(var11, var4);
            int var13 = ColorUtility.b(10, var9 * 15, var5, var6);
            if (var7) {
               this.a(var11, var2 + var8, var3, var4, var13);
            } else {
               this.b(var11, var2 + var8, var3, var4, var13);
            }

            var8 += var12;
         }
      }
   }

   public void a(String var1, float var2, float var3, float var4, int var5, int var6) {
      this.a(var1, var2, var3, var4, var5, var6, true);
   }

   public float a(String var1, float var2, float var3, float var4, int var5, boolean var6, int var7) {
      var1 = a(var1);
      if (recoveredField045) {
         return var2;
      } else {
         NanoVG.nvgFontFace(Constants.getNanoVGContext(), this.fontName);
         NanoVG.nvgFontSize(Constants.getNanoVGContext(), var4);
         NanoVG.nvgTextAlign(Constants.getNanoVGContext(), var7);
         boolean var8 = false;
         boolean var9 = false;
         NVGRenderer.a(var6 ? ColorUtility.darkenColor(var5) : var5, NVGRenderer.primaryColor);
         NanoVG.nvgFillColor(Constants.getNanoVGContext(), NVGRenderer.primaryColor);
         StringBuilder var10 = new StringBuilder();

         for (int var11 = 0; var11 < var1.length(); var11++) {
            char var12 = var1.charAt(var11);
            if (var12 == 167 && var1.length() > var11 + 1) {
               if (var10.length() > 0) {
                  this.a(var10.toString(), var2, var3, var4, var8, var9);
                  var2 += NanoVG.nvgTextBounds(Constants.getNanoVGContext(), 0.0F, 0.0F, var10.toString(), (FloatBuffer)null);
                  var10.setLength(0);
               }

               int var13 = this.getAsciiGlyphIndex(Character.toLowerCase(var1.charAt(var11 + 1)));
               if (var13 >= 0) {
                  if (var13 < 16) {
                     NanoVG.nvgFontFace(Constants.getNanoVGContext(), this.fontName);
                     var9 = false;
                     var8 = false;
                     int var14 = colorLookup[var13];
                     if (var6) {
                        var14 = ColorUtility.darkenColor(var14);
                     }

                     NVGRenderer.a(ColorUtility.a(var14, var5 >> 24 & 0xFF), NVGRenderer.secondaryColor);
                     NanoVG.nvgFillColor(Constants.getNanoVGContext(), NVGRenderer.secondaryColor);
                  } else {
                     switch (var13) {
                        case 17:
                        case 20:
                           break;
                        case 18:
                           var9 = true;
                           break;
                        case 19:
                           var8 = true;
                           break;
                        default:
                           var9 = false;
                           var8 = false;
                           NanoVG.nvgFillColor(Constants.getNanoVGContext(), NVGRenderer.primaryColor);
                     }
                  }
               }

               var11++;
            } else {
               var10.append(var12);
            }
         }

         if (var10.length() > 0) {
            this.a(var10.toString(), var2, var3, var4, var8, var9);
            var2 += NanoVG.nvgTextBounds(Constants.getNanoVGContext(), 0.0F, 0.0F, var10.toString(), (FloatBuffer)null);
         }

         return var2;
      }
   }

   private int getAsciiGlyphIndex(char var1) {
      return var1 < 128 ? ASCII_GLYPH_LOOKUP[var1] : -1;
   }

   private void a(String var1, float var2, float var3, float var4, boolean var5, boolean var6) {
      NanoVG.nvgText(Constants.getNanoVGContext(), var2, var3, var1);
      float var7 = NanoVG.nvgTextBounds(Constants.getNanoVGContext(), 0.0F, 0.0F, var1, (FloatBuffer)null);
      if (var6) {
         float var8 = var3 - var4 * 0.25F;
         NanoVG.nvgBeginPath(Constants.getNanoVGContext());
         NanoVG.nvgMoveTo(Constants.getNanoVGContext(), var2, var8);
         NanoVG.nvgLineTo(Constants.getNanoVGContext(), var2 + var7, var8 + 0.5F);
         NanoVG.nvgFill(Constants.getNanoVGContext());
         NanoVG.nvgClosePath(Constants.getNanoVGContext());
      }

      if (var5) {
         NanoVG.nvgBeginPath(Constants.getNanoVGContext());
         NanoVG.nvgMoveTo(Constants.getNanoVGContext(), var2, var3);
         NanoVG.nvgLineTo(Constants.getNanoVGContext(), var2 + var7, var3 + 0.5F);
         NanoVG.nvgFill(Constants.getNanoVGContext());
         NanoVG.nvgClosePath(Constants.getNanoVGContext());
      }
   }

   public float a(String var1, float var2) {
      var1 = a(var1);
      NanoVG.nvgFontFace(Constants.getNanoVGContext(), this.fontName);
      NanoVG.nvgFontSize(Constants.getNanoVGContext(), var2);
      StringBuilder var3 = new StringBuilder();
      float var4 = 0.0F;
      int var5 = var1.length();

      for (int var6 = 0; var6 < var5; var6++) {
         char var7 = var1.charAt(var6);
         if (var7 == 167 && var6 < var5 - 1) {
            var6++;
         } else {
            var3.append(var7);
         }

         if ((var7 == 167 && var6 < var5 - 1 || var6 == var5 - 1) && var3.length() > 0) {
            var4 += NanoVG.nvgTextBounds(Constants.getNanoVGContext(), 0.0F, 0.0F, var3.toString(), (FloatBuffer)null);
            var3.setLength(0);
         }
      }

      return var4;
   }

   public float a(CharSequence var1, float var2) {
      if (var1 == null) {
         return 0.0F;
      } else {
         NanoVG.nvgFontFace(Constants.getNanoVGContext(), this.fontName);
         NanoVG.nvgFontSize(Constants.getNanoVGContext(), var2);
         float var3 = 0.0F;

         for (int var4 = 0; var4 < var1.length(); var4++) {
            char var5 = normalizeConfusable(var1.charAt(var4));
            if (var5 == 167 && var4 < var1.length() - 1) {
               var4++;
            } else {
               var3 += NanoVG.nvgTextBounds(Constants.getNanoVGContext(), 0.0F, 0.0F, String.valueOf(var5), (FloatBuffer)null);
            }
         }

         return var3;
      }
   }

   private static void initializePalette() {
      for (int var0 = 0; var0 < 32; var0++) {
         int var1 = (var0 >> 3 & 1) * 85;
         int var2 = (var0 >> 2 & 1) * 170 + var1;
         int var3 = (var0 >> 1 & 1) * 170 + var1;
         int var4 = (var0 & 1) * 170 + var1;
         if (var0 == 6) {
            var2 += 85;
         }

         if (var0 >= 16) {
            var2 /= 4;
            var3 /= 4;
            var4 /= 4;
         }

         colorLookup[var0] = (var2 & 0xFF) << 16 | (var3 & 0xFF) << 8 | var4 & 0xFF;
      }

      for (int var5 = 0; var5 < 128; var5++) {
         ASCII_GLYPH_LOOKUP[var5] = -1;
      }

      for (int var6 = 0; var6 < "0123456789abcdefklmnor".length(); var6++) {
         char var7 = "0123456789abcdefklmnor".charAt(var6);
         ASCII_GLYPH_LOOKUP[var7] = (byte)var6;
         ASCII_GLYPH_LOOKUP[Character.toLowerCase(var7)] = (byte)var6;
      }
   }

   static {
      initializePalette();
   }
}
