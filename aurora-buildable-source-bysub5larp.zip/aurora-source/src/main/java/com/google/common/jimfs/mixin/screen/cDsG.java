package com.google.common.jimfs.mixin.screen;

import com.google.common.jimfs.client.Constants;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1309;
import net.minecraft.class_332;
import net.minecraft.class_490;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({class_490.class})
public final class cDsG {
   private cDsG() {
   }

   @Inject(
      method = {"drawEntity(Lnet/minecraft/client/gui/DrawContext;IIIIIFFFLnet/minecraft/entity/LivingEntity;)V"},
      at = {@At("HEAD")}
   )
   private static void kW(
      class_332 var0, int var1, int var2, int var3, int var4, int var5, float var6, float var7, float var8, class_1309 var9, CallbackInfo var10
   ) {
      if (Constants.MINECRAFT.field_1724 != null && var9 == Constants.MINECRAFT.field_1724) {
      }
   }

   @Inject(
      method = {"drawEntity(Lnet/minecraft/client/gui/DrawContext;IIIIIFFFLnet/minecraft/entity/LivingEntity;)V"},
      at = {@At("TAIL")}
   )
   private static void xR(
      class_332 var0, int var1, int var2, int var3, int var4, int var5, float var6, float var7, float var8, class_1309 var9, CallbackInfo var10
   ) {
      if (Constants.MINECRAFT.field_1724 != null && var9 == Constants.MINECRAFT.field_1724) {
      }
   }
}
