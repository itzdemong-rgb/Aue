package com.google.common.jimfs.recovered;

import com.google.common.jimfs.client.Constants;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_268;
import net.minecraft.class_640;

public final class CubeCraftProfile extends ServerProfile {

   public CubeCraftProfile() {
      super("Cubecraft");
   }

   @Override
   public boolean b(class_1309 var1) {
      boolean var2 = true;
      if (!(var1 instanceof class_1657 var3)) {
         return true;
      } else {
         class_640 var4 = Constants.MINECRAFT.method_1562().method_2871(var3.method_5667());
         if (var4 != null && var4.method_2966() != null) {
            class_268 var5 = var4.method_2955();
            return var5 != null && !var5.method_1197().equals(var3.method_5477().getString());
         } else {
            return false;
         }
      }
   }

}
