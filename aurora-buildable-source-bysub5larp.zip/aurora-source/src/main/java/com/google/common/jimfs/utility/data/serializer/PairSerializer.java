package com.google.common.jimfs.utility.data.serializer;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import com.ibm.icu.impl.Pair;
import java.lang.reflect.Type;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class PairSerializer implements JsonDeserializer<Pair>, JsonSerializer<Pair> {
   public JsonElement serialize(Pair var1, Type var2, JsonSerializationContext var3) {
      JsonObject var4 = new JsonObject();
      var4.addProperty("x", (Number)var1.first);
      var4.addProperty("y", (Number)var1.second);
      return var4;
   }

   public Pair deserialize(JsonElement var1, Type var2, JsonDeserializationContext var3) throws JsonParseException {
      JsonObject var4 = var1.getAsJsonObject();
      return Pair.of(var4.get("x").getAsFloat(), var4.get("y").getAsFloat());
   }

}
