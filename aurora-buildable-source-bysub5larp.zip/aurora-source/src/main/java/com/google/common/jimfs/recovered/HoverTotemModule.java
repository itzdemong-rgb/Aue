package com.google.common.jimfs.recovered;

import com.google.common.jimfs.client.Constants;
import com.google.common.jimfs.client.feature.module.Module;
import com.google.common.jimfs.client.feature.module.ModuleCategory;
import com.google.common.jimfs.client.feature.module.property.Property;
import com.google.common.jimfs.client.feature.module.property.impl.bool.BooleanProperty;
import com.google.common.jimfs.client.feature.module.property.impl.number.NumberProperty;
import com.google.common.jimfs.duck.HandledScreenAccess;
import com.google.common.jimfs.event.impl.render.PreRenderEvent;
import com.google.common.jimfs.event.subscriber.Subscribe;
import com.google.common.jimfs.utility.misc.StringObfuscation;
import j2cc.Nativeify;
import net.minecraft.class_1713;
import net.minecraft.class_1723;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_490;

@Nativeify
public class HoverTotemModule extends Module {
   private final NumberProperty m = new NumberProperty(StringObfuscation.a("Delay"), 0.0, 0.0, 20.0, 1.0);
   private final BooleanProperty o = new BooleanProperty(StringObfuscation.a("Hotbar"), true);
   private final NumberProperty p = new NumberProperty(StringObfuscation.a("Slot"), 1.0, 1.0, 9.0, 1.0);
   private final BooleanProperty q = new BooleanProperty(StringObfuscation.a("Magnetic Mouse"), true);
   private int r = 0;
   private long s = 0L;
   
   
   private static final long u = 50L;

   public HoverTotemModule() {
      super(StringObfuscation.a("Hover Totem"), "", ModuleCategory.COMBAT);
      this.b(new Property[]{this.m, this.o, this.p, this.q});
   }

   @Override
   protected void g() {
      super.g();
      this.s = 0L;
   }

   @Override
   protected void h() {
      this.s = 0L;
      super.h();
   }

   @Subscribe
   public void b(PreRenderEvent var1) {
      boolean var2 = true;
      if (this.isEnabled() && Constants.MINECRAFT.field_1724 != null) {
         if (Constants.MINECRAFT.field_1755 instanceof class_490 var3 && var3.method_17577() != null) {
            class_1735 var12 = ((HandledScreenAccess)var3).jimfs$getFocusedSlot();
            if (var12 != null && var12.method_7681() && var12.field_7874 >= 9 && var12.field_7874 < 45) {
               int var5 = var12.field_7874;
               int var6 = 36 + ((Double)this.p.getValue()).intValue() - 1;
               if (var12.method_7677().method_31574(class_1802.field_8288)) {
                  long var7 = (long)((Double)this.m.getValue()).intValue() * u;
                  int var9 = 0;

                  for (int var10 = 0; var10 < Constants.MINECRAFT.field_1724.method_31548().method_5439(); var10++) {
                     class_1799 var11 = Constants.MINECRAFT.field_1724.method_31548().method_5438(var10);
                     if (var11.method_31574(class_1802.field_8288)) {
                        var9 += var11.method_7947();
                     }
                  }

                  boolean var13 = Constants.MINECRAFT.field_1724.method_6079().method_31574(class_1802.field_8288);
                  if (var9 <= 1 && !var13) {
                     if (System.currentTimeMillis() - this.s < var7) {
                        return;
                     }

                     Constants.MINECRAFT
                        .field_1761
                        .method_2906(((class_1723)var3.method_17577()).field_7763, var5, 40, class_1713.field_7791, Constants.MINECRAFT.field_1724);
                     this.s = System.currentTimeMillis();
                  } else if (this.o.isEnabled()
                     && !Constants.MINECRAFT.field_1724.method_31548().method_5438(var6 - 36).method_31574(class_1802.field_8288)) {
                     if (System.currentTimeMillis() - this.s < var7) {
                        return;
                     }

                     Constants.MINECRAFT
                        .field_1761
                        .method_2906(
                           ((class_1723)var3.method_17577()).field_7763, var5, var6 - 36, class_1713.field_7791, Constants.MINECRAFT.field_1724
                        );
                     this.s = System.currentTimeMillis();
                  } else if (!var13) {
                     if (System.currentTimeMillis() - this.s < var7) {
                        return;
                     }

                     Constants.MINECRAFT
                        .field_1761
                        .method_2906(((class_1723)var3.method_17577()).field_7763, var5, 40, class_1713.field_7791, Constants.MINECRAFT.field_1724);
                     this.s = System.currentTimeMillis();
                  }
               }
            }
         }
      }
   }

   @Override
   public boolean e() {
      return this.isEnabled();
   }

}
