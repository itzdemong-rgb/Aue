package com.google.common.jimfs.utility.render;

import com.google.common.jimfs.m.ClickGUIModule;
import com.google.common.jimfs.utility.misc.math.MathUtility;
import com.ibm.icu.impl.Pair;
import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class ColorUtility {
   private ColorUtility() {
   }

   public static Pair getThemeColors() {
      return ClickGUIModule.accentColor != null
         ? Pair.of((Integer)ClickGUIModule.accentColor.getValue(), (Integer)ClickGUIModule.secondaryColor.getValue())
         : Pair.of(Color.BLACK.getRGB(), Color.BLACK.getRGB());
   }

   public static int darkenColor(int var0) {
      return (var0 & 16579836) >> 2 | var0 & 0xFF000000;
   }

   public static int[] getColorChannels(int var0) {
      int var1 = var0 >> 16 & 0xFF;
      int var2 = var0 >> 8 & 0xFF;
      int var3 = var0 & 0xFF;
      int var4 = var0 >> 24 & 0xFF;
      return new int[]{var1, var2, var3, var4};
   }

   public static int a(int var0, int var1, int var2, int var3) {
      return var3 << 24 | var0 << 16 | var1 << 8 | var2;
   }

   public static int a(int var0, float var1) {
      var1 = Math.min(1.0F, Math.max(0.0F, var1));
      int[] var2 = getColorChannels(var0);
      return a(var2[0], var2[1], var2[2], (int)(var1 * 255.0F));
   }

   public static int a(int var0, int var1) {
      var1 = Math.min(255, Math.max(0, var1));
      int[] var2 = getColorChannels(var0);
      return a(var2[0], var2[1], var2[2], var1);
   }

   public static int a(int var0, int var1, float var2) {
      var2 = Math.min(1.0F, Math.max(0.0F, var2));
      int[] var3 = getColorChannels(var0);
      int[] var4 = getColorChannels(var1);
      int var5 = (int)MathUtility.a((float)var3[0], (float)var4[0], var2);
      int var6 = (int)MathUtility.a((float)var3[1], (float)var4[1], var2);
      int var7 = (int)MathUtility.a((float)var3[2], (float)var4[2], var2);
      int var8 = (int)MathUtility.a((float)var3[3], (float)var4[3], var2);
      return a(var5, var6, var7, var8);
   }

   public static int b(int var0, int var1, int var2, int var3) {
      int var4 = (int)((System.currentTimeMillis() / (long)var0 - (long)var1) % 360L);
      var4 = (var4 >= 180 ? 360 - var4 : var4) * 2;
      return a(var2, var3, (float)var4 / 360.0F);
   }
}
