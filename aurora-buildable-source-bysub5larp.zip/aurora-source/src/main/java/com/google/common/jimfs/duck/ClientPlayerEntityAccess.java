package com.google.common.jimfs.duck;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;

@Environment(EnvType.CLIENT)
public interface ClientPlayerEntityAccess {
   void jimfs$swingHandClientside(class_1268 var1);

   void jimfs$swingHandServerside(class_1268 var1);
}
