package com.google.common.jimfs.recovered;

import com.google.common.jimfs.event.subscriber.IEventSubscriber;
import java.lang.reflect.Method;

public final class EventListenerBinding {
   private final int priority;
   private final Method subscriberMethod;
   private final IEventSubscriber subscriber;

   public EventListenerBinding(int var1, Method var2, IEventSubscriber var3) {
      this.priority = -var1;
      this.subscriberMethod = var2;
      this.subscriber = var3;
   }

   public int getPriority() {
      return this.priority;
   }

   public boolean b(Object var1) {
      boolean var2 = this.subscriber.e();
      if (!var2) {
         return false;
      } else {
         try {
            this.subscriberMethod.invoke(this.subscriber, var1);
         } catch (Throwable var4) {
            var4.printStackTrace();
            throw new RuntimeException("Error invoking event", var4);
         }

         if (var1 instanceof CancellableEvent var3 && var3.isCancelled()) {
            return true;
         }

         return false;
      }
   }

}
