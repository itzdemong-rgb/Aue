package com.google.common.jimfs.mixin.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_2940;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Environment(EnvType.CLIENT)
@Mixin({class_1309.class})
public interface LivingEntityAccessor {
   @Accessor("LIVING_FLAGS")
   static class_2940 getLivingFlags() {
      throw new AssertionError();
   }

   @Invoker("travelMidAir")
   void b(class_243 var1);

   @Invoker("getJumpVelocity")
   float invokeGetJumpVelocity();

   @Accessor("jumpingCooldown")
   void d(int var1);
}
