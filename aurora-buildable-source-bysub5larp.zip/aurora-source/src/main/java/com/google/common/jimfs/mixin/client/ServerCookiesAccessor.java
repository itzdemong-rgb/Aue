package com.google.common.jimfs.mixin.client;

import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_8673;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Environment(EnvType.CLIENT)
@Mixin({class_8673.class})
public interface ServerCookiesAccessor {
   @Accessor("serverCookies")
   Map getServerCookies();
}
