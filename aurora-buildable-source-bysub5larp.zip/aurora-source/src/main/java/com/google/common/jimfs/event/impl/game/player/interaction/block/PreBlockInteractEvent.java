package com.google.common.jimfs.event.impl.game.player.interaction.block;

public final class PreBlockInteractEvent {
}
