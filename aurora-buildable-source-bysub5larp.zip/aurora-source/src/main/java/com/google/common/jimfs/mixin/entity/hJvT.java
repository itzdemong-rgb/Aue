package com.google.common.jimfs.mixin.entity;

import com.google.common.jimfs.client.Swag;
import com.google.common.jimfs.client.feature.helper.impl.ClientSyncHelper;
import com.google.common.jimfs.client.feature.helper.impl.render.IndicatorRenderer;
import com.google.common.jimfs.client.feature.helper.impl.render.IndicatorStateExt;
import com.google.common.jimfs.client.feature.module.Module;
import com.google.common.jimfs.m.NameTagsModule;
import com.google.common.jimfs.m.ClickGUIModule;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10017;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_4587;
import net.minecraft.class_897;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({class_897.class})
public abstract class hJvT {
   @ModifyReturnValue(
      method = {"hasLabel*"},
      at = {@At("RETURN")}
   )
   private boolean a(boolean var1) {
      return ((NameTagsModule)Swag.getInstance().getModuleRepository().a(NameTagsModule.class)).isEnabled() ? false : var1;
   }

   @Inject(
      method = {"updateRenderState*"},
      at = {@At("TAIL")}
   )
   private void b(class_1297 var1, class_10017 var2, float var3, CallbackInfo var4) {
      Module var5 = Swag.getInstance().getModuleRepository().a(ClickGUIModule.class);
      if (var5 != null && ((ClickGUIModule)var5).clientIndicator.isEnabled()) {
         if (var1 instanceof class_1309 var6 && ClientSyncHelper.getInstance().a(var6.method_5477().getString())) {
            ((IndicatorStateExt)var2).speedclient$setIndicator(true);
            ((IndicatorStateExt)var2).speedclient$setEntity(var1);
            return;
         }

         ((IndicatorStateExt)var2).speedclient$setIndicator(false);
      }
   }

   @Inject(
      method = {"renderLabelIfPresent*"},
      at = {@At("TAIL")}
   )
   private void c(class_10017 var1, class_4587 var2, class_11659 var3, class_12075 var4, CallbackInfo var5) {
      if (((IndicatorStateExt)var1).speedclient$hasIndicator()) {
         class_1297 var6 = ((IndicatorStateExt)var1).speedclient$getEntity();
         if (var6 != null) {
            IndicatorRenderer.trackEntity(var6);
         }
      }
   }
}
