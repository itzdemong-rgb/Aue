package com.google.common.jimfs.recovered;

import com.google.common.jimfs.client.Constants;
import com.google.common.jimfs.client.feature.helper.impl.player.packet.blockage.impl.InboundNetworkBlockage;
import com.google.common.jimfs.client.feature.helper.impl.player.packet.blockage.impl.OutboundNetworkBlockage;
import com.google.common.jimfs.client.feature.module.Module;
import com.google.common.jimfs.client.feature.module.ModuleCategory;
import com.google.common.jimfs.client.feature.module.property.Property;
import com.google.common.jimfs.client.feature.module.property.impl.KeybindProperty;
import com.google.common.jimfs.client.feature.module.property.impl.bool.BooleanProperty;
import com.google.common.jimfs.client.feature.module.property.impl.number.BoundedNumberProperty;
import com.google.common.jimfs.client.feature.module.property.impl.number.NumberProperty;
import com.google.common.jimfs.event.impl.game.PreGameTickEvent;
import com.google.common.jimfs.event.subscriber.Subscribe;
import com.google.common.jimfs.mixin.client.ClientWorldPendingUpdateAccessor;
import com.google.common.jimfs.utility.player.PlayerUtility;
import j2cc.Nativeify;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2885;
import net.minecraft.class_3965;
import net.minecraft.class_7202;
import net.minecraft.class_239.class_240;

@Nativeify
public class DoubleAnchorModule extends Module {
   private final KeybindProperty m;
   private final BooleanProperty o;
   private final BoundedNumberProperty p;
   private final BoundedNumberProperty q;
   private final BoundedNumberProperty r;
   private final NumberProperty s;
   private final BooleanProperty t;
   private final BooleanProperty u;
   private long v = 0L;
   private int w = 0;
   private int x = 0;
   private boolean y = false;
   private class_1657 z = null;
   private boolean A = false;
   
   

   public DoubleAnchorModule() {
      super("Double Anchor", "", ModuleCategory.CRYSTAL);
      this.m = new KeybindProperty("Activate Key", 2);
      this.o = new BooleanProperty("Damage Tick", true);
      this.p = new BoundedNumberProperty("Switch Delay", " ms", 0.0, 50.0, 0.0, 100.0, 5.0);
      this.q = new BoundedNumberProperty("Charge Delay", " ms", 0.0, 50.0, 0.0, 100.0, 5.0);
      this.r = new BoundedNumberProperty("Explode Delay", " ms", 0.0, 50.0, 0.0, 100.0, 5.0);
      this.s = new NumberProperty("Totem Slot", 9.0, 1.0, 9.0, 1.0);
      this.t = new BooleanProperty("Click Sim", false);
      this.u = new BooleanProperty("Work With Anything", false);
      this.b(new Property[]{this.m, this.o, this.p, this.q, this.r, this.s, this.t, this.u});
   }

   @Override
   protected void g() {
      super.g();
      this.n();
   }

   @Override
   protected void h() {
      this.n();
      super.h();
   }

   private void n() {
      this.v = 0L;
      this.w = 0;
      this.x = 0;
      this.y = false;
      this.z = null;
      this.A = false;
   }

   @Subscribe
   public void b(PreGameTickEvent var1) {
      boolean var2 = false;
      if (Constants.MINECRAFT.field_1755 == null) {
         if (Constants.MINECRAFT.field_1724 != null && Constants.MINECRAFT.field_1687 != null) {
            if (this.q()) {
               if (this.y || this.r()) {
                  if (!(Constants.MINECRAFT.field_1765 instanceof class_3965 var3) || var3.method_17783() == class_240.field_1333) {
                     this.y = false;
                     this.n();
                     return;
                  }

                  if (Constants.MINECRAFT.field_1687.method_8320(var3.method_17777()).method_27852(class_2246.field_10124)) {
                     this.y = false;
                     this.n();
                  } else {
                     if (this.A && this.o.isEnabled()) {
                        if (this.z == null) {
                           this.z = this.o();
                        }

                        if (this.z != null && this.z.field_6235 > 0) {
                           return;
                        }

                        this.A = false;
                        this.v = System.currentTimeMillis();
                        this.x = this.b(this.w);
                     }

                     if (System.currentTimeMillis() - this.v >= (long)this.x) {
                        Object var41 = null;
                        Object var5 = null;
                        switch (this.w) {
                           case 0:
                              this.b(class_1802.field_23141);
                              this.v = System.currentTimeMillis();
                              this.x = this.b(1);
                              break;
                           case 1:
                              var41 = OutboundNetworkBlockage.getInstance().register();
                              var5 = InboundNetworkBlockage.getInstance().register();

                              try {
                                 if (this.t.isEnabled()) {
                                    KeyInputHelper.d(1);
                                 } else {
                                    Constants.MINECRAFT.method_1562().method_52787(new class_2885(class_1268.field_5808, var3, this.s()));
                                 }
                              } finally {
                                 OutboundNetworkBlockage.getInstance().b((PacketDelayRegistration)var41);
                                 InboundNetworkBlockage.getInstance().b((PacketDelayRegistration)var5);
                              }

                              this.v = System.currentTimeMillis();
                              this.x = this.b(2);
                              break;
                           case 2:
                              this.b(class_1802.field_8801);
                              this.v = System.currentTimeMillis();
                              this.x = this.b(3);
                              break;
                           case 3:
                              var41 = OutboundNetworkBlockage.getInstance().register();
                              var5 = InboundNetworkBlockage.getInstance().register();

                              try {
                                 if (this.t.isEnabled()) {
                                    KeyInputHelper.d(1);
                                 } else {
                                    Constants.MINECRAFT.method_1562().method_52787(new class_2885(class_1268.field_5808, var3, this.s()));
                                 }
                              } finally {
                                 OutboundNetworkBlockage.getInstance().b((PacketDelayRegistration)var41);
                                 InboundNetworkBlockage.getInstance().b((PacketDelayRegistration)var5);
                              }

                              this.v = System.currentTimeMillis();
                              this.x = this.b(4);
                              break;
                           case 4:
                              this.b(class_1802.field_23141);
                              this.v = System.currentTimeMillis();
                              this.x = this.b(5);
                              break;
                           case 5:
                              var41 = OutboundNetworkBlockage.getInstance().register();
                              var5 = InboundNetworkBlockage.getInstance().register();

                              try {
                                 if (this.t.isEnabled()) {
                                    KeyInputHelper.d(1);
                                 } else {
                                    Constants.MINECRAFT.method_1562().method_52787(new class_2885(class_1268.field_5808, var3, this.s()));
                                    Constants.MINECRAFT.method_1562().method_52787(new class_2885(class_1268.field_5808, var3, this.s()));
                                 }
                              } finally {
                                 OutboundNetworkBlockage.getInstance().b((PacketDelayRegistration)var41);
                                 InboundNetworkBlockage.getInstance().b((PacketDelayRegistration)var5);
                              }

                              if (this.o.isEnabled()) {
                                 this.z = this.o();
                              }

                              this.v = System.currentTimeMillis();
                              this.x = this.b(6);
                              break;
                           case 6:
                              this.b(class_1802.field_8801);
                              this.v = System.currentTimeMillis();
                              this.x = this.b(7);
                              break;
                           case 7:
                              var41 = OutboundNetworkBlockage.getInstance().register();
                              var5 = InboundNetworkBlockage.getInstance().register();

                              try {
                                 if (this.t.isEnabled()) {
                                    KeyInputHelper.d(1);
                                 } else {
                                    Constants.MINECRAFT.method_1562().method_52787(new class_2885(class_1268.field_5808, var3, this.s()));
                                 }
                              } finally {
                                 OutboundNetworkBlockage.getInstance().b((PacketDelayRegistration)var41);
                                 InboundNetworkBlockage.getInstance().b((PacketDelayRegistration)var5);
                              }

                              this.v = System.currentTimeMillis();
                              this.x = this.b(8);
                              break;
                           case 8:
                              if (this.o.isEnabled() && this.z != null && this.z.field_6235 > 0) {
                                 this.A = true;
                                 return;
                              }

                              Constants.MINECRAFT.field_1724.method_31548().method_61496(((Double)this.s.getValue()).intValue() - 1);
                              this.v = System.currentTimeMillis();
                              this.x = this.b(9);
                              break;
                           case 9:
                              var41 = OutboundNetworkBlockage.getInstance().register();
                              var5 = InboundNetworkBlockage.getInstance().register();

                              try {
                                 if (this.t.isEnabled()) {
                                    KeyInputHelper.d(1);
                                 } else {
                                    Constants.MINECRAFT.method_1562().method_52787(new class_2885(class_1268.field_5808, var3, this.s()));
                                 }
                              } finally {
                                 OutboundNetworkBlockage.getInstance().b((PacketDelayRegistration)var41);
                                 InboundNetworkBlockage.getInstance().b((PacketDelayRegistration)var5);
                              }

                              this.v = System.currentTimeMillis();
                              break;
                           case 10:
                              this.y = false;
                              this.w = 0;
                              this.n();
                              return;
                        }

                        this.w++;
                     }
                  }
               }
            }
         }
      }
   }

   private class_1657 o() {
      boolean var1 = true;
      if (Constants.MINECRAFT.field_1687 != null && Constants.MINECRAFT.field_1724 != null) {
         class_1657 var2 = null;
         double var3 = Double.MAX_VALUE;

         for (class_1657 var6 : Constants.MINECRAFT.field_1687.method_18456()) {
            if (var6 != Constants.MINECRAFT.field_1724 && var6.method_5805() && !(var6.method_6032() <= 0.0F)) {
               double var7 = Constants.MINECRAFT.field_1724.method_5858(var6);
               if (var7 < var3 && var7 < 36.0) {
                  var3 = var7;
                  var2 = var6;
               }
            }
         }

         return var2;
      } else {
         return null;
      }
   }

   private int b(int var1) {
      boolean var2 = false;

      return switch (var1) {
         case 0, 2, 4, 6, 8 -> this.p.getRandomValue().intValue();
         case 1, 3, 5, 7 -> this.q.getRandomValue().intValue();
         case 9 -> this.r.getRandomValue().intValue();
         default -> this.p.getRandomValue().intValue();
      };
   }

   private boolean p() {
      int var2 = (Integer)this.m.getValue();
      boolean var1 = true;
      return var2 == 0 || var2 == 1 || var2 == 0 || var2 == 1;
   }

   private boolean q() {
      boolean var1 = true;
      if (!this.u.isEnabled() && this.p()) {
         boolean var2 = false;
         boolean var3 = false;

         for (int var4 = 0; var4 < 9; var4++) {
            class_1799 var5 = (class_1799)Constants.MINECRAFT.field_1724.method_31548().method_67533().get(var4);
            if (var5.method_31574(class_1802.field_23141)) {
               var2 = true;
            }

            if (var5.method_31574(class_1802.field_8801)) {
               var3 = true;
            }
         }

         return var2 && var3;
      } else {
         return true;
      }
   }

   private boolean r() {
      int var2 = (Integer)this.m.getValue();
      boolean var1 = true;
      boolean var3;
      if (var2 >= 0 && var2 <= 7) {
         var3 = PlayerUtility.c(var2);
      } else {
         var3 = PlayerUtility.isMouseButtonPressed(var2);
      }

      if (!var3) {
         this.n();
         return false;
      } else {
         this.y = true;
         this.v = System.currentTimeMillis();
         this.x = this.b(0);
         return true;
      }
   }

   private void b(class_1792 var1) {
      boolean var2 = true;
      if (Constants.MINECRAFT.field_1724 != null) {
         for (int var3 = 0; var3 < 9; var3++) {
            if (((class_1799)Constants.MINECRAFT.field_1724.method_31548().method_67533().get(var3)).method_31574(var1)) {
               Constants.MINECRAFT.field_1724.method_31548().method_61496(var3);
               return;
            }
         }
      }
   }

   private int s() {
      boolean var1 = false;
      if (Constants.MINECRAFT.field_1687 != null) {
         class_7202 var2 = ((ClientWorldPendingUpdateAccessor)Constants.MINECRAFT.field_1687).getPendingUpdateManager();
         var2.method_41937();
         return var2.method_41942();
      } else {
         return 0;
      }
   }

   public static CharSequence c(final String var0, final int var1) {
      return new CharSequence() {
         @Override
         public int length() {
            return var0.length();
         }

         @Override
         public char charAt(int var1x) {
            return (char)(var0.charAt(var1x) ^ var1);
         }

         @Override
         public CharSequence subSequence(int var1x, int var2) {
            return DoubleAnchorModule.c(var0.substring(var1x, var2), var1);
         }

         @Override
         public String toString() {
            char[] var2 = new char[this.length()];
            int var3 = 0;

            for (boolean var1x = true; var3 < var2.length; var3++) {
               var2[var3] = this.charAt(var3);
            }

            return new String(var2);
         }
      };
   }

}
