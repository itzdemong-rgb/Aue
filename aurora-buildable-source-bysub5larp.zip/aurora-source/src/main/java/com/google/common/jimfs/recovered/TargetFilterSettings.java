package com.google.common.jimfs.recovered;

public final class TargetFilterSettings {
   private String recoveredField091 = "ALL";
   private static TargetFilterSettings instance;

   private TargetFilterSettings() {
   }

   public static void initialize() {
      instance = new TargetFilterSettings();
   }
}
