package com.google.common.jimfs.mixin.client;

import com.google.common.jimfs.client.Swag;
import com.google.common.jimfs.client.feature.helper.impl.player.mouse.MouseButton;
import com.google.common.jimfs.client.feature.helper.impl.player.mouse.MouseHelper;
import com.google.common.jimfs.client.feature.helper.impl.player.slot.SlotHelper;
import com.google.common.jimfs.event.EventDispatcher;
import com.google.common.jimfs.event.impl.game.JoinWorldEvent;
import com.google.common.jimfs.event.impl.game.PostGameTickEvent;
import com.google.common.jimfs.event.impl.game.PreGameTickEvent;
import com.google.common.jimfs.event.impl.game.ScheduledExecutablesEvent;
import com.google.common.jimfs.event.impl.game.input.MouseHandleInputEvent;
import com.google.common.jimfs.event.impl.game.input.PostHandleInputEvent;
import com.google.common.jimfs.event.impl.game.input.PreHandleInputEvent;
import com.google.common.jimfs.event.impl.game.player.interaction.BvKxLw;
import com.google.common.jimfs.event.impl.game.player.interaction.ItemUseEvent;
import com.google.common.jimfs.event.impl.game.player.interaction.block.BlockPlacedEvent;
import com.google.common.jimfs.event.impl.game.server.ServerDisconnectEvent;
import com.google.common.jimfs.event.impl.render.PreRenderEvent;
import com.google.common.jimfs.event.impl.render.ResolutionChangeEvent;
import com.google.common.jimfs.utility.player.RotationUtility;
import com.llamalad7.mixinextras.sugar.Local;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1661;
import net.minecraft.class_1747;
import net.minecraft.class_239;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_437;
import net.minecraft.class_542;
import net.minecraft.class_638;
import net.minecraft.class_746;
import net.minecraft.class_759;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.Slice;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin({class_310.class})
public abstract class MinecraftClientMixin {
   @Shadow
   protected int field_1771;
   @Shadow
   private int field_1752;
   @Shadow
   @Nullable
   public class_239 field_1765;
   @Shadow
   @Nullable
   public class_746 field_1724;
   @Shadow
   @Nullable
   public class_437 field_1755;

   @Shadow
   protected abstract boolean method_1536();

   private MinecraftClientMixin() {
   }

   @Inject(
      method = {"<init>"},
      at = {@At("TAIL")}
   )
   private void a(class_542 var1, CallbackInfo var2) {
      Swag.getInstance().initialize();
   }

   @Inject(
      method = {"handleInputEvents"},
      at = {@At("HEAD")}
   )
   private void b(CallbackInfo var1) {
      EventDispatcher.b(new PreHandleInputEvent());
   }

   @Inject(
      method = {"handleInputEvents"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/network/ClientPlayerEntity;isUsingItem()Z",
         ordinal = 0
      )}
   )
   private void c(CallbackInfo var1) {
      EventDispatcher.b(new MouseHandleInputEvent());
   }

   @Inject(
      method = {"handleInputEvents"},
      at = {@At("TAIL")}
   )
   private void d(CallbackInfo var1) {
      MouseHelper.getInstance().tick();
      EventDispatcher.b(new PostHandleInputEvent());
   }

   @Redirect(
      method = {"handleInputEvents"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/entity/player/PlayerInventory;setSelectedSlot(I)V"
      )
   )
   private void e(class_1661 var1, int var2) {
      SlotHelper var3 = SlotHelper.getInstance();
      if (var3.isSlotOverrideActive()) {
         if (var3.getSlotMode() != SlotHelper.a.NONE) {
            var3.setSelectedSlot(var2);
         }
      } else {
         var1.method_61496(var2);
      }
   }

   @Inject(
      method = {"handleInputEvents"},
      at = {@At(
         value = "FIELD",
         target = "Lnet/minecraft/client/option/GameOptions;socialInteractionsKey:Lnet/minecraft/client/option/KeyBinding;",
         shift = Shift.BEFORE
      )}
   )
   private void f(CallbackInfo var1) {
      SlotHelper.getInstance().a(false, false);
   }

   @Redirect(
      method = {"handleInputEvents"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/option/KeyBinding;isPressed()Z"
      )
   )
   private boolean g(class_304 var1) {
      MouseButton var2 = MouseHelper.a(var1);
      return var2 != null ? var2.isPressed() : var1.method_1434();
   }

   @Redirect(
      method = {"handleInputEvents"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/option/KeyBinding;wasPressed()Z"
      ),
      slice = @Slice(
         from = @At(
            value = "FIELD",
            target = "Lnet/minecraft/client/option/GameOptions;useKey:Lnet/minecraft/client/option/KeyBinding;",
            ordinal = 1
         ),
         to = @At("TAIL")
      )
   )
   private boolean h(class_304 var1) {
      MouseButton var2 = MouseHelper.a(var1);
      return var2 != null ? var2.consumePress() : var1.method_1436();
   }

   @Inject(
      method = {"doItemUse"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void i(CallbackInfo var1) {
      ItemUseEvent var2 = new ItemUseEvent();
      EventDispatcher.b(var2);
      if (var2.isCancelled()) {
         var1.cancel();
      }
   }

   @Redirect(
      method = {"doAttack"},
      at = @At(
         value = "FIELD",
         target = "Lnet/minecraft/client/MinecraftClient;attackCooldown:I",
         opcode = 181
      )
   )
   private void j(class_310 var1, int var2) {
      BvKxLw var3 = new BvKxLw(var2);
      EventDispatcher.b(var3);
      this.field_1771 = var3.getCooldown();
   }

   @Inject(
      method = {"render"},
      at = {@At("HEAD")}
   )
   private void k(CallbackInfo var1) {
      EventDispatcher.b(new PreRenderEvent());
   }

   @Inject(
      method = {"render"},
      at = {@At("TAIL")}
   )
   private void l(CallbackInfo var1) {
   }

   @Inject(
      method = {"render"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/MinecraftClient;runTasks()V",
         shift = Shift.BEFORE
      )}
   )
   private void m(boolean var1, CallbackInfo var2, @Local(ordinal = 0) int var3) {
      EventDispatcher.b(new ScheduledExecutablesEvent(var3 > 0));
   }

   @Inject(
      method = {"tick"},
      at = {@At("HEAD")}
   )
   private void n(CallbackInfo var1) {
      RotationUtility.recoveredField141 = false;
      RotationUtility.recoveredField045 = false;
      EventDispatcher.b(new PreGameTickEvent());
   }

   @Inject(
      method = {"joinWorld"},
      at = {@At("HEAD")}
   )
   private void o(class_638 var1, CallbackInfo var2) {
      EventDispatcher.b(new JoinWorldEvent());
   }

   @Inject(
      method = {"tick"},
      at = {@At("TAIL")}
   )
   private void p(CallbackInfo var1) {
      EventDispatcher.b(new PostGameTickEvent());
   }

   @Inject(
      method = {"onDisconnected"},
      at = {@At("HEAD")}
   )
   private void q(CallbackInfo var1) {
      EventDispatcher.b(new ServerDisconnectEvent());
   }

   @Inject(
      method = {"isTelemetryEnabledByApi"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void r(CallbackInfoReturnable var1) {
      var1.setReturnValue(false);
   }

   @Inject(
      method = {"onResolutionChanged"},
      at = {@At("HEAD")}
   )
   private void s(CallbackInfo var1) {
      EventDispatcher.b(new ResolutionChangeEvent());
   }

   @Inject(
      method = {"doItemUse"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/util/ActionResult$Success;swingSource()Lnet/minecraft/util/ActionResult$SwingSource;",
         ordinal = 1
      )}
   )
   private void t(CallbackInfo var1, @Local class_3965 var2) {
      EventDispatcher.b(new BlockPlacedEvent(var2));
   }

   @Redirect(
      method = {"doItemUse"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/item/HeldItemRenderer;resetEquipProgress(Lnet/minecraft/util/Hand;)V",
         ordinal = 0
      )
   )
   private void u(class_759 var1, class_1268 var2) {
      SlotHelper var3 = SlotHelper.getInstance();
      if (var2 != class_1268.field_5808 || !var3.isSlotOverrideActive() || var3.a(this.field_1724).method_7909() instanceof class_1747) {
         var1.method_3215(var2);
      }
   }
}
