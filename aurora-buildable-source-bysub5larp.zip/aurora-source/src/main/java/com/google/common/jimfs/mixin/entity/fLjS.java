package com.google.common.jimfs.mixin.entity;

import com.google.common.jimfs.duck.BipedEntityRenderStateAccess;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10034;
import net.minecraft.class_10442;
import net.minecraft.class_1309;
import net.minecraft.class_909;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({class_909.class})
public final class fLjS {
   @Inject(
      method = {"updateBipedRenderState"},
      at = {@At("TAIL")}
   )
   private static void a(class_1309 var0, class_10034 var1, float var2, class_10442 var3, CallbackInfo var4) {
      ((BipedEntityRenderStateAccess)var1).jimfs$setEntity(var0);
   }
}
