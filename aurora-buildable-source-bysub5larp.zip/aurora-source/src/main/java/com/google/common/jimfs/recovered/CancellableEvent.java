package com.google.common.jimfs.recovered;

public class CancellableEvent {
   private boolean cancelled;
   private static String[] scratchStrings = new String[5];

   public boolean isCancelled() {
      return this.cancelled;
   }

   public void g() {
      this.cancelled = true;
   }

   public static void b(String[] var0) {
      scratchStrings = var0;
   }

   public static String[] h() {
      return scratchStrings;
   }
}
