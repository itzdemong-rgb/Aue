package com.google.common.jimfs.event.impl.game.player.movement;

import com.google.common.jimfs.recovered.CancellableEvent;

public final class JumpEvent extends CancellableEvent {
   private boolean recoveredField170;

   public JumpEvent(boolean var1) {
      this.recoveredField170 = var1;
   }
}
