package com.google.common.jimfs.client.feature.helper.impl.render;

import com.google.common.jimfs.event.EventDispatcher;
import com.google.common.jimfs.event.impl.game.JoinWorldEvent;
import com.google.common.jimfs.event.subscriber.IEventSubscriber;
import com.google.common.jimfs.event.subscriber.Subscribe;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_4604;
import org.jetbrains.annotations.Nullable;

@Environment(EnvType.CLIENT)
public class FrustumHelper implements IEventSubscriber {
   @Nullable
   private static class_4604 frustum;
   private static FrustumHelper instance = new FrustumHelper();

   public static void a(@Nullable class_4604 var0) {
      frustum = var0;
   }

   @Subscribe
   public void a(JoinWorldEvent var1) {
      a((class_4604)null);
   }

   static {
      EventDispatcher.a(instance);
   }
}
