package com.google.common.jimfs.recovered;

import com.google.common.jimfs.client.Constants;
import com.google.common.jimfs.client.feature.module.Module;
import com.google.common.jimfs.client.feature.module.ModuleCategory;
import com.google.common.jimfs.client.feature.module.property.Property;
import com.google.common.jimfs.client.feature.module.property.impl.bool.BooleanProperty;
import com.google.common.jimfs.client.feature.module.property.impl.number.NumberProperty;
import com.google.common.jimfs.event.impl.render.RenderWorldEvent;
import com.google.common.jimfs.event.subscriber.Subscribe;
import com.google.common.jimfs.utility.misc.StringObfuscation;
import com.google.common.jimfs.utility.render.CustomRenderLayers;
import com.google.common.jimfs.utility.render.Draw3DUtility;
import j2cc.Nativeify;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1694;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2595;
import net.minecraft.class_2601;
import net.minecraft.class_2608;
import net.minecraft.class_2611;
import net.minecraft.class_2614;
import net.minecraft.class_2627;
import net.minecraft.class_2646;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_3719;
import net.minecraft.class_3866;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_9799;
import net.minecraft.class_4597.class_4598;

@Nativeify
public class StorageESPModule extends Module {
   private static final class_238 m = new class_238(0.0, 0.0, 0.0, 1.0, 1.0, 1.0);
   private static final class_238 o = new class_238(0.0, 0.0, 0.0, 0.0, 0.0, 0.0);
   public final BooleanProperty p = new BooleanProperty(StringObfuscation.a("Chests"), true);
   public final BooleanProperty q = new BooleanProperty(StringObfuscation.a("Ender Chests"), true);
   public final BooleanProperty r = new BooleanProperty(StringObfuscation.a("Trapped Chests"), false);
   public final BooleanProperty s = new BooleanProperty(StringObfuscation.a("Furnaces"), false);
   public final BooleanProperty t = new BooleanProperty(StringObfuscation.a("Barrels"), true);
   public final BooleanProperty u = new BooleanProperty(StringObfuscation.a("Minecart"), true);
   public final BooleanProperty v = new BooleanProperty(StringObfuscation.a("Shulkers"), true);
   public final BooleanProperty w = new BooleanProperty(StringObfuscation.a("Droppers"), false);
   public final BooleanProperty x = new BooleanProperty(StringObfuscation.a("Dispensers"), false);
   public final BooleanProperty y = new BooleanProperty(StringObfuscation.a("Hoppers"), false);
   public final BooleanProperty z = new BooleanProperty(StringObfuscation.a("Fill"), true);
   public final BooleanProperty A = new BooleanProperty(StringObfuscation.a("Outline"), true);
   public final NumberProperty B = new NumberProperty(StringObfuscation.a("Max Distance"), 128.0, 5.0, 256.0, 1.0);
   private static final String[] recoveredField060 = new String[]{
      "\u0002pæCvPèì\u001bxK\u0089®à2p\u0081b×s=aAVÏ\u00110Dyë[½@å¬`s\u0089\u0088ÖøK\u0016\u0010\n\u0088F\u0019",
      "*ªÃ*ÿnYW\u008d½\u0014ÉJ\rNÕÎ\u0094Ò\u009cß\u009b\u001eÀI\u0004 ÀÃÏ\u0091\u00065U¡P3;`º'ôOÊãOÚïñÑ\u0019|\nÏ¨.\u001d4JÛNaÁüÜÕ?0\u0001\u001aÈ\u0003>ê¸Zl@J\u0083",
      "\u0090's~ê\u009b\u0098jµ¯\u0012\u0092¤\u0012q\u0091¨M\u0093¾ó¾\u001e\u0019g©\t+¦bqléiÔ\u008c\u0091Ñµé\u0011\u0011¦Y\u001c¸\u0084z",
      "ÖQ|K+½\u0081x\u0094òuÕg\u0091Å\u0090Q=!þ \u0016Ñ¬\u0090º8\u001c\u008ds·DÐY\u001d@©\u0084ÇK\u0082\f·\u00860õÃòÝVrxgf\\SÿÁÙe=·Ø\u0003",
      "¥t½ÆqKæ\u0011ÛìrA\u0089üÕ\u0005\u001e£&\u0085OªÏ\u0084óüÕ§°\u0013²¡¾Yÿu6Ñï*\u0014\u009e\u0084à¶\u0084ÞÔ<\u009f\u0016\u0095¸Þþ÷\u0081¹E\u0003öN«£",
      "F&cïdZjÀ¨>\u0093Àô\u001f\u001aî\u008b\u009cz9È[¼'Q¬â\bTãnOgtÊl^¾ÂH\u0090ü\u0014V¤¡\u009c¸uÍFþáïÛV¾\u0085%ÌÐ¿eÐ",
      "\u008d\u00ad6\u001ecÜ¯ê\u0098Æ\u0018¬\u0087¬8R\u000fø\b$\u0006WËÄý¢yöæûú>Ug\f\u008b$gB§\u0081^\u0017òÊ\u0097\u009e\u008a5É@zà¦;Ù",
      "\u009b&Õ\u0096\u001c^%G\u0002dç\u0000{\u0089Ê\u001e\u009cÞ9¾\u0001×';îDx\u000bÉNÿÁ8\u0088á=ÛÒ¼]",
      "CÃÃ3p\u0097é©ôì·»\u001e\u0004ê\t»T\u0093×Ôµ?\u0099",
      "úÞÚï¿ÕP\u0015\u008cl\u0014\u0003kùdZHN\u0083«wÅæÆ5ï\u00adà1(ã~Ù^ýâyÖé\u0095",
      "\u008cû7ÚM\u009a \"Ò\u008b\u0092ÛY\u0012¯Ù1J£Õ\u0090\u007f·\u001a?ßÁ20aàWõG·13PÃ!¾»\u001e\u0085ëÊìº",
      "ï7{Ãè;ºÐÑÕ¿F\u0015bÏbþN×\u0019\u001dkgôiýË.\u009f¾\u0015CEânG\t\u001a«7sÈE\u001f\u000f°fï",
      "¨%ò\u00ad\u0096&Û¨¿~s\u0015«µÑÛÓap®ªÐ²y\u0090¼Ú \\J\u00837",
      "\u0097\u0084v`\n2À7{\u007fª\u008eñQØgÿÊT\u0004\u0083\u0097¶Ý\u0015ÊÏÊþ!×¾\u001cÓd<H\u0097\u008e|"
   };
   

   public StorageESPModule() {
      super(StringObfuscation.a("Storage ESP"), "", ModuleCategory.VISUAL);
      this.b(new Property[]{this.p, this.q, this.r, this.s, this.t, this.u, this.v, this.w, this.x, this.y, this.z, this.A, this.B});
   }

   @Subscribe
   public void b(RenderWorldEvent var1) {
      boolean var2 = false;
      if (Constants.MINECRAFT.field_1687 != null && Constants.MINECRAFT.field_1724 != null && this.isEnabled()) {
         try {
            class_9799 var3 = new class_9799(16384);

            try {
               class_4587 var4 = var1.getMatrixStack();
               class_4184 var5 = Constants.MINECRAFT.field_1773.method_19418();
               class_243 var6 = var5.method_71156();
               class_4598 var7 = class_4597.method_22991(var3);
               CustomRenderLayers.beginTransparentRender();
               if (this.z.isEnabled()) {
                  for (class_2586 var9 : this.d()) {
                     if (this.c(var9)) {
                        for (class_238 var11 : this.b(var9)) {
                           class_4588 var12 = var7.method_73477(CustomRenderLayers.a(true));
                           Draw3DUtility.a(var4, var12, var11.method_989(-var6.method_10216(), -var6.method_10214(), -var6.method_10215()), this.b(var9, 50));
                        }
                     }
                  }

                  for (class_1297 var19 : Constants.MINECRAFT.field_1687.method_18112()) {
                     if (this.b(var19)) {
                        class_238 var22 = var19.method_5829();
                        class_4588 var25 = var7.method_73477(CustomRenderLayers.a(true));
                        Draw3DUtility.a(var4, var25, var22.method_989(-var6.method_10216(), -var6.method_10214(), -var6.method_10215()), this.b(var19, 50));
                     }
                  }
               }

               if (this.A.isEnabled()) {
                  for (class_2586 var20 : this.d()) {
                     if (this.c(var20)) {
                        for (class_238 var26 : this.b(var20)) {
                           class_4588 var28 = var7.method_73477(CustomRenderLayers.a(2.0F, true));
                           Draw3DUtility.b(var4, var28, var26.method_989(-var6.method_10216(), -var6.method_10214(), -var6.method_10215()), this.b(var20, 255));
                        }
                     }
                  }

                  for (class_1297 var21 : Constants.MINECRAFT.field_1687.method_18112()) {
                     if (this.b(var21)) {
                        class_238 var24 = var21.method_5829();
                        class_4588 var27 = var7.method_73477(CustomRenderLayers.a(2.0F, true));
                        Draw3DUtility.b(var4, var27, var24.method_989(-var6.method_10216(), -var6.method_10214(), -var6.method_10215()), this.b(var21, 255));
                     }
                  }
               }

               var7.method_22993();
               CustomRenderLayers.endTransparentRender();
            } catch (Throwable var14) {
               try {
                  var3.close();
               } catch (Throwable var13) {
                  var14.addSuppressed(var13);
               }

               throw var14;
            }

            var3.close();
         } catch (Throwable var15) {
         }
      }
   }

   private Iterable<class_2586> d() {
      ArrayList var2 = new ArrayList();
      boolean var1 = true;
      if (Constants.MINECRAFT.field_1687 != null) {
         int var3 = ((Double)this.B.getValue()).intValue();
         class_2338 var4 = Constants.MINECRAFT.field_1724.method_24515();

         for (int var5 = -var3; var5 <= var3; var5 += 16) {
            for (int var6 = -var3; var6 <= var3; var6 += 16) {
               if (Constants.MINECRAFT.field_1687.method_2935().method_21730(var4.method_10263() + var5 >> 4, var4.method_10260() + var6 >> 4) instanceof class_2818 var8
                  )
                {
                  var2.addAll(var8.method_12214().values());
               }
            }
         }
      }

      return var2;
   }

   private List<class_238> b(class_2586 var1) {
      boolean var2 = true;
      if (Constants.MINECRAFT.field_1687 == null) {
         return List.of(o);
      } else {
         class_2338 var3 = var1.method_11016();
         class_2680 var4 = Constants.MINECRAFT.field_1687.method_8320(var3);
         class_265 var5 = var4.method_26218(Constants.MINECRAFT.field_1687, var3);
         return var5.method_1110() ? List.of(m.method_996(var3)) : var5.method_1090().stream().map(var1x -> var1x.method_996(var3)).toList();
      }
   }

   private boolean c(class_2586 var1) {
      double var3 = (Double)this.B.getValue() * (Double)this.B.getValue();
      boolean var2 = true;
      if (Constants.MINECRAFT.field_1724 == null || Constants.MINECRAFT.field_1724.method_5707(var1.method_11016().method_46558()) > var3) {
         return false;
      } else if (var1 instanceof class_2595 && this.p.isEnabled()) {
         return true;
      } else if (var1 instanceof class_2611 && this.q.isEnabled()) {
         return true;
      } else if (var1 instanceof class_2646 && this.r.isEnabled()) {
         return true;
      } else if (var1 instanceof class_3866 && this.s.isEnabled()) {
         return true;
      } else if (var1 instanceof class_3719 && this.t.isEnabled()) {
         return true;
      } else if (var1 instanceof class_2627 && this.v.isEnabled()) {
         return true;
      } else if (var1 instanceof class_2608 && this.w.isEnabled()) {
         return true;
      } else {
         return var1 instanceof class_2601 && this.x.isEnabled() ? true : var1 instanceof class_2614 && this.y.isEnabled();
      }
   }

   private Color b(class_2586 var1, int var2) {
      boolean var3 = true;
      if (var1 instanceof class_2595) {
         return new Color(255, 131, 54, var2);
      } else if (var1 instanceof class_2611) {
         return new Color(121, 54, 255, var2);
      } else if (var1 instanceof class_2646) {
         return new Color(255, 101, 54, var2);
      } else if (var1 instanceof class_3866) {
         return new Color(126, 126, 126, var2);
      } else if (var1 instanceof class_3719) {
         return new Color(255, 185, 54, var2);
      } else if (var1 instanceof class_2627) {
         return new Color(181, 54, 255, var2);
      } else {
         return !(var1 instanceof class_2608) && !(var1 instanceof class_2601) && !(var1 instanceof class_2614)
            ? new Color(255, 255, 255, var2)
            : new Color(100, 100, 100, var2);
      }
   }

   private Color b(class_1297 var1, int var2) {
      return var1 instanceof class_1694 ? new Color(255, 200, 100, var2) : new Color(255, 255, 255, var2);
   }

   private boolean b(class_1297 var1) {
      double var3 = (Double)this.B.getValue() * (Double)this.B.getValue();
      boolean var2 = true;
      return Constants.MINECRAFT.field_1724 != null && !(Constants.MINECRAFT.field_1724.method_5707(var1.method_73189()) > var3)
         ? var1 instanceof class_1694 && this.u.isEnabled()
         : false;
   }

   static {
      byte var0 = 73;
      byte var1 = 40;
      String var2 = "Å&øæÙ\u0010ÙÅ¼t8Z\u009d·¼ØÙ*?\u0098¨½±sÛóì¢1I\u0089|(ú\u0087|+E\u0004ÂZxuáÁÇSµdõ\u0081\u001b2\u0081úµ×^\u0085ùÈ\u0093\"ÝõSåfQK\u009dÅ3";
      byte var3 = 14;
      byte var4 = 73;
      String[] var5 = recoveredField060;
      byte var6 = 40;
   }

}
