package com.google.common.jimfs.client.feature.module.property.impl.bool;

import com.google.common.jimfs.client.feature.module.property.Property;

public final class BooleanProperty extends Property {
   private static Property[] scratchProperties = new Property[5];

   public BooleanProperty(CharSequence var1, boolean var2) {
      super(var1);
      this.a(var2);
   }

   public Boolean isEnabled() {
      boolean var1 = false;
      return (Boolean)super.getValue() && !this.isVisible();
   }

   @Override
   public Object getValue() {
      return this.isEnabled();
   }

   public static void b(Property[] var0) {
      scratchProperties = var0;
   }

   public static Property[] getScratchProperties() {
      return scratchProperties;
   }

}
