package com.google.common.jimfs.event.impl.render;

import net.minecraft.class_332;

public class RenderHudEvent {
   private final class_332 drawContext;

   public RenderHudEvent(class_332 var1) {
      this.drawContext = var1;
   }

   public class_332 getDrawContext() {
      return this.drawContext;
   }
}
