package com.google.common.jimfs.recovered;

import net.minecraft.class_1309;

public class TrackedLivingEntity extends TrackedEntity {
   public TrackedLivingEntity(class_1309 var1) {
      super(var1);
   }
}
