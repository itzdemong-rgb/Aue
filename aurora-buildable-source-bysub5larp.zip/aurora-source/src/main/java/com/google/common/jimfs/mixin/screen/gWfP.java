package com.google.common.jimfs.mixin.screen;

import com.google.common.jimfs.event.EventDispatcher;
import com.google.common.jimfs.event.impl.game.server.ServerDisconnectEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_419;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({class_419.class})
public final class gWfP {
   private gWfP() {
   }

   @Inject(
      method = {"init"},
      at = {@At("HEAD")}
   )
   private void kW(CallbackInfo var1) {
      EventDispatcher.b(new ServerDisconnectEvent());
   }
}
