package com.google.common.jimfs.client.feature.module.property.impl;

import com.google.common.jimfs.client.Constants;
import com.google.common.jimfs.client.feature.module.property.Property;
import com.ibm.icu.impl.Pair;
import net.minecraft.class_1041;

public final class ScreenPositionProperty extends Property {
   private ScreenPositionProperty(CharSequence name) { super(name); }
   private float dragOffsetX;
   private float dragOffsetY;
   private float j;
   private float k;
   private boolean l;

   public float i() {
      return (Float)((Pair)this.getValue()).first;
   }

   public float l() {
      return (Float)((Pair)this.getValue()).second;
   }

   public float getPixelX() {
      float var2 = this.i();
      boolean var1 = true;
      float var3 = var2 * (float)Constants.MINECRAFT.method_22683().method_4486();
      return var2 > 0.5F ? var3 - this.j : var3;
   }

   public float d() {
      return this.l() * (float)Constants.MINECRAFT.method_22683().method_4502();
   }

   public void b(float var1) {
      this.a(Pair.of(var1, this.l()));
   }

   public void g(float var1) {
      this.a(Pair.of(this.i(), var1));
   }

   public void c(float var1) {
      int var3 = Constants.MINECRAFT.method_22683().method_4486();
      float var4 = var1 / (float)var3;
      boolean var2 = false;
      if (var4 > 0.5F) {
         var4 += this.j / (float)var3;
      }

      this.b(var4);
   }

   public void d(float var1) {
      float var2 = var1 / (float)Constants.MINECRAFT.method_22683().method_4502();
      this.g(var2);
   }

   public void snapToEdges() {
      class_1041 var2 = Constants.MINECRAFT.method_22683();
      int var3 = var2.method_4486();
      int var4 = var2.method_4502();
      float var5 = this.i();
      float var6 = this.l();
      float var7 = this.j / (float)var3;
      float var8 = this.k / (float)var4;
      float var9 = var7 / 2.0F;
      float var10 = var8 / 2.0F;
      boolean var1 = false;
      if (var5 < 0.01F) {
         this.b(0.0F);
      } else if (var5 > 0.99F) {
         this.b(1.0F);
      } else if (var5 + var9 > 0.49F && var5 + var9 < 0.51F) {
         this.b(0.5F - var9);
      }

      if (var6 < 0.01F) {
         this.g(0.0F);
      } else if (var6 + var8 > 0.99F) {
         this.g(1.0F - var8);
      } else if (var6 + var10 > 0.49F && var6 + var10 < 0.51F) {
         this.g(0.5F - var10);
      }
   }

   public float e() {
      return this.j;
   }

   public float f() {
      return this.k;
   }

   public boolean isDragging() {
      return this.l;
   }

   public void a(boolean var1) {
      this.l = var1;
   }

   public float g() {
      boolean var1 = true;
      return this.dragOffsetX > (float)Constants.MINECRAFT.method_22683().method_4486() / 2.0F
         ? this.dragOffsetX - this.j
         : this.dragOffsetX;
   }

   public float h() {
      return this.dragOffsetY;
   }

   public void e(float var1) {
      this.dragOffsetX = var1;
   }

   public void f(float var1) {
      this.dragOffsetY = var1;
   }

}
