package com.google.common.jimfs.mixin.client;

import com.google.common.jimfs.client.feature.helper.impl.player.packet.blockage.impl.InboundNetworkBlockage;
import com.google.common.jimfs.client.feature.helper.impl.player.packet.blockage.impl.OutboundNetworkBlockage;
import com.google.common.jimfs.duck.ClientConnectionAccess;
import com.google.common.jimfs.event.EventDispatcher;
import com.google.common.jimfs.event.impl.game.packet.InstantaneousReceivePacketEvent;
import com.google.common.jimfs.event.impl.game.packet.InstantaneousSendPacketEvent;
import com.google.common.jimfs.event.impl.game.packet.ReceivePacketEvent;
import com.google.common.jimfs.event.impl.game.packet.SendPacketEvent;
import com.google.common.jimfs.mixin.mWpL;
import com.google.common.jimfs.utility.player.RotationUtility;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import java.util.concurrent.RejectedExecutionException;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2535;
import net.minecraft.class_2547;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2598;
import net.minecraft.class_2828;
import net.minecraft.class_2842;
import net.minecraft.class_2846;
import net.minecraft.class_2848;
import net.minecraft.class_2868;
import net.minecraft.class_2879;
import net.minecraft.class_2885;
import net.minecraft.class_2886;
import net.minecraft.class_2987;
import net.minecraft.class_310;
import net.minecraft.class_8042;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({class_2535.class})
public abstract class ClientConnectionMixin implements ClientConnectionAccess {
   @Shadow
   @Nullable
   private volatile class_2547 field_11652;
   @Shadow
   @Final
   private static Logger field_11642;
   @Shadow
   private int field_11658;
   @Shadow
   private Channel field_11651;

   @Shadow
   private static void method_10759(class_2596 var0, class_2547 var1) {
   }

   @Shadow
   public abstract void method_10747(class_2561 var1);

   @Shadow
   protected abstract void method_10770(ChannelHandlerContext var1, class_2596 var2);

   @Shadow
   public abstract class_2598 method_36121();

   private ClientConnectionMixin() {
   }

   @Inject(
      method = {"<init>"},
      at = {@At("TAIL")}
   )
   private void a(class_2598 var1, CallbackInfo var2) {
      InboundNetworkBlockage.getInstance().clear();
      OutboundNetworkBlockage.getInstance().clear();
   }

   @Unique
   private static boolean b(class_2596 var0) {
      return var0 instanceof class_2885
         || var0 instanceof class_2879
         || var0 instanceof class_2868
         || var0 instanceof class_2846
         || var0 instanceof class_2848
         || var0 instanceof class_2886
         || var0 instanceof class_2842;
   }

   @Inject(
      method = {"send(Lnet/minecraft/network/packet/Packet;)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void c(class_2596 var1, CallbackInfo var2) {
      InstantaneousSendPacketEvent var3 = new InstantaneousSendPacketEvent(var1);
      EventDispatcher.b(var3);
      SendPacketEvent var4 = new SendPacketEvent(var1);
      EventDispatcher.b(var4);
      if (!var3.isCancelled() && !var4.isCancelled() && !OutboundNetworkBlockage.getInstance().a(var1)) {
         if (var1 instanceof class_2868 var5) {
            class_310 var6 = class_310.method_1551();
            if (var6 != null && var6.field_1761 != null) {
               ((mWpL)var6.field_1761).m(var5.method_12442());
            }
         }

         if (var1 instanceof class_2828) {
            RotationUtility.recoveredField190 = true;
         }
      } else {
         var2.cancel();
      }
   }

   @Inject(
      method = {"handlePacket"},
      at = {@At("HEAD")},
      cancellable = true,
      require = 1
   )
   private static void d(class_2596 var0, class_2547 var1, CallbackInfo var2) {
      if (!(var0 instanceof class_8042 var3)) {
         ReceivePacketEvent var8 = new ReceivePacketEvent(var0);
         EventDispatcher.b(var8);
         if (var8.isCancelled()) {
            var2.cancel();
         }
      } else {
         var2.cancel();

         for (class_2596 var5 : var3.method_48324()) {
            try {
               method_10759(var5, var1);
            } catch (class_2987 var7) {
            }
         }
      }
   }

   @Inject(
      method = {"channelRead0(Lio/netty/channel/ChannelHandlerContext;Lnet/minecraft/network/packet/Packet;)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void e(ChannelHandlerContext var1, class_2596 var2, CallbackInfo var3) {
      if (this.method_36121() == class_2598.field_11942) {
         if (var2 instanceof class_8042 var9) {
            var3.cancel();

            for (class_2596 var6 : var9.method_48324()) {
               try {
                  this.method_10770(var1, var6);
               } catch (class_2987 var8) {
               }
            }

            return;
         }

         InstantaneousReceivePacketEvent var4 = new InstantaneousReceivePacketEvent(var2);
         EventDispatcher.b(var4);
         if (var4.isCancelled() || InboundNetworkBlockage.getInstance().a(var2)) {
            var3.cancel();
         }
      }
   }

   @Unique
   @Override
   public void jimfs$channelReadSilent(class_2596 var1) {
      if (this.field_11651.isOpen()) {
         class_2547 var2 = this.field_11652;
         if (var2 == null) {
            throw new IllegalStateException("Received a packet before the packet listener was initialized");
         }

         if (var2.method_52413(var1)) {
            try {
               method_10759(var1, var2);
            } catch (class_2987 var4) {
            } catch (RejectedExecutionException var5) {
               this.method_10747(class_2561.method_43471("multiplayer.disconnect.server_shutdown"));
            } catch (ClassCastException var6) {
               field_11642.error("Received {} that couldn't be processed", var1.getClass(), var6);
               this.method_10747(class_2561.method_43471("multiplayer.disconnect.invalid_packet"));
            }

            this.field_11658++;
         }
      }
   }
}
