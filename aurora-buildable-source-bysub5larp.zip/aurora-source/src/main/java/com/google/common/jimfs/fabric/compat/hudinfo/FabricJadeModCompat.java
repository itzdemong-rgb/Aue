package com.google.common.jimfs.fabric.compat.hudinfo;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class FabricJadeModCompat {
}
