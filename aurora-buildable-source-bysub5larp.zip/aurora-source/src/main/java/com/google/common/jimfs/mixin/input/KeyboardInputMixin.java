package com.google.common.jimfs.mixin.input;

import com.google.common.jimfs.client.Constants;
import com.google.common.jimfs.event.EventDispatcher;
import com.google.common.jimfs.event.impl.game.input.MoveInputEvent;
import com.google.common.jimfs.utility.player.RotationUtility;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10185;
import net.minecraft.class_241;
import net.minecraft.class_3532;
import net.minecraft.class_743;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;

@Environment(EnvType.CLIENT)
@Mixin({class_743.class})
public final class KeyboardInputMixin {
   @Unique
   private static double fT = 0.0;
   @Unique
   private MoveInputEvent xR;

   @ModifyExpressionValue(
      method = {"tick"},
      at = {@At(
         value = "NEW",
         target = "(ZZZZZZZ)Lnet/minecraft/util/PlayerInput;"
      )}
   )
   private class_10185 kW(class_10185 var1) {
      this.xR = new MoveInputEvent(
         qP(Constants.MINECRAFT.field_1690.field_1894.method_1434(), Constants.MINECRAFT.field_1690.field_1881.method_1434()),
         qP(Constants.MINECRAFT.field_1690.field_1913.method_1434(), Constants.MINECRAFT.field_1690.field_1849.method_1434()),
         Constants.MINECRAFT.field_1690.field_1903.method_1434(),
         var1.comp_3164()
      );
      EventDispatcher.b(this.xR);
      float var2 = this.xR.getForward();
      float var3 = this.xR.getSideways();
      boolean var4 = false;
      float var5 = 0.0F;
      float var6 = 0.0F;
      if (RotationUtility.recoveredField045) {
         var4 = true;
         var5 = RotationUtility.recoveredField001;
         var6 = RotationUtility.recoveredField063;
      }

      RotationUtility.recoveredField045 = var4;
      if (var4) {
         RotationUtility.recoveredField001 = var5;
         RotationUtility.recoveredField063 = var6;
         float var7 = (float)Math.toRadians((double)class_3532.method_15393(Constants.MINECRAFT.field_1724.method_36454() - var5));
         float var8 = class_3532.method_15362((double)var7);
         float var9 = class_3532.method_15374((double)var7);
         float var10 = var2 * var8 - var3 * var9;
         float var11 = var2 * var9 + var3 * var8;
         var2 = var10;
         var3 = var11;
      }

      boolean var17 = false;
      boolean var18 = false;
      boolean var19 = false;
      boolean var20 = false;
      if (var2 != 0.0F || var3 != 0.0F) {
         double var21 = Math.atan2((double)var2, (double)var3);
         double var13 = Math.abs(class_3532.method_15338(Math.toDegrees(var21 - fT)));
         double var15;
         if (var13 < 30.0) {
            var15 = fT;
         } else {
            var15 = (double)Math.round(var21 / (Math.PI / 4)) * (Math.PI / 4);
            fT = var15;
         }

         var17 = Math.cos(var15) > 0.1;
         var18 = Math.cos(var15) < -0.1;
         var19 = Math.sin(var15) > 0.1;
         var20 = Math.sin(var15) < -0.1;
      }

      if (var4 && Constants.MINECRAFT.field_1724 != null && Constants.MINECRAFT.field_1724.method_5624()) {
         var17 = true;
         var18 = false;
         var19 = false;
         var20 = false;
      }

      boolean var22 = var1.comp_3165() && var17 && !Constants.MINECRAFT.field_1724.field_5976 && !this.xR.isSneaking();
      if ((RotationUtility.recoveredField141 || var4) && Constants.MINECRAFT.field_1724 != null) {
         var22 = Constants.MINECRAFT.field_1724.method_5624()
            && var17
            && !Constants.MINECRAFT.field_1724.field_5976
            && !this.xR.isSneaking();
      }

      float var12 = (var19 ? 1.0F : 0.0F) - (var20 ? 1.0F : 0.0F);
      float var23 = (var17 ? 1.0F : 0.0F) - (var18 ? 1.0F : 0.0F);
      RotationUtility.recoveredField110 = var17;
      ((kXvL)(Object)this).kS(new class_241(var12, var23));
      return new class_10185(var17, var18, var19, var20, this.xR.isJumping(), this.xR.isSneaking(), var22);
   }

   @Unique
   private static float qP(boolean var0, boolean var1) {
      if (var0 == var1) {
         return 0.0F;
      } else {
         return var0 ? 1.0F : -1.0F;
      }
   }
}
