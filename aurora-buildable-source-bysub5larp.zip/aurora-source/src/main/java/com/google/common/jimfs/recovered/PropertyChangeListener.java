package com.google.common.jimfs.recovered;

public interface PropertyChangeListener {
   void a(Object var1, Object var2);
}
