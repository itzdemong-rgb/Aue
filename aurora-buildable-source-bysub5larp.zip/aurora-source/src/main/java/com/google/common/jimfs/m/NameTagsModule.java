package com.google.common.jimfs.m;

import com.google.common.jimfs.client.Constants;
import com.google.common.jimfs.client.Swag;
import com.google.common.jimfs.client.feature.helper.impl.ClientSyncHelper;
import com.google.common.jimfs.client.feature.module.Module;
import com.google.common.jimfs.client.feature.module.ModuleCategory;
import com.google.common.jimfs.client.feature.module.property.Property;
import com.google.common.jimfs.client.feature.module.property.impl.ColorProperty;
import com.google.common.jimfs.client.feature.module.property.impl.bool.BooleanProperty;
import com.google.common.jimfs.client.feature.module.property.impl.number.NumberProperty;
import com.google.common.jimfs.event.impl.render.RenderHudEvent;
import com.google.common.jimfs.event.subscriber.Subscribe;
import com.google.common.jimfs.recovered.FriendRegistry;
import com.google.common.jimfs.utility.misc.StringObfuscation;
import com.google.common.jimfs.utility.misc.math.MathUtility;
import com.google.common.jimfs.utility.render.ColorUtility;
import com.google.common.jimfs.utility.render.ESPUtility;
import j2cc.Nativeify;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_5250;
import net.minecraft.class_640;

@Nativeify
public class NameTagsModule extends Module {
   public final BooleanProperty showArmor = new BooleanProperty(StringObfuscation.a("Armor"), true);
   public final BooleanProperty showItems = new BooleanProperty(StringObfuscation.a("Items"), true);
   public final BooleanProperty showBackgrounds = new BooleanProperty(StringObfuscation.a("Backgrounds"), true);
   public final ColorProperty textColor = new ColorProperty(StringObfuscation.a("Tехт Cоlоr"), -1);
   public final ColorProperty backgroundColor = new ColorProperty(StringObfuscation.a("Bасkgrоund Cоlоr"), 1711276032);
   public final BooleanProperty showHealth = new BooleanProperty(StringObfuscation.a("Show Health"), true);
   public final BooleanProperty showDistance = new BooleanProperty(StringObfuscation.a("Show Distance"), true);
   public final BooleanProperty showPing = new BooleanProperty(StringObfuscation.a("Show Ping"), false);
   public final NumberProperty scale = new NumberProperty(StringObfuscation.a("Scale"), 1.0, 0.5, 2.0, 0.1);
   
   

   public NameTagsModule() {
      super(StringObfuscation.a("Name Tags"), "", ModuleCategory.VISUAL);
      this.b(new Property[]{this.showArmor, this.showItems, this.showBackgrounds, this.textColor, this.backgroundColor, this.showHealth, this.showDistance, this.showPing, this.scale});
   }

   @Subscribe(
      a = -150
   )
   public void b(RenderHudEvent var1) {
      boolean var2 = true;
      if (Constants.MINECRAFT.field_1687 != null && Constants.MINECRAFT.field_1724 != null && this.isEnabled()) {
         float var3 = Constants.MINECRAFT.method_61966().method_60637(false);
         ArrayList<class_1297> var4 = new ArrayList();

         for (class_1297 var6 : Constants.MINECRAFT.field_1687.method_18112()) {
            if (var6 != Constants.MINECRAFT.field_1724 && (var6 instanceof class_1657 || var6.method_5864() == class_1299.field_6052)) {
               var4.add(var6);
            }
         }

         LinkedList<List<class_1542>> var14 = new LinkedList();
         HashSet var15 = new HashSet();

         for (class_1297 var8 : var4) {
            if (var8 instanceof class_1542 var9 && !var15.contains(var9)) {
               LinkedList var10 = new LinkedList();

               for (class_1297 var12 : var4) {
                  if (var12 instanceof class_1542) {
                     class_1542 var13 = (class_1542)var12;
                     if (!var15.contains(var13) && var9.method_5858(var13) < 1.0) {
                        var10.add(var13);
                        var15.add(var13);
                     }
                  }
               }

               var14.add(var10);
            }
         }

         for (class_1297 var21 : var4) {
            class_243 var26 = MathUtility.a(var21, var3);
            class_243 var31 = var26.method_1031(0.0, (double)var21.method_17682() + 0.5, 0.0);
            class_243 var36 = ESPUtility.a(var31);
            if (var36 != null && var21 instanceof class_1657) {
               this.b(var1.getDrawContext(), var21, var36);
            }
         }

         for (List var22 : var14) {
            if (!var22.isEmpty()) {
               class_1542 var27 = (class_1542)var22.get(0);
               class_243 var32 = MathUtility.a(var27, var3);
               class_243 var37 = var32.method_1031(0.0, (double)var27.method_17682() + 0.5, 0.0);
               class_243 var41 = ESPUtility.a(var37);
               if (var41 != null && this.showBackgrounds.isEnabled() && this.showItems.isEnabled()) {
                  if (var22.size() > 1) {
                     this.b(var1.getDrawContext(), var22, var41);
                  } else {
                     this.b(var1.getDrawContext(), var27, var41);
                  }
               }
            }
         }

         for (class_1297 var23 : var4) {
            class_243 var28 = MathUtility.a(var23, var3);
            class_243 var33 = var28.method_1031(0.0, (double)var23.method_17682() + 0.5, 0.0);
            class_243 var38 = ESPUtility.a(var33);
            if (var38 != null && var23 instanceof class_1657 && this.showArmor.isEnabled()) {
               this.b(var1.getDrawContext(), (class_1657)var23, var38);
            }
         }

         for (class_1297 var24 : var4) {
            class_243 var29 = MathUtility.a(var24, var3);
            class_243 var34 = var29.method_1031(0.0, (double)var24.method_17682() + 0.5, 0.0);
            class_243 var39 = ESPUtility.a(var34);
            if (var39 != null && var24 instanceof class_1657) {
               this.c(var1.getDrawContext(), var24, var39);
            }
         }

         for (List var25 : var14) {
            if (!var25.isEmpty()) {
               class_1542 var30 = (class_1542)var25.get(0);
               class_243 var35 = MathUtility.a(var30, var3);
               class_243 var40 = var35.method_1031(0.0, (double)var30.method_17682() + 0.5, 0.0);
               class_243 var42 = ESPUtility.a(var40);
               if (var42 != null && this.showItems.isEnabled()) {
                  if (var25.size() > 1) {
                     this.c(var1.getDrawContext(), var25, var42);
                  } else {
                     this.c(var1.getDrawContext(), var30, var42);
                  }
               }
            }
         }
      }
   }

   public class_5250 a(class_1657 var1) {
      class_5250 var3 = var1.method_5477().method_27661();
      boolean var2 = true;
      if (this.showHealth.isEnabled()) {
         float var4 = var1.method_6032() + var1.method_6067();
         int var5 = var4 > 15.0F ? -11141291 : (var4 > 7.0F ? -171 : -43691);
         var3.method_10852(class_2561.method_43470(" ")).method_10852(class_2561.method_43470((int)var4 + "❤").method_54663(var5));
      }

      if (this.showDistance.isEnabled() && Constants.MINECRAFT.field_1724 != null) {
         float var7 = var1.method_5739(Constants.MINECRAFT.field_1724);
         var3.method_10852(class_2561.method_43470(" ")).method_10852(class_2561.method_43470(String.format("%.1fm", var7)).method_54663(-5592406));
      }

      if (this.showPing.isEnabled() && Constants.MINECRAFT.method_1562() != null) {
         class_640 var8 = Constants.MINECRAFT.method_1562().method_2871(var1.method_5667());
         if (var8 != null) {
            int var9 = var8.method_2959();
            int var6 = var9 < 50 ? -11141291 : (var9 < 150 ? -171 : -43691);
            var3.method_10852(class_2561.method_43470(" ")).method_10852(class_2561.method_43470(var9 + "ms").method_54663(var6));
         }
      }

      return var3;
   }

   private void b(class_332 var1, class_1297 var2, class_243 var3) {
      float var5 = var2.method_5739(Constants.MINECRAFT.field_1724);
      boolean var4 = false;
      float var6 = ((Double)this.scale.getValue()).floatValue();
      float var7 = class_3532.method_15363(1.0F - var5 / 30.0F, 0.5F, 1.0F);
      float var8 = var6 * var7;
      if (var2 instanceof class_1657 var9) {
         var1.method_51448().pushMatrix();
         var1.method_51448().translate((float)var3.field_1352, (float)var3.field_1351);
         var1.method_51448().scale(var8, var8);
         class_5250 var10 = this.a(var9);
         int var11 = Constants.MINECRAFT.field_1772.method_27525(var10);
         Module var12 = Swag.getInstance().getModuleRepository().a(ClickGUIModule.class);
         boolean var13 = var12 != null
            && ((ClickGUIModule)var12).clientIndicator.isEnabled()
            && ClientSyncHelper.getInstance().a(var9.method_5477().getString());
         int var14 = var13 ? 14 : 0;
         int var15 = var11 + var14;
         byte var16 = 9;
         int var17 = -var15 / 2;
         int var18 = -var16 - 2;
         byte var19 = 5;
         byte var20 = 3;
         int var21 = (Integer)ColorUtility.getThemeColors().first;
         if (FriendRegistry.getInstance().b(var9.method_5477().getString())) {
            var21 = -11141291;
         }

         var1.method_25294(var17 - var19, var18 - var20, var17 + var15 + var19, var18 + var16 + var20 - 1, 1997607185);
         var1.method_25294(var17 - var19 - 1, var18 - var20 - 1, var17 + var15 + var19 + 1, var18 - var20, var21);
         var1.method_25294(var17 - var19 - 1, var18 + var16 + var20 - 1, var17 + var15 + var19 + 1, var18 + var16 + var20, var21);
         var1.method_25294(var17 - var19 - 1, var18 - var20, var17 - var19, var18 + var16 + var20 - 1, var21);
         var1.method_25294(var17 + var15 + var19, var18 - var20, var17 + var15 + var19 + 1, var18 + var16 + var20 - 1, var21);
         var1.method_51448().popMatrix();
      }
   }

   private void c(class_332 var1, class_1297 var2, class_243 var3) {
      float var5 = var2.method_5739(Constants.MINECRAFT.field_1724);
      float var6 = ((Double)this.scale.getValue()).floatValue();
      boolean var4 = true;
      float var7 = class_3532.method_15363(1.0F - var5 / 30.0F, 0.5F, 1.0F);
      float var8 = var6 * var7;
      if (var2 instanceof class_1657 var9) {
         var1.method_51448().pushMatrix();
         var1.method_51448().translate((float)var3.field_1352, (float)var3.field_1351);
         var1.method_51448().scale(var8, var8);
         class_5250 var10 = this.a(var9);
         int var11 = Constants.MINECRAFT.field_1772.method_27525(var10);
         Module var12 = Swag.getInstance().getModuleRepository().a(ClickGUIModule.class);
         boolean var13 = var12 != null
            && ((ClickGUIModule)var12).clientIndicator.isEnabled()
            && ClientSyncHelper.getInstance().a(var9.method_5477().getString());
         int var14 = var13 ? 14 : 0;
         int var15 = var11 + var14;
         int var16 = -var15 / 2;
         int var17 = -9 - 2;
         var1.method_51439(Constants.MINECRAFT.field_1772, var10, var16 + var14, var17, (Integer)this.textColor.getValue(), true);
         var1.method_51448().popMatrix();
      }
   }

   private void b(class_332 var1, class_1657 var2, class_243 var3) {
      float var5 = var2.method_5739(Constants.MINECRAFT.field_1724);
      float var6 = ((Double)this.scale.getValue()).floatValue();
      float var7 = class_3532.method_15363(1.0F - var5 / 30.0F, 0.5F, 1.0F);
      float var8 = var6 * var7;
      var1.method_51448().pushMatrix();
      var1.method_51448().translate((float)var3.field_1352, (float)var3.field_1351);
      var1.method_51448().scale(var8, var8);
      LinkedList<class_1799> var9 = new LinkedList();
      var9.add(var2.method_6118(class_1304.field_6169));
      var9.add(var2.method_6118(class_1304.field_6174));
      var9.add(var2.method_6118(class_1304.field_6172));
      var9.add(var2.method_6118(class_1304.field_6166));
      boolean var4 = true;
      var9.add(var2.method_6047());
      var9.add(var2.method_6079());
      var9.removeIf(class_1799::method_7960);
      int var10 = var9.size();
      if (var10 > 0) {
         float var11 = (float)(var10 - 1) * 18.0F + 16.0F;
         float var12 = -var11 / 2.0F;
         int var13 = -9 - 22;

         for (int var14 = 0; var14 < var10; var14++) {
            class_1799 var15 = (class_1799)var9.get(var14);
            int var16 = (int)(var12 + (float)(var14 * 18));
            var1.method_51427(var15, var16, var13);
            if (var15.method_7963()) {
               float var17 = 1.0F - (float)var15.method_7919() / (float)var15.method_7936();
               int var18 = class_3532.method_15369(Math.max(0.0F, var17) / 3.0F, 1.0F, 1.0F) | 0xFF000000;
               var1.method_25294(var16 + 2, var13 + 13, var16 + 14, var13 + 15, -16777216);
               var1.method_25294(var16 + 2, var13 + 13, var16 + 2 + (int)(12.0F * var17), var13 + 14, var18);
            }

            if (var15.method_7947() > 1) {
               String var19 = String.valueOf(var15.method_7947());
               var1.method_51433(
                  Constants.MINECRAFT.field_1772,
                  var19,
                  var16 + 17 - Constants.MINECRAFT.field_1772.method_1727(var19),
                  var13 + 9,
                  16777215,
                  true
               );
            }
         }
      }

      var1.method_51448().popMatrix();
   }

   private void b(class_332 var1, class_1542 var2, class_243 var3) {
      float var4 = var2.method_5739(Constants.MINECRAFT.field_1724);
      float var5 = class_3532.method_15363(1.0F - var4 / 20.0F, 0.5F, 1.0F);
      var1.method_51448().pushMatrix();
      var1.method_51448().translate((float)var3.field_1352, (float)var3.field_1351);
      var1.method_51448().scale(var5, var5);
      String var6 = var2.method_6983().method_7964().getString() + " " + var2.method_6983().method_7947() + "x";
      int var7 = Constants.MINECRAFT.field_1772.method_1727(var6);
      byte var8 = 9;
      int var9 = -var7 / 2;
      int var10 = -var8 - 2;
      byte var11 = 5;
      byte var12 = 3;
      int var13 = (Integer)ColorUtility.getThemeColors().first;
      int var14 = -1442840576;
      var1.method_25294(var9 - var11 - 1, var10 - var12 - 1, var9 + var7 + var11 + 1, var10 - var12, var14);
      var1.method_25294(var9 - var11 - 1, var10 + var8 + var12 - 1, var9 + var7 + var11 + 1, var10 + var8 + var12, var14);
      var1.method_25294(var9 - var11 - 1, var10 - var12, var9 - var11, var10 + var8 + var12 - 1, var14);
      var1.method_25294(var9 + var7 + var11, var10 - var12, var9 + var7 + var11 + 1, var10 + var8 + var12 - 1, var14);
      var1.method_25296(var9 - var11, var10 - var12, var9 + var7 + var11, var10 + var8 + var12 - 1, -1728053248, 1711276032);
      var1.method_25294(var9 - var11, var10 - var12, var9 + var7 + var11, var10 - var12 + 1, var13);
      var1.method_51448().popMatrix();
   }

   private void c(class_332 var1, class_1542 var2, class_243 var3) {
      float var4 = var2.method_5739(Constants.MINECRAFT.field_1724);
      float var5 = class_3532.method_15363(1.0F - var4 / 20.0F, 0.5F, 1.0F);
      var1.method_51448().pushMatrix();
      var1.method_51448().translate((float)var3.field_1352, (float)var3.field_1351);
      var1.method_51448().scale(var5, var5);
      String var6 = var2.method_6983().method_7964().getString() + " " + var2.method_6983().method_7947() + "x";
      int var7 = Constants.MINECRAFT.field_1772.method_1727(var6);
      int var8 = -var7 / 2;
      int var9 = -9 - 2;
      var1.method_51433(Constants.MINECRAFT.field_1772, var6, var8, var9, (Integer)this.textColor.getValue(), false);
      var1.method_51448().popMatrix();
   }

   private void b(class_332 var1, List<class_1542> var2, class_243 var3) {
      boolean var4 = true;
      if (!var2.isEmpty()) {
         float var5 = ((class_1542)var2.get(0)).method_5739(Constants.MINECRAFT.field_1724);
         float var6 = class_3532.method_15363(1.0F - var5 / 20.0F, 0.5F, 1.0F);
         var1.method_51448().pushMatrix();
         var1.method_51448().translate((float)var3.field_1352, (float)var3.field_1351);
         var1.method_51448().scale(var6, var6);
         int var7 = 0;
         byte var8 = 9;

         for (class_1542 var10 : var2) {
            String var11 = var10.method_6983().method_7964().getString() + " " + var10.method_6983().method_7947() + "x";
            int var12 = Constants.MINECRAFT.field_1772.method_1727(var11);
            if (var12 > var7) {
               var7 = var12;
            }
         }

         int var17 = var7 + 6;
         int var18 = var2.size() * var8 + (var2.size() - 1) * 2 + 6;
         int var19 = -var7 / 2 - 3;
         int var20 = -var18 - 2;
         byte var13 = 5;
         byte var14 = 3;
         int var15 = (Integer)ColorUtility.getThemeColors().first;
         int var16 = -1442840576;
         var1.method_25294(var19 - var13 + 1, var20 - var14 - 1, var19 + var17 + var13 - 1, var20 - var14, var16);
         var1.method_25294(var19 - var13 + 1, var20 + var18 + var14 - 1, var19 + var17 + var13 - 1, var20 + var18 + var14, var16);
         var1.method_25294(var19 - var13 + 1, var20 - var14, var19 - var13 + 2, var20 + var18 + var14 - 1, var16);
         var1.method_25294(var19 + var17 + var13 - 2, var20 - var14, var19 + var17 + var13 - 1, var20 + var18 + var14 - 1, var16);
         var1.method_25296(var19 - var13 + 2, var20 - var14, var19 + var17 + var13 - 2, var20 + var18 + var14 - 1, -1728053248, 1711276032);
         var1.method_25294(var19 - var13 + 2, var20 - var14, var19 + var17 + var13 - 2, var20 - var14 + 1, var15);
         var1.method_51448().popMatrix();
      }
   }

   private void c(class_332 var1, List<class_1542> var2, class_243 var3) {
      boolean var4 = true;
      if (!var2.isEmpty()) {
         float var5 = ((class_1542)var2.get(0)).method_5739(Constants.MINECRAFT.field_1724);
         float var6 = class_3532.method_15363(1.0F - var5 / 20.0F, 0.5F, 1.0F);
         var1.method_51448().pushMatrix();
         var1.method_51448().translate((float)var3.field_1352, (float)var3.field_1351);
         var1.method_51448().scale(var6, var6);
         byte var7 = 9;
         int var8 = 0;
         ArrayList var9 = new ArrayList();

         for (class_1542 var11 : var2) {
            String var12 = var11.method_6983().method_7964().getString() + " " + var11.method_6983().method_7947() + "x";
            var9.add(var12);
            int var13 = Constants.MINECRAFT.field_1772.method_1727(var12);
            if (var13 > var8) {
               var8 = var13;
            }
         }

         int var16 = -var8 / 2;

         for (int var17 = 0; var17 < var9.size(); var17++) {
            String var18 = (String)var9.get(var17);
            int var19 = Constants.MINECRAFT.field_1772.method_1727(var18);
            int var14 = var16 + (var8 - var19) / 2;
            int var15 = -(var9.size() - var17) * (var7 + 2);
            var1.method_51433(Constants.MINECRAFT.field_1772, var18, var14, var15, (Integer)this.textColor.getValue(), false);
         }

         var1.method_51448().popMatrix();
      }
   }

}
