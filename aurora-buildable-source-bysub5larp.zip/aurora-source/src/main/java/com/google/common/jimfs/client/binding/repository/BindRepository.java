package com.google.common.jimfs.client.binding.repository;

import com.google.common.jimfs.client.binding.BindingService;
import com.google.common.jimfs.client.screen.settings.SettingsScreen;
import com.google.common.jimfs.event.EventDispatcher;
import com.google.common.jimfs.event.impl.press.KeyPressEvent;
import com.google.common.jimfs.event.impl.press.MousePressEvent;
import com.google.common.jimfs.event.subscriber.IEventSubscriber;
import com.google.common.jimfs.event.subscriber.Subscribe;
import com.google.common.jimfs.recovered.InputDevice;
import com.google.common.jimfs.utility.misc.StringObfuscation;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_490;
import org.lwjgl.glfw.GLFW;

public final class BindRepository implements IEventSubscriber {
   private final BindingService bindingService = new BindingService();
   private final Map<String, Integer> keyNames = new HashMap();
   public static final String currentKeyName = StringObfuscation.d("8e4e815f6d4e6c64635f8d83", 22837);
   private static String currentMouseName = "Ecaw6b";
   private static final String[] recoveredField060 = new String[]{
      "y}\u0006O$Ì/Þ",
      "ùRµs¿¬?\u0085",
      "~6\b\u0081èW\u001a®",
      "k\u0000èOû\u0096\u0096\u0097Û\u0087³ê|\u008a+þ",
      "\u0093<\u0014×ã4ûWÚÇ\u009cÌq¶L\u009e",
      "¯Éþ\u0095UJ 8±Éò´Ú<\u009d¼u\u0016kñÆðßÅ",
      "*\u0004ãfÜ+û÷",
      "Í:?Cb/¥\u0082",
      "MàOÝ\u0000\u009d\bÅ"
   };
   

   public BindRepository() {
      try {
         for (Field var4 : GLFW.class.getDeclaredFields()) {
            if (var4.getName().startsWith(currentKeyName)) {
               this.keyNames.put(var4.getName().substring(currentKeyName.length()), var4.getInt(null));
            }
         }

         for (int var6 = 0; var6 < 10; var6++) {
            this.keyNames.put("MOUSE_" + var6, var6);
         }

         this.keyNames.put("LMB", 0);
         this.keyNames.put("RMB", 1);
         this.keyNames.put("MMB", 2);
         this.keyNames.put("CLEAR", -1);
      } catch (IllegalAccessException var5) {
      }

      EventDispatcher.a(this);
   }

   public String b(int var1) {
      boolean var2 = true;
      if (var1 == 0) {
         return "LMB";
      } else if (var1 == 1) {
         return "RMB";
      } else {
         return var1 == 2 ? "MMB" : this.keyNames.entrySet().stream().filter(var1x -> {
            boolean var2x = false;
            return (Integer)var1x.getValue() == var1;
         }).map(Entry::getKey).findFirst().orElse(null);
      }
   }

   public BindingService getBindingService() {
      return this.bindingService;
   }

   private boolean isInputBlockedByScreen() {
      class_437 var2 = class_310.method_1551().field_1755;
      boolean var1 = true;
      if (var2 == null) {
         return false;
      } else {
         return var2 instanceof class_490 ? false : !(var2 instanceof SettingsScreen);
      }
   }

   @Subscribe
   public void b(KeyPressEvent var1) {
      boolean var2 = true;
      if (!this.isInputBlockedByScreen()) {
         this.bindingService.b(var1.getCode(), InputDevice.KEYBOARD);
      }
   }

   @Subscribe
   public void b(MousePressEvent var1) {
      boolean var2 = false;
      if (!this.isInputBlockedByScreen()) {
         this.bindingService.b(var1.getCode(), InputDevice.MOUSE);
      }
   }

   static {
      byte var0 = 17;
      byte var1 = 8;
      String var2 = "ÌL/_)N¡\u0083\bL\u0096_ÁKü\fÄ";
      byte var3 = 9;
      byte var4 = 17;
      String[] var5 = recoveredField060;
      byte var6 = 8;
   }

   public static void b(String var0) {
      currentMouseName = var0;
   }

   public static String d() {
      return currentMouseName;
   }

}
