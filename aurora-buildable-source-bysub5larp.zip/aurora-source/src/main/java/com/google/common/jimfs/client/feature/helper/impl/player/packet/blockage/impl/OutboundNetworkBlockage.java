package com.google.common.jimfs.client.feature.helper.impl.player.packet.blockage.impl;

import com.google.common.jimfs.recovered.PacketDelayQueue;
import net.minecraft.class_2535;
import net.minecraft.class_2596;

public final class OutboundNetworkBlockage extends PacketDelayQueue {
   private static final OutboundNetworkBlockage INSTANCE = new OutboundNetworkBlockage();

   public static OutboundNetworkBlockage getInstance() {
      return INSTANCE;
   }

   @Override
   protected void b(class_2535 var1, class_2596 var2) {
      var1.method_10752(var2, null);
   }
}
