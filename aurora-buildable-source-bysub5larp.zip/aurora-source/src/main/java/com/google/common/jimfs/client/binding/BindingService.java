package com.google.common.jimfs.client.binding;

import com.google.common.collect.HashMultimap;
import com.google.common.collect.Multimap;
import com.google.common.jimfs.recovered.BindAction;
import com.google.common.jimfs.recovered.InputDevice;
import com.ibm.icu.impl.Pair;
import java.util.Collection;

public final class BindingService {
   private final Multimap<Pair<Integer, InputDevice>, BindAction> bindings = HashMultimap.create();

   public void b(int var1, BindAction var2, InputDevice var3) {
      this.bindings.put(Pair.of(var1, var3), var2);
   }

   public void b(BindAction var1) {
      this.bindings.entries().removeIf(var1x -> var1x.getValue() == var1);
   }

   public void b(int var1, InputDevice var2) {
      Pair var3 = Pair.of(var1, var2);
      Collection<BindAction> var4 = this.bindings.get(var3);
      var4.forEach(BindAction::f);
   }

}
