package com.google.common.jimfs.event.subscriber;

public interface IEventSubscriber {
   default boolean e() {
      return true;
   }
}
