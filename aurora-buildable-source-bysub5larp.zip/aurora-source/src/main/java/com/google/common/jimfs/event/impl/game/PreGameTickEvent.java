package com.google.common.jimfs.event.impl.game;

public final class PreGameTickEvent {
   private static String[] recoveredField114 = new String[5];

   public static void b(String[] var0) {
      recoveredField114 = var0;
   }

   public static String[] getScratchStrings() {
      return recoveredField114;
   }
}
