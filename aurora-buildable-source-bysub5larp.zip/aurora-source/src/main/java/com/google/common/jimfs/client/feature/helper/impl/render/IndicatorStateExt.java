package com.google.common.jimfs.client.feature.helper.impl.render;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;

@Environment(EnvType.CLIENT)
public interface IndicatorStateExt {
   boolean speedclient$hasIndicator();

   void speedclient$setIndicator(boolean var1);

   class_1297 speedclient$getEntity();

   void speedclient$setEntity(class_1297 var1);
}
