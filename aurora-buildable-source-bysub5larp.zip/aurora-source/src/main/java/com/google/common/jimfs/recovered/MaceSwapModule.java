package com.google.common.jimfs.recovered;

import com.google.common.jimfs.client.Constants;
import com.google.common.jimfs.client.feature.module.Module;
import com.google.common.jimfs.client.feature.module.ModuleCategory;
import com.google.common.jimfs.client.feature.module.property.Property;
import com.google.common.jimfs.client.feature.module.property.impl.bool.BooleanProperty;
import com.google.common.jimfs.client.feature.module.property.impl.mode.ModeProperty;
import com.google.common.jimfs.client.feature.module.property.impl.number.NumberProperty;
import com.google.common.jimfs.event.impl.game.PreGameTickEvent;
import com.google.common.jimfs.event.impl.game.player.PreUpdateEvent;
import com.google.common.jimfs.event.subscriber.Subscribe;
import com.google.common.jimfs.utility.misc.StringObfuscation;
import j2cc.Nativeify;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1893;
import net.minecraft.class_2868;

@Nativeify
public final class MaceSwapModule extends Module {
   private final BooleanProperty m = new BooleanProperty(StringObfuscation.a("Only When Falling"), true);
   private final NumberProperty o = new NumberProperty(StringObfuscation.a("Swap Delay"), 0.0, 0.0, 5.0, 1.0);
   private final BooleanProperty p = new BooleanProperty(StringObfuscation.a("Swap Back"), true);
   private final ModeProperty q = new ModeProperty(StringObfuscation.a("Enchant Priority"), MaceSwapModule.a.BREACH_PRIORITY);
   private final BooleanProperty r = new BooleanProperty(StringObfuscation.a("Shield Check"), true);
   private boolean s = false;
   private int t = -1;
   private int u = 0;
   
   

   public MaceSwapModule() {
      super(StringObfuscation.a("Mace Swap"), StringObfuscation.a("Automatically swaps to the best mace when falling on a target"), ModuleCategory.COMBAT);
      this.b(new Property[]{this.m, this.o, this.p, this.q, this.r});
   }

   @Override
   protected void g() {
      super.g();
      this.n();
   }

   @Override
   protected void h() {
      boolean var1 = false;
      if (this.s && this.t != -1 && Constants.MINECRAFT.field_1724 != null) {
         this.b(this.t);
      }

      this.n();
      super.h();
   }

   @Subscribe
   public void b(PreUpdateEvent var1) {
      boolean var2 = false;
      if (Constants.MINECRAFT.field_1724 != null && Constants.MINECRAFT.field_1687 != null && Constants.MINECRAFT.field_1761 != null) {
         if (Constants.MINECRAFT.field_1755 == null) {
            class_1799 var3 = Constants.MINECRAFT.field_1724.method_6047();
            if (!var3.method_31574(class_1802.field_49814)) {
               if (!this.m.isEnabled() || !(Constants.MINECRAFT.field_1724.field_6017 < 3.0)) {
                  class_1309 var4 = this.o();
                  if (var4 != null) {
                     if (!this.r.isEnabled() || !this.b(var4)) {
                        int var5 = this.p();
                        if (var5 != -1) {
                           if (this.t == -1) {
                              this.t = Constants.MINECRAFT.field_1724.method_31548().method_67532();
                           }

                           this.b(var5);
                           this.s = true;
                           this.u = 0;
                        }
                     }
                  }
               }
            }
         }
      }
   }

   @Subscribe
   public void b(PreGameTickEvent var1) {
      boolean var2 = true;
      if (this.s && this.p.isEnabled() && Constants.MINECRAFT.field_1724 != null) {
         if (this.u < ((Double)this.o.getValue()).intValue()) {
            this.u++;
         } else {
            if (this.t != -1) {
               this.b(this.t);
            }

            this.n();
         }
      }
   }

   private void n() {
      this.s = false;
      this.t = -1;
      this.u = 0;
   }

   private class_1309 o() {
      List<class_1309> var2 = Constants.MINECRAFT
         .field_1687
         .method_8390(
            class_1309.class,
            Constants.MINECRAFT.field_1724.method_5829().method_1014(4.0),
            var0 -> {
               boolean var1x = false;
               return var0 != Constants.MINECRAFT.field_1724
                  && var0.method_5805()
                  && !var0.method_29504()
                  && Constants.MINECRAFT.field_1724.method_6057(var0);
            }
         );
      boolean var1 = true;
      return var2.isEmpty()
         ? null
         : var2.stream().min(Comparator.comparingDouble(var0 -> (double)Constants.MINECRAFT.field_1724.method_5739(var0))).orElse(null);
   }

   private boolean b(class_1309 var1) {
      boolean var2 = true;
      if (var1 instanceof class_1657 var3 && var3.method_6039()) {
         return true;
      }

      return false;
   }

   private int p() {
      int var2 = -1;
      int var3 = -1;
      int var4 = 0;

      for (boolean var1 = false; var4 < 9; var4++) {
         class_1799 var5 = Constants.MINECRAFT.field_1724.method_31548().method_5438(var4);
         if (var5.method_31574(class_1802.field_49814)) {
            int var6 = EnchantmentLevelHelper.b(var5, class_1893.field_50158);
            int var7 = EnchantmentLevelHelper.b(var5, class_1893.field_50157);
            int var8 = this.b(var6, var7);
            if (var8 > var3) {
               var3 = var8;
               var2 = var4;
            }
         }
      }

      return var2;
   }

   private int b(int n, int n2) {
        boolean bl = true;
        return switch (((a)((Object)this.q.getValue())).ordinal()) {
            default -> throw new MatchException(null, null);
            case 0 -> n * 100 + n2;
            case 1 -> n2 * 100 + n;
            case 2 -> Math.max(n, n2) * 100 + Math.min(n, n2);
        };
    }

   private void b(int var1) {
      Constants.MINECRAFT.field_1724.method_31548().method_61496(var1);
      boolean var2 = false;
      if (Constants.MINECRAFT.method_1562() != null) {
         Constants.MINECRAFT.method_1562().method_52787(new class_2868(var1));
      }
   }

   public static enum a {
   BREACH_PRIORITY(),
   DENSITY_PRIORITY(),
   BEST();

      
   }
}
