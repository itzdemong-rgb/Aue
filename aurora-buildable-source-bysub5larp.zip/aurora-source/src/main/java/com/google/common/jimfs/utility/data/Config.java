package com.google.common.jimfs.utility.data;

import com.google.common.jimfs.client.feature.module.property.Property;
import com.google.common.jimfs.recovered.BindAction;
import java.util.Date;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class Config implements BindAction {
   private final String recoveredField025;
   private String recoveredField091;
   private boolean recoveredField141;
   private Date createdAt;
   private static String recoveredField185;

   public Config(String var1) {
      this.recoveredField025 = var1;
   }

   public Config(String var1, String var2, boolean var3, Date var4) {
      String var10000 = g();
      String var5 = var10000;
      this.recoveredField025 = var1;
      this.recoveredField091 = var2;
      this.recoveredField141 = var3;
      this.createdAt = var4;
      if (var5 != null) {
         Property.c(!Property.j());
      }
   }

   @Override
   public void f() {
   }

   public Date getCreatedAt() {
      return this.createdAt;
   }

   public boolean recoveredMethod110() {
      return this.recoveredField141;
   }

   public String d() {
      return this.recoveredField025;
   }

   public String e() {
      return this.recoveredField091;
   }

   public static void b(String var0) {
      recoveredField185 = var0;
   }

   public static String g() {
      return recoveredField185;
   }

}
