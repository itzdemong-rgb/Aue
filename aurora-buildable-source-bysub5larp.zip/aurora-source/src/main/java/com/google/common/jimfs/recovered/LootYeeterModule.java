package com.google.common.jimfs.recovered;

import com.google.common.jimfs.client.Constants;
import com.google.common.jimfs.client.feature.module.Module;
import com.google.common.jimfs.client.feature.module.ModuleCategory;
import com.google.common.jimfs.client.feature.module.property.Property;
import com.google.common.jimfs.client.feature.module.property.impl.KeybindProperty;
import com.google.common.jimfs.client.feature.module.property.impl.number.NumberProperty;
import com.google.common.jimfs.event.impl.game.PreGameTickEvent;
import com.google.common.jimfs.event.subscriber.Subscribe;
import com.google.common.jimfs.utility.misc.StringObfuscation;
import com.google.common.jimfs.utility.player.PlayerUtility;
import j2cc.Nativeify;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_465;

@Nativeify
public final class LootYeeterModule extends Module {
   private final KeybindProperty m;
   private final NumberProperty o;
   private final NumberProperty p;
   private final NumberProperty q;
   private int r = 0;
   
   

   public LootYeeterModule() {
      super(StringObfuscation.a("Loot Yeeter"), StringObfuscation.a("Cttlt htetk Liemex"), ModuleCategory.COMBAT);
      this.m = new KeybindProperty(StringObfuscation.a("Activate Key"), 88);
      this.o = new NumberProperty(StringObfuscation.a("Swit Totem"), 5.0, 0.0, 36.0, 1.0);
      this.p = new NumberProperty(StringObfuscation.a("Swit Pearl"), 16.0, 0.0, 576.0, 1.0);
      this.q = new NumberProperty(StringObfuscation.a("Drop tupay"), 1.0, 0.0, 20.0, 1.0);
      this.b(new Property[]{this.m, this.o, this.p, this.q});
   }

   @Override
   protected void g() {
      super.g();
      this.r = 0;
   }

   @Subscribe
   public void b(PreGameTickEvent var1) {
      boolean var2 = true;
      if (Constants.MINECRAFT.field_1724 != null && Constants.MINECRAFT.field_1687 != null) {
         if (Constants.MINECRAFT.field_1755 != null) {
            if (Constants.MINECRAFT.field_1755 instanceof class_465) {
               int var3 = (Integer)this.m.getValue();
               boolean var4 = false;
               if (var3 != -1) {
                  if (var3 >= 0 && var3 <= 7) {
                     var4 = PlayerUtility.c(var3);
                  } else {
                     var4 = PlayerUtility.isMouseButtonPressed(var3);
                  }
               }

               if (!var4) {
                  this.r = 0;
               } else if (this.r > 0) {
                  this.r--;
               } else {
                  int var5 = this.b(class_1802.field_8288);
                  int var6 = this.b(class_1802.field_8634);
                  int var7 = ((Double)this.o.getValue()).intValue();
                  int var8 = ((Double)this.p.getValue()).intValue();
                  boolean var9 = false;
                  if (var5 > var7) {
                     int var10 = this.c(class_1802.field_8288);
                     if (var10 != -1) {
                        Constants.MINECRAFT
                           .field_1761
                           .method_2906(
                              Constants.MINECRAFT.field_1724.field_7498.field_7763,
                              var10,
                              1,
                              class_1713.field_7795,
                              Constants.MINECRAFT.field_1724
                           );
                        var9 = true;
                     }
                  }

                  if (!var9 && var6 > var8) {
                     int var11 = this.c(class_1802.field_8634);
                     if (var11 != -1) {
                        Constants.MINECRAFT
                           .field_1761
                           .method_2906(
                              Constants.MINECRAFT.field_1724.field_7498.field_7763,
                              var11,
                              1,
                              class_1713.field_7795,
                              Constants.MINECRAFT.field_1724
                           );
                        var9 = true;
                     }
                  }

                  if (var9) {
                     this.r = ((Double)this.q.getValue()).intValue();
                  }
               }
            }
         }
      }
   }

   private int b(class_1792 var1) {
      boolean var2 = false;
      if (Constants.MINECRAFT.field_1724 == null) {
         return 0;
      } else {
         int var3 = 0;

         for (int var4 = 0; var4 < Constants.MINECRAFT.field_1724.method_31548().method_5439(); var4++) {
            class_1799 var5 = Constants.MINECRAFT.field_1724.method_31548().method_5438(var4);
            if (var5.method_31574(var1)) {
               var3 += var5.method_7947();
            }
         }

         return var3;
      }
   }

   private int c(class_1792 var1) {
      boolean var2 = false;
      if (Constants.MINECRAFT.field_1724 == null) {
         return -1;
      } else {
         for (int var3 = 9; var3 < 36; var3++) {
            if (Constants.MINECRAFT.field_1724.field_7512.method_7611(var3).method_7677().method_31574(var1)) {
               return var3;
            }
         }

         return -1;
      }
   }

}
