package com.google.common.jimfs.event.impl.game.server;

public final class ServerDisconnectEvent {
}
