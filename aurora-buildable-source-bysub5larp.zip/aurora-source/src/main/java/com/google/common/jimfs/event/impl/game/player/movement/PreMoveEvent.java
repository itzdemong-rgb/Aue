package com.google.common.jimfs.event.impl.game.player.movement;

import com.google.common.jimfs.recovered.CancellableEvent;
import net.minecraft.class_243;

public final class PreMoveEvent extends CancellableEvent {
   private final float recoveredField148;
   private final class_243 recoveredField189;

   public PreMoveEvent(float var1, class_243 var2) {
      this.recoveredField148 = var1;
      this.recoveredField189 = var2;
   }
}
