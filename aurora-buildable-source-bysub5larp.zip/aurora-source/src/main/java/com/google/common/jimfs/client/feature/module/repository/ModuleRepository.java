package com.google.common.jimfs.client.feature.module.repository;

import com.google.common.collect.ClassToInstanceMap;
import com.google.common.collect.ImmutableClassToInstanceMap;
import com.google.common.collect.ImmutableClassToInstanceMap.Builder;
import com.google.common.jimfs.client.feature.module.Module;
import com.google.common.jimfs.client.feature.module.property.Property;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public final class ModuleRepository {
   private final ClassToInstanceMap<Module> modulesByClass;
   private final List<Module> moduleList;
   private static Property[] scratchProperties;

   public ModuleRepository(ClassToInstanceMap<Module> var1, List<Module> var2) {
      this.modulesByClass = var1;
      this.moduleList = var2;
   }

   public <T extends Module> T a(Class<T> var1) {
      return this.modulesByClass.getInstance(var1);
   }

   public Collection<Module> getModules() {
      return this.modulesByClass.values();
   }

   public static ModuleRepository b(Module[] var0) {
      ModuleRepository.a var2 = builder();
      boolean var1 = true;

      for (Module var6 : var0) {
         var2.b(var6);
      }

      return var2.build();
   }

   public static ModuleRepository.a builder() {
      return new ModuleRepository.a();
   }

   public static void b(Property[] var0) {
      scratchProperties = var0;
   }

   public static Property[] getScratchProperties() {
      return scratchProperties;
   }

   public static class a {
      private final Builder<Module> builder = ImmutableClassToInstanceMap.builder();
      private final List<Module> moduleList = new ArrayList();

      public ModuleRepository.a b(Module var1) {
         this.builder.put((Class<Module>)(Class<?>)var1.getClass(), var1);
         this.moduleList.add(var1);
         return this;
      }

      public ModuleRepository build() {
         return new ModuleRepository(this.builder.build(), this.moduleList);
      }
   }
}
