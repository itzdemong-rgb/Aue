package com.google.common.jimfs.client.feature.helper.impl.render;

import com.google.common.jimfs.recovered.ClientEventSubscriber;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1309;

@Environment(EnvType.CLIENT)
public final class RingHelper implements ClientEventSubscriber {
   private class_1309 targetEntity;
   private long targetSince;
   private long fadeStartedAt;
   private int color = -1;
   private static RingHelper instance;

   private RingHelper() {
   }

   public class_1309 getTarget() {
      if (this.targetEntity != null && !this.targetEntity.method_31481() && this.targetEntity.method_5805()) {
         if (System.currentTimeMillis() - this.targetSince > 1200L) {
            this.targetEntity = null;
            return null;
         } else {
            return this.targetEntity;
         }
      } else {
         this.targetEntity = null;
         return null;
      }
   }

   public float getOpacity() {
      if (this.targetEntity == null) {
         return 0.0F;
      } else {
         long var1 = System.currentTimeMillis();
         long var3 = var1 - this.targetSince;
         if (var3 < 150L) {
            long var7 = var1 - this.fadeStartedAt;
            return var7 < 200L ? (float)var7 / 200.0F : 1.0F;
         } else {
            long var5 = var3 - 150L;
            if (var5 > 1000L) {
               this.targetEntity = null;
               return 0.0F;
            } else {
               return 1.0F - (float)var5 / 1000.0F;
            }
         }
      }
   }

   public int getColor() {
      return this.color;
   }

   public static RingHelper getInstance() {
      return instance;
   }

   public static void initialize() {
      instance = new RingHelper();
   }
}
