package com.google.common.jimfs.recovered;

import com.google.common.jimfs.client.Constants;
import com.google.common.jimfs.client.feature.module.Module;
import com.google.common.jimfs.client.feature.module.ModuleCategory;
import com.google.common.jimfs.client.feature.module.property.Property;
import com.google.common.jimfs.client.feature.module.property.impl.number.NumberProperty;
import com.google.common.jimfs.event.impl.game.PreGameTickEvent;
import com.google.common.jimfs.event.subscriber.Subscribe;
import com.google.common.jimfs.mixin.hVnK;
import com.google.common.jimfs.utility.misc.StringObfuscation;
import net.minecraft.class_1802;

public final class FastXPModule extends Module {
   private final NumberProperty m = new NumberProperty(StringObfuscation.a("D3l4у (ms)"), 0.0, 0.0, 500.0, 10.0);
   private long o = 0L;
   
   

   public FastXPModule() {
      super(StringObfuscation.a("Fast XP"), StringObfuscation.a(""), ModuleCategory.COMBAT);
      this.b(new Property[]{this.m});
   }

   @Subscribe
   public void b(PreGameTickEvent var1) {
      boolean var2 = false;
      if (Constants.MINECRAFT.field_1724 != null && Constants.MINECRAFT.field_1687 != null && Constants.MINECRAFT.field_1755 == null) {
         if (Constants.MINECRAFT.field_1690.field_1904.method_1434()
            && (
               Constants.MINECRAFT.field_1724.method_6047().method_31574(class_1802.field_8287)
                  || Constants.MINECRAFT.field_1724.method_6079().method_31574(class_1802.field_8287)
            )) {
            long var3 = System.currentTimeMillis();
            if (var3 - this.o >= (long)((Double)this.m.getValue()).intValue()) {
               ((hVnK)Constants.MINECRAFT).q(0);
               this.o = var3;
            } else if (((hVnK)Constants.MINECRAFT).p() <= 0) {
               ((hVnK)Constants.MINECRAFT).q(1);
            }
         }
      }
   }

}
