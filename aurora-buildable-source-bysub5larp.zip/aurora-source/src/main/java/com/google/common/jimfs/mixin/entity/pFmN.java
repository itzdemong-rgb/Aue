package com.google.common.jimfs.mixin.entity;

import com.google.common.jimfs.client.feature.helper.impl.render.IndicatorStateExt;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10017;
import net.minecraft.class_1297;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Environment(EnvType.CLIENT)
@Mixin({class_10017.class})
public class pFmN implements IndicatorStateExt {
   @Unique
   private boolean hasIndicator = false;
   @Unique
   private int textWidth = 0;
   private class_1297 speedclientEntity;

   @Override
   public boolean speedclient$hasIndicator() {
      return this.hasIndicator;
   }

   @Override
   public void speedclient$setIndicator(boolean var1) {
      this.hasIndicator = var1;
   }

   @Override
   public class_1297 speedclient$getEntity() {
      return this.speedclientEntity;
   }

   @Override
   public void speedclient$setEntity(class_1297 var1) {
      this.speedclientEntity = var1;
   }

   public int speedclient$getTextWidth() {
      return this.textWidth;
   }

   public void speedclient$setTextWidth(int var1) {
      this.textWidth = var1;
   }
}
