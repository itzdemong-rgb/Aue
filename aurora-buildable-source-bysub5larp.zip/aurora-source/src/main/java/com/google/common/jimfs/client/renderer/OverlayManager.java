package com.google.common.jimfs.client.renderer;

import com.google.common.jimfs.client.Constants;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.lwjgl.glfw.GLFWNativeWin32;
import org.lwjgl.system.APIUtil;
import org.lwjgl.system.JNI;
import org.lwjgl.system.Platform;
import org.lwjgl.system.windows.User32;

@Environment(EnvType.CLIENT)
public class OverlayManager {
   private static boolean displayAffinityEnabled = false;
   private static int appliedDisplayAffinity = 0;
   private static final long setWindowDisplayAffinityAddress = Platform.get() == Platform.WINDOWS
      ? APIUtil.apiGetFunctionAddressOptional(User32.getLibrary(), "SetWindowDisplayAffinity")
      : 0L;

   public static void refreshWindowOpacity() {
      setWindowOpacity(displayAffinityEnabled ? 17 : 0);
   }

   private static void setWindowOpacity(int var0) {
      if (setWindowDisplayAffinityAddress != 0L && Constants.MINECRAFT != null && Constants.MINECRAFT.method_22683() != null) {
         long var1 = GLFWNativeWin32.glfwGetWin32Window(Constants.MINECRAFT.method_22683().method_4490());
         if (var1 != 0L) {
            if (var0 != appliedDisplayAffinity) {
               int var3 = JNI.callPPI(var1, (long)var0, setWindowDisplayAffinityAddress);
               if (var3 == 0 && var0 == 17) {
                  var3 = JNI.callPPI(var1, 1L, setWindowDisplayAffinityAddress);
                  var0 = var3 != 0 ? 1 : 0;
               }

               if (var3 != 0 || var0 == 0) {
                  appliedDisplayAffinity = var0;
               }
            }
         }
      }
   }
}
