package com.google.common.jimfs.client.renderer.world;

import com.google.common.jimfs.client.Constants;
import com.google.common.jimfs.utility.render.ColorUtility;
import com.google.common.jimfs.utility.render.Emitter;
import java.util.Objects;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4587.class_4665;
import org.joml.Vector3f;

@Environment(EnvType.CLIENT)
public final class WorldRenderer {
   private final class_4184 camera;
   private final class_4597 vertexConsumers;

   public WorldRenderer(class_4184 var1, class_4597 var2) {
      this.camera = var1;
      this.vertexConsumers = var2;
   }

   public WorldRenderer(class_4597 var1) {
      this(Constants.MINECRAFT.field_1773.method_19418(), var1);
   }

   @Override
   public boolean equals(Object var1) {
      if (var1 == this) {
         return true;
      } else if (var1 != null && var1.getClass() == this.getClass()) {
         WorldRenderer var2 = (WorldRenderer)var1;
         return Objects.equals(this.camera, var2.camera) && Objects.equals(this.vertexConsumers, var2.vertexConsumers);
      } else {
         return false;
      }
   }

   @Override
   public int hashCode() {
      return Objects.hash(this.camera, this.vertexConsumers);
   }

   @Override
   public String toString() {
      return "WorldRenderer[camera=" + this.camera + ", vcp=" + this.vertexConsumers + ']';
   }

   public void a(class_4587 var1, class_1921 var2, class_243 var3, class_243 var4, int var5) {
      class_4588 var6 = this.vertexConsumers.method_73477(var2);
      class_4665 var7 = var1.method_23760();
      Vector3f var8 = var3.method_1020(this.camera.method_71156()).method_46409();
      float var9 = var8.x;
      float var10 = var8.y;
      float var11 = var8.z;
      int[] var12 = ColorUtility.getColorChannels(var5);
      float var13 = (float)var12[0] / 255.0F;
      float var14 = (float)var12[1] / 255.0F;
      float var15 = (float)var12[2] / 255.0F;
      float var16 = (float)var12[3] / 255.0F;
      Emitter.a(
         var7,
         var6,
         var9 + 0.0F,
         var10 + 0.0F,
         var11 + 0.0F,
         var13,
         var14,
         var15,
         var16,
         (float)((double)var9 + var4.method_10216()),
         var10 + 0.0F,
         var11 + 0.0F,
         var13,
         var14,
         var15,
         var16,
         (float)((double)var9 + var4.method_10216()),
         var10 + 0.0F,
         (float)((double)var11 + var4.method_10215()),
         var13,
         var14,
         var15,
         var16,
         var9 + 0.0F,
         var10 + 0.0F,
         (float)((double)var11 + var4.method_10215()),
         var13,
         var14,
         var15,
         var16,
         var9 + 0.0F,
         (float)((double)var10 + var4.method_10214()),
         var11 + 0.0F,
         var13,
         var14,
         var15,
         var16,
         (float)((double)var9 + var4.method_10216()),
         (float)((double)var10 + var4.method_10214()),
         var11 + 0.0F,
         var13,
         var14,
         var15,
         var16,
         (float)((double)var9 + var4.method_10216()),
         (float)((double)var10 + var4.method_10214()),
         (float)((double)var11 + var4.method_10215()),
         var13,
         var14,
         var15,
         var16,
         var9 + 0.0F,
         (float)((double)var10 + var4.method_10214()),
         (float)((double)var11 + var4.method_10215()),
         var13,
         var14,
         var15,
         var16
      );
   }
}
