package com.google.common.jimfs.client.renderer.image;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class NVGImageRenderer {
}
