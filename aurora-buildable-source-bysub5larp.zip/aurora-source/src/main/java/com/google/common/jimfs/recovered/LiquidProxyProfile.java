package com.google.common.jimfs.recovered;

public final class LiquidProxyProfile extends GenericServerProfile {

   public LiquidProxyProfile() {
      super("LiquidProxy");
   }
}
