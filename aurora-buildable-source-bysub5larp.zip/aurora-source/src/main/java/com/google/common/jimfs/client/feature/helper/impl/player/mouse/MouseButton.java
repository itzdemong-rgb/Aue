package com.google.common.jimfs.client.feature.helper.impl.player.mouse;

import com.google.common.jimfs.mixin.input.KeyBindingAccessor;
import net.minecraft.class_304;

public final class MouseButton {
   private final class_304 keyBinding;
   private boolean queuedPress;
   private boolean blocked;
   private int pressTicks;
   private boolean ready = true;
   private static int[] recoveredField214 = new int[]{0};

   public MouseButton(class_304 var1) {
      this.keyBinding = var1;
   }

   public boolean consumePress() {
      boolean var1 = true;
      if (this.blocked) {
         return false;
      } else {
         boolean var2 = false;
         if (this.queuedPress) {
            var2 = true;
            this.queuedPress = false;
         }

         return this.keyBinding.method_1436() || var2;
      }
   }

   public boolean isPressed() {
      boolean var1 = false;
      return this.blocked ? false : this.keyBinding.method_1434() || this.queuedPress || this.pressTicks > 0;
   }

   public void tick() {
      boolean var1 = false;
      if (this.pressTicks > 0) {
         this.pressTicks--;
      }

      if (this.keyBinding.method_1434() || this.pressTicks == 0) {
         this.ready = true;
      }

      this.queuedPress = false;
      this.blocked = false;
   }

   public boolean d() {
      boolean var1 = true;
      return this.ready || ((KeyBindingAccessor)this.keyBinding).kW() > 0;
   }

   public class_304 e() {
      return this.keyBinding;
   }

   public static void b(int[] var0) {
      recoveredField214 = var0;
   }

   public static int[] f() {
      return recoveredField214;
   }

}
