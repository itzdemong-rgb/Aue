package com.google.common.jimfs.mixin.entity;

import com.google.common.jimfs.event.EventDispatcher;
import com.google.common.jimfs.event.impl.game.input.SlotChangeEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1661;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({class_1661.class})
public final class PlayerInventorySlotMixin {
   @Inject(
      method = {"setSelectedSlot"},
      at = {@At(
         value = "FIELD",
         target = "Lnet/minecraft/entity/player/PlayerInventory;selectedSlot:I"
      )}
   )
   private void a(int var1, CallbackInfo var2) {
      EventDispatcher.b(new SlotChangeEvent(var1));
   }
}
