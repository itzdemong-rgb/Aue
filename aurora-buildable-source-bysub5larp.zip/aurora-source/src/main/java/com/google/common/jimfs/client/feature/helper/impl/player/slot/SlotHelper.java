package com.google.common.jimfs.client.feature.helper.impl.player.slot;

import com.google.common.jimfs.client.Constants;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_746;

public final class SlotHelper {
   private int selectedSlot;
   private int originalSlot;
   private boolean overrideActive;
   private int swapCount;
   private int tickCount;
   private SlotHelper.a slotMode = SlotHelper.a.DEFAULT;
   private static SlotHelper instance;
   private static String scratchString = "V56bVc";

   private SlotHelper() {
   }

   public void setSelectedSlot(int var1) {
      this.selectedSlot = var1;
   }

   public void a(boolean var1, boolean var2) {
      boolean var3 = true;
      if (this.overrideActive && (!var2 || Constants.MINECRAFT.method_18506() == null && Constants.MINECRAFT.field_1755 == null)) {
         if (var1 && this.swapCount != this.tickCount) {
            Constants.MINECRAFT.field_1724.method_31548().method_61496(this.selectedSlot);
            this.slotMode = SlotHelper.a.DEFAULT;
            this.overrideActive = false;
         } else {
            Constants.MINECRAFT.field_1724.method_31548().method_61496(this.originalSlot);
         }
      }
   }

   public void tick() {
      this.a(true, true);
      this.tickCount++;
   }

   public class_1799 a(class_746 var1) {
      boolean var2 = false;
      return this.overrideActive && this.slotMode != SlotHelper.a.NONE
         ? (class_1799)var1.method_31548().method_67533().get(this.selectedSlot)
         : var1.method_6047();
   }

   public int a(class_1661 var1) {
      boolean var2 = false;
      return this.overrideActive && this.slotMode == SlotHelper.a.FULL ? this.selectedSlot : var1.method_67532();
   }

   public boolean isSlotOverrideActive() {
      return this.overrideActive;
   }

   public int getSelectedSlot() {
      return this.selectedSlot;
   }

   public SlotHelper.a getSlotMode() {
      return this.slotMode;
   }

   public static SlotHelper getInstance() {
      return instance;
   }

   public static void initialize() {
      instance = new SlotHelper();
   }

   public static void b(String var0) {
      scratchString = var0;
   }

   public static String d() {
      return scratchString;
   }

   public static enum a {
   NONE(),
   DEFAULT(),
   FULL();
      private static String recoveredField091 = "TEsph";

      

      public static void b(String var0) {
         recoveredField091 = var0;
      }

      public static String getScratchString() {
         return recoveredField091;
      }
   }
}
