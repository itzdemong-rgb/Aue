package com.google.common.jimfs.event.impl.game.player.movement.step;

import com.google.common.jimfs.recovered.CancellableEvent;
import net.minecraft.class_243;

public final class StepSuccessEvent extends CancellableEvent {
   private class_243 recoveredField164;
   private class_243 position;

   public StepSuccessEvent(class_243 var1, class_243 var2) {
      this.recoveredField164 = var1;
      this.position = var2;
   }

   public class_243 getPosition() {
      return this.position;
   }
}
