package com.google.common.jimfs.utility.crypto;

import j2cc.Nativeify;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;

@Nativeify
public final class LocalConfigIdentity {
   private static volatile String recoveredField091;
   
   

   private LocalConfigIdentity() {
   }

   public static String getMachineIdentity() {
      boolean var0 = false;
      if (recoveredField091 != null) {
         return recoveredField091;
      } else {
         synchronized (LocalConfigIdentity.class) {
            if (recoveredField091 == null) {
               recoveredField091 = collectMachineAttributes();
            }
         }

         return recoveredField091;
      }
   }

   private static String collectMachineAttributes() {
      ArrayList var1 = new ArrayList(4);
      boolean var0 = true;
      String var2 = b("baseboard", "serialnumber");
      var1.add("baseboard:" + (var2.isEmpty() ? "NONE" : var2));
      String var3 = b("cpu", "processorid");
      var1.add("cpu:" + (var3.isEmpty() ? "NONE" : var3));
      String var4 = b("diskdrive", "serialnumber");
      var1.add("diskdrive:" + (var4.isEmpty() ? "NONE" : var4));
      String var5 = c("HKLM\\SOFTWARE\\Microsoft\\Cryptography", "MachineGuid");
      var1.add("guid:" + (var5.isEmpty() ? "NONE" : var5));
      String var6 = String.join("|", var1);
      return b(var6);
   }

   private static String b(String var0, String var1) {
      boolean var2 = true;

      try {
         ProcessBuilder var3 = new ProcessBuilder("cmd.exe", "/c", "wmic " + var0 + " get " + var1);
         var3.redirectErrorStream(true);
         Process var4 = var3.start();
         String var5 = "";

         try (BufferedReader var6 = new BufferedReader(new InputStreamReader(var4.getInputStream(), StandardCharsets.UTF_8))) {
            boolean var8 = false;

            String var7;
            while ((var7 = var6.readLine()) != null) {
               String var9 = var7.trim();
               if (!var9.isEmpty()) {
                  if (var8) {
                     var5 = var9;
                     break;
                  }

                  var8 = true;
               }
            }
         }

         var4.waitFor();
         return var5;
      } catch (Exception var12) {
         return "";
      }
   }

   private static String c(String var0, String var1) {
      boolean var2 = true;

      try {
         ProcessBuilder var3 = new ProcessBuilder("reg", "query", var0, "/v", var1);
         var3.redirectErrorStream(true);
         Process var4 = var3.start();
         String var5 = "";

         String var7;
         try (BufferedReader var6 = new BufferedReader(new InputStreamReader(var4.getInputStream(), StandardCharsets.UTF_8))) {
            while ((var7 = var6.readLine()) != null) {
               String var8 = var7.trim();
               if (var8.contains("REG_SZ") || var8.contains("REG_EXPAND_SZ")) {
                  String[] var9 = var8.split("\\s{2,}");
                  if (var9.length >= 3) {
                     var5 = var9[var9.length - 1].trim();
                     break;
                  }
               }
            }
         }

         var4.waitFor();
         return var5;
      } catch (Exception var12) {
         return "";
      }
   }

   private static String b(String var0) {
      boolean var1 = true;

      try {
         MessageDigest var2 = MessageDigest.getInstance("SHA-256");
         byte[] var3 = var2.digest(var0.getBytes(StandardCharsets.UTF_8));
         StringBuilder var4 = new StringBuilder(var3.length * 2);

         for (byte var8 : var3) {
            var4.append(String.format("%02x", var8 & 255));
         }

         return var4.toString();
      } catch (Exception var9) {
         return "hash:" + var0.hashCode();
      }
   }

}
