package com.google.common.jimfs.client.renderer.repository;

import java.util.HashMap;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class ImageRepository {
   private static final HashMap recoveredField029 = new HashMap();
}
