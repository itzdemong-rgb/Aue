package com.google.common.jimfs.recovered;

public class InputPressEvent {
   private final int code;

   protected InputPressEvent(int var1) {
      this.code = var1;
   }

   public int getCode() {
      return this.code;
   }
}
