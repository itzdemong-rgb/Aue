package com.google.common.jimfs.recovered;

import com.google.common.jimfs.client.feature.module.property.Property;
import java.util.List;

public final class PropertyList extends Property {
   private PropertyList(CharSequence name) { super(name); }
   public List<Property> getProperties() {
      return (List)this.getValue();
   }
}
