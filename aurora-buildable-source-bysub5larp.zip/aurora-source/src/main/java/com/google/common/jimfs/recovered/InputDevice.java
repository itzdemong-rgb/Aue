package com.google.common.jimfs.recovered;

public enum InputDevice {
   KEYBOARD(),
   MOUSE();

   
}
