package com.google.common.jimfs.recovered;

import java.util.Random;

public final class RandomInterpolation {
   public static final Random RANDOM = new Random();
   public static double currentRandomValue = RANDOM.nextDouble();

   public static double b(double var0, double var2) {
      return b(var0, var2, RANDOM.nextDouble());
   }

   public static double b(double var0, double var2, double var4) {
      boolean var6 = true;
      return var0 == var2 ? var0 : var0 + (var2 - var0) * var4;
   }

   public static void refreshRandomValue() {
      currentRandomValue = RANDOM.nextDouble();
   }

}
