package com.google.common.jimfs.client.feature.module.property.impl.mode;

import com.google.common.jimfs.client.feature.module.Module;
import com.google.common.jimfs.client.feature.module.property.Property;
import com.google.common.jimfs.recovered.ModuleModeHandler;

public final class ModeProperty extends Property {
   private final Enum[] modes;
   private Module module;
   private static String[] j;

   public ModeProperty(CharSequence var1, Enum var2) {
      super(var1);
      this.a(var2);
      this.modes = this.getModes();
   }

   private Enum[] getModes() {
        return (Enum[])((Enum)this.getValue()).getClass().getEnumConstants();
    }

   public void b(int var1) {
      boolean var2 = true;
      if (this.module != null && this.module.isEnabled()) {
         this.module.i().forEach(ModuleModeHandler::onDisabled);
      }

      this.a(this.modes[var1]);
      if (this.module != null) {
         for (ModuleModeHandler var4 : this.module.i()) {
            if (var4.d().ordinal() == var1 && this.module.isEnabled()) {
               var4.onEnabled();
               break;
            }
         }
      }
   }

   public void a(boolean var1) {
      int var3 = ((Enum)this.getValue()).ordinal();
      boolean var2 = false;
      int var4 = (var3 + (var1 ? 1 : this.modes.length - 1)) % this.modes.length;
      this.b(var4);
   }

   public static void b(String[] var0) {
      j = var0;
   }

   public static String[] getScratchStrings() {
      return j;
   }

}
