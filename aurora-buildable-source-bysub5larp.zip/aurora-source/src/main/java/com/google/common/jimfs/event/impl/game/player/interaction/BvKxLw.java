package com.google.common.jimfs.event.impl.game.player.interaction;

public final class BvKxLw {
   private int recoveredField064;

   public BvKxLw(int var1) {
      this.recoveredField064 = var1;
   }

   public int getCooldown() {
      return this.recoveredField064;
   }
}
