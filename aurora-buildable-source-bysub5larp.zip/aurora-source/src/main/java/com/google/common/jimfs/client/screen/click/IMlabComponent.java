package com.google.common.jimfs.client.screen.click;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_11908;
import net.minecraft.class_332;

@Environment(EnvType.CLIENT)
public interface IMlabComponent {
   default void init() {
   }

   default void close() {
   }

   void render(class_332 var1, int var2, int var3, float var4);

   void mouseClicked(double var1, double var3, int var5);

   default void mouseScrolled(double var1, double var3, double var5, double var7) {
   }

   default void mouseReleased(double var1, double var3, int var5) {
   }

   default void mouseDragged(double var1, double var3, int var5) {
   }

   default void keyPressed(class_11908 var1) {
   }

   default void charTyped(char var1, int var2) {
   }
}
