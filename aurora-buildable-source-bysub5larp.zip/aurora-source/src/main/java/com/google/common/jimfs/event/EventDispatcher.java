package com.google.common.jimfs.event;

import com.google.common.jimfs.recovered.ReflectiveEventBus;
import com.google.common.jimfs.utility.misc.StringObfuscation;

public final class EventDispatcher {
   private static final ReflectiveEventBus EVENT_BUS = new ReflectiveEventBus();
   private static boolean recoveredField141;

   public static void a(Object var0) {
      EVENT_BUS.b(var0);
   }

   public static void b(Object var0) {
      EVENT_BUS.c(var0);
      StringObfuscation.wipeScratchState();
   }

   static {
      b(true);
   }

   public static void b(boolean var0) {
      recoveredField141 = var0;
   }

   public static boolean recoveredMethod084() {
      return recoveredField141;
   }

   public static boolean recoveredMethod110() {
      boolean var0 = recoveredMethod084();
      return !var0;
   }
}
