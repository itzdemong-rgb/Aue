package com.google.common.jimfs.mixin.input;

import com.google.common.jimfs.client.feature.helper.impl.player.slot.SlotHelper;
import com.google.common.jimfs.event.EventDispatcher;
import com.google.common.jimfs.event.impl.game.input.MouseUpdateEvent;
import com.google.common.jimfs.event.impl.press.MousePressEvent;
import com.llamalad7.mixinextras.sugar.Local;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_11910;
import net.minecraft.class_1661;
import net.minecraft.class_312;
import net.minecraft.class_315;
import net.minecraft.class_746;
import net.minecraft.class_9928;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({class_312.class})
public final class MouseEventMixin {
   @Shadow
   private double field_1789;
   @Shadow
   private double field_1787;
   @Unique
   private MouseUpdateEvent dG;
   @Unique
   private boolean bN;

   private MouseEventMixin() {
   }

   @Inject(
      method = {"onMouseButton"},
      at = {@At("HEAD")}
   )
   private void kS(long var1, class_11910 var3, int var4, CallbackInfo var5) {
      if (var4 == 1) {
         if (var3.comp_4801() == -1) {
            return;
         }

         EventDispatcher.b(new MousePressEvent(var3.comp_4801()));
      }
   }

   @Redirect(
      method = {"onMouseScroll"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/entity/player/PlayerInventory;setSelectedSlot(I)V"
      )
   )
   private void rF(class_1661 var1, int var2, @Local int var3) {
      SlotHelper var4 = SlotHelper.getInstance();
      if (var4.isSlotOverrideActive()) {
         if (var4.getSlotMode() != SlotHelper.a.NONE) {
            var4.setSelectedSlot(class_9928.method_61972((double)var3, var4.getSelectedSlot(), class_1661.method_7368()));
         }
      } else {
         var1.method_61496(var2);
      }
   }

   @Redirect(
      method = {"updateMouse"},
      at = @At(
         value = "FIELD",
         target = "Lnet/minecraft/client/option/GameOptions;smoothCameraEnabled:Z",
         opcode = 180
      )
   )
   private boolean vN(class_315 var1, @Local(ordinal = 3) double var2) {
      this.dG = new MouseUpdateEvent(this.field_1789, this.field_1787, var2, this.bN);
      EventDispatcher.b(this.dG);
      return var1.field_1914 && !this.dG.isHandled();
   }

   @Redirect(
      method = {"tick"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/Mouse;isCursorLocked()Z"
      )
   )
   private boolean hT(class_312 var1) {
      return var1.method_1613();
   }

   @Inject(
      method = {"updateMouse"},
      at = {@At("TAIL")}
   )
   private void xR(double var1, CallbackInfo var3) {
      this.bN = false;
      this.dG = null;
   }

   @Redirect(
      method = {"updateMouse"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/network/ClientPlayerEntity;isUsingSpyglass()Z"
      )
   )
   private boolean kW(class_746 var1) {
      return var1.method_31550() && (this.dG == null || !this.dG.isHandled());
   }

   @Redirect(
      method = {"updateMouse"},
      at = @At(
         value = "FIELD",
         target = "Lnet/minecraft/client/Mouse;cursorDeltaX:D",
         opcode = 180
      )
   )
   private double fT(class_312 var1) {
      return this.dG == null ? 0.0 : this.dG.getDeltaX();
   }

   @Redirect(
      method = {"updateMouse"},
      at = @At(
         value = "FIELD",
         target = "Lnet/minecraft/client/Mouse;cursorDeltaY:D",
         opcode = 180
      )
   )
   private double qP(class_312 var1) {
      return this.dG == null ? 0.0 : this.dG.getDeltaY();
   }

   @Inject(
      method = {"onCursorPos"},
      at = {@At("HEAD")}
   )
   private void mW(long var1, double var3, double var5, CallbackInfo var7) {
   }
}
