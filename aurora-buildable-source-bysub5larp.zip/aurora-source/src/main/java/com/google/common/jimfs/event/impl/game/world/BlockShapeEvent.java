package com.google.common.jimfs.event.impl.game.world;

import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_265;
import net.minecraft.class_2680;

public final class BlockShapeEvent {
   private final class_2338 blockPosition;
   private final class_2680 blockState;
   private class_265 shape;
   private final List recoveredField186;

   public BlockShapeEvent(class_2338 var1, class_2680 var2, class_265 var3, List var4) {
      this.blockPosition = var1;
      this.blockState = var2;
      this.shape = var3;
      this.recoveredField186 = var4;
   }

   public class_265 getShape() {
      return this.shape;
   }
}
