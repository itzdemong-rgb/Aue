package com.google.common.jimfs.recovered;

import net.minecraft.class_2596;

public interface PacketTransformer {
   class_2596 b(class_2596 var1);
}
