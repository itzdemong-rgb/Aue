package com.google.common.jimfs.utility.render;

import java.util.Objects;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;

@Environment(EnvType.CLIENT)
public final class SidebarEntry {
   private SidebarEntry(class_2561 name, class_2561 score, int recoveredField002) {
      this.name = name;
      this.score = score;
      this.scoreWidth = recoveredField002;
   }

   private final class_2561 name;
   private final class_2561 score;
   private final int scoreWidth;

   @Override
   public boolean equals(Object var1) {
      if (var1 == this) {
         return true;
      } else if (var1 != null && var1.getClass() == this.getClass()) {
         SidebarEntry var2 = (SidebarEntry)var1;
         return Objects.equals(this.name, var2.name)
            && Objects.equals(this.score, var2.score)
            && this.scoreWidth == var2.scoreWidth;
      } else {
         return false;
      }
   }

   @Override
   public int hashCode() {
      return Objects.hash(this.name, this.score, this.scoreWidth);
   }

   @Override
   public String toString() {
      return "SidebarEntry[name=" + this.name + ", score=" + this.score + ", scoreWidth=" + this.scoreWidth + ']';
   }
}
