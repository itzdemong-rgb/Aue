package com.google.common.jimfs.mixin.client;

import com.google.common.jimfs.event.EventDispatcher;
import com.google.common.jimfs.event.impl.game.world.PlaySoundEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({class_638.class})
public final class ClientWorldSoundMixin {
   private ClientWorldSoundMixin() {
   }

   @Inject(
      method = {"playSound(DDDLnet/minecraft/sound/SoundEvent;Lnet/minecraft/sound/SoundCategory;FFZJ)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void a(
      double var1, double var3, double var5, class_3414 var7, class_3419 var8, float var9, float var10, boolean var11, long var12, CallbackInfo var14
   ) {
      PlaySoundEvent var15 = new PlaySoundEvent(var7, var1, var3, var5);
      EventDispatcher.b(var15);
      if (var15.isCancelled()) {
         var14.cancel();
      }
   }
}
