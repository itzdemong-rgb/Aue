package com.google.common.jimfs.client.screen.settings;

import com.google.common.jimfs.client.Constants;
import com.google.common.jimfs.client.Swag;
import com.google.common.jimfs.client.feature.module.Module;
import com.google.common.jimfs.client.feature.module.ModuleCategory;
import com.google.common.jimfs.client.feature.module.property.Property;
import com.google.common.jimfs.client.feature.module.property.impl.ColorProperty;
import com.google.common.jimfs.client.feature.module.property.impl.KeybindProperty;
import com.google.common.jimfs.client.feature.module.property.impl.bool.BooleanProperty;
import com.google.common.jimfs.client.feature.module.property.impl.mode.ModeProperty;
import com.google.common.jimfs.client.feature.module.property.impl.number.BoundedNumberProperty;
import com.google.common.jimfs.client.feature.module.property.impl.number.NumberProperty;
import com.google.common.jimfs.client.renderer.NVGRenderer;
import com.google.common.jimfs.client.renderer.repository.FontRepository;
import com.google.common.jimfs.client.renderer.shader.ShaderFramebuffer;
import com.google.common.jimfs.m.ClickGUIModule;
import com.google.common.jimfs.utility.misc.HoverUtility;
import com.google.common.jimfs.utility.misc.StringObfuscation;
import com.google.common.jimfs.utility.render.ColorUtility;
import com.google.common.jimfs.utility.render.animation.AnimatedValue;
import com.google.common.jimfs.utility.render.animation.Easing;
import com.ibm.icu.impl.Pair;
import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1109;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.nanovg.NanoVG;

@Environment(EnvType.CLIENT)
public class SettingsScreen extends class_437 {
   public static boolean editingKeybindActive = false;
   public static boolean recoveredField110 = false;
   public static KeybindProperty editingKeybind = null;
   private static ModuleCategory defaultCategory = ModuleCategory.COMBAT;
   private static float lastModuleScroll = 0.0F;
   private static boolean lastFavoritesOnly = false;
   private static Module selectedModule = null;
   private ModuleCategory selectedCategory = defaultCategory;
   private float moduleScroll = lastModuleScroll;
   private float targetModuleScroll = 0.0F;
   private Module focusedModule = selectedModule;
   private Property selectedProperty = null;
   private int recoveredField002 = 0;
   private int accentColor = -6723841;
   private Map categoryHoverAnimations = new HashMap();
   private Map categorySelectionAnimations = new HashMap();
   private final List<Module> visibleModules = new ArrayList();
   private AnimatedValue favoritesHoverAnimation = new AnimatedValue(0.0F, Easing.EASE_OUT_CUBIC, 250.0F);
   private AnimatedValue favoritesSelectionAnimation = new AnimatedValue(0.0F, Easing.EASE_OUT_CUBIC, 350.0F);
   private boolean favoritesOnly = lastFavoritesOnly;
   private Map<Module, AnimatedValue> moduleFavoriteAnimations = new HashMap();
   private Map moduleHoverAnimations = new HashMap();
   private Map moduleToggleAnimations = new HashMap();
   private Map moduleFocusAnimations = new HashMap();
   private Map<Object, AnimatedValue> booleanPropertyAnimations = new HashMap();
   private AnimatedValue openingAnimation = new AnimatedValue(0.0F, Easing.EASE_OUT_EXPO, 700.0F);
   private List profileEntries = new ArrayList();
   private boolean profilesLoading = false;
   private String recoveredField025 = null;
   private float profileScroll = 0.0F;
   private float targetProfileScroll = 0.0F;
   private final Map moduleBounds = new HashMap();
   private Map recoveredField239 = new HashMap();
   private AnimatedValue recoveredField157 = new AnimatedValue(0.0F, Easing.EASE_OUT_CUBIC, 250.0F);
   private AnimatedValue recoveredField183 = new AnimatedValue(0.0F, Easing.EASE_OUT_CUBIC, 250.0F);
   private String searchText = "";
   private boolean searchFocused = false;
   private String toastMessage = null;
   private long toastTimeMillis = 0L;
   private String editingProfileId = null;
   private String recoveredField185 = "";
   private String editedProfileName = "";
   private boolean editingProfileName = false;
   private List recoveredField132 = new ArrayList();
   private boolean recoveredField226 = false;
   private float recoveredField194 = 0.0F;
   private float recoveredField206 = 0.0F;
   private float[][] particles = new float[35][5];
   private boolean particlesInitialized = false;

   private void a(float var1, float var2) {
      if (!this.particlesInitialized) {
         Random var3 = new Random();

         for (int var4 = 0; var4 < 35; var4++) {
            this.particles[var4][0] = var3.nextFloat() * var1;
            this.particles[var4][1] = var3.nextFloat() * var2;
            this.particles[var4][2] = (var3.nextFloat() - 0.5F) * 0.3F;
            this.particles[var4][3] = (var3.nextFloat() - 0.5F) * 0.2F - 0.1F;
            this.particles[var4][4] = var3.nextFloat() * 6.28F;
         }

         this.particlesInitialized = true;
      }
   }

   protected void method_25426() {
      super.method_25426();
      this.openingAnimation.b(0.0F);
      this.openingAnimation.animateTo(1.0F);
      this.resetScreen();
   }

   public SettingsScreen() {
      super(class_2561.method_43470("Settings"));

      for (ModuleCategory var4 : ModuleCategory.values()) {
         this.categoryHoverAnimations.put(var4, new AnimatedValue(0.0F, Easing.EASE_OUT_CUBIC, 250.0F));
         this.categorySelectionAnimations.put(var4, new AnimatedValue(var4 == this.selectedCategory ? 1.0F : 0.0F, Easing.EASE_OUT_CUBIC, 350.0F));
      }

      for (Module var6 : Swag.getInstance().getModuleRepository().getModules()) {
         this.moduleHoverAnimations.put(var6, new AnimatedValue(0.0F, Easing.EASE_OUT_CUBIC, 250.0F));
         this.moduleToggleAnimations.put(var6, new AnimatedValue(var6.isEnabled() ? 1.0F : 0.0F, Easing.EASE_OUT_CUBIC, 350.0F));
         this.moduleFocusAnimations.put(var6, new AnimatedValue(0.0F, Easing.EASE_OUT_CUBIC, 350.0F));
      }
   }

   public void method_25420(class_332 var1, int var2, int var3, float var4) {
      ShaderFramebuffer.render();
      ShaderFramebuffer.a(
         Constants.MINECRAFT.method_22683().method_4489(),
         Constants.MINECRAFT.method_22683().method_4506(),
         (float)(System.currentTimeMillis() % 1000000L) / 1000.0F,
         (float)var2,
         (float)var3
      );
   }

   private float getScaleFactor() {
      return (float)Constants.MINECRAFT.method_22683().method_4506() / 750.0F;
   }

   private double a(double var1) {
      return var1 * (double)((float)Constants.MINECRAFT.method_22683().method_4495() / this.getScaleFactor());
   }

   private double b(double var1) {
      return var1 * (double)((float)Constants.MINECRAFT.method_22683().method_4495() / this.getScaleFactor());
   }

   private float a(float var1, float var2, float var3) {
      if (var1 <= var2) {
         return 0.0F;
      } else {
         return var1 >= var3 ? 1.0F : (var1 - var2) / (var3 - var2);
      }
   }

   public void method_25394(class_332 var1, int var2, int var3, float var4) {
      int var5 = (int)this.a((double)var2);
      int var6 = (int)this.b((double)var3);
      this.openingAnimation.c(16.0F);
      float var7 = this.openingAnimation.getValue();
      this.accentColor = (Integer)ClickGUIModule.accentColor.getValue() | 0xFF000000;
      float var8 = ((Double)ClickGUIModule.cornerRoundness.getValue()).floatValue();
      float var9 = 16.0F;
      ShaderFramebuffer.render();
      boolean var10 = NVGRenderer.beginFrame(this.getScaleFactor());
      float var11 = this.a(var7, 0.0F, 0.2F);
      float var12 = this.a(var7, 0.15F, 0.35F);
      float var13 = this.a(var7, 0.3F, 0.5F);
      float var14 = this.a(var7, 0.45F, 0.65F);
      float var15 = this.getScaleFactor();
      float var16 = (float)Constants.MINECRAFT.method_22683().method_4489() / var15;
      float var17 = (float)Constants.MINECRAFT.method_22683().method_4506() / var15;
      float var18 = Math.min(680.0F, var16 * 0.9F);
      float var19 = Math.min(460.0F, var17 * 0.9F);
      float var20 = (var16 - var18) / 2.0F;
      float var21 = (var17 - var19) / 2.0F + (1.0F - var7) * 50.0F;
      NVGRenderer.setGlobalAlpha(var12);
      NVGRenderer.b(var20, var21, var18, var19, 15.0F, 40.0F, -16777216, 0.5F);
      NVGRenderer.a(var20, var21, var18, var19, var8, var8, var8, var8, ColorUtility.a(-15592938, 0.5F), ColorUtility.a(-15329758, 0.5F), 45.0F);
      NVGRenderer.a(var20, var21, var18, var19, 10.0F, 1.0F, -14145483);
      NVGRenderer.setGlobalAlpha(var11);
      float var22 = var18 * 0.1F;
      NVGRenderer.c(var20, var21, var22, var19, 10.0F, ColorUtility.a(-15132382, 0.7F));
      NVGRenderer.a(var20 + var22, var21, 1.0F, var19, ColorUtility.a(ColorUtility.a(-15132382, 0.7F), this.accentColor, 0.15F));
      float var23 = 65.0F;
      NVGRenderer.setGlobalAlpha(var13);
      String var24 = StringObfuscation.a("Aur").get();
      String var25 = StringObfuscation.a("ora").get();
      float var26 = 40.0F;
      String var27 = "\ue3e7";
      float var28 = 32.0F;
      float var29 = FontRepository.a("materialicons-regular").a(var27, var28);
      float var30 = var20 + var22 + 25.0F;
      float var31 = var21 + 48.0F;
      float var32 = FontRepository.a("monument").a(var24, var26);
      float var33 = var30 + var32 + 1.0F;
      float var34 = var31 + 1.0F;
      float var35 = var33 + var29 + 1.0F;
      float var36 = (float)(System.currentTimeMillis() % 2000L) / 2000.0F;
      float var37 = (float)Math.sin((double)var36 * Math.PI * 2.0) * 0.5F + 0.5F;
      float var38 = (float)Math.pow((double)var37, 4.0);
      int var39 = ColorUtility.a(this.accentColor, -1, var38);
      int var40 = ColorUtility.a(this.accentColor, -1, (float)Math.pow((double)(1.0F - var37), 4.0));
      FontRepository.a("monument").a(var24, var30, var31, var26, var39, var40);
      FontRepository.a("materialicons-regular").b(var27, var33, var34, var28, this.accentColor);
      FontRepository.a("monument").a(var25, var35, var31, var26, var39, var40);
      String var41 = this.favoritesOnly ? "FAVORITES" : (this.selectedCategory != null ? this.selectedCategory.name().toUpperCase() : "");
      float var42 = 20.0F;
      float var43 = FontRepository.a("monument").a(var41, var42);
      float var44 = var20 + var18 - 25.0F - var43;
      FontRepository.a("monument").b(var41, var44, var31 - 1.0F, var42, -1);
      float var45 = (float)(System.currentTimeMillis() % 2000L) / 2000.0F;
      float var46 = var44 - 10.0F + (var43 + 20.0F) * var45;
      NVGRenderer.a(var46, var31 - 25.0F, 15.0F, 35.0F, () -> FontRepository.a("monument").b(var41, var44, var31 - 1.0F, var42, this.accentColor));
      NVGRenderer.setGlobalAlpha(var12);
      float var47 = var20 + var22;
      float var48 = var21 + var23;
      float var49 = var18 - var22;
      float var50 = var19 - var23;
      NVGRenderer.a(var47, var48, var49, var50, () -> {
         float var6x = 14.0F;
         float var7x = (float)(System.currentTimeMillis() % 20000L) / 1000.0F;

         for (float var8x = var47; var8x < var47 + var49 + var6x; var8x += var6x) {
            for (float var9x = var48; var9x < var48 + var50 + var6x; var9x += var6x) {
               float var10x = (var8x - (var47 + var49 / 2.0F)) / (var49 / 2.0F);
               float var11x = (var9x - (var48 + var50 / 2.0F)) / (var50 / 2.0F);
               float var12x = (float)Math.sqrt((double)(var10x * var10x + var11x * var11x));
               float var13x = (float)Math.atan2((double)var11x, (double)var10x);
               var12x -= (float)Math.sin((double)(var13x * 5.0F + var7x * 2.0F)) * 0.1F;
               var12x -= (float)Math.cos((double)(var13x * 3.0F - var7x * 1.5F)) * 0.1F;
               float var14x = (float)Math.sin((double)(var12x * 25.0F - var7x * 5.0F));
               if (var14x > 0.3F) {
                  float var15x = (var14x - 0.3F) / 0.7F;
                  float var16x = 1.0F + var15x * 1.5F;
                  float var17x = var15x * 0.16F * var7;
                  int var18x = ColorUtility.a(this.accentColor, var17x);
                  NVGRenderer.c(var8x - var16x / 2.0F, var9x - var16x / 2.0F, var16x, var16x, var16x / 2.0F, var18x);
               }
            }
         }

         float var19x = (float)(System.currentTimeMillis() % 1000000L) / 1000.0F;
         this.a(var49, var50);

         for (int var20x = 0; var20x < 35; var20x++) {
            float var21x = this.particles[var20x][0];
            float var23x = this.particles[var20x][1];
            float var27x = this.particles[var20x][2];
            float var28x = this.particles[var20x][3];
            float var29x = this.particles[var20x][4];
            var21x += var27x;
            var23x += var28x;
            if (var21x < -20.0F) {
               var21x = var49 + 20.0F;
            }

            if (var21x > var49 + 20.0F) {
               var21x = -20.0F;
            }

            if (var23x < -20.0F) {
               var23x = var50 + 20.0F;
            }

            if (var23x > var50 + 20.0F) {
               var23x = -20.0F;
            }

            this.particles[var20x][0] = var21x;
            this.particles[var20x][1] = var23x;
            float var30x = (float)(Math.sin((double)(var19x * 1.5F + var29x)) * 0.3F + 0.35F);
            float var31x = 2.5F + (float)Math.sin((double)(var19x * 0.8F + var29x * 2.0F)) * 1.0F;
            int var32x = ColorUtility.a(-6723841, var30x * var7);
            NVGRenderer.b(var47 + var21x - var31x, var48 + var23x - var31x, var31x * 2.0F, var31x * 2.0F, var31x, var31x * 3.0F, var32x, var30x * 0.5F * var7);
            NVGRenderer.c(var47 + var21x - var31x / 2.0F, var48 + var23x - var31x / 2.0F, var31x, var31x, var31x / 2.0F, var32x);
         }
      });
      NVGRenderer.setGlobalAlpha(var12);
      NVGRenderer.a(var20 + var22, var21 + var23, var18 - var22, 1.0F, ColorUtility.a(-14803416, this.accentColor, 0.5F));
      float var51 = 40.0F;
      NVGRenderer.a(var20 + var22, var21 + var19 - var51, var18 - var22, 1.0F, ColorUtility.a(-14803416, this.accentColor, 0.5F));
      FontRepository.a("monument").b("Goat Wanda (for GUI) & Drought for Modules", var20 + var22 + 15.0F, var21 + var19 - var51 + 16.0F, 8.0F, -5592406);
      FontRepository.a("monument").b("by neuro", var20 + var18 - 45.0F, var21 + var19 - var51 + 16.0F, 8.0F, -5592406);
      float var52 = var19 * 0.13F;
      float var53 = 0.0F;
      float var54 = 0.0F;

      for (ModuleCategory var58 : ModuleCategory.values()) {
         if (var58 != ModuleCategory.UPDATES) {
            if (var58 != ModuleCategory.CLIENT && var58 != ModuleCategory.CONFIGS) {
               var53++;
            } else {
               var54++;
            }
         }
      }

      float var107 = var21 + 20.0F;
      float var108 = var21 + var19 - var51 - var54 * var52 - 5.0F;
      NVGRenderer.setGlobalAlpha(var11);

      for (ModuleCategory var60 : ModuleCategory.values()) {
         if (var60 != ModuleCategory.UPDATES) {
            AnimatedValue var61 = (AnimatedValue)this.categoryHoverAnimations.get(var60);
            AnimatedValue var62 = (AnimatedValue)this.categorySelectionAnimations.get(var60);
            float var63 = var60 != ModuleCategory.CLIENT && var60 != ModuleCategory.CONFIGS ? var107 : var108;
            boolean var64 = HoverUtility.a(var20, var63, var22, var52, (double)var5, (double)var6);
            var61.c(var9);
            var61.animateTo(var64 ? 1.0F : 0.0F);
            var62.c(var9);
            var62.animateTo(var60 == this.selectedCategory ? 1.0F : 0.0F);
            float var65 = var61.getValue();
            float var66 = var62.getValue();
            float var67 = 36.0F;
            float var68 = var20 + var22 / 2.0F - var67 / 2.0F;
            float var69 = var63 + var52 / 2.0F - var67 / 2.0F;
            if (var66 > 0.0F) {
               NVGRenderer.b(var68, var69, var67, var67, 10.0F, 12.0F, this.accentColor, var66 * 0.4F);
               NVGRenderer.c(var68, var69, var67, var67, 10.0F, ColorUtility.a(this.accentColor, var66 * 0.7F));
            }

            int var70 = ColorUtility.a(-5592406, -1, var66);
            if (var60 == ModuleCategory.CRYSTAL) {
               float var71 = var68 + var67 / 2.0F;
               float var72 = var69 + var67 / 2.0F;

               for (int var73 = 0; var73 < 2; var73++) {
                  float var74 = var73 == 0 ? 8.0F : 4.0F;
                  float var75 = var73 == 0 ? 0.0F : (float) (Math.PI / 6);
                  float var76 = var71 + (float)(Math.cos(4.712388980384689 + (double)var75) * (double)var74);
                  float var77 = var72 + (float)(Math.sin(4.712388980384689 + (double)var75) * (double)var74);
                  float var78 = 0.0F;
                  float var79 = 0.0F;
                  float var80 = 0.0F;
                  float var81 = 0.0F;
                  float var82 = 0.0F;
                  float var83 = 0.0F;

                  for (int var84 = 0; var84 < 6; var84++) {
                     float var85 = (float)((Math.PI / 3) * (double)var84 - (Math.PI / 6)) + var75;
                     float var86 = var71 + (float)(Math.cos((double)var85) * (double)var74);
                     float var87 = var72 + (float)(Math.sin((double)var85) * (double)var74);
                     NVGRenderer.b(var76, var77, var86, var87, 1.5F, var70);
                     var76 = var86;
                     var77 = var87;
                     if (var84 == 1) {
                        var78 = var86;
                        var79 = var87;
                     } else if (var84 == 3) {
                        var80 = var86;
                        var81 = var87;
                     } else if (var84 == 5) {
                        var82 = var86;
                        var83 = var87;
                     }
                  }

                  NVGRenderer.b(var71, var72, var78, var79, 1.5F, var70);
                  NVGRenderer.b(var71, var72, var80, var81, 1.5F, var70);
                  NVGRenderer.b(var71, var72, var82, var83, 1.5F, var70);
               }
            } else {
               Object var150 = var60.getName() != null ? var60.getName() : "\ue8b8";
               float var153 = 24.0F;
               FontRepository.a("materialsymbolsoutlined")
                  .a((CharSequence)var150, var68 + var67 / 2.0F - var153 / 2.0F, var69 + var67 / 2.0F + 12.5F, var153, var70);
            }

            if (var60 != ModuleCategory.CLIENT && var60 != ModuleCategory.CONFIGS) {
               var107 += var52;
            } else {
               var108 += var52;
            }
         }
      }

      NVGRenderer.a(var20 + var22 * 0.25F, var107 + var52 + 15.0F, var22 * 0.5F, 2.0F, -14013899);
      NVGRenderer.setGlobalAlpha(var11);
      float var110 = 36.0F;
      float var113 = var20 + var22 / 2.0F - var110 / 2.0F;
      float var115 = var107 + var52 / 2.0F - var110 / 2.0F;
      boolean var117 = HoverUtility.a(var20, var107, var22, var52, (double)var5, (double)var6);
      this.favoritesHoverAnimation.c(var9);
      this.favoritesHoverAnimation.animateTo(var117 ? 1.0F : 0.0F);
      this.favoritesSelectionAnimation.c(var9);
      this.favoritesSelectionAnimation.animateTo(this.favoritesOnly ? 1.0F : 0.0F);
      float var119 = this.favoritesSelectionAnimation.getValue();
      if (var119 > 0.0F) {
         NVGRenderer.b(var113, var115, var110, var110, 10.0F, 12.0F, this.accentColor, var119 * 0.4F);
         NVGRenderer.c(var113, var115, var110, var110, 10.0F, ColorUtility.a(this.accentColor, var119 * 0.7F));
      }

      int var122 = ColorUtility.a(-5592406, -1, var119);
      float var125 = 24.0F;
      FontRepository.a("materialsymbolsoutlined").b("\ue838", var113 + var110 / 2.0F - var125 / 2.0F, var115 + var110 / 2.0F + 12.5F, var125, var122);
      var110 = var20 + var22 + 15.0F;
      var113 = var21 + var23 + 5.0F;
      var115 = var18 - var22 - 30.0F;
      float var118 = var19 - var23 - var51 - 10.0F;
      this.visibleModules.clear();

      for (Module var123 : Swag.getInstance().getModuleRepository().getModules()) {
         if (this.favoritesOnly ? var123.isFavorite() : var123.getCategory() == this.selectedCategory) {
            this.visibleModules.add(var123);
         }
      }

      this.visibleModules.sort((var0, var1x) -> {
         CharSequence var2x = var0.getName();
         CharSequence var3x = var1x.getName();
         int var4x = Math.min(var2x.length(), var3x.length());

         for (int var5x = 0; var5x < var4x; var5x++) {
            char var6x = var2x.charAt(var5x);
            char var7x = var3x.charAt(var5x);
            if (var6x >= 'A' && var6x <= 'Z') {
               var6x = (char)(var6x + ' ');
            }

            if (var7x >= 'A' && var7x <= 'Z') {
               var7x = (char)(var7x + ' ');
            }

            if (var6x != var7x) {
               return var6x - var7x;
            }
         }

         return var2x.length() - var3x.length();
      });
      List<Module> var121 = this.visibleModules;
      float var124 = 0.0F;
      if (this.favoritesOnly) {
         for (Module var130 : var121) {
            float var134 = this.focusedModule == var130 ? this.a(var130) : 0.0F;
            var124 += 42.0F + var134 + 15.0F;
         }
      } else if (this.selectedCategory == ModuleCategory.CLIENT) {
         Module var127 = Swag.getInstance().getModuleRepository().a(ClickGUIModule.class);
         if (var127 != null) {
            for (Property var135 : var127.getProperties()) {
               if (!var135.isVisible()) {
                  float var138 = this.a(var135);
                  var124 += var138 + 15.0F;
               }
            }
         }
      } else if (this.selectedCategory == ModuleCategory.CONFIGS) {
         var124 = var118;
      } else {
         for (Module var132 : var121) {
            float var136 = this.focusedModule == var132 ? this.a(var132) : 0.0F;
            var124 += 42.0F + var136 + 15.0F;
         }
      }

      var125 = Math.max(0.0F, var124 - var118);
      if (this.targetModuleScroll > var125) {
         this.targetModuleScroll = var125;
      }

      if (this.targetModuleScroll < 0.0F) {
         this.targetModuleScroll = 0.0F;
      }

      float var133 = 1.0F - (float)Math.pow(0.97, (double)var9 / 16.0);
      this.moduleScroll = this.moduleScroll + (this.targetModuleScroll - this.moduleScroll) * var133;
      if (Math.abs(this.moduleScroll - this.targetModuleScroll) < 0.1F) {
         this.moduleScroll = this.targetModuleScroll;
      }

      float var137 = Math.max(0.0F, (float)this.profileEntries.size() * 54.0F - 300.0F);
      if (this.targetProfileScroll > var137) {
         this.targetProfileScroll = var137;
      }

      if (this.targetProfileScroll < 0.0F) {
         this.targetProfileScroll = 0.0F;
      }

      this.profileScroll = this.profileScroll + (this.targetProfileScroll - this.profileScroll) * var133;
      if (Math.abs(this.profileScroll - this.targetProfileScroll) < 0.5F) {
         this.profileScroll = this.targetProfileScroll;
      }

      NanoVG.nvgScissor(NVGRenderer.getFrameContext(), var110 - 5.0F, var113, var115 + 10.0F, var118);
      float var139 = var113 - this.moduleScroll;
      NVGRenderer.setGlobalAlpha(var14);
      if (this.selectedCategory == ModuleCategory.CLIENT) {
         Module var140 = Swag.getInstance().getModuleRepository().a(ClickGUIModule.class);
         if (var140 != null) {
            float var143 = 350.0F;
            float var146 = var110 + (var115 - var143) / 2.0F;

            for (Property var151 : var140.getProperties()) {
               if (!var151.isVisible()) {
                  float var154 = this.a(var140, var151, var146, var139, var143, var5, var6);
                  var139 += var154 + 15.0F;
               }
            }
         }
      } else if (this.selectedCategory == ModuleCategory.CONFIGS) {
         String var141 = "Coming Soon";
         float var144 = FontRepository.a("monument").a(var141, 18.0F);
         FontRepository.a("monument").b(var141, var110 + (var115 - var144) / 2.0F, var113 + var118 / 2.0F - 5.0F, 18.0F, -10066296);
      } else {
         int var142 = 0;
         int var145 = var121.size();
         this.moduleBounds.clear();

         for (Module var149 : var121) {
            float var152 = 0.35F / (float)Math.max(1, var145);
            float var155 = this.a(var7, 0.65F + (float)var142 * var152, 0.65F + (float)(var142 + 2) * var152);
            NVGRenderer.setGlobalAlpha(var155);
            var142++;
            AnimatedValue var156 = (AnimatedValue)this.moduleHoverAnimations.get(var149);
            AnimatedValue var157 = (AnimatedValue)this.moduleToggleAnimations.get(var149);
            AnimatedValue var158 = (AnimatedValue)this.moduleFocusAnimations.get(var149);
            var156.c(var9);
            var156.animateTo(HoverUtility.a(var110, var139, var115, 35.0F, (double)var5, (double)var6) ? 1.0F : 0.0F);
            var157.c(var9);
            var157.animateTo(var149.isEnabled() ? 1.0F : 0.0F);
            var158.c(var9);
            var158.animateTo(this.focusedModule == var149 ? 1.0F : 0.0F);
            float var159 = var156.getValue();
            float var160 = var157.getValue();
            float var161 = var158.getValue();
            float var162 = 42.0F;
            float var163 = this.a(var149) * var161;
            this.moduleBounds.put(var149, new float[]{var139, var162, var163});
            int var164 = ColorUtility.a(ColorUtility.a(-15066590, -14803414, var161), 0.35F);
            NVGRenderer.c(var110, var139, var115, var162 + var163, var8, var164);
            if (var159 > 0.0F) {
               NVGRenderer.c(var110, var139, var115, var162 + var163, var8, ColorUtility.a(-14013899, var159 * 0.5F));
            }

            String var165 = this.focusedModule == var149 ? "\ue5ce" : "\ue5cf";
            FontRepository.a("materialicons-regular").b(var165, var110 + 10.0F, var139 + 27.5F, 16.0F, -5592406);
            int var166 = ColorUtility.a(-5592406, -1, var160);
            CharSequence var167 = var149.getName();
            float var168 = FontRepository.a("monument").a(var167, 15.0F);
            FontRepository.a("monument").a(var167, var110 + 28.0F, var139 + 26.5F, 15.0F, var166);
            float var169 = 16.0F;
            float var170 = var110 + var115 - 32.0F - 10.0F - var169 - 8.0F;
            float var88 = var139 + (var162 - var169) / 2.0F;
            boolean var89 = var149.isFavorite();
            int var90 = var89 ? -10496 : -11184794;
            AnimatedValue var91 = this.moduleFavoriteAnimations
               .computeIfAbsent(var149, var1x -> new AnimatedValue(var89 ? 1.0F : 0.0F, Easing.EASE_OUT_CUBIC, 250.0F));
            var91.animateTo(var89 ? 1.0F : 0.0F);
            var91.c(var9);
            float var92 = var170 + var169 / 2.0F;
            float var93 = var88 + var169 / 2.0F;
            FontRepository.a("materialicons-regular").b("\ue83a", var92 - var169 / 2.0F, var93 + var169 / 2.0F - 2.0F, var169, -11184794);
            float var94 = var91.getValue();
            if (var94 > 0.01F) {
               float var95 = var169 * (0.5F + 0.5F * var94);
               int var96 = ColorUtility.a(var90, var94);
               FontRepository.a("materialicons-regular").b("\ue838", var92 - var95 / 2.0F, var93 + var95 / 2.0F - 2.0F, var95, var96);
            }

            float var171 = 32.0F;
            float var172 = 16.0F;
            float var97 = var110 + var115 - var171 - 10.0F;
            float var98 = var139 + (var162 - var172) / 2.0F;
            int var99 = ColorUtility.a(-14013899, this.accentColor, var160);
            NVGRenderer.c(var97, var98, var171, var172, var172 / 2.0F, var99);
            if (var160 > 0.01F) {
               NVGRenderer.b(var97, var98, var171, var172, var172 / 2.0F, 8.0F * var160, this.accentColor, 0.4F * var160);
            }

            float var100 = 6.0F;
            float var101 = var97 + var100 + 2.0F + (var171 - 2.0F * var100 - 4.0F) * var160;
            float var102 = var98 + var172 / 2.0F;
            NVGRenderer.c(var101 - var100, var102 - var100, var100 * 2.0F, var100 * 2.0F, var100, -1);
            if (var161 > 0.01F) {
               NanoVG.nvgIntersectScissor(NVGRenderer.getFrameContext(), var110, var139 + var162, var115, var163);
               float var103 = var139 + var162;

               for (Property var105 : var149.getProperties()) {
                  if (!var105.isVisible()) {
                     float var106 = this.a(var149, var105, var110 + 20.0F, var103, var115 - 40.0F, var5, var6);
                     var103 += var106;
                  }
               }

               NanoVG.nvgResetScissor(NVGRenderer.getFrameContext());
               NanoVG.nvgScissor(NVGRenderer.getFrameContext(), var110 - 5.0F, var113, var115 + 10.0F, var118);
            }

            var139 += var162 + var163 + 15.0F;
         }
      }

      NanoVG.nvgResetScissor(NVGRenderer.getFrameContext());
      NVGRenderer.a(var110 - 5.0F, var113 + var118 - 40.0F, var115 + 10.0F, 40.0F, 1644834, -535226078, 90.0F);
      if (var10) {
         NVGRenderer.a(true);
      }
   }

   private float a(Module var1, Property var2, float var3, float var4, float var5, int var6, int var7) {
      float var8 = this.a(var2);
      if (!(var2 instanceof NumberProperty) && !(var2 instanceof BoundedNumberProperty) && !(var2 instanceof ColorProperty)) {
         FontRepository.a("monument").a(var2.getName(), var3, var4 + (var8 + 6.0F) / 2.0F, 9.0F, -5592406);
      }

      if (var2 instanceof BooleanProperty var38) {
         float var41 = 24.0F;
         float var46 = 12.0F;
         float var49 = var3 + var5 - var41;
         float var54 = var4 + (var8 - var46) / 2.0F;
         boolean var59 = var38.isEnabled();
         AnimatedValue var15 = this.booleanPropertyAnimations.computeIfAbsent(var38, var1x -> new AnimatedValue(var59 ? 1.0F : 0.0F, Easing.EASE_IN_OUT_CUBIC, 150.0F));
         var15.animateTo(var59 ? 1.0F : 0.0F);
         var15.c(16.0F);
         float var62 = var15.getValue();
         int var17 = ColorUtility.a(-13421756, this.accentColor, var62);
         NVGRenderer.c(var49, var54, var41, var46, var46 / 2.0F, var17);
         float var65 = 8.0F;
         float var66 = var49 + 2.0F + (var41 - var65 - 4.0F) * var62;
         float var69 = var54 + 2.0F;
         NVGRenderer.b(var66, var69, var65, var65, var65 / 2.0F, 8.0F, -16777216, 0.4F);
         if (var62 > 0.0F) {
            NVGRenderer.b(var49, var54, var41, var46, var46 / 2.0F, 12.0F, this.accentColor, 0.4F * var62);
         }

         NVGRenderer.c(var66, var69, var65, var65, var65 / 2.0F, -1);
         return var8;
      } else if (var2 instanceof NumberProperty var37) {
         FontRepository.a("monument").a(var2.getName(), var3, var4 + 12.0F, 9.0F, -5592406);
         float var45 = var4 + 22.0F;
         float var53 = 4.0F;
         NVGRenderer.c(var3, var45, var5, var53, var53 / 2.0F, -14013899);
         double var58 = var37.getMaximum() - var37.getMinimum();
         double var61 = (Double)var37.getValue();
         double var64 = (var61 - var37.getMinimum()) / var58;
         float var68 = (float)((double)var5 * var64);
         if (var68 > 0.1F) {
            NVGRenderer.b(var3, var45, var68, var53, var53 / 2.0F, 15.0F, this.accentColor, 0.45F);
         }

         NVGRenderer.c(var3, var45, var68, var53, var53 / 2.0F, this.accentColor);
         float var71 = 10.0F;
         NVGRenderer.c(var3 + var68 - var71 / 2.0F, var45 + var53 / 2.0F - var71 / 2.0F, var71, var71, var71 / 2.0F, -1);
         String var72 = String.format("%.1f", var61);
         float var74 = FontRepository.a("monument").a(var72, 9.0F);
         FontRepository.a("monument").b(var72, var3 + var5 - var74, var4 + 12.0F, 9.0F, -1);
         if (this.selectedProperty == var2 && GLFW.glfwGetMouseButton(Constants.MINECRAFT.method_22683().method_4490(), 0) == 1) {
            double var75 = (double)Math.min(var5, Math.max(0.0F, (float)var6 - var3));
            double var78 = var37.getMinimum() + var75 / (double)var5 * var58;
            var37.a(var78);
         }

         return var8;
      } else if (var2 instanceof BoundedNumberProperty var36) {
         FontRepository.a("monument").a(var2.getName(), var3, var4 + 12.0F, 9.0F, -5592406);
         float var44 = var4 + 22.0F;
         float var52 = 4.0F;
         NVGRenderer.c(var3, var44, var5, var52, var52 / 2.0F, -14013899);
         double var57 = var36.getMaximum() - var36.getMinimum();
         double var60 = (Double)((Pair)var36.getValue()).first;
         double var63 = (Double)((Pair)var36.getValue()).second;
         float var67 = (float)((var60 - var36.getMinimum()) / var57);
         float var70 = (float)((var63 - var36.getMinimum()) / var57);
         float var22 = var3 + var5 * var67;
         float var73 = var3 + var5 * var70;
         float var24 = var73 - var22;
         if (var24 > 0.1F) {
            NVGRenderer.b(var22, var44, var24, var52, var52 / 2.0F, 15.0F, this.accentColor, 0.45F);
            NVGRenderer.c(var22, var44, var24, var52, var52 / 2.0F, this.accentColor);
         }

         float var76 = 10.0F;
         NVGRenderer.c(var22 - var76 / 2.0F, var44 + var52 / 2.0F - var76 / 2.0F, var76, var76, var76 / 2.0F, -1);
         NVGRenderer.c(var73 - var76 / 2.0F, var44 + var52 / 2.0F - var76 / 2.0F, var76, var76, var76 / 2.0F, -1);
         String var77 = String.format("%.1f - %.1f", var60, var63);
         float var79 = FontRepository.a("monument").a(var77, 9.0F);
         FontRepository.a("monument").b(var77, var3 + var5 - var79, var4 + 12.0F, 9.0F, -1);
         if (this.selectedProperty == var2 && GLFW.glfwGetMouseButton(Constants.MINECRAFT.method_22683().method_4490(), 0) == 1) {
            double var80 = (double)Math.min(var5, Math.max(0.0F, (float)var6 - var3));
            double var82 = var36.getMinimum() + var80 / (double)var5 * var57;
            if (Math.abs(var82 - var60) < Math.abs(var82 - var63)) {
               var36.a(Pair.of(var82, var63));
            } else {
               var36.a(Pair.of(var60, var82));
            }
         }

         return var8;
      } else if (var2 instanceof ColorProperty var35) {
         var8 = this.a(var2);
         int var40 = (Integer)var35.getValue() | 0xFF000000;
         float var43 = 10.0F;
         float var48 = var3 + var5 - var43 - 2.0F;
         float var51 = var4 + 8.0F;
         NVGRenderer.b(var48, var51, var43, var43, var43 / 2.0F, 6.0F, var40, 0.4F);
         NVGRenderer.c(var48, var51, var43, var43, var43 / 2.0F, var40);
         NVGRenderer.a(var48, var51, var43, var43, var43 / 2.0F, 1.5F, -1);
         FontRepository.a("monument").a(var2.getName(), var3, var4 + 12.0F, 9.0F, -5592406);
         float[] var56 = var35.getHsv();
         float var16 = var4 + 20.0F;
         float var18 = 65.0F;
         int var19 = Color.HSBtoRGB(var56[0], 1.0F, 1.0F) | 0xFF000000;
         NVGRenderer.c(var3, var16, var5, var18, 4.0F, var19);
         NVGRenderer.a(var3, var16, var5, var18, 4.0F, -1, 16777215, 0.0F);
         NVGRenderer.a(var3, var16, var5, var18, 4.0F, 0, -16777216, 90.0F);
         float var20 = var3 + var5 * var56[1];
         float var21 = var16 + var18 * (1.0F - var56[2]);
         NVGRenderer.a(var20 - 3.0F, var21 - 3.0F, 6.0F, 6.0F, 3.0F, 1.5F, -1);
         float var23 = var16 + var18 + 6.0F;
         float var25 = 6.0F;
         NVGRenderer.a(var3, var23, var5, var25, var25 / 2.0F);
         float var26 = var56[0];
         float var27 = var3 + var5 * var26;
         float var28 = 10.0F;
         float var29 = var23 + var25 / 2.0F - var28 / 2.0F;
         NVGRenderer.b(var27 - var28 / 2.0F, var29, var28, var28, var28 / 2.0F, 8.0F, -16777216, 0.6F);
         NVGRenderer.c(var27 - var28 / 2.0F, var29, var28, var28, var28 / 2.0F, -1);
         NVGRenderer.c(var27 - var28 / 2.0F + 2.0F, var29 + 2.0F, var28 - 4.0F, var28 - 4.0F, (var28 - 4.0F) / 2.0F, var40);
         if (this.selectedProperty == var2 && GLFW.glfwGetMouseButton(Constants.MINECRAFT.method_22683().method_4490(), 0) == 1) {
            if (this.recoveredField002 != 2 && (this.recoveredField002 != 0 || !((float)var7 >= var23 - 3.0F) || !((float)var7 <= var23 + var25 + 3.0F))) {
               if (this.recoveredField002 == 1 || this.recoveredField002 == 0) {
                  this.recoveredField002 = 1;
                  float var81 = (float)Math.min(1.0, Math.max(0.0, (double)(((float)var6 - var3) / var5)));
                  float var31 = (float)Math.min(1.0, Math.max(0.0, (double)(1.0F - ((float)var7 - var16) / var18)));
                  var35.b(var81);
                  var35.c(var31);
               }
            } else {
               this.recoveredField002 = 2;
               double var30 = (double)Math.min(var5, Math.max(0.0F, (float)var6 - var3));
               float var32 = (float)(var30 / (double)var5);
               var35.setHue(var32);
            }

            var35.updateColorFromHsv();
         } else {
            this.recoveredField002 = 0;
         }

         return var8;
      } else if (var2 instanceof ModeProperty var34) {
         float var39 = var5 / 2.5F;
         if (var39 > 80.0F) {
            var39 = 80.0F;
         }

         if (var39 > 80.0F) {
            var39 = 80.0F;
         }

         if (var39 > 80.0F) {
            var39 = 80.0F;
         }

         if (var39 > 80.0F) {
            var39 = 80.0F;
         }

         float var42 = 14.0F;
         float var47 = var4 + (var8 - var42) / 2.0F;
         NVGRenderer.c(var3 + var5 - var39, var47, var39, var42, 4.0F, -13421756);
         String var50 = var34.getValue().toString();
         float var55 = FontRepository.a("monument").a(var50, 9.0F);
         FontRepository.a("monument").b(var50, var3 + var5 - var39 + (var39 - var55) / 2.0F, var47 + 10.5F, 9.0F, -1);
         return var8;
      } else if (!(var2 instanceof KeybindProperty var9)) {
         return var8;
      } else {
         float var10 = 50.0F;
         float var11 = 14.0F;
         float var12 = var4 + (var8 - var11) / 2.0F;
         NVGRenderer.a(var3 + var5 - var10, var12, var10, var11, 4.0F, 1.0F, ColorUtility.a(-14803416, this.accentColor, 0.5F));
         String var13 = editingKeybindActive && editingKeybind == var2 ? "..." : var9.getDisplayName();
         float var14 = FontRepository.a("monument").a(var13, 9.0F);
         FontRepository.a("monument").b(var13, var3 + var5 - var10 + (var10 - var14) / 2.0F, var12 + 10.5F, 9.0F, -1);
         return var8;
      }
   }

   private float a(Property var1) {
      if (var1 instanceof ColorProperty) {
         return 105.0F;
      } else {
         return !(var1 instanceof NumberProperty) && !(var1 instanceof BoundedNumberProperty) ? 25.0F : 30.0F;
      }
   }

   private float a(Module var1) {
      float var2 = 0.0F;

      for (Property var4 : var1.getProperties()) {
         if (!var4.isVisible()) {
            var2 += this.a(var4);
         }
      }

      return var2;
   }

   private boolean a(double var1, double var3, int var5) {
      if (editingKeybindActive) {
         if (editingKeybind != null) {
            editingKeybind.a(var5);
         }

         editingKeybindActive = false;
         editingKeybind = null;
         return true;
      } else {
         double var6 = this.a(var1);
         double var8 = this.b(var3);
         if (this.editingProfileId != null && var5 == 0) {
            float var60 = (float)var6;
            float var61 = (float)var8;
            float var62 = this.getScaleFactor();
            float var63 = (float)Constants.MINECRAFT.method_22683().method_4489() / var62;
            float var64 = (float)Constants.MINECRAFT.method_22683().method_4506() / var62;
            float var65 = Math.min(680.0F, var63 * 0.9F);
            float var66 = Math.min(460.0F, var64 * 0.9F);
            float var67 = (var63 - var65) / 2.0F;
            float var68 = var67 + var65 * 0.1F + 15.0F;
            float var69 = var65 - var65 * 0.1F - 30.0F;
            float var70 = 85.0F;
            float var72 = (var64 - var66) / 2.0F + 65.0F + 5.0F;
            float var74 = var72 + var70 + 5.0F;
            float var76 = 48.0F;
            float var79 = 6.0F;
            float var81 = var74 - this.profileScroll;
            float var83 = 30.0F;
            float var85 = var68 + 10.0F + var83 + 10.0F;

            for (int var87 = 0; var87 < this.profileEntries.size(); var87++) {
               Map var88 = (Map)this.profileEntries.get(var87);
               if (this.editingProfileId.equals(var88.get("id"))) {
                  float var90 = 170.0F;
                  float var94 = 22.0F;
                  float var98 = var81 + (var76 - var94) / 2.0F;
                  if (HoverUtility.a(var85, var98, var90, var94, (double)var60, (double)var61)) {
                     this.editingProfileName = true;
                     return true;
                  }

                  float var101 = 36.0F;
                  float var104 = 16.0F;
                  float var107 = var85 + var90 + 6.0F;
                  float var110 = var81 + (var76 - var104) / 2.0F;
                  if (HoverUtility.a(var107, var110, var101, var104, (double)var60, (double)var61)) {
                     if (!this.editedProfileName.isEmpty()) {
                        this.a(this.editingProfileId, this.editedProfileName);
                     }

                     return true;
                  }

                  float var112 = var107 + var101 + 4.0F;
                  if (HoverUtility.a(var112, var110, var101, var104, (double)var60, (double)var61)) {
                     this.editingProfileId = null;
                     this.editingProfileName = false;
                     this.editedProfileName = "";
                     return true;
                  }

                  this.editingProfileId = null;
                  this.editingProfileName = false;
                  this.editedProfileName = "";
                  return true;
               }

               var81 += var76 + var79;
            }

            this.editingProfileId = null;
            this.editingProfileName = false;
            this.editedProfileName = "";
            return true;
         } else {
            float var10 = this.getScaleFactor();
            float var11 = (float)Constants.MINECRAFT.method_22683().method_4489() / var10;
            float var12 = (float)Constants.MINECRAFT.method_22683().method_4506() / var10;
            float var13 = Math.min(680.0F, var11 * 0.9F);
            float var14 = Math.min(460.0F, var12 * 0.9F);
            float var15 = (var11 - var13) / 2.0F;
            float var16 = (var12 - var14) / 2.0F + (1.0F - this.openingAnimation.getValue()) * 50.0F;
            float var17 = var13 * 0.1F;
            float var18 = var14 * 0.13F;
            float var19 = 0.0F;
            float var20 = 0.0F;

            for (ModuleCategory var24 : ModuleCategory.values()) {
               if (var24 != ModuleCategory.UPDATES) {
                  if (var24 != ModuleCategory.CLIENT && var24 != ModuleCategory.CONFIGS) {
                     var19++;
                  } else {
                     var20++;
                  }
               }
            }

            float var71 = var16 + 20.0F;
            float var73 = 40.0F;
            float var75 = var16 + var14 - var73 - var20 * var18 - 5.0F;

            for (ModuleCategory var27 : ModuleCategory.values()) {
               if (var27 != ModuleCategory.UPDATES) {
                  float var28 = var27 != ModuleCategory.CLIENT && var27 != ModuleCategory.CONFIGS ? var71 : var75;
                  if (HoverUtility.a(var15, var28, var17, var18, (double)((int)var6), (double)((int)var8)) && var5 == 0) {
                     this.selectedCategory = var27;
                     this.favoritesOnly = false;
                     this.moduleScroll = 0.0F;
                     this.targetModuleScroll = 0.0F;
                     return true;
                  }

                  if (var27 != ModuleCategory.CLIENT && var27 != ModuleCategory.CONFIGS) {
                     var71 += var18;
                  } else {
                     var75 += var18;
                  }
               }
            }

            if (HoverUtility.a(var15, var71, var17, var18, (double)((int)var6), (double)((int)var8)) && var5 == 0) {
               this.favoritesOnly = true;
               this.selectedCategory = null;
               this.moduleScroll = 0.0F;
               this.targetModuleScroll = 0.0F;
               return true;
            } else {
               float var78 = 65.0F;
               float var80 = var15 + var17 + 15.0F;
               float var82 = var16 + var78 + 5.0F;
               float var84 = var13 - var17 - 30.0F;
               float var86 = var14 - var78 - var73 - 10.0F;
               if (HoverUtility.a(var80, var82, var84, var86, (double)((int)var6), (double)((int)var8))) {
                  ArrayList<Module> var29 = new ArrayList();

                  for (Module var31 : Swag.getInstance().getModuleRepository().getModules()) {
                     if (this.favoritesOnly ? var31.isFavorite() : var31.getCategory() == this.selectedCategory) {
                        var29.add(var31);
                     }
                  }

                  var29.sort((var0, var1x) -> {
                     CharSequence var2 = var0.getName();
                     CharSequence var3x = var1x.getName();
                     int var4 = Math.min(var2.length(), var3x.length());

                     for (int var5x = 0; var5x < var4; var5x++) {
                        char var6x = var2.charAt(var5x);
                        char var7 = var3x.charAt(var5x);
                        if (var6x >= 'A' && var6x <= 'Z') {
                           var6x = (char)(var6x + ' ');
                        }

                        if (var7 >= 'A' && var7 <= 'Z') {
                           var7 = (char)(var7 + ' ');
                        }

                        if (var6x != var7) {
                           return var6x - var7;
                        }
                     }

                     return var2.length() - var3x.length();
                  });
                  float var89 = var82 - this.moduleScroll;
                  if (this.selectedCategory == ModuleCategory.CLIENT) {
                     Module var91 = Swag.getInstance().getModuleRepository().a(ClickGUIModule.class);
                     if (var91 != null) {
                        float var32 = 350.0F;
                        float var33 = var80 + (var84 - var32) / 2.0F;

                        for (Property var35 : var91.getProperties()) {
                           if (!var35.isVisible()) {
                              float var36 = this.a(var35);
                              if (HoverUtility.a(var33, var89, var32, var36, (double)((int)var6), (double)((int)var8))) {
                                 if (var35 instanceof BooleanProperty && var5 == 0) {
                                    ((BooleanProperty)var35).a(Boolean.valueOf(!((BooleanProperty)var35).isEnabled()));
                                 } else if ((var35 instanceof NumberProperty || var35 instanceof BoundedNumberProperty) && var5 == 0) {
                                    this.selectedProperty = var35;
                                 } else if (var35 instanceof ColorProperty && var5 == 0) {
                                    this.selectedProperty = var35;
                                 } else if (var35 instanceof ModeProperty && var5 == 0) {
                                    ((ModeProperty)var35).a(true);
                                 } else if (var35 instanceof ModeProperty && var5 == 1) {
                                    ((ModeProperty)var35).a(false);
                                 } else if (var35 instanceof KeybindProperty && var5 == 0) {
                                    editingKeybindActive = true;
                                    editingKeybind = (KeybindProperty)var35;
                                 }

                                 return true;
                              }

                              var89 += var36 + 15.0F;
                           }
                        }
                     }
                  } else if (this.selectedCategory == ModuleCategory.CONFIGS) {
                     float var92 = 85.0F;
                     float var96 = 24.0F;
                     if (HoverUtility.a(var80, var82, var84, var96, (double)((int)var6), (double)((int)var8))) {
                        this.searchFocused = true;
                        return true;
                     }

                     this.searchFocused = false;
                     float var99 = 70.0F;
                     float var102 = 20.0F;
                     float var105 = 8.0F;
                     float var37 = var82 + var96 + 8.0F;
                     float var39 = var80 + var99 + var105;
                     if (var5 == 0) {
                        if (HoverUtility.a(var80, var37, var99, var102, (double)((int)var6), (double)((int)var8))) {
                           this.showComingSoon();
                           return true;
                        }

                        if (HoverUtility.a(var39, var37, var99, var102, (double)((int)var6), (double)((int)var8))) {
                           this.resetScreen();
                           return true;
                        }

                        float var40 = var82 + var92 + 5.0F;
                        float var41 = 48.0F;
                        float var42 = 6.0F;
                        float var43 = var40 - this.profileScroll;
                        float var44 = var84;

                        for (int var45 = 0; var45 < this.profileEntries.size(); var45++) {
                           Map var46 = (Map)this.profileEntries.get(var45);
                           String var47 = var46.get("id") != null ? var46.get("id").toString() : "";
                           String var48 = var46.get("name") != null ? var46.get("name").toString() : "";
                           float var49 = 30.0F;
                           float var50 = var80 + 10.0F + var49 + 10.0F;
                           float var51 = 44.0F;
                           float var52 = 16.0F;
                           float var53 = 4.0F;
                           float var54 = var51 * 3.0F + var53 * 2.0F;
                           float var55 = var80 + var44 - var54 - 10.0F;
                           float var56 = var43 + (var41 - var52) / 2.0F;
                           if (HoverUtility.a(var55, var56, var51, var52, (double)((int)var6), (double)((int)var8))) {
                              this.a(var47);
                              return true;
                           }

                           float var58 = var55 + var51 + var53;
                           if (HoverUtility.a(var58, var56, var51, var52, (double)((int)var6), (double)((int)var8))) {
                              this.editingProfileId = var47;
                              this.recoveredField185 = var48;
                              this.editedProfileName = var48;
                              this.editingProfileName = true;
                              return true;
                           }

                           float var59 = var55 + (var51 + var53) * 2.0F;
                           if (HoverUtility.a(var59, var56, var51, var52, (double)((int)var6), (double)((int)var8))) {
                              this.b(var47);
                              return true;
                           }

                           var43 += var41 + var42;
                        }
                     }
                  } else {
                     for (Module var95 : var29) {
                        float[] var97 = (float[])this.moduleBounds.get(var95);
                        float var100 = var97 != null ? var97[1] : 42.0F;
                        float var103 = var97 != null ? var97[2] : 0.0F;
                        float var106 = var97 != null ? var97[0] : var89;
                        if (HoverUtility.a(var80, var106, var84, var100, (double)((int)var6), (double)((int)var8))) {
                           float var109 = 32.0F;
                           float var111 = 16.0F;
                           float var114 = var80 + var84 - var109 - 10.0F - var111 - 8.0F;
                           float var116 = var106 + (var100 - var111) / 2.0F;
                           if (var5 == 0 && HoverUtility.a(var114, var116, var111, var111, (double)((int)var6), (double)((int)var8))) {
                              var95.b(!var95.isFavorite());
                              if (var95.isFavorite()) {
                                 Constants.MINECRAFT
                                    .method_1483()
                                    .method_4873(class_1109.method_4757((class_3414)class_3417.field_14725.comp_349(), 1.5F, 0.8F));
                              }

                              return true;
                           }

                           if (var5 == 0) {
                              var95.toggle();
                           } else if (var5 == 1) {
                              this.focusedModule = this.focusedModule == var95 ? null : var95;
                           }

                           return true;
                        }

                        if (this.focusedModule == var95 && HoverUtility.a(var80, var106 + var100, var84, var103, (double)((int)var6), (double)((int)var8))) {
                           float var108 = var106 + var100;

                           for (Property var113 : var95.getProperties()) {
                              if (!var113.isVisible()) {
                                 float var115 = this.a(var113);
                                 if (HoverUtility.a(var80 + 20.0F, var108, var84 - 40.0F, var115, (double)((int)var6), (double)((int)var8))) {
                                    if (var113 instanceof BooleanProperty && var5 == 0) {
                                       ((BooleanProperty)var113).a(Boolean.valueOf(!((BooleanProperty)var113).isEnabled()));
                                    } else if ((var113 instanceof NumberProperty || var113 instanceof BoundedNumberProperty) && var5 == 0) {
                                       this.selectedProperty = var113;
                                    } else if (var113 instanceof ColorProperty && var5 == 0) {
                                       this.selectedProperty = var113;
                                    } else if (var113 instanceof ModeProperty && var5 == 0) {
                                       ((ModeProperty)var113).a(true);
                                    } else if (var113 instanceof ModeProperty && var5 == 1) {
                                       ((ModeProperty)var113).a(false);
                                    } else if (var113 instanceof KeybindProperty && var5 == 0) {
                                       editingKeybindActive = true;
                                       editingKeybind = (KeybindProperty)var113;
                                    }

                                    return true;
                                 }

                                 var108 += var115;
                              }
                           }
                        }

                        var89 += var100 + var103 + 15.0F;
                     }
                  }
               }

               return false;
            }
         }
      }
   }

   public boolean method_25402(class_11909 var1, boolean var2) {
      return this.a(var1.comp_4798(), var1.comp_4799(), var1.method_74245());
   }

   public boolean method_25406(class_11909 var1) {
      this.selectedProperty = null;
      return false;
   }

   public boolean method_25401(double var1, double var3, double var5, double var7) {
      var1 = this.a(var1);
      var3 = this.b(var3);
      if (this.selectedCategory == ModuleCategory.CONFIGS) {
         this.targetProfileScroll = (float)((double)this.targetProfileScroll - var7 * 30.0);
         if (this.targetProfileScroll < 0.0F) {
            this.targetProfileScroll = 0.0F;
         }

         float var9 = Math.max(0.0F, (float)this.profileEntries.size() * 54.0F - 300.0F);
         if (this.targetProfileScroll > var9) {
            this.targetProfileScroll = var9;
         }
      } else {
         this.targetModuleScroll = (float)((double)this.targetModuleScroll - var7 * 30.0);
         if (this.targetModuleScroll < 0.0F) {
            this.targetModuleScroll = 0.0F;
         }
      }

      return true;
   }

   public boolean method_25404(class_11908 var1) {
      int var2 = var1.comp_4795();
      int var3 = var1.comp_4797();
      if (editingKeybindActive) {
         if (var2 != 256) {
            if (editingKeybind != null) {
               editingKeybind.a(var2);
            }
         } else if (editingKeybind != null) {
            editingKeybind.a(-1);
         }

         editingKeybindActive = false;
         editingKeybind = null;
         return true;
      } else if (this.editingProfileName) {
         if (var2 == 256) {
            this.editingProfileId = null;
            this.editingProfileName = false;
            return true;
         } else if (var2 == 257) {
            if (!this.editedProfileName.isEmpty() && this.editingProfileId != null) {
               this.a(this.editingProfileId, this.editedProfileName);
            }

            this.editingProfileName = false;
            return true;
         } else if (var2 == 259 && !this.editedProfileName.isEmpty()) {
            this.editedProfileName = this.editedProfileName.substring(0, this.editedProfileName.length() - 1);
            return true;
         } else if (var2 == 86 && (var3 & 2) != 0) {
            String var7 = Constants.MINECRAFT.field_1774.method_1460();
            if (var7 != null) {
               this.editedProfileName = this.editedProfileName + var7.trim();
            }

            return true;
         } else {
            String var6 = a(var2, var3);
            if (var6 != null) {
               this.editedProfileName = this.editedProfileName + var6;
               return true;
            } else {
               return true;
            }
         }
      } else if (this.searchFocused) {
         if (var2 == 256 || var2 == 257) {
            this.searchFocused = false;
            return true;
         } else if (var2 == 259 && !this.searchText.isEmpty()) {
            this.searchText = this.searchText.substring(0, this.searchText.length() - 1);
            return true;
         } else if (var2 == 86 && (var3 & 2) != 0) {
            String var5 = Constants.MINECRAFT.field_1774.method_1460();
            if (var5 != null) {
               this.searchText = this.searchText + var5.trim();
            }

            return true;
         } else {
            String var4 = a(var2, var3);
            if (var4 != null) {
               this.searchText = this.searchText + var4;
               return true;
            } else {
               return true;
            }
         }
      } else if (var2 == 256) {
         this.method_25419();
         return true;
      } else {
         return false;
      }
   }

   private static String a(int var0, int var1) {
      boolean var2 = (var1 & 1) != 0;
      if (var0 >= 65 && var0 <= 90) {
         char var5 = (char)(97 + (var0 - 65));
         return var2 ? String.valueOf(Character.toUpperCase(var5)) : String.valueOf(var5);
      } else if (var0 >= 48 && var0 <= 57) {
         if (var2) {
            String var3 = ")!@#$%^&*(";
            int var4 = var0 - 48;
            return var4 < var3.length() ? String.valueOf(var3.charAt(var4)) : null;
         } else {
            return String.valueOf((char)(48 + (var0 - 48)));
         }
      } else if (var0 == 32) {
         return " ";
      } else if (var0 == 45) {
         return var2 ? "_" : "-";
      } else if (var0 == 61) {
         return var2 ? "+" : "=";
      } else if (var0 == 46) {
         return var2 ? ">" : ".";
      } else if (var0 == 44) {
         return var2 ? "<" : ",";
      } else if (var0 == 47) {
         return var2 ? "?" : "/";
      } else if (var0 == 92) {
         return var2 ? "|" : "\\";
      } else if (var0 == 39) {
         return var2 ? "\"" : "'";
      } else if (var0 == 91) {
         return var2 ? "{" : "[";
      } else if (var0 == 93) {
         return var2 ? "}" : "]";
      } else if (var0 == 59) {
         return var2 ? ":" : ";";
      } else {
         return null;
      }
   }

   public void method_25419() {
      defaultCategory = this.selectedCategory;
      lastModuleScroll = this.moduleScroll;
      lastFavoritesOnly = this.favoritesOnly;
      selectedModule = this.focusedModule;
      super.method_25419();
   }

   public boolean method_25421() {
      return false;
   }

   private void resetScreen() {
      if (!this.profilesLoading) {
         this.profilesLoading = true;
         this.recoveredField025 = null;
         Constants.MINECRAFT.method_40000(() -> {
            this.profileEntries = new ArrayList();
            this.profilesLoading = false;
            this.profileScroll = 0.0F;
            this.targetProfileScroll = 0.0F;
         });
      }
   }

   private void showComingSoon() {
      this.toastMessage = "Coming Soon";
      this.toastTimeMillis = System.currentTimeMillis();
   }

   private void a(String var1) {
   }

   private void b(String var1) {
   }

   private void a(String var1, String var2) {
      Constants.MINECRAFT.method_40000(() -> {
         this.editingProfileId = null;
         this.editedProfileName = "";
      });
   }

}
