package com.google.common.jimfs.recovered;

import com.google.common.jimfs.client.Constants;
import com.google.common.jimfs.client.feature.module.Module;
import com.google.common.jimfs.client.feature.module.ModuleCategory;
import com.google.common.jimfs.client.feature.module.property.Property;
import com.google.common.jimfs.client.feature.module.property.impl.bool.BooleanProperty;
import com.google.common.jimfs.client.feature.module.property.impl.number.NumberProperty;
import com.google.common.jimfs.event.impl.game.PreGameTickEvent;
import com.google.common.jimfs.event.impl.game.player.interaction.HnWqPm;
import com.google.common.jimfs.event.subscriber.Subscribe;
import com.google.common.jimfs.mixin.eQyS;
import com.google.common.jimfs.utility.misc.StringObfuscation;
import j2cc.Nativeify;
import java.util.Arrays;
import java.util.Base64;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2868;
import net.minecraft.class_3489;

@Nativeify
public final class AutoTotemHitModule extends Module {
   private final BooleanProperty m = new BooleanProperty(StringObfuscation.a("Require Sword"), true);
   private final BooleanProperty o = new BooleanProperty(StringObfuscation.a("Switch Back"), true);
   private final NumberProperty p = new NumberProperty(StringObfuscation.a("Switch Delay"), 0.0, 0.0, 5.0, 1.0);
   private boolean q;
   private int r = -1;
   private int s;
   
   

   

   public AutoTotemHitModule() {
      super(
         StringObfuscation.a("Auto Totem Hit"),
         StringObfuscation.a("Automatically switches to sword on hit"),
         ModuleCategory.COMBAT
      );
      this.b(new Property[]{this.m, this.o, this.p});
   }

   @Override
   protected void g() {
      super.g();
      this.n();
   }

   @Override
   protected void h() {
      boolean var1 = true;
      if (this.q && this.r != -1 && Constants.MINECRAFT.field_1724 != null) {
         this.b(this.r);
      }

      this.n();
      super.h();
   }

   @Subscribe
   public void b(HnWqPm var1) {
      boolean var2 = true;
      if (this.isEnabled() && Constants.MINECRAFT.field_1724 != null) {
         class_1297 var3 = var1.getEntity();
         if (var3 != null) {
            class_1799 var4 = Constants.MINECRAFT.field_1724.method_6047();
            if (!var4.method_31574(class_1802.field_8301)) {
               if (var3.method_5864() != class_1299.field_6110) {
                  if (!this.b(var4)) {
                     if (this.q) {
                        this.s = 0;
                     } else if (this.m.isEnabled()) {
                        int var5 = this.o();
                        if (var5 == -1) {
                           return;
                        }

                        if (this.o.isEnabled() && this.r == -1) {
                           this.r = ((eQyS)Constants.MINECRAFT.field_1724.method_31548()).N();
                        }

                        this.b(var5);
                        if (this.o.isEnabled()) {
                           this.q = true;
                           this.s = 0;
                        }
                     }
                  }
               }
            }
         }
      }
   }

   @Subscribe
   public void b(PreGameTickEvent var1) {
      boolean var2 = false;
      if (this.isEnabled() && Constants.MINECRAFT.field_1724 != null) {
         if (this.q && this.r != -1) {
            if (this.s < ((Double)this.p.getValue()).intValue()) {
               this.s++;
            } else {
               this.b(this.r);
               this.n();
            }
         }
      }
   }

   private void n() {
      this.q = false;
      this.r = -1;
      this.s = 0;
   }

   private boolean b(class_1799 var1) {
      class_1792 var3 = var1.method_7909();
      boolean var2 = true;
      return var1.method_31573(class_3489.field_42611)
         || var1.method_31573(class_3489.field_42612)
         || var3 == class_1802.field_8547
         || var3 == class_1802.field_49814;
   }

   private int o() {
      int var2 = 0;

      for (boolean var1 = true; var2 < 9; var2++) {
         class_1799 var3 = Constants.MINECRAFT.field_1724.method_31548().method_5438(var2);
         if (var3.method_31573(class_3489.field_42611)) {
            return var2;
         }
      }

      return -1;
   }

   private void b(int var1) {
      eQyS var3 = (eQyS)Constants.MINECRAFT.field_1724.method_31548();
      boolean var2 = true;
      if (var3.N() != var1) {
         var3.O(var1);
         if (Constants.MINECRAFT.method_1562() != null) {
            Constants.MINECRAFT.method_1562().method_52787(new class_2868(var1));
         }
      }
   }

}
