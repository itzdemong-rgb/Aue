package com.google.common.jimfs.client.feature.module.property.impl.number;

import com.google.common.jimfs.client.feature.module.property.Property;
import com.google.common.jimfs.recovered.RandomInterpolation;
import com.google.common.jimfs.utility.misc.math.MathUtility;
import com.ibm.icu.impl.Pair;

public final class BoundedNumberProperty extends Property {
   private final double minimum;
   private final double maximum;
   private final double j;
   private String k;

   public BoundedNumberProperty(CharSequence var1, double var2, double var4, double var6, double var8, double var10) {
      super(var1);
      this.minimum = var6;
      this.maximum = var8;
      this.j = var10;
      this.a(Pair.of(var2, var4));
   }

   public BoundedNumberProperty(CharSequence var1, String var2, double var3, double var5, double var7, double var9, double var11) {
      this(var1, var3, var5, var7, var9, var11);
      this.k = var2;
   }

   public double getMaximum() {
      return this.maximum;
   }

   public double getMinimum() {
      return this.minimum;
   }

   public Double getRandomValue() {
      return RandomInterpolation.b((Double)((Pair)this.getValue()).first, (Double)((Pair)this.getValue()).second);
   }

   public void a(Pair var1) {
      super.a(
         Pair.of(
            MathUtility.b((Number)var1.first, this.minimum, this.maximum, this.j).doubleValue(),
            MathUtility.b((Number)var1.second, this.minimum, this.maximum, this.j).doubleValue()
         )
      );
   }

   @Override
   public void a(Object var1) {
      this.a((Pair)var1);
   }
}
