package com.google.common.jimfs.client.feature.helper.impl;

import java.util.HashSet;
import java.util.Set;

public class ClientSyncHelper {
   private static final ClientSyncHelper INSTANCE = new ClientSyncHelper();
   private final Set localNames = new HashSet();

   public static ClientSyncHelper getInstance() {
      return INSTANCE;
   }

   public boolean a(String var1) {
      return this.localNames.contains(var1);
   }

}
