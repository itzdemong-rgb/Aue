package com.google.common.jimfs.mixin.block;

import com.google.common.jimfs.event.EventDispatcher;
import com.google.common.jimfs.event.impl.game.player.interaction.block.BlockBreakCanHarvestEvent;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2680;
import net.minecraft.class_4970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Environment(EnvType.CLIENT)
@Mixin({class_4970.class})
public final class qFmT {
   private qFmT() {
   }

   @ModifyExpressionValue(
      method = {"calcBlockBreakingDelta"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/entity/player/PlayerEntity;canHarvest(Lnet/minecraft/block/BlockState;)Z"
      )}
   )
   private boolean aBx(boolean var1, @Local(argsOnly = true) class_2680 var2) {
      BlockBreakCanHarvestEvent var3 = new BlockBreakCanHarvestEvent(var2, var1);
      EventDispatcher.b(var3);
      return var3.canHarvest();
   }
}
