package com.google.common.jimfs.client.feature.helper.impl.render;

import com.google.common.jimfs.utility.misc.StringObfuscation;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class ScaleProperty {
   private static final ScaleProperty.ScaleMode[] scaleModes;

   static String a(String var0, int var1) {
      char[] var2 = var0.toCharArray();

      for (int var3 = 0; var3 < var2.length; var3++) {
         var2[var3] ^= (char)var1;
      }

      return new String(var2);
   }

   static {
      ScaleMode[] var10000 = new ScaleMode[5];
      Object[] var10001 = new Object[]{ScaleProperty.ScaleMode.AUTO, null, null, null, null};
      var10000[1] = ScaleProperty.ScaleMode.SMALL;
      var10000[2] = ScaleProperty.ScaleMode.NORMAL;
      var10000[3] = null;
      var10000[4] = ScaleProperty.ScaleMode.LARGE;
      scaleModes = var10000;
   }

   @Environment(EnvType.CLIENT)
   public static enum ScaleMode {
   AUTO("Auto"),
   SMALL("Small (1x)"),
   NORMAL("Normal (2x)"),
   MEDIUM("Medium (2.67x)"),
   LARGE("Large (3x)");
      private final StringObfuscation.E encodedName;

      private ScaleMode(String var3) {
         this.encodedName = StringObfuscation.a(var3);
      }

      @Override
      public String toString() {
         return this.encodedName.get();
      }
   }
}
