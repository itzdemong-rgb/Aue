package com.google.common.jimfs.recovered;

import java.util.ArrayList;
import java.util.List;

public final class ClientState {
   private final List recoveredField092 = new ArrayList();
}
