package com.google.common.jimfs.mixin.screen;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;

@Environment(EnvType.CLIENT)
@Mixin({class_437.class})
public final class ScreenAccessor {
   private ScreenAccessor() {
   }
}
