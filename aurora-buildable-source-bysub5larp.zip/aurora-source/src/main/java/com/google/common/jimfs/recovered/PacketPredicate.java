package com.google.common.jimfs.recovered;

import net.minecraft.class_2596;

public interface PacketPredicate {
   boolean a(class_2596 var1);
}
