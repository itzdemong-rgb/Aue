package com.google.common.jimfs.event.impl.game.input;

public final class SlotChangeEvent {
   private int slotIndex;

   public SlotChangeEvent(int var1) {
      this.slotIndex = var1;
   }
}
