package com.google.common.jimfs.event.impl.game.player.interaction.block;

import net.minecraft.class_2680;

public final class BlockBreakHardnessEvent {
   private final class_2680 blockState;
   private float hardness;

   public BlockBreakHardnessEvent(class_2680 var1, float var2) {
      this.blockState = var1;
      this.hardness = var2;
   }

   public float getHardness() {
      return this.hardness;
   }
}
