package com.google.common.jimfs.mixin.input;

import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_304;
import net.minecraft.class_3675.class_306;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Environment(EnvType.CLIENT)
@Mixin({class_304.class})
public interface KeyBindingAccessor {
   @Accessor("timesPressed")
   int kW();

   @Accessor("timesPressed")
   void kW(int var1);

   @Accessor("boundKey")
   class_306 xR();

   @Accessor("boundKey")
   void xR(class_306 var1);

   @Accessor("KEYS_BY_ID")
   static Map fT() {
      throw new AssertionError();
   }

   @Invoker("reset")
   void bN();
}
