package com.google.common.jimfs.event.impl.game.player.interaction;

import com.google.common.jimfs.recovered.CancellableEvent;

public final class ItemUseEvent extends CancellableEvent {
   private static String recoveredField025 = "zWNBbb";

   public static void b(String var0) {
      recoveredField025 = var0;
   }

   public static String recoveredMethod107() {
      return recoveredField025;
   }
}
