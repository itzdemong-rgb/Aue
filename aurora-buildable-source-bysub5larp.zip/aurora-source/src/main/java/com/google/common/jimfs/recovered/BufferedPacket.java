package com.google.common.jimfs.recovered;

import net.minecraft.class_2596;

public final class BufferedPacket {
   private final class_2596 packet;
   private final long timestamp;

   public BufferedPacket(class_2596 var1, long var2) {
      this.packet = var1;
      this.timestamp = var2;
   }

   public class_2596 getPacket() {
      return this.packet;
   }

   public long getTimestamp() {
      return this.timestamp;
   }
}
