package com.google.common.jimfs.mixin.input;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_11910;
import net.minecraft.class_312;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Environment(EnvType.CLIENT)
@Mixin({class_312.class})
public interface MouseAccessor {
   @Invoker("onMouseButton")
   void hT(long var1, class_11910 var3, int var4);

   @Accessor("x")
   double kW();

   @Accessor("x")
   void kW(double var1);

   @Accessor("y")
   double xR();

   @Accessor("y")
   void xR(double var1);
}
