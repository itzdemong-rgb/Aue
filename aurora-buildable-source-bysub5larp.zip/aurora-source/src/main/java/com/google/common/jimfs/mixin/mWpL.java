package com.google.common.jimfs.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_636;
import net.minecraft.class_638;
import net.minecraft.class_7204;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Environment(EnvType.CLIENT)
@Mixin({class_636.class})
public interface mWpL {
   @Invoker("sendSequencedPacket")
   void i(class_638 var1, class_7204 var2);

   @Invoker("syncSelectedSlot")
   void j();

   @Accessor("blockBreakingCooldown")
   void k(int var1);

   @Accessor("lastSelectedSlot")
   int l();

   @Accessor("lastSelectedSlot")
   void m(int var1);
}
