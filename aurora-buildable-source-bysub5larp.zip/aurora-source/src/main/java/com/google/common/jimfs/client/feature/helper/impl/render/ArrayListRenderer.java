package com.google.common.jimfs.client.feature.helper.impl.render;

import com.google.common.jimfs.client.Swag;
import com.google.common.jimfs.client.feature.module.Module;
import com.google.common.jimfs.client.renderer.NVGRenderer;
import com.google.common.jimfs.client.renderer.repository.FontRepository;
import com.google.common.jimfs.client.renderer.text.NVGTextRenderer;
import com.google.common.jimfs.m.ArrayListModule;
import com.google.common.jimfs.m.AutoHitCrystalModule;
import com.google.common.jimfs.m.AutoCrystalModule;
import com.google.common.jimfs.utility.render.ColorUtility;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;

@Environment(EnvType.CLIENT)
public class ArrayListRenderer {
   private static final float[] moduleSlideProgress = new float[]{
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F
   };
   private static final ArrayListRenderer.ModuleComparator MODULE_COMPARATOR = new ArrayListRenderer.ModuleComparator();

   static int a(CharSequence var0, CharSequence var1) {
      int var2 = Math.min(var0.length(), var1.length());

      for (int var3 = 0; var3 < var2; var3++) {
         char var4 = var0.charAt(var3);
         char var5 = var1.charAt(var3);
         if (var4 >= 'A' && var4 <= 'Z') {
            var4 = (char)(var4 + ' ');
         }

         if (var5 >= 'A' && var5 <= 'Z') {
            var5 = (char)(var5 + ' ');
         }

         if (var4 != var5) {
            return var4 - var5;
         }
      }

      return var0.length() - var1.length();
   }

   public static void render() {
      class_310 var0 = class_310.method_1551();
      if (var0.field_1687 != null && var0.field_1724 != null) {
         Module var1 = Swag.getInstance().getModuleRepository().a(ArrayListModule.class);
         if (var1 != null && var1.isEnabled()) {
            ArrayListModule var2 = (ArrayListModule)var1;
            boolean var3 = NVGRenderer.beginWindowFrame();
            if (!var3) {
               NVGRenderer.endFrame();
               var3 = NVGRenderer.beginWindowFrame();
            }

            if (var3) {
               int var4 = var0.method_22683().method_4486();
               NVGTextRenderer var5 = FontRepository.a("inter-semibold");
               float var6 = 9.0F * ((Double)var2.textScale.getValue()).floatValue();
               float var7 = 4.0F;
               float var8 = 1.5F;
               float var9 = var6 + var8 * 2.0F;
               float var10 = ((Double)var2.cornerRadius.getValue()).floatValue();
               float var11 = ((Double)var2.gap.getValue()).floatValue();
               int var12 = (Integer)var2.accentColor.getValue() | 0xFF000000;
               boolean var13 = var2.shadowEnabled.isEnabled();
               boolean var14 = var2.backgroundEnabled.isEnabled();
               boolean var15 = var2.watermarkEnabled.isEnabled();
               boolean var16 = var2.outlineEnabled.isEnabled();
               boolean var17 = var2.slideIn.isEnabled();
               float var18 = ((Double)var2.rainbowSpeed.getValue()).floatValue();
               float var19 = ((Double)var2.rainbowWidth.getValue()).floatValue();
               float var20 = ((Double)var2.animationSpeed.getValue()).floatValue() / 10.0F;
               boolean var21 = false;
               AutoHitCrystalModule var22 = (AutoHitCrystalModule)Swag.getInstance().getModuleRepository().a(AutoHitCrystalModule.class);
               if (var22 != null && var22.isEnabled() && var22.restoreAutoCrystal) {
                  var21 = true;
               }

               boolean var23 = var21;
               ArrayListModule.b var24 = (ArrayListModule.b)var2.sortMode.getValue();
               MODULE_COMPARATOR.a(var24, var5, var6);
               List<Module> var25 = Swag.getInstance()
                  .getModuleRepository()
                  .getModules()
                  .stream()
                  .filter(var1x -> var1x.isEnabled() || var1x instanceof AutoCrystalModule && var23)
                  .sorted(MODULE_COMPARATOR)
                  .collect(Collectors.toList());
               if (var15) {
                  String var26 = "Aurora v1.2";
                  float var27 = 10.0F;
                  float var28 = var5.a((CharSequence)var26, var27);
                  float var29 = (float)var4 - var28 - 6.0F;
                  var5.a(var26, var29, 6.0F + var27, var27, var12, true, 0);
               }

               float var43 = var15 ? 24.0F : 4.0F;
               int var44 = 0;

               for (Module var47 : var25) {
                  if (!(var47 instanceof ArrayListModule)) {
                     var44++;
                  }
               }

               int var46 = 0;

               for (int var48 = 0; var48 < var25.size(); var48++) {
                  Module var30 = (Module)var25.get(var48);
                  if (!(var30 instanceof ArrayListModule)) {
                     CharSequence var31 = var30.getName();
                     float var32 = var5.a(var31, var6);
                     float var33 = var32 + var7 * 2.0F;
                     float var34 = (float)var4 - var33;
                     if (var17) {
                        if (var46 < moduleSlideProgress.length) {
                           float var35 = 1.0F;
                           moduleSlideProgress[var46] = moduleSlideProgress[var46] + (var35 - moduleSlideProgress[var46]) * var20;
                        }

                        float var49 = var46 < moduleSlideProgress.length ? moduleSlideProgress[var46] : 1.0F;
                        var34 = (float)var4 + (var33 + 10.0F) * (1.0F - var49);
                     }

                     float var50 = -1.0F;

                     for (int var36 = var48 + 1; var36 < var25.size(); var36++) {
                        Module var37 = (Module)var25.get(var36);
                        if (!(var37 instanceof ArrayListModule)) {
                           var50 = var5.a(var37.getName(), var6) + var7 * 2.0F;
                           break;
                        }
                     }

                     float var51 = 0.0F;
                     if (var50 < 0.0F) {
                        var51 = var10;
                     } else {
                        float var52 = var33 - var50;
                        if (var52 > 0.0F) {
                           var51 = Math.min(var10, var52);
                        }
                     }

                     if (var14) {
                        NVGRenderer.a(var34, var43, var33, var9, var10, var10, var10, var51, -937813478);
                     }

                     if (var16) {
                        int var53 = (Integer)var2.outlineColor.getValue() | 0xFF000000;
                        NVGRenderer.a(var34, var43, var33, var9, var10, 1.0F, var53);
                     }

                     ArrayListModule.a var38 = (ArrayListModule.a)var2.colorMode.getValue();

                     int var54 = switch (var38) {
                        case SOLID -> var12;
                        case RAINBOW -> {
                           float var55 = ((float)(System.currentTimeMillis() % (long)(10000.0F / var18)) / (10000.0F / var18) + (float)var46 * var19 * 0.05F)
                              % 1.0F;
                           yield a(var55, 0.8F, 1.0F);
                        }
                        default -> {
                           float var39 = var44 > 1 ? (float)var46 / (float)(var44 - 1) : 0.0F;
                           float var40 = (float)(System.currentTimeMillis() % 3000L) / 3000.0F;
                           float var41 = (var39 * 0.5F - var40) * (float) Math.PI * 2.0F;
                           float var42 = (float)Math.sin((double)var41) * 0.5F + 0.5F;
                           yield ColorUtility.a(var12, (Integer)ColorUtility.getThemeColors().second, var42);
                        }
                     };
                     float var56 = var34 + var7;
                     float var57 = var43 + var8 + var6 - 1.0F;
                     int var58 = 1073741824;
                     var5.a(var31, var56 + 0.75F, var57 + 0.75F, var6, var58, false, 0);
                     var5.a(var31, var56, var57, var6, var54, false, 0);
                     var43 += var9 + var11;
                     var46++;
                  }
               }

               if (var3) {
                  NVGRenderer.b(true);
               }
            }
         }
      }
   }

   private static int a(float var0, float var1, float var2) {
      int var6 = (int)(var0 * 6.0F);
      float var7 = var0 * 6.0F - (float)var6;
      float var8 = var2 * (1.0F - var1);
      float var9 = var2 * (1.0F - var7 * var1);
      float var10 = var2 * (1.0F - (1.0F - var7) * var1);
      int var3;
      int var4;
      int var5;
      switch (var6 % 6) {
         case 0:
            var3 = (int)(var2 * 255.0F);
            var4 = (int)(var10 * 255.0F);
            var5 = (int)(var8 * 255.0F);
            break;
         case 1:
            var3 = (int)(var9 * 255.0F);
            var4 = (int)(var2 * 255.0F);
            var5 = (int)(var8 * 255.0F);
            break;
         case 2:
            var3 = (int)(var8 * 255.0F);
            var4 = (int)(var2 * 255.0F);
            var5 = (int)(var10 * 255.0F);
            break;
         case 3:
            var3 = (int)(var8 * 255.0F);
            var4 = (int)(var9 * 255.0F);
            var5 = (int)(var2 * 255.0F);
            break;
         case 4:
            var3 = (int)(var10 * 255.0F);
            var4 = (int)(var8 * 255.0F);
            var5 = (int)(var2 * 255.0F);
            break;
         default:
            var3 = (int)(var2 * 255.0F);
            var4 = (int)(var8 * 255.0F);
            var5 = (int)(var9 * 255.0F);
      }

      return 0xFF000000 | var3 << 16 | var4 << 8 | var5;
   }

   @Environment(EnvType.CLIENT)
   static class ModuleComparator implements Comparator<Module> {
      private ArrayListModule.b sortMode;
      private NVGTextRenderer textRenderer;
      private float recoveredField001;

      void a(ArrayListModule.b var1, NVGTextRenderer var2, float var3) {
         this.sortMode = var1;
         this.textRenderer = var2;
         this.recoveredField001 = var3;
      }

      public int compare(Module var1, Module var2) {
         CharSequence var3 = var1.getName();
         CharSequence var4 = var2.getName();
         switch (this.sortMode) {
            case ALPHABETICAL:
               return ArrayListRenderer.a(var3, var4);
            case LENGTH:
               return Integer.compare(var4.length(), var3.length());
            case WIDTH:
            default:
               float var5 = this.textRenderer.a(var3, this.recoveredField001);
               float var6 = this.textRenderer.a(var4, this.recoveredField001);
               return Float.compare(var6, var5);
         }
      }
   }
}
