package com.google.common.jimfs.recovered;

import com.google.common.jimfs.event.subscriber.IEventSubscriber;

public interface ClientEventSubscriber extends IEventSubscriber {
}
