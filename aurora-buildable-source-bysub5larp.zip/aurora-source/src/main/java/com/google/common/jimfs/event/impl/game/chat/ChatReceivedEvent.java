package com.google.common.jimfs.event.impl.game.chat;

import com.google.common.jimfs.recovered.CancellableEvent;
import net.minecraft.class_2561;

public final class ChatReceivedEvent extends CancellableEvent {
   private final class_2561 message;
   private boolean recoveredField190;

   public ChatReceivedEvent(class_2561 var1, boolean var2) {
      this.message = var1;
      this.recoveredField190 = var2;
   }
}
