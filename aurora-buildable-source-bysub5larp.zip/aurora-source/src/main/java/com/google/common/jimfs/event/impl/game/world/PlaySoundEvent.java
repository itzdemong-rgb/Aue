package com.google.common.jimfs.event.impl.game.world;

import com.google.common.jimfs.recovered.CancellableEvent;
import net.minecraft.class_3414;

public final class PlaySoundEvent extends CancellableEvent {
   private final class_3414 sound;
   private final double x;
   private final double y;
   private final double z;

   public PlaySoundEvent(class_3414 var1, double var2, double var4, double var6) {
      this.sound = var1;
      this.x = var2;
      this.y = var4;
      this.z = var6;
   }
}
