package com.google.common.jimfs.utility.render;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.lwjgl.opengl.GL;
import org.lwjgl.opengl.GL30;
import org.lwjgl.opengl.GL33;

@Environment(EnvType.CLIENT)
public final class GLUtility {
   private static final int[] savedActiveTexture = new int[]{0};
   private static final int[] savedShaderProgram = new int[]{0};
   private static final int[] savedTextureBinding = new int[]{0};
   private static final int[] savedSamplerBinding = new int[]{0};
   private static final int[] savedArrayBufferBinding = new int[]{0};
   private static final int[] savedElementArrayBufferBinding = new int[]{0};
   private static final int[] savedVertexArrayBinding = new int[]{0};
   private static final int[] savedPolygonMode = new int[]{0, 0};
   private static final int[] savedViewport = new int[]{0, 0, 0, 0};
   private static final int[] savedScissorBox = new int[]{0, 0, 0, 0};
   private static final int[] savedBlendSourceRgb = new int[]{0};
   private static final int[] savedBlendDestinationRgb = new int[]{0};
   private static final int[] savedBlendSourceAlpha = new int[]{0};
   private static final int[] savedBlendDestinationAlpha = new int[]{0};
   private static final int[] savedBlendEquationRgb = new int[]{0};
   private static final int[] savedBlendEquationAlpha = new int[]{0};
   private static final int[] savedStencilFunction = new int[]{0};
   private static final int[] savedStencilReference = new int[]{0};
   private static final int[] savedStencilValueMask = new int[]{0};
   private static final int[] savedStencilWriteMask = new int[]{0};
   private static final int[] savedStencilFailOperation = new int[]{0};
   private static final int[] savedStencilDepthFailOperation = new int[]{0};
   private static final int[] savedStencilDepthPassOperation = new int[]{0};
   private static final int[] savedFrontFace = new int[]{0};
   private static boolean savedBlendEnabled;
   private static boolean savedCullFaceEnabled;
   private static boolean savedDepthTestEnabled;
   private static boolean savedStencilTestEnabled;
   private static boolean savedScissorTestEnabled;
   private static boolean savedPrimitiveRestartEnabled;
   private static boolean savedDepthWriteEnabled;
   private static int glVersion = -1;

   private GLUtility() {
   }

   public static void detectGlVersion() {
      int[] var0 = new int[1];
      int[] var1 = new int[1];
      GL30.glGetIntegerv(33307, var0);
      GL30.glGetIntegerv(33308, var1);
      glVersion = var0[0] * 100 + var1[0] * 10;
   }

   public static void pushState() {
      if (glVersion == -1) {
         throw new IllegalStateException("GlStateUtility.setup(glVersion) must be called before push/pop!");
      } else {
         GL30.glGetIntegerv(34016, savedActiveTexture);
         GL30.glActiveTexture(33984);
         GL30.glGetIntegerv(35725, savedShaderProgram);
         GL30.glGetIntegerv(32873, savedTextureBinding);
         if (glVersion >= 330 || GL.getCapabilities().GL_ARB_sampler_objects) {
            GL30.glGetIntegerv(35097, savedSamplerBinding);
            GL33.glBindSampler(0, 0);
         }

         GL30.glGetIntegerv(34964, savedArrayBufferBinding);
         GL30.glGetIntegerv(34965, savedElementArrayBufferBinding);
         GL30.glGetIntegerv(34229, savedVertexArrayBinding);
         if (glVersion >= 200) {
            GL30.glGetIntegerv(2880, savedPolygonMode);
         }

         GL30.glGetIntegerv(2978, savedViewport);
         GL30.glGetIntegerv(3088, savedScissorBox);
         GL30.glGetIntegerv(32969, savedBlendSourceRgb);
         GL30.glGetIntegerv(32968, savedBlendDestinationRgb);
         GL30.glGetIntegerv(32971, savedBlendSourceAlpha);
         GL30.glGetIntegerv(32970, savedBlendDestinationAlpha);
         GL30.glGetIntegerv(32777, savedBlendEquationRgb);
         GL30.glGetIntegerv(34877, savedBlendEquationAlpha);
         GL30.glGetIntegerv(2962, savedStencilFunction);
         GL30.glGetIntegerv(2967, savedStencilReference);
         GL30.glGetIntegerv(2963, savedStencilValueMask);
         GL30.glGetIntegerv(2968, savedStencilWriteMask);
         GL30.glGetIntegerv(2964, savedStencilFailOperation);
         GL30.glGetIntegerv(2965, savedStencilDepthFailOperation);
         GL30.glGetIntegerv(2966, savedStencilDepthPassOperation);
         GL30.glGetIntegerv(2886, savedFrontFace);
         savedBlendEnabled = GL30.glIsEnabled(3042);
         savedCullFaceEnabled = GL30.glIsEnabled(2884);
         savedDepthTestEnabled = GL30.glIsEnabled(2929);
         savedStencilTestEnabled = GL30.glIsEnabled(2960);
         savedScissorTestEnabled = GL30.glIsEnabled(3089);
         if (glVersion >= 310) {
            savedPrimitiveRestartEnabled = GL30.glIsEnabled(36765);
         }

         savedDepthWriteEnabled = GL30.glGetBoolean(2930);
      }
   }

   public static void popState() {
      if (glVersion == -1) {
         throw new IllegalStateException("GlStateUtility.setup(glVersion) must be called before push/pop!");
      } else {
         GL30.glUseProgram(savedShaderProgram[0]);
         GL30.glActiveTexture(33984);
         GL30.glBindTexture(3553, savedTextureBinding[0]);
         if (glVersion >= 330 || GL.getCapabilities().GL_ARB_sampler_objects) {
            GL33.glBindSampler(0, savedSamplerBinding[0]);
         }

         GL30.glActiveTexture(savedActiveTexture[0]);
         GL30.glBindVertexArray(savedVertexArrayBinding[0]);
         GL30.glBindBuffer(34962, savedArrayBufferBinding[0]);
         GL30.glBindBuffer(34963, savedElementArrayBufferBinding[0]);
         GL30.glBlendEquationSeparate(savedBlendEquationRgb[0], savedBlendEquationAlpha[0]);
         GL30.glBlendFuncSeparate(savedBlendSourceRgb[0], savedBlendDestinationRgb[0], savedBlendSourceAlpha[0], savedBlendDestinationAlpha[0]);
         GL30.glStencilFunc(savedStencilFunction[0], savedStencilReference[0], savedStencilValueMask[0]);
         GL30.glStencilMask(savedStencilWriteMask[0]);
         GL30.glStencilOp(savedStencilFailOperation[0], savedStencilDepthFailOperation[0], savedStencilDepthPassOperation[0]);
         GL30.glFrontFace(savedFrontFace[0]);
         a(3042, savedBlendEnabled);
         a(2884, savedCullFaceEnabled);
         a(2929, savedDepthTestEnabled);
         a(2960, savedStencilTestEnabled);
         a(3089, savedScissorTestEnabled);
         if (glVersion >= 310) {
            a(36765, savedPrimitiveRestartEnabled);
         }

         if (glVersion >= 200) {
            GL30.glPolygonMode(1032, savedPolygonMode[0]);
         }

         GL30.glViewport(savedViewport[0], savedViewport[1], savedViewport[2], savedViewport[3]);
         GL30.glScissor(savedScissorBox[0], savedScissorBox[1], savedScissorBox[2], savedScissorBox[3]);
         GL30.glDepthMask(savedDepthWriteEnabled);
      }
   }

   private static void a(int var0, boolean var1) {
      if (var1) {
         GL30.glEnable(var0);
      } else {
         GL30.glDisable(var0);
      }
   }
}
