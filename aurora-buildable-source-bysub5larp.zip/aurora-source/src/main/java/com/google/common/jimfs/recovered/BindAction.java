package com.google.common.jimfs.recovered;

public interface BindAction {
   void f();
}
