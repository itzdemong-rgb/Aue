package com.google.common.jimfs.utility.render;

import com.google.common.jimfs.utility.misc.StringObfuscation;
import com.ibm.icu.impl.Pair;
import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public enum ClientTheme {
   OPAL(StringObfuscation.a("Opal"), new Color(45, 191, 254), new Color(36, 153, 203)),
   SPEARMINT(StringObfuscation.a("Spearmint"), new Color(97, 194, 162), new Color(65, 130, 108)),
   JADE_GREEN(StringObfuscation.a("Jade Green"), new Color(0, 168, 107), new Color(0, 105, 66)),
   GREEN_SPIRIT(StringObfuscation.a("Green Spirit"), new Color(159, 226, 191), new Color(0, 135, 62)),
   ROSY_PINK(StringObfuscation.a("Rosy Pink"), new Color(255, 102, 204), new Color(191, 77, 153)),
   MAGENTA(StringObfuscation.a("Magenta"), new Color(213, 63, 119), new Color(157, 68, 110)),
   HOT_PINK(StringObfuscation.a("Hot Pink"), new Color(231, 84, 128), new Color(172, 79, 198)),
   LAVENDER(StringObfuscation.a("Lavender"), new Color(219, 166, 247), new Color(152, 115, 172)),
   AMETHYST(StringObfuscation.a("Amethyst"), new Color(144, 99, 205), new Color(98, 67, 140)),
   PURPLE_FIRE(StringObfuscation.a("Purple Fire"), new Color(177, 162, 202), new Color(104, 71, 141)),
   SUNSET_PINK(StringObfuscation.a("Sunset Pink"), new Color(255, 145, 20), new Color(245, 105, 231)),
   BLAZE_ORANGE(StringObfuscation.a("Blaze Orange"), new Color(255, 169, 77), new Color(255, 130, 0)),
   PINK_BLOOD(StringObfuscation.a("Pink Blood"), new Color(255, 166, 201), new Color(228, 0, 70)),
   PASTEL(StringObfuscation.a("Pastel"), new Color(255, 109, 106), new Color(191, 82, 80)),
   NEON_RED(StringObfuscation.a("Neon Red"), new Color(210, 39, 48), new Color(184, 25, 42)),
   RED_COFFEE(StringObfuscation.a("Red Coffee"), new Color(225, 34, 59), new Color(75, 19, 19)),
   DEEP_OCEAN(StringObfuscation.a("Deep Ocean"), new Color(60, 82, 145), new Color(0, 20, 64)),
   CHAMBRAY_BLUE(StringObfuscation.a("Chambray Blue"), new Color(60, 82, 145), new Color(33, 46, 182)),
   MINT_BLUE(StringObfuscation.a("Mint Blue"), new Color(66, 158, 157), new Color(40, 94, 93)),
   PACIFIC_BLUE(StringObfuscation.a("Pacific Blue"), new Color(5, 169, 199), new Color(4, 115, 135)),
   TROPICAL_ICE(StringObfuscation.a("Tropical Ice"), new Color(102, 255, 209), new Color(6, 149, 255)),
   BLUE_PURPLE(StringObfuscation.a("Blue Purple"), new Color(104, 77, 178), new Color(4, 60, 174)),
   RAINBOW(StringObfuscation.a("Rainbow"), Color.BLACK, Color.BLACK),
   CUSTOM(StringObfuscation.a("Custom"), Color.BLACK, Color.BLACK);
   private final StringObfuscation.E name;
   private final Pair colors;

   private ClientTheme(StringObfuscation.E var3, Color var4, Color var5) {
      this.name = var3;
      this.colors = Pair.of(var4.getRGB(), var5.getRGB());
   }

   @Override
   public String toString() {
      return this.name.get();
   }
}
