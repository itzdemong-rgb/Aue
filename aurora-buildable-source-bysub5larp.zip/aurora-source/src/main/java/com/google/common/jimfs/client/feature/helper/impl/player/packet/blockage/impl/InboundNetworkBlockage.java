package com.google.common.jimfs.client.feature.helper.impl.player.packet.blockage.impl;

import com.google.common.jimfs.duck.ClientConnectionAccess;
import com.google.common.jimfs.recovered.PacketPredicate;
import com.google.common.jimfs.recovered.PacketDelayQueue;
import net.minecraft.class_2535;
import net.minecraft.class_2596;
import net.minecraft.class_2616;
import net.minecraft.class_2663;
import net.minecraft.class_2739;
import net.minecraft.class_2744;
import net.minecraft.class_2767;
import net.minecraft.class_2770;
import net.minecraft.class_310;
import net.minecraft.class_5888;
import net.minecraft.class_5903;
import net.minecraft.class_5904;
import net.minecraft.class_5905;
import net.minecraft.class_7438;
import net.minecraft.class_746;
import net.minecraft.class_7597;

public final class InboundNetworkBlockage extends PacketDelayQueue {
   private static final InboundNetworkBlockage INSTANCE = new InboundNetworkBlockage();
   public static final PacketPredicate PACKET_PREDICATE = var0 -> {
      boolean var1 = false;
      if (var0 instanceof class_2663 var2) {
         return var2.method_11470() != 2 && var2.method_11470() != 3;
      } else if (var0 instanceof class_2739 var3) {
         class_746 var4 = class_310.method_1551().field_1724;
         return var4 == null || var3.comp_1127() == var4.method_5628();
      } else {
         return !(var0 instanceof class_2616)
            && !(var0 instanceof class_5904)
            && !(var0 instanceof class_5905)
            && !(var0 instanceof class_5888)
            && !(var0 instanceof class_2767)
            && !(var0 instanceof class_2770)
            && !(var0 instanceof class_7438)
            && !(var0 instanceof class_7597)
            && !(var0 instanceof class_2744)
            && !(var0 instanceof class_5903);
      }
   };

   public static InboundNetworkBlockage getInstance() {
      return INSTANCE;
   }

   @Override
   protected void b(class_2535 var1, class_2596 var2) {
      ClientConnectionAccess var3 = (ClientConnectionAccess)var1;
      class_310.method_1551().method_63588(() -> var3.jimfs$channelReadSilent(var2));
   }

}
