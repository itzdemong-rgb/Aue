package com.google.common.jimfs.recovered;

import com.google.common.jimfs.client.Constants;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_2199;
import net.minecraft.class_2238;
import net.minecraft.class_2244;
import net.minecraft.class_2260;
import net.minecraft.class_2269;
import net.minecraft.class_2272;
import net.minecraft.class_2281;
import net.minecraft.class_2286;
import net.minecraft.class_2288;
import net.minecraft.class_2304;
import net.minecraft.class_2309;
import net.minecraft.class_2315;
import net.minecraft.class_2323;
import net.minecraft.class_2328;
import net.minecraft.class_2331;
import net.minecraft.class_2336;
import net.minecraft.class_2349;
import net.minecraft.class_2354;
import net.minecraft.class_2356;
import net.minecraft.class_2362;
import net.minecraft.class_2363;
import net.minecraft.class_2377;
import net.minecraft.class_2378;
import net.minecraft.class_2387;
import net.minecraft.class_2401;
import net.minecraft.class_2406;
import net.minecraft.class_2428;
import net.minecraft.class_2457;
import net.minecraft.class_2462;
import net.minecraft.class_2478;
import net.minecraft.class_2480;
import net.minecraft.class_2490;
import net.minecraft.class_2515;
import net.minecraft.class_2533;
import net.minecraft.class_2560;
import net.minecraft.class_2667;
import net.minecraft.class_3708;
import net.minecraft.class_3709;
import net.minecraft.class_3711;
import net.minecraft.class_3713;
import net.minecraft.class_3715;
import net.minecraft.class_3717;
import net.minecraft.class_3718;
import net.minecraft.class_3748;
import net.minecraft.class_3830;
import net.minecraft.class_3962;
import net.minecraft.class_4969;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_5545;
import net.minecraft.class_5804;
import net.minecraft.class_5805;
import net.minecraft.class_6089;
import net.minecraft.class_7714;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_8168;

public final class EnchantmentLevelHelper {
   private static final List recoveredField092 = class_7923.field_41175
      .method_10220()
      .filter(
         var0 -> {
            boolean var1 = true;
            return var0 instanceof class_2533
               || var0 instanceof class_3830
               || var0 instanceof class_2363
               || var0 instanceof class_2478
               || var0 instanceof class_2199
               || var0 instanceof class_3708
               || var0 instanceof class_2238
               || var0 instanceof class_2244
               || var0 instanceof class_3709
               || var0 instanceof class_2260
               || var0 instanceof class_2269
               || var0 instanceof class_2272
               || var0 instanceof class_5545
               || var0 instanceof class_3711
               || var0 instanceof class_5804
               || var0 instanceof class_5805
               || var0 instanceof class_2281
               || var0 instanceof class_7714
               || var0 instanceof class_2288
               || var0 instanceof class_2286
               || var0 instanceof class_3962
               || var0 instanceof class_2304
               || var0 instanceof class_2309
               || var0 instanceof class_8168
               || var0 instanceof class_2315
               || var0 instanceof class_2323
               || var0 instanceof class_2328
               || var0 instanceof class_2331
               || var0 instanceof class_2336
               || var0 instanceof class_2354
               || var0 instanceof class_2349
               || var0 instanceof class_2362
               || var0 instanceof class_3713
               || var0 instanceof class_2377
               || var0 instanceof class_3748
               || var0 instanceof class_2387
               || var0 instanceof class_3715
               || var0 instanceof class_2401
               || var0 instanceof class_6089
               || var0 instanceof class_2406
               || var0 instanceof class_2428
               || var0 instanceof class_2667
               || var0 instanceof class_2457
               || var0 instanceof class_2462
               || var0 instanceof class_4969
               || var0 instanceof class_2480
               || var0 instanceof class_3717
               || var0 instanceof class_3718
               || var0 instanceof class_2356
               || var0 instanceof class_2515
               || var0 instanceof class_2490
               || var0 instanceof class_2560;
         }
      )
      .toList();

   public static int b(class_1799 var0, class_5321 var1) {
      class_5455 var2 = Constants.MINECRAFT.field_1687.method_30349();
      class_2378 var3 = var2.method_30530(class_7924.field_41265);
      return class_1890.method_8225(var3.method_46747(var1), var0);
   }

}
