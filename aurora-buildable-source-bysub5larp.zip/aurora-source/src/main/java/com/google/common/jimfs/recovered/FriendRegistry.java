package com.google.common.jimfs.recovered;

import java.util.HashSet;
import java.util.Set;

public class FriendRegistry {
   private static final FriendRegistry instance = new FriendRegistry();
   private final Set friendNames = new HashSet();

   public static FriendRegistry getInstance() {
      return instance;
   }

   public boolean b(String var1) {
      return this.friendNames.contains(var1.toLowerCase());
   }
}
