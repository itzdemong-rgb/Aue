package com.google.common.jimfs.client.feature.helper.impl.render;

import com.google.common.jimfs.client.Constants;
import com.google.common.jimfs.client.feature.module.Module;
import com.google.common.jimfs.client.feature.module.property.impl.ScreenPositionProperty;
import com.google.common.jimfs.client.renderer.NVGRenderer;
import com.google.common.jimfs.client.screen.settings.SettingsScreen;
import com.google.common.jimfs.event.EventDispatcher;
import com.google.common.jimfs.event.impl.render.RenderScreenEvent;
import com.google.common.jimfs.event.subscriber.Subscribe;
import com.google.common.jimfs.recovered.ClientEventSubscriber;
import com.google.common.jimfs.utility.misc.HoverUtility;
import com.google.common.jimfs.utility.player.PlayerUtility;
import com.google.common.jimfs.utility.render.ColorUtility;
import java.util.HashMap;
import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1041;
import net.minecraft.class_408;

@Environment(EnvType.CLIENT)
public final class ScreenPositionManager implements ClientEventSubscriber {
   private final Map<ScreenPositionProperty, Module> positionedModules = new HashMap();
   private boolean dragging;
   private static ScreenPositionManager instance;

   private ScreenPositionManager() {
   }

   public void a(Module var1, ScreenPositionProperty var2) {
      this.positionedModules.put(var2, var1);
   }

   @Subscribe(
      a = -50
   )
   public void a(RenderScreenEvent var1) {
      if (!(Constants.MINECRAFT.field_1755 instanceof class_408) && !(Constants.MINECRAFT.field_1755 instanceof SettingsScreen)) {
         if (this.dragging) {
            this.reset();
         }
      } else {
         double var2 = var1.getMouseX();
         double var4 = var1.getMouseY();
         this.positionedModules.forEach((var5, var6x) -> {
            if (this.a(var6x)) {
               if (var5.isDragging()) {
                  var5.c((float)(var2 - (double)var5.g()));
                  var5.d((float)(var4 - (double)var5.h()));
                  if (!PlayerUtility.isMouseButtonPressed(340)) {
                     var5.snapToEdges();
                  }
               }

               float var7x = var5.getPixelX();
               float var8x = var5.d();
               float var9x = var5.e();
               float var10 = var5.f();
               if (HoverUtility.a(var7x, var8x, var9x, var10, var2, var4)) {
                  NVGRenderer.c(var7x - 2.0F, var8x - 2.0F, var9x + 4.0F, var10 + 4.0F, 6.0F, ColorUtility.a(-16777216, 0.2F));
               }
            }
         });
         class_1041 var6 = Constants.MINECRAFT.method_22683();
         int var7 = var6.method_4486();
         int var8 = var6.method_4502();
         if (this.dragging) {
            int var9 = ColorUtility.a(-1, 0.5F);
            NVGRenderer.a(0.0F, 0.0F, (float)var7, (float)var8, 1.0F, var9);
            NVGRenderer.a(0.0F, (float)var8 / 2.0F - 0.5F, (float)var7, 1.0F, var9);
            NVGRenderer.a((float)var7 / 2.0F - 1.0F, 0.0F, 1.0F, (float)var8, var9);
         }
      }
   }

   public void a(double var1, double var3, int var5) {
      if (var5 == 0) {
         this.positionedModules.forEach((var5x, var6) -> {
            if (this.a(var6)) {
               float var7 = var5x.getPixelX();
               float var8 = var5x.d();
               if (HoverUtility.a(var7, var8, var5x.e(), var5x.f(), var1, var3)) {
                  var5x.e((float)(var1 - (double)var7));
                  var5x.f((float)(var3 - (double)var8));
                  var5x.a(true);
                  this.dragging = true;
               }
            }
         });
      }
   }

   private boolean a(Module var1) {
      boolean var2 = Constants.MINECRAFT.field_1755 instanceof class_408 || Constants.MINECRAFT.field_1755 instanceof SettingsScreen;
      boolean var10000;
      if (!var1.isEnabled()) {
         if (var2) {
         }

         var10000 = false;
      } else {
         var10000 = true;
      }

      return var10000;
   }

   public void reset() {
      this.positionedModules.forEach((var0, var1) -> var0.a(false));
      this.dragging = false;
   }

   public static ScreenPositionManager getInstance() {
      return instance;
   }

   public static void initialize() {
      instance = new ScreenPositionManager();
      EventDispatcher.a(instance);
   }
}
