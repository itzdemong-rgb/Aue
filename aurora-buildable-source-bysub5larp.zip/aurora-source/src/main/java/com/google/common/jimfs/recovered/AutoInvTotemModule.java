package com.google.common.jimfs.recovered;

import com.google.common.jimfs.client.Constants;
import com.google.common.jimfs.client.feature.module.Module;
import com.google.common.jimfs.client.feature.module.ModuleCategory;
import com.google.common.jimfs.client.feature.module.property.Property;
import com.google.common.jimfs.client.feature.module.property.impl.bool.BooleanProperty;
import com.google.common.jimfs.client.feature.module.property.impl.number.NumberProperty;
import com.google.common.jimfs.event.impl.game.PreGameTickEvent;
import com.google.common.jimfs.event.subscriber.Subscribe;
import com.google.common.jimfs.mixin.jRtF;
import com.google.common.jimfs.utility.misc.StringObfuscation;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1713;
import net.minecraft.class_1802;
import net.minecraft.class_2848;
import net.minecraft.class_490;
import net.minecraft.class_2848.class_2849;

public class AutoInvTotemModule extends Module {
   private final BooleanProperty m = new BooleanProperty(StringObfuscation.a("Refill Offhand"), true);
   private final BooleanProperty o = new BooleanProperty(StringObfuscation.a("Refill Hotbar"), false);
   private final NumberProperty p = new NumberProperty(StringObfuscation.a("Hotbar Slot"), 9.0, 1.0, 9.0, 1.0);
   private final NumberProperty q = new NumberProperty(StringObfuscation.a("Delay (Ticks)"), 2.0, 0.0, 20.0, 1.0);
   private boolean r = false;
   private int s = 0;
   private int t = -1;
   private int u = -1;
   
   

   public AutoInvTotemModule() {
      super(StringObfuscation.a("Auto Inv Totem"), StringObfuscation.a("Automatically equips totems when inventory opened"), ModuleCategory.COMBAT);
      this.b(new Property[]{this.m, this.o, this.p, this.q});
   }

   @Override
   protected void g() {
      super.g();
      this.n();
   }

   @Override
   protected void h() {
      this.n();
      super.h();
   }

   private void n() {
      this.r = false;
      this.s = 0;
      this.t = -1;
      this.u = -1;
   }

   @Subscribe
   public void b(PreGameTickEvent var1) {
      boolean var2 = false;
      if (Constants.MINECRAFT.field_1724 != null && Constants.MINECRAFT.field_1687 != null) {
         boolean var3 = Constants.MINECRAFT.field_1755 instanceof class_490;
         if (!var3) {
            this.t = -1;
            this.u = -1;
            this.s = 0;
            this.r = false;
         } else {
            int var4 = Constants.MINECRAFT.field_1724.field_7512.field_7763;
            boolean var5 = this.m.isEnabled() && !Constants.MINECRAFT.field_1724.method_6079().method_31574(class_1802.field_8288);
            int var6 = ((Double)this.p.getValue()).intValue() - 1;
            boolean var7 = this.o.isEnabled()
               && !Constants.MINECRAFT.field_1724.method_31548().method_5438(var6).method_31574(class_1802.field_8288);
            List<Integer> var8 = this.o();
            if ((var5 && this.t == -1 || var7 && this.u == -1) && !var8.isEmpty()) {
               if (var5 && this.t == -1) {
                  this.t = (Integer)var8.get(Constants.MINECRAFT.field_1687.field_9229.method_43048(var8.size()));
                  if (this.s == 0) {
                     this.s = ((Double)this.q.getValue()).intValue();
                  }
               }

               if (var7 && this.u == -1) {
                  int var9 = Constants.MINECRAFT.field_1687.field_9229.method_43048(var8.size());
                  this.u = var8.size() > 1 && this.t != -1 && var8.get(var9) == this.t ? (Integer)var8.get((var9 + 1) % var8.size()) : (Integer)var8.get(var9);
                  if (this.s == 0) {
                     this.s = ((Double)this.q.getValue()).intValue();
                  }
               }
            }

            if (this.t != -1 || this.u != -1) {
               if (this.t != -1 && !Constants.MINECRAFT.field_1724.field_7512.method_7611(this.t).method_7677().method_31574(class_1802.field_8288)) {
                  this.t = -1;
               }

               if (this.u != -1 && !Constants.MINECRAFT.field_1724.field_7512.method_7611(this.u).method_7677().method_31574(class_1802.field_8288)) {
                  this.u = -1;
               }

               if (this.s > 0) {
                  this.s--;
               } else {
                  if (Constants.MINECRAFT.field_1724.method_5624()) {
                     Constants.MINECRAFT.field_1724.method_5728(false);
                     Constants.MINECRAFT
                        .field_1724
                        .field_3944
                        .method_52787(new class_2848(Constants.MINECRAFT.field_1724, class_2849.field_12985));
                     ((jRtF)Constants.MINECRAFT.field_1724).I(false);
                  }

                  if (this.t != -1) {
                     Constants.MINECRAFT.field_1761.method_2906(var4, this.t, 40, class_1713.field_7791, Constants.MINECRAFT.field_1724);
                     this.t = -1;
                     this.s = ((Double)this.q.getValue()).intValue();
                  } else if (this.u != -1) {
                     Constants.MINECRAFT.field_1761.method_2906(var4, this.u, var6, class_1713.field_7791, Constants.MINECRAFT.field_1724);
                     this.u = -1;
                     this.s = ((Double)this.q.getValue()).intValue();
                  }
               }
            }

            this.r = true;
         }
      }
   }

   private List<Integer> o() {
      ArrayList var2 = new ArrayList();
      int var3 = 9;

      for (boolean var1 = false; var3 < 45; var3++) {
         if (Constants.MINECRAFT.field_1724.field_7498.method_7611(var3).method_7677().method_31574(class_1802.field_8288)) {
            var2.add(var3);
         }
      }

      return var2;
   }

   @Override
   public boolean e() {
      return this.isEnabled();
   }

}
