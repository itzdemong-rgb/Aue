package com.google.common.jimfs.event.impl.game.player.movement;

import com.google.common.jimfs.recovered.CancellableEvent;

public final class PushOutOfBlocksEvent extends CancellableEvent {
}
