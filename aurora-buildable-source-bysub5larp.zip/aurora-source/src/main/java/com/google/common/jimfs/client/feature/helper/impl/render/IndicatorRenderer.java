package com.google.common.jimfs.client.feature.helper.impl.render;

import com.google.common.jimfs.client.Swag;
import com.google.common.jimfs.client.feature.helper.impl.ClientSyncHelper;
import com.google.common.jimfs.client.feature.module.Module;
import com.google.common.jimfs.client.renderer.NVGRenderer;
import com.google.common.jimfs.client.renderer.repository.FontRepository;
import com.google.common.jimfs.client.renderer.text.NVGTextRenderer;
import com.google.common.jimfs.m.NameTagsModule;
import com.google.common.jimfs.m.ClickGUIModule;
import com.google.common.jimfs.utility.misc.math.MathUtility;
import com.google.common.jimfs.utility.render.ColorUtility;
import com.google.common.jimfs.utility.render.ESPUtility;
import com.mojang.blaze3d.opengl.GlStateManager;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;

@Environment(EnvType.CLIENT)
public class IndicatorRenderer {
   public static final List<class_1297> trackedEntities = new CopyOnWriteArrayList();
   public static float recoveredField001 = 1.0F;

   public static void trackEntity(class_1297 var0) {
      if (!trackedEntities.contains(var0)) {
         trackedEntities.add(var0);
      }
   }

   public static void render(float var0) {
      class_310 var1 = class_310.method_1551();
      if (var1.field_1687 != null && var1.field_1724 != null) {
         Module var2 = Swag.getInstance().getModuleRepository().a(ClickGUIModule.class);
         if (var2 != null && ((ClickGUIModule)var2).clientIndicator.isEnabled()) {
            if (((NameTagsModule)Swag.getInstance().getModuleRepository().a(NameTagsModule.class)).isEnabled()) {
               for (class_1297 var4 : var1.field_1687.method_18112()) {
                  if (var4 instanceof class_1309) {
                     class_1309 var5 = (class_1309)var4;
                     if (var4 != var1.field_1724 && ClientSyncHelper.getInstance().a(var5.method_5477().getString())) {
                        trackEntity(var4);
                     }
                  }
               }
            }

            if (!trackedEntities.isEmpty()) {
               if (NVGRenderer.beginWindowFrame()) {
                  GlStateManager._disableDepthTest();
                  long var33 = System.currentTimeMillis();
                  float var34 = 1.0F;
                  int var6 = ColorUtility.a((Integer)ColorUtility.getThemeColors().first, var34);
                  NameTagsModule var7 = (NameTagsModule)Swag.getInstance().getModuleRepository().a(NameTagsModule.class);
                  boolean var8 = var7 != null && var7.isEnabled();
                  NVGTextRenderer var9 = FontRepository.a("monument");

                  for (class_1297 var11 : trackedEntities) {
                     class_243 var12 = MathUtility.a(var11, var0);
                     class_243 var13 = var12.method_1031(0.0, (double)var11.method_17682() + 0.5, 0.0);
                     class_243 var14 = ESPUtility.a(var13);
                     if (var14 != null) {
                        float var15 = 1.0F;
                        if (var8) {
                           float var16 = var11.method_5739(var1.field_1724);
                           float var17 = ((Double)var7.scale.getValue()).floatValue();
                           float var18 = class_3532.method_15363(1.0F - var16 / 30.0F, 0.5F, 1.0F);
                           var15 = var17 * var18;
                        } else {
                           class_243 var35 = var13.method_1031(0.0, 1.0, 0.0);
                           class_243 var37 = ESPUtility.a(var35);
                           if (var37 != null) {
                              float var39 = (float)(var14.field_1351 - var37.field_1351);
                              var15 = var39 * 0.025F;
                           }
                        }

                        String var36 = "A";
                        float var38 = 12.0F * var15;
                        byte var40 = 9;
                        float var19 = var9.a(var36, var38);
                        int var20 = var1.field_1772.method_27525(var11.method_5477());
                        if (var8 && var11 instanceof class_1657 var21) {
                           var20 = var1.field_1772.method_27525(var7.a(var21));
                        }

                        byte var41 = 14;
                        int var22 = var20 + var41;
                        float var23 = (float)(-var22) / 2.0F + (float)var41;
                        float var24 = (float)var14.field_1352 + var23 * var15;
                        float var25 = var24 - var19 - 4.5F * var15;
                        float var26 = 9.0F;
                        float var27 = (float)var14.field_1351 + (-var26 - 3.0F) * var15;
                        if (!var8) {
                           var27 -= 10.0F * var15;
                        }

                        float var29 = var27;
                        var9.a(var36, var25, var29, var38, var6, true, var40);
                        float var30 = (float)(var33 % 1500L) / 1500.0F;
                        float var31 = 5.0F * var15;
                        float var32 = var25 - var31 + (var19 + var31 * 2.0F) * var30;
                        NVGRenderer.a(
                           var32,
                           var29 - 1.0F * var15,
                           var31,
                           var38 + 2.0F * var15,
                           () -> var9.a(var36, var25, var29, var38, ColorUtility.a(-1, var34), false, var40)
                        );
                     }
                  }

                  NVGRenderer.b(true);
                  GlStateManager._enableDepthTest();
                  trackedEntities.clear();
               }
            }
         } else {
            trackedEntities.clear();
         }
      }
   }
}
